// Unit test cho HwtBuilder (tạo file HWT mới).
// Giá trị kỳ vọng của bố cục lấy từ watchface.bin thật (Light_Speed.hwt); mã hoá ảnh đã được đối chiếu từng byte
// với các file HWT thật bằng bản tham chiếu Python (ảnh → bin cho ra đúng file gốc).
import XCTest
@testable import WristMirror

final class HwtBuilderTests: XCTestCase {
    /// Bố cục protobuf (316 byte) đọc từ watchface.bin của Light_Speed.hwt.
    static let lightSpeedLayoutHex = "0a3608001000180022002a1508001001220f0a03303032120408001000280030002a1508011001220f0a03303033120408001000280130000af10108011000180022002a270800100542210a03303034120a0873107318ec0120ec011a04080d1076200028e80230960148002a280801100542220a03303035120a0837103718e40220e4021a05080b10b201200028e80230990148002a280802100542220a03303036120a081f101f1894032094031a05080810ca01200028e802309a0148002a170803100122110a03303037120608de0110de01280030002a270804100542210a03303038120a0873107318ec0120ec011a04080a1076200028e80230960148012a280805100542220a03303039120a0837103718e40220e4021a05080910b201200028e8023099014801120644656e656d651a06e58589e9809f"

    private func hex(_ b: [UInt8]) -> String { b.map { String(format: "%02x", $0) }.joined() }

    private func lightSpeedSpec() -> HwtFaceSpec {
        let r1 = HwtRect(x: 115, y: 115, w: 236, h: 236)
        let r2 = HwtRect(x: 55, y: 55, w: 356, h: 356)
        let r3 = HwtRect(x: 31, y: 31, w: 404, h: 404)
        let bg: [HwtLayer] = [.single(resource: 2, x: 0, y: 0, ambient: false),
                              .single(resource: 3, x: 0, y: 0, ambient: true)]
        let time: [HwtLayer] = [
            .hand(resource: 4, rect: r1, pivotX: 13, pivotY: 118, valueType: 150, ambient: false),
            .hand(resource: 5, rect: r2, pivotX: 11, pivotY: 178, valueType: 153, ambient: false),
            .hand(resource: 6, rect: r3, pivotX: 8, pivotY: 202, valueType: 154, ambient: false),
            .single(resource: 7, x: 222, y: 222, ambient: false),
            .hand(resource: 8, rect: r1, pivotX: 10, pivotY: 118, valueType: 150, ambient: true),
            .hand(resource: 9, rect: r2, pivotX: 9, pivotY: 178, valueType: 153, ambient: true)
        ]
        return HwtFaceSpec(title: "Deneme", titleCN: "光速", author: "Burak", elements: [bg, time], images: [])
    }

    func testLayoutMatchesRealFile() {
        XCTAssertEqual(hex(HwtBuilder.layoutBytes(lightSpeedSpec())), HwtBuilderTests.lightSpeedLayoutHex)
    }

    /// Lớp số (loại 3) phải trùng từng byte với lớp nhịp tim của Kozmik Kule (HWT thật): ảnh 161...170, dấu trừ 171, đơn vị 172.
    func testNumberLayerMatchesRealFile() {
        let spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [[
            .number(digits: Array(161...170), minus: 171, suffix: 172, x: 73, y: 140, align: 0,
                    dataType: HwtDataType.heartRate, ambient: false)
        ]], images: [])
        let real = "08001003324e0a033136310a033136320a033136330a033136340a033136350a033136360a033136370a033136380a033136390a03313730120331373112033137311a050849108c012000280232033137326800"
        XCTAssertTrue(hex(HwtBuilder.layoutBytes(spec)).contains(real))
    }

    func testNumberLayerWithoutSuffixHasEmptyField() {
        let spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [[
            .number(digits: Array(1...10), minus: 11, suffix: 0, x: 5, y: 6, align: 0,
                    dataType: HwtDataType.steps, ambient: false)
        ]], images: [])
        // ... trường 4 (căn lề), 5 (loại số liệu), 6 rỗng, 13 = 0
        XCTAssertTrue(hex(HwtBuilder.layoutBytes(spec)).contains("2000280032006800"))
    }

    func testConfigXmlHasOneLayerPerLayout() {
        let xml = HwtBuilder.configXML(lightSpeedSpec())
        XCTAssertEqual(xml.components(separatedBy: "<layer ").count - 1, 8)
        XCTAssertTrue(xml.contains("res_left=\"A100_004.png\""))
        XCTAssertTrue(xml.contains("rotate_rect=\"115,115,236,236\""))
        XCTAssertTrue(xml.contains("res_name=\"A100_003.png\" res_position=\"0,0\""))
    }

    func testRLEKnownBytes() {
        let img = HwtRaster(width: 4, height: 4, fill: 0)
        XCTAssertEqual(hex(HwtRLE.encode(img)), "4523888804000400" + "89674523" + "00000000" + "10000000")
    }

    func testRLERoundTrip() throws {
        var px = [UInt32](repeating: 0, count: 8 * 8)
        for i in 20..<40 { px[i] = 0xFF11_2233 }
        px[3] = 0x80FF_0000
        px[5] = 0x40FF_0000
        px[63] = 0xFFAA_BBCC
        let img = HwtRaster(width: 8, height: 8, argb: px)
        XCTAssertEqual(try HwtRLE.decode(HwtRLE.encode(img)), img)
    }

    func testRLELeadingLiteralHasNoMarker() throws {
        // Điểm ảnh đầu không thuộc đoạn lặp: luồng bắt đầu bằng điểm ảnh rời, không có dấu hiệu.
        var px = [UInt32](repeating: 0xFF00_00FF, count: 4 * 4)
        px[0] = 0xFF12_3456
        let img = HwtRaster(width: 4, height: 4, argb: px)
        let enc = HwtRLE.encode(img)
        XCTAssertEqual(Array(enc[8..<12]), [0x56, 0x34, 0x12, 0xFF])
        XCTAssertEqual(try HwtRLE.decode(enc), img)
    }

    func testMarkerCollisionIsSanitized() throws {
        var px = [UInt32](repeating: 0xFF00_0000, count: 3 * 3)
        px[4] = HwtRLE.marker
        let img = HwtRaster(width: 3, height: 3, argb: px)
        let back = try HwtRLE.decode(HwtRLE.encode(img))
        XCTAssertEqual(back.argb[4], HwtRLE.marker ^ 1)
        XCTAssertEqual(back, HwtRLE.sanitize(img))
    }

    func testBinHeaderAndTable() {
        let a = HwtRaster(width: 2, height: 2, fill: 0)
        let b = HwtRaster(width: 3, height: 1, argb: [0xFF000001, 0xFF000002, 0xFF000003])
        var spec = lightSpeedSpec()
        spec.images = [a, b]
        let bin = HwtBuilder.binData(spec)
        let layoutLen = HwtBuilder.layoutBytes(spec).count
        XCTAssertEqual(Array(bin[0..<2]), [2, 0])
        XCTAssertEqual(Int(bin[2]) | Int(bin[3]) << 8, layoutLen)
        XCTAssertEqual(Int(bin[4]), 16) // 2 ảnh × 8 byte bảng
        let recA = HwtRLE.encode(a).count, recB = HwtRLE.encode(b).count
        XCTAssertEqual(Int(bin[8]) | Int(bin[9]) << 8 | Int(bin[10]) << 16, 8 + recA + recB)
        XCTAssertEqual(bin.count, 16 + layoutLen + 16 + 8 + recA + recB)
    }

    func testZipWriterReadableByZipArchive() throws {
        var w = HwtZipWriter()
        w.addDirectory("dir/")
        w.add(name: "dir/a.txt", data: Array("xin chào".utf8))
        w.add(name: "b.bin", data: [UInt8](0..<200))
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("zipw-\(UUID().uuidString).zip")
        defer { try? FileManager.default.removeItem(at: url) }
        try Data(w.finish()).write(to: url)
        let z = try ZipArchive(url: url)
        XCTAssertEqual(z.entries.count, 3)
        XCTAssertEqual(try z.read(XCTUnwrap(z.entries["dir/a.txt"]), max: 1000), Array("xin chào".utf8))
        XCTAssertEqual(try z.read(XCTUnwrap(z.entries["b.bin"]), max: 1000), [UInt8](0..<200))
        XCTAssertTrue(try XCTUnwrap(z.entries["dir/"]).isDirectory)
    }

    func testPackageIsInspectableAndBinSurvives() throws {
        // Mặt đồng hồ nhỏ nhất hợp lệ: 1 nền, 1 kim.
        let bg = HwtRaster(width: 4, height: 4, fill: 0xFF10_2030)
        let hand = HwtRaster(width: 2, height: 6, fill: 0xFFFF_FFFF)
        let thumb = HwtRaster(width: 2, height: 2, fill: 0)
        let spec = HwtFaceSpec(title: "Thu nghiem", titleCN: "Thu", author: "Toi", elements: [
            [.single(resource: 2, x: 0, y: 0, ambient: false)],
            [.hand(resource: 3, rect: HwtRect(x: 1, y: 1, w: 4, h: 4), pivotX: 1, pivotY: 2, valueType: 150, ambient: false)]
        ], images: [thumb, bg, hand])
        var pngs = [[UInt8]]()
        for img in spec.images { pngs.append(try XCTUnwrap(FaceRenderer.pngData(img))) }
        let jpeg: [UInt8] = [0xFF, 0xD8, 0xFF, 0xD9]
        let bytes = try HwtBuilder.build(spec: spec, pngs: pngs,
                                         previews: .init(cover: jpeg, aod: jpeg, icon: jpeg))
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("pkg-\(UUID().uuidString).hwt")
        defer { try? FileManager.default.removeItem(at: url) }
        try Data(bytes).write(to: url)

        let report = try HwtInspector.inspect(url: url)
        XCTAssertTrue(report.hasBin)
        XCTAssertTrue(report.hasConfig)
        XCTAssertEqual(report.images.count, 3)
        XCTAssertEqual(report.info["title"], "Thu nghiem")
        XCTAssertEqual(report.layerCount, 2)

        // hashCode: 3 giá trị SHA-256 tính từ chính file + hằng số thứ 4
        let outer = try ZipArchive(url: url)
        let hashText = String(decoding: try outer.read(XCTUnwrap(outer.entries["hashCode"]), max: 4096), as: UTF8.self)
        let parts = hashText.split(separator: ",").map(String.init)
        XCTAssertEqual(parts.count, 4)
        XCTAssertEqual(parts[3], HwtBuilder.constantHash)
        let desc = try outer.read(XCTUnwrap(outer.entries["description.xml"]), max: 65536)
        XCTAssertEqual(parts[0], WMCore.hex(WMCore.digest(desc)).uppercased())
        let ability = try outer.read(XCTUnwrap(outer.entries["ability.xml"]), max: 65536)
        XCTAssertEqual(parts[2], WMCore.hex(WMCore.digest(ability)).uppercased())
    }

    func testRejectsBadInput() {
        var spec = lightSpeedSpec()
        spec.images = [HwtRaster(width: 2, height: 2, fill: 0)]
        XCTAssertThrowsError(try HwtBuilder.build(spec: spec, pngs: [[1]], previews: .init(cover: [], aod: [], icon: []))) // tham chiếu ảnh vượt số ảnh
        var empty = lightSpeedSpec()
        empty.title = ""
        empty.images = [HwtRaster(width: 2, height: 2, fill: 0)]
        XCTAssertThrowsError(try HwtBuilder.validate(empty, pngs: [[1]]))
    }

    func testXmlEscapingInDescription() {
        let spec = HwtFaceSpec(title: "A & B <c>", titleCN: "x", author: "\"q\"", elements: [], images: [])
        let xml = HwtBuilder.descriptionXML(spec)
        XCTAssertTrue(xml.contains("<title>A &amp; B &lt;c&gt;</title>"))
        XCTAssertTrue(xml.contains("<author>&quot;q&quot;</author>"))
    }

    func testFileNameIsSafe() {
        XCTAssertEqual(FaceBuilder.fileName("Face #1"), "Face_1.hwt")
        XCTAssertEqual(FaceBuilder.fileName("Mặt đồng hồ của tôi"), "Mat_dong_ho_cua_toi.hwt")
        XCTAssertEqual(FaceBuilder.fileName("Quốc Đại"), "Quoc_Dai.hwt")
        XCTAssertTrue(FaceBuilder.fileName("../../etc").hasSuffix(".hwt"))
        XCTAssertFalse(FaceBuilder.fileName("../../etc").contains("/"))
        XCTAssertFalse(FaceBuilder.fileName("../../etc").contains(".."))
        XCTAssertTrue(FaceBuilder.fileName("   ").hasSuffix(".hwt"))
    }
}

// MARK: - Thêm âm lịch vào HWT có sẵn

final class LunarPatchTests: XCTestCase {
    private func sampleHwt() throws -> URL {
        let bg = HwtRaster(width: 4, height: 4, fill: 0xFF10_2030)
        let hand = HwtRaster(width: 2, height: 6, fill: 0xFFFF_FFFF)
        let thumb = HwtRaster(width: 2, height: 2, fill: 0)
        let spec = HwtFaceSpec(title: "Mau", titleCN: "Mau", author: "Toi", elements: [
            [.single(resource: 2, x: 0, y: 0, ambient: false)],
            [.hand(resource: 3, rect: HwtRect(x: 1, y: 1, w: 4, h: 4), pivotX: 1, pivotY: 2, valueType: 150, ambient: false)]
        ], images: [thumb, bg, hand])
        let pngs = try spec.images.map { try XCTUnwrap(FaceRenderer.pngData($0)) }
        let jpeg: [UInt8] = [0xFF, 0xD8, 0xFF, 0xD9]
        let bytes = try HwtBuilder.build(spec: spec, pngs: pngs, previews: .init(cover: jpeg, aod: jpeg, icon: jpeg))
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("lp-\(UUID().uuidString).hwt")
        try Data(bytes).write(to: url)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }

    func testPatchAddsLunarAndKeepsPackageValid() throws {
        let src = try sampleHwt()
        var design = FaceDesign()
        design.showLunar = true; design.showSolar = true; design.showWeekday = true
        design.showDigital = true; design.showName = true; design.nameText = "Lâm Quốc Đại"
        let out = try HwtLunarPatch.apply(source: src, design: design)
        let dst = FileManager.default.temporaryDirectory.appendingPathComponent("lp-out-\(UUID().uuidString).hwt")
        try Data(out.hwt).write(to: dst)
        addTeardownBlock { try? FileManager.default.removeItem(at: dst) }

        let report = try HwtInspector.inspect(url: dst)
        XCTAssertTrue(report.hasBin)
        XCTAssertGreaterThan(report.images.count, 3)

        // hashCode giá trị thứ 2 khớp gói trong mới
        let outer = try ZipArchive(url: dst)
        let inner = try outer.read(XCTUnwrap(outer.entries["com.huawei.watchface"]), max: 64 * 1024 * 1024)
        let hash = String(decoding: try outer.read(XCTUnwrap(outer.entries["hashCode"]), max: 4096), as: UTF8.self)
        let parts = hash.split(separator: ",").map(String.init)
        XCTAssertEqual(parts.count, 4)
        XCTAssertEqual(parts[1], WMCore.hex(WMCore.digest(inner)).uppercased())

        // Bố cục mới có âm lịch, và không thể thêm lần hai
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("lp-in-\(UUID().uuidString)")
        try Data(inner).write(to: tmp)
        addTeardownBlock { try? FileManager.default.removeItem(at: tmp) }
        let z = try ZipArchive(url: tmp)
        let bin = try z.read(XCTUnwrap(z.entries["watchface.bin"]), max: 64 * 1024 * 1024)
        let layoutLen = Int(bin[2]) | Int(bin[3]) << 8
        XCTAssertTrue(try HwtLunarPatch.hasLunar(layout: Array(bin[16..<(16 + layoutLen)])))
        XCTAssertThrowsError(try HwtLunarPatch.patchBin(bin, design: design))
        // Chỉ thêm tên (không trùng mã dữ liệu nào) thì vẫn thêm được vào bản đã có âm lịch
        var nameOnly = FaceDesign()
        nameOnly.showName = true; nameOnly.nameText = "A"
        XCTAssertNoThrow(try HwtLunarPatch.patchBin(bin, design: nameOnly))
        XCTAssertThrowsError(try HwtLunarPatch.patchBin(bin, design: FaceDesign()))
    }

    func testOriginalWithoutLunarIsDetected() throws {
        var root = HwtProto()
        root.message(1) { e in e.int(1, 0) }
        XCTAssertFalse(try HwtLunarPatch.hasLunar(layout: root.bytes))
    }
}
