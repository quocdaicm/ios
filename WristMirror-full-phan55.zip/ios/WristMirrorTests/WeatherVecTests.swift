// Unit test Phần 39: biểu tượng và tên tình trạng thời tiết vector, đồng bộ với kiểu số.
import XCTest
import SwiftUI
@testable import WristMirror

final class WeatherVecTests: XCTestCase {
    private let box = CGRect(x: 0, y: 0, width: 48, height: 48)

    /// Số điểm ảnh có độ trong suốt khác 0 của ảnh `w` x `h` do `draw` vẽ.
    private func inkCount(_ w: Int, _ h: Int, _ draw: @escaping () -> Void) -> Int {
        let r = FaceRenderer.drawRaster(width: w, height: h) { _ in draw() }
        return r.argb.filter { ($0 >> 24) != 0 }.count
    }

    func testIconSetsComplete() {
        XCTAssertEqual(WeatherIconSets.titles.count, 3, "0 = bộ cũ + 2 bộ mới")
        XCTAssertEqual(WeatherIconSets.solid.count, FaceRenderer.weatherNames.count)
        XCTAssertEqual(WeatherIconSets.line.count, FaceRenderer.weatherNames.count)
        XCTAssertEqual(WeatherIconSets.nameFXTitles.count, FaceTextFX.specs.count + 1)
        XCTAssertNil(WeatherIconSets.svg(style: 0, index: 1), "bộ cũ nằm ở FaceSVGData")
        XCTAssertNil(WeatherIconSets.svg(style: 1, index: 11))
        XCTAssertNil(WeatherIconSets.svg(style: 1, index: -1))
        XCTAssertNotNil(WeatherIconSets.svg(style: 2, index: 10))
    }

    func testSetsAreDistinctAndUsePaletteRoles() throws {
        XCTAssertNotEqual(WeatherIconSets.solid[1], WeatherIconSets.line[1])
        XCTAssertEqual(WeatherIconSets.solid[0], WeatherIconSets.line[0], "không dữ liệu giống nhau ở hai bộ")
        let roles: Set<String> = ["sun", "cloud", "rain", "snow", "sand", "gray", "none"]
        let re = try NSRegularExpression(pattern: #"(?:fill|stroke)="([A-Za-z]+)""#)
        for set in [WeatherIconSets.solid, WeatherIconSets.line] {
            for svg in set {
                XCTAssertFalse(svg.contains("nan"))
                let ns = svg as NSString
                for m in re.matches(in: svg, range: NSRange(location: 0, length: ns.length)) {
                    XCTAssertTrue(roles.contains(ns.substring(with: m.range(at: 1))), svg)
                }
            }
        }
    }

    func testInkPathsCountsFillAndStroke() {
        let svg = #"<circle cx="50" cy="50" r="20" fill="sun" stroke="sun" stroke-width="4"/><path d="M0 0 L10 0" fill="none" stroke="gray" stroke-width="2"/>"#
        XCTAssertEqual(MiniSVG.inkPaths(svg).count, 3, "vòng tô + nét viền + nét đường")
        XCTAssertTrue(MiniSVG.inkPaths("").isEmpty)
    }

    func testEveryNewIconDrawsInk() {
        for style in 1...2 {
            for i in 0..<11 {
                for mono in [false, true] {
                    let n = inkCount(48, 48) {
                        FaceRenderer.drawWeatherIcon(i, in: self.box, textColor: .white, mono: mono, svg: true, style: style)
                    }
                    XCTAssertGreaterThan(n, 100, "bộ \(style) mã \(i) mono \(mono)")
                }
            }
        }
    }

    func testSyncedIconDrawsInkForSeveralNumberStyles() throws {
        for st in [DigitalStyle.ledGreen, .goldHex, .thinLine, .outlineSeg, .dotMatrix] {
            let def = try XCTUnwrap(st.def)
            for style in 1...2 {
                for i in 0..<11 {
                    let n = inkCount(48, 48) {
                        FaceRenderer.drawWeatherIcon(i, in: self.box, textColor: .white, mono: false, svg: true,
                                                     style: style, sync: IconPaint(def: def, own: true))
                    }
                    XCTAssertGreaterThan(n, 100, "\(st.rawValue) bộ \(style) mã \(i)")
                }
            }
        }
    }

    func testOldSetIgnoresSync() throws {
        let def = try XCTUnwrap(DigitalStyle.ledGreen.def)
        let plain = inkCount(48, 48) {
            FaceRenderer.drawWeatherIcon(1, in: self.box, textColor: .white, mono: false, svg: true, style: 0)
        }
        let synced = inkCount(48, 48) {
            FaceRenderer.drawWeatherIcon(1, in: self.box, textColor: .white, mono: false, svg: true,
                                         style: 0, sync: IconPaint(def: def, own: true))
        }
        XCTAssertEqual(plain, synced, "bộ cũ không có chế độ đồng bộ")
    }

    func testLayoutModes() {
        var d = FaceDesign()
        d.weather.show = true
        d.weatherText = true
        let plain = WeatherLayout(d)
        XCTAssertNil(plain.textFX)
        XCTAssertFalse(plain.synced)
        XCTAssertEqual(plain.textPadX, 0)
        XCTAssertNil(plain.paint)

        d.dataStyle = .ledGreen
        let synced = WeatherLayout(d)
        XCTAssertTrue(synced.synced)
        XCTAssertTrue(synced.textSynced)
        XCTAssertNotNil(synced.paint)
        XCTAssertGreaterThan(synced.textPadX, 0, "quầng sáng cần đệm")
        XCTAssertGreaterThan(synced.textH, plain.textH - 1)

        d.weatherSync = false
        XCTAssertFalse(WeatherLayout(d).synced)
        XCTAssertNil(WeatherLayout(d).paint)

        d.weatherSync = true
        d.weatherFX = 1
        let fx = WeatherLayout(d)
        XCTAssertNotNil(fx.textFX)
        XCTAssertFalse(fx.textSynced, "đã chọn kiểu chữ riêng thì tên không tô theo số")
        XCTAssertNotNil(fx.paint, "biểu tượng vẫn đồng bộ")
        XCTAssertGreaterThan(fx.textPadX, 0)
        XCTAssertLessThanOrEqual(fx.textX, fx.x)
    }

    func testNameDrawsInkInEveryMode() {
        for mode in 0..<3 {
            var d = FaceDesign()
            d.weather.show = true
            d.weatherText = true
            if mode >= 1 { d.dataStyle = .ledGreen }
            if mode == 2 { d.weatherFX = 3 }
            let L = WeatherLayout(d)
            for name in FaceRenderer.weatherNames {
                let n = inkCount(L.textW, L.textH) {
                    FaceRenderer.drawWeatherName(name, L, color: .white, origin: .zero)
                }
                XCTAssertGreaterThan(n, 30, "chế độ \(mode): \(name)")
            }
        }
    }

    func testCodecKeepsNewFieldsAndDefaults() throws {
        let fresh = FaceDesign()
        XCTAssertEqual(fresh.weatherIconStyle, 1)
        XCTAssertTrue(fresh.weatherSync)
        XCTAssertEqual(fresh.weatherFX, 0)

        var d = FaceDesign()
        d.weatherIconStyle = 2
        d.weatherSync = false
        d.weatherFX = 5
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.weatherIconStyle, 2)
        XCTAssertFalse(back.weatherSync)
        XCTAssertEqual(back.weatherFX, 5)

        // Thiết kế cũ (chưa có trường) lấy giá trị mặc định mới.
        let old = try XCTUnwrap(FaceDesignCodec.decode(Data(#"{"version":1,"design":{"name":"Cũ"}}"#.utf8)))
        XCTAssertEqual(old.weatherIconStyle, 1)
        XCTAssertTrue(old.weatherSync)
    }

    func testWeatherThumbs() {
        for s in 0..<WeatherIconSets.titles.count {
            XCTAssertGreaterThan(UnitIconThumbs.weather(s).size.width, 0)
        }
    }
}
