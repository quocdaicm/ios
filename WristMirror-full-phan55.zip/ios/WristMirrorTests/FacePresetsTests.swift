// Unit test cho các mẫu mặt đồng hồ có sẵn.
import XCTest
import SwiftUI
@testable import WristMirror

final class FacePresetsTests: XCTestCase {
    func testPresetIdsAreUnique() {
        let ids = FacePresets.all.map { $0.id }
        XCTAssertEqual(Set(ids).count, ids.count)
    }

    /// Nền SVG ban ngày / AOD mà mẫu dùng phải có thật trong thư viện nền.
    func testBackdropIdsResolve() {
        for p in FacePresets.all {
            let d = p.make()
            if !d.backdrop.isEmpty {
                XCTAssertNotNil(FaceBackdrops.day.first { $0.id == d.backdrop }, "\(p.id): nền ban ngày \(d.backdrop)")
            }
            if !d.aodBackdrop.isEmpty {
                XCTAssertNotNil(FaceBackdrops.aod.first { $0.id == d.aodBackdrop }, "\(p.id): nền AOD \(d.aodBackdrop)")
            }
        }
    }

    func testAnimationSettingsInRange() {
        for p in FacePresets.all {
            let d = p.make()
            guard d.animOn else { continue }
            XCTAssertTrue([24, 32, 48].contains(d.animFallFrames), p.id)
            XCTAssertTrue((0.1...1.0).contains(d.animDensity), p.id)
        }
    }
}
