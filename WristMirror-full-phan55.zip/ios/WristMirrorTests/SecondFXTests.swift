// Unit test cho các hiệu ứng chuyển động theo giây.
import XCTest
import SwiftUI
@testable import WristMirror

final class SecondFXTests: XCTestCase {
    /// Mọi kiểu (trừ "Không") vẽ ra đủ 10 khung và mỗi khung có điểm ảnh không trong suốt.
    func testEveryStyleDrawsTenNonEmptyFrames() {
        for st in SecondFX.allCases where st != .none {
            var d = FaceDesign()
            d.secondFX = st
            let frames = FaceRenderer.secondFXFrames(d)
            XCTAssertEqual(frames.count, SecondFX.frameCount, st.rawValue)
            for (i, fr) in frames.enumerated() {
                XCTAssertTrue(fr.argb.contains { ($0 >> 24) != 0 }, "\(st.rawValue) khung \(i) trống")
            }
            XCTAssertFalse(st.detail.isEmpty, st.rawValue)
        }
    }

    func testNoneHasNoFrames() {
        var d = FaceDesign()
        d.secondFX = .none
        XCTAssertTrue(FaceRenderer.secondFXFrames(d).isEmpty)
    }
}
