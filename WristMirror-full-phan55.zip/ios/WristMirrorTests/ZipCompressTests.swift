// Unit test: bộ ghi ZIP nén deflate (chỉ nén khi đáng nén) và đọc lại đúng.
import XCTest
@testable import WristMirror

final class ZipCompressTests: XCTestCase {
    func testDeflateRoundTripAndFallback() throws {
        let big = [UInt8](repeating: 7, count: 50_000) + (0..<2000).map { UInt8($0 % 251) }
        let noise = (0..<4000).map { _ in UInt8.random(in: 0...255) }
        var w = HwtZipWriter()
        w.add(name: "big.bin", data: big, compress: true)
        w.add(name: "noise.bin", data: noise, compress: true)
        w.add(name: "plain.bin", data: big)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("zc-\(UUID().uuidString).zip")
        try Data(w.finish()).write(to: url)
        defer { try? FileManager.default.removeItem(at: url) }

        let z = try ZipArchive(url: url)
        let b = try XCTUnwrap(z.entries["big.bin"])
        XCTAssertEqual(b.method, 8)
        XCTAssertLessThan(Int(b.compressedSize), 5000)
        XCTAssertEqual(try z.read(b, max: 1_000_000), big)
        XCTAssertEqual(z.entries["noise.bin"]?.method, 0, "dữ liệu không nén được thì ghi nguyên bản")
        XCTAssertEqual(z.entries["plain.bin"]?.method, 0)
    }
}
