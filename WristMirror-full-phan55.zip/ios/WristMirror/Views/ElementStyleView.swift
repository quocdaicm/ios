// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Khung "Chung cho tất cả mục": công tắc chung, font chung, vùng chạm và chạm ở mép mặt đồng hồ.
/// Font riêng, cỡ chữ và hành động chạm của từng mục nằm ngay trong khung của mục đó (`ElementFontTapRows`).
struct ElementStyleView: View {
    @Binding var design: FaceDesign

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Chung cho tất cả mục")).font(.headline)
            Toggle(tr("Tự sắp xếp, không cho chữ chồng nhau hoặc đè lên số giờ"), isOn: $design.autoLayout)
            Toggle(tr("Viền chữ mờ phía sau cho dễ đọc"), isOn: $design.textOutline)
            Toggle(tr("Biểu tượng SVG riêng (tắt = biểu tượng iOS)"), isOn: $design.iconSVG)
            fontRow(tr("Font chữ"), $design.textFontIndex)
            fontRow(tr("Font số"), $design.numberFontIndex)
            Text(tr("Mỗi mục bên dưới có thể chọn font riêng; mặc định theo font chung ở đây."))
                .font(.caption2).foregroundStyle(.secondary)
            Divider()
            Toggle(tr("Bật vùng chạm (chạm vào mục để mở trên đồng hồ)"), isOn: $design.tapsOn)
            VStack(alignment: .leading, spacing: 4) {
                Text(tr("Chạm ở mép mặt đồng hồ")).font(.subheadline.weight(.semibold))
                ForEach(TapEdge.allCases) { edge in
                    Picker(edge.title, selection: Binding<Int>(
                        get: { design.edgeAction(edge).rawValue },
                        set: { design.edgeTaps[edge.rawValue] = $0 }
                    )) {
                        ForEach(TapAction.allCases) { Text($0.title).tag($0.rawValue) }
                    }
                    .pickerStyle(.menu)
                    .disabled(!design.tapsOn)
                }
            }
            Text(tr("Vùng chạm ghi theo đúng vị trí của mục (tối thiểu 64×48 điểm). Mã hành động đối chiếu từ các file HWT thật; cần thử trên đồng hồ."))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .card()
    }

    private func fontRow(_ title: String, _ sel: Binding<Int>) -> some View {
        HStack {
            Text(title)
            Spacer(minLength: 8)
            Picker(title, selection: sel) {
                ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            .labelsHidden()
        }
    }
}

/// Font riêng và hành động chạm của một mục, đặt trong khung của chính mục đó.
struct ElementFontTapRows: View {
    @Binding var design: FaceDesign
    let key: String

    var body: some View {
        let fontBinding = Binding<Int>(
            get: { design.elementFonts[key] ?? -1 },
            set: { design.elementFonts[key] = $0 < 0 ? nil : $0 }
        )
        let tapBinding = Binding<Int>(
            get: { design.tapAction(key).rawValue },
            set: { design.taps[key] = $0 }
        )
        VStack(alignment: .leading, spacing: 8) {
            Picker(tr("Font"), selection: fontBinding) {
                Text(tr("Theo font chung")).tag(-1)
                ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            Picker(tr("Khi chạm"), selection: tapBinding) {
                ForEach(TapAction.allCases) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            .disabled(!design.tapsOn)
            if !design.tapsOn {
                Text(tr("Vùng chạm đang tắt (bật ở khung Chung cho tất cả mục)."))
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
    }
}
