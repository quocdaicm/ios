// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Tương đương AboutScreen.kt.
struct AboutView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        List {
            Section {
                VStack(spacing: 12) {
                    BrandLogo(size: 92)
                    Text("Watch face").font(.title2.bold())
                    Text(trf("Bản iOS bởi Quốc Đại · v%@", vm.ui.appVersion))
                        .font(.footnote).foregroundStyle(.secondary)
                    HStack(spacing: 10) {
                        Link(destination: URL(string: "https://quocdai.site")!) {
                            Label("quocdai.site", systemImage: "globe")
                        }
                        .buttonStyle(SecondaryButtonStyle())
                        Link(destination: URL(string: "https://www.tiktok.com/@quocdai69f1")!) {
                            Label("TikTok", systemImage: "play.rectangle")
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            }
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)
            Section {
                Text(tr("Công cụ cài mặt đồng hồ HWT bên thứ ba cho đồng hồ Huawei bằng phương pháp thay thế; dành cho phần lớn thiết bị dùng giao thức mặt đồng hồ tương thích như GT, FIT."))
                    .font(.subheadline)
            }
.glassRows()
            Section(tr("Dự án gốc")) {
                Link(tr("Mã nguồn gốc WristMirror (Escosis, Android)"), destination: URL(string: "https://github.com/Escosis/WristMirror")!)
            }
.glassRows()
            Section(tr("Giấy phép")) {
                NavigationLink(tr("Giấy phép và ghi công")) { LicensesView() }
                Link("Apache License 2.0", destination: URL(string: "https://www.apache.org/licenses/LICENSE-2.0")!)
            }
.glassRows()
            Section {
                Text(tr("Bản iOS là bản viết lại bằng Swift/SwiftUI/CoreBluetooth, giấy phép Apache-2.0. Hãy tự chịu rủi ro; app không chép mã hay SDK của Huawei Health."))
                    .font(.footnote).foregroundStyle(.secondary)
            }
.glassRows()
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(tr("Giới thiệu"))
        .navigationBarTitleDisplayMode(.inline)
    }
}

/// Hiển thị ghi công/giấy phép ngay trong app (bản đầy đủ: LICENSE, NOTICE, THIRD_PARTY_NOTICES.md trong mã nguồn).
struct LicensesView: View {
    var body: some View {
        List {
            Section(tr("Mã nguồn gốc")) {
                Text(tr("WristMirror (腕镜) – Copyright 2026 Escosis – Apache License 2.0.\nBản iOS này là tác phẩm phái sinh, được port từ Kotlin/Java sang Swift/SwiftUI/CoreBluetooth và sửa đổi bởi Quốc Đại (quocdaicm, 2026)."))
                Link("github.com/Escosis/WristMirror", destination: URL(string: "https://github.com/Escosis/WristMirror")!)
            }
.glassRows()
            Section(tr("Tham khảo giao thức")) {
                Text(tr("Luồng giao tiếp tham khảo từ Huawei Health, 腕连手表助手 và Gadgetbridge rồi triển khai độc lập. App không chứa mã, SDK hay tài nguyên của các ứng dụng đó."))
            }
.glassRows()
            Section(tr("Công cụ build")) {
                Text(tr("XcodeGen (MIT) chỉ dùng khi build, không nhúng vào app. Không có thư viện bên thứ ba nào trong app."))
            }
.glassRows()
            Section(tr("Miễn trừ")) {
                Text(tr("Huawei, HarmonyOS và các tên liên quan là nhãn hiệu của chủ sở hữu. Dự án độc lập, không liên kết với Huawei, cung cấp NGUYÊN TRẠNG, không bảo hành. Hãy tự chịu rủi ro."))
            }
.glassRows()
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(tr("Giấy phép"))
        .navigationBarTitleDisplayMode(.inline)
    }
}
