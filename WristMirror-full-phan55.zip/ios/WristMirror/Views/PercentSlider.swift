// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Thanh kéo có số: tên bên trái, giá trị (%) trong ô bên phải, hai đầu thanh ghi mốc nhỏ/lớn
/// (hoặc trái/phải, trên/dưới) kèm % để biết đang kéo tới đâu. Giá trị lưu vẫn là số thực (1.0 = 100%).
struct PercentSlider: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    /// Chữ ở đầu thấp / đầu cao của thanh (vd. "Trái", "Phải"). Để trống thì chỉ hiện số.
    var lowLabel: String? = nil
    var highLabel: String? = nil
    /// Bước kéo; mặc định 0,01 = tròn từng 1% cho số hiển thị gọn.
    var step: Double = 0.01
    /// Tự định dạng giá trị (vd. "24 pt · 120%", "50 ms"). Mặc định là phần trăm.
    var valueText: ((Double) -> String)? = nil

    private func percent(_ v: Double) -> String {
        let p = Int((v * 100).rounded())
        // Thanh đi qua 0 (dịch trái/phải) thì ghi dấu để biết hướng.
        if range.lowerBound < 0 && p > 0 { return "+\(p)%" }
        return "\(p)%"
    }

    private func text(_ v: Double) -> String { valueText?(v) ?? percent(v) }

    private func edge(_ label: String?, _ v: Double) -> String {
        let t = text(v)
        guard let label = label, !label.isEmpty else { return t }
        return "\(label) \(t)"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .firstTextBaseline) {
                Text(tr(title)).font(.footnote).foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text(text(value))
                    .font(.footnote.weight(.semibold).monospacedDigit())
                    .foregroundStyle(Color.accentColor)
            }
            Slider(value: $value, in: range, step: step)
        }
    }
}

/// Nhóm "Kích thước & vị trí" dùng chung: cỡ, vị trí ngang, vị trí dọc (tính theo % mặt đồng hồ).
struct PlacementControls: View {
    @Binding var size: Double
    @Binding var x: Double
    @Binding var y: Double
    var sizeTitle: String = tr("Cỡ chữ")
    var xTitle: String = tr("Vị trí ngang")
    /// Cỡ chữ gốc (pt) ở 100%; có thì hiện thêm số pt cạnh %.
    var basePoints: Double? = nil

    private var sizeText: ((Double) -> String)? {
        guard let base = basePoints else { return nil }
        return { (v: Double) -> String in
            let pt = Int((base * Double(FaceRenderer.dataScale(v))).rounded())
            return "\(pt) pt · \(Int((v * 100).rounded()))%"
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            PercentSlider(title: sizeTitle, value: $size, range: 0.6...1.8,
                          valueText: sizeText)
            PercentSlider(title: xTitle, value: $x, range: 0.1...0.9)
            PercentSlider(title: tr("Vị trí dọc"), value: $y, range: 0.1...0.9)
        }
    }
}
