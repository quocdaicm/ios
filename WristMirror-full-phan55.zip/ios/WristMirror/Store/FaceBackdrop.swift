// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Nền SVG có sẵn
//
// Mỗi nền là một đoạn SVG (khung 466x466) vẽ bằng `MiniSVG` chồng lên nền chuyển sắc `top` -> `bottom`.
// Nền được vẽ thẳng vào ảnh nền sẵn có nên KHÔNG tốn thêm ảnh trong file HWT (không ảnh hưởng giới hạn 300 ảnh).
// Nền AOD chỉ gồm nét mảnh tối màu để tiết kiệm pin.

struct FaceBackdrop: Identifiable {
    let id: String
    let title: String
    let top: UInt32
    let bottom: UInt32
    let svg: String

    var topColor: Color { Color(red: Double((top >> 16) & 0xff) / 255, green: Double((top >> 8) & 0xff) / 255, blue: Double(top & 0xff) / 255) }
    var bottomColor: Color { Color(red: Double((bottom >> 16) & 0xff) / 255, green: Double((bottom >> 8) & 0xff) / 255, blue: Double(bottom & 0xff) / 255) }
}

/// Bộ dựng chuỗi SVG nhỏ gọn.
private struct SVGBuilder {
    private(set) var out = ""
    private var seed: UInt32

    init(seed: UInt32) { self.seed = seed }

    /// Số ngẫu nhiên xác định (0..<1) để nền luôn giống nhau mỗi lần dựng.
    mutating func rnd() -> Double {
        seed = seed &* 1664525 &+ 1013904223
        return Double((seed >> 8) & 0xffff) / 65536.0
    }

    private func n(_ v: Double) -> String { String(format: "%.1f", v) }

    mutating func circle(_ cx: Double, _ cy: Double, _ r: Double, _ fill: String, _ op: Double = 1) {
        out += "<circle cx=\"\(n(cx))\" cy=\"\(n(cy))\" r=\"\(n(r))\" fill=\"\(fill)\" opacity=\"\(n2(op))\"/>"
    }

    mutating func ring(_ cx: Double, _ cy: Double, _ r: Double, _ stroke: String, _ sw: Double = 1, _ op: Double = 1) {
        out += "<circle cx=\"\(n(cx))\" cy=\"\(n(cy))\" r=\"\(n(r))\" fill=\"none\" stroke=\"\(stroke)\" stroke-width=\"\(n(sw))\" opacity=\"\(n2(op))\"/>"
    }

    mutating func ellipse(_ cx: Double, _ cy: Double, _ rx: Double, _ ry: Double, fill: String = "none", stroke: String = "none", sw: Double = 1, op: Double = 1) {
        out += "<ellipse cx=\"\(n(cx))\" cy=\"\(n(cy))\" rx=\"\(n(rx))\" ry=\"\(n(ry))\" fill=\"\(fill)\" stroke=\"\(stroke)\" stroke-width=\"\(n(sw))\" opacity=\"\(n2(op))\"/>"
    }

    mutating func rect(_ x: Double, _ y: Double, _ w: Double, _ h: Double, _ fill: String, _ op: Double = 1, rx: Double = 0) {
        out += "<rect x=\"\(n(x))\" y=\"\(n(y))\" width=\"\(n(w))\" height=\"\(n(h))\" rx=\"\(n(rx))\" fill=\"\(fill)\" opacity=\"\(n2(op))\"/>"
    }

    mutating func path(_ d: String, fill: String = "none", stroke: String = "none", sw: Double = 1, op: Double = 1) {
        out += "<path d=\"\(d)\" fill=\"\(fill)\" stroke=\"\(stroke)\" stroke-width=\"\(n(sw))\" opacity=\"\(n2(op))\"/>"
    }

    private func n2(_ v: Double) -> String { String(format: "%.2f", v) }

    /// Quầng sáng: nhiều vòng tròn đồng tâm mờ chồng lên nhau.
    mutating func glow(_ cx: Double, _ cy: Double, _ r: Double, _ color: String, steps: Int = 8, peak: Double = 0.5) {
        for i in 0..<steps {
            let f = 1.0 - Double(i) / Double(steps)
            circle(cx, cy, r * f, color, peak / Double(steps) * 1.6)
        }
    }

    /// Sao rải ngẫu nhiên trong hình chữ nhật.
    mutating func stars(_ count: Int, x0: Double, y0: Double, x1: Double, y1: Double, color: String, maxR: Double, op: Double = 0.85) {
        for _ in 0..<count {
            let x = x0 + rnd() * (x1 - x0)
            let y = y0 + rnd() * (y1 - y0)
            let r = 0.5 + rnd() * (maxR - 0.5)
            circle(x, y, r, color, op * (0.45 + rnd() * 0.55))
        }
    }

    /// Ngôi sao 4 cánh nhấp nháy.
    mutating func sparkle(_ cx: Double, _ cy: Double, _ s: Double, _ color: String, _ op: Double = 0.9) {
        let k = s * 0.18
        let d = "M \(n(cx)) \(n(cy - s)) Q \(n(cx + k)) \(n(cy - k)) \(n(cx + s)) \(n(cy)) Q \(n(cx + k)) \(n(cy + k)) \(n(cx)) \(n(cy + s)) Q \(n(cx - k)) \(n(cy + k)) \(n(cx - s)) \(n(cy)) Q \(n(cx - k)) \(n(cy - k)) \(n(cx)) \(n(cy - s)) Z"
        path(d, fill: color, op: op)
    }

    /// Dải sóng đầy (tô) từ đường y đến đáy.
    mutating func waveFill(y: Double, amp: Double, color: String, op: Double, phase: Double = 0) {
        let a = amp
        let d = "M 0 \(n(y)) C 78 \(n(y - a + phase)) 155 \(n(y + a + phase)) 233 \(n(y)) S 388 \(n(y - a - phase)) 466 \(n(y)) L 466 466 L 0 466 Z"
        path(d, fill: color, op: op)
    }

    /// Đường sóng (nét).
    mutating func waveLine(y: Double, amp: Double, color: String, sw: Double, op: Double, phase: Double = 0) {
        let a = amp
        let d = "M 0 \(n(y)) C 78 \(n(y - a + phase)) 155 \(n(y + a + phase)) 233 \(n(y)) S 388 \(n(y - a - phase)) 466 \(n(y))"
        path(d, stroke: color, sw: sw, op: op)
    }

    /// Bông hoa 5 cánh tròn.
    mutating func blossom(_ cx: Double, _ cy: Double, _ r: Double, _ petal: String, _ center: String, _ op: Double = 0.95) {
        for k in 0..<5 {
            let a = Double(k) * 2.0 * Double.pi / 5.0 - Double.pi / 2.0
            circle(cx + cos(a) * r * 0.62, cy + sin(a) * r * 0.62, r * 0.55, petal, op)
        }
        circle(cx, cy, r * 0.28, center, 1)
    }
}

enum FaceBackdrops {
    static func find(_ id: String) -> FaceBackdrop? {
        if id.isEmpty { return nil }
        return day.first { $0.id == id } ?? aod.first { $0.id == id }
    }

    // MARK: Nền ban ngày

    static let day: [FaceBackdrop] = dayBasic + daySeasonal

    /// Nền ban ngày có sẵn (gốc); các nền theo mùa, Noel, Tết nằm ở FaceBackdropSeasons.swift.
    static let dayBasic: [FaceBackdrop] = [
        FaceBackdrop(id: "sunsetMountain", title: "Núi hoàng hôn", top: 0x2A1046, bottom: 0xF0764A, svg: sunsetMountain()),
        FaceBackdrop(id: "moonSea", title: "Biển trăng", top: 0x050B1F, bottom: 0x123A63, svg: moonSea()),
        FaceBackdrop(id: "starryNight", title: "Đêm sao", top: 0x000000, bottom: 0x0B1B3A, svg: starryNight()),
        FaceBackdrop(id: "aurora", title: "Cực quang", top: 0x021018, bottom: 0x14083A, svg: aurora()),
        FaceBackdrop(id: "waves", title: "Sóng xanh", top: 0x0A3D91, bottom: 0x00B4D8, svg: waves()),
        FaceBackdrop(id: "bamboo", title: "Rừng tre", top: 0x0B2A1F, bottom: 0x1F5B3A, svg: bamboo()),
        FaceBackdrop(id: "blossom", title: "Hoa đào", top: 0x3A0F2A, bottom: 0x8E2C5C, svg: blossom()),
        FaceBackdrop(id: "dunes", title: "Sa mạc", top: 0x3B1F0E, bottom: 0xE8A25A, svg: dunes()),
        FaceBackdrop(id: "goldGeo", title: "Hình học vàng", top: 0x0C0C14, bottom: 0x1A1426, svg: goldGeo()),
        FaceBackdrop(id: "cityNight", title: "Phố đêm", top: 0x070B1E, bottom: 0x2A1B5E, svg: cityNight()),
        FaceBackdrop(id: "lotusPond", title: "Đầm sen", top: 0x06303A, bottom: 0x0E6B6B, svg: lotusPond())
    ]

    private static func sunsetMountain() -> String {
        var s = SVGBuilder(seed: 11)
        s.stars(26, x0: 0, y0: 0, x1: 466, y1: 170, color: "#FFFFFF", maxR: 1.6, op: 0.7)
        s.glow(233, 262, 190, "#FFB36B", steps: 9, peak: 0.55)
        s.circle(233, 262, 50, "#FFE2B0", 0.95)
        s.path("M 0 300 L 60 252 L 112 288 L 182 222 L 252 292 L 322 236 L 392 282 L 466 242 L 466 466 L 0 466 Z", fill: "#5B2A6E", op: 0.85)
        s.path("M 0 350 L 70 300 L 140 338 L 220 286 L 300 340 L 380 298 L 466 346 L 466 466 L 0 466 Z", fill: "#3A1B55", op: 0.95)
        s.path("M 0 405 C 90 368 170 420 260 386 S 400 372 466 400 L 466 466 L 0 466 Z", fill: "#1E0E33", op: 1)
        return s.out
    }

    private static func moonSea() -> String {
        var s = SVGBuilder(seed: 23)
        s.stars(40, x0: 0, y0: 0, x1: 466, y1: 250, color: "#DDE8FF", maxR: 1.5, op: 0.75)
        s.glow(330, 118, 96, "#BFD6FF", steps: 8, peak: 0.4)
        s.circle(330, 118, 34, "#F4F1E4", 1)
        s.circle(318, 110, 6, "#D9D4C0", 0.55)
        s.circle(341, 128, 4, "#D9D4C0", 0.5)
        var y = 292.0
        var i = 0
        while y < 466 {
            s.waveLine(y: y, amp: 9 + Double(i), color: "#7FB2E5", sw: 1.6, op: max(0.12, 0.5 - Double(i) * 0.06), phase: Double(i % 2 == 0 ? 4 : -4))
            y += 24
            i += 1
        }
        var ry = 304.0
        for k in 0..<6 {
            let w = 46.0 - Double(k) * 6
            s.ellipse(330, ry, w, 2.2, fill: "#F4F1E4", op: 0.5 - Double(k) * 0.06)
            ry += 22
        }
        return s.out
    }

    private static func starryNight() -> String {
        var s = SVGBuilder(seed: 37)
        s.path("M 0 430 C 120 330 300 200 466 60", stroke: "#9DB8FF", sw: 74, op: 0.07)
        s.path("M 0 430 C 120 330 300 200 466 60", stroke: "#C9D8FF", sw: 34, op: 0.07)
        s.stars(110, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 1.9, op: 0.9)
        s.sparkle(88, 96, 11, "#FFFFFF", 0.95)
        s.sparkle(372, 70, 9, "#CFE0FF", 0.9)
        s.sparkle(410, 300, 12, "#FFFFFF", 0.9)
        s.sparkle(70, 360, 8, "#CFE0FF", 0.85)
        s.sparkle(300, 410, 10, "#FFFFFF", 0.85)
        return s.out
    }

    private static func aurora() -> String {
        var s = SVGBuilder(seed: 41)
        s.stars(46, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 1.4, op: 0.7)
        let ribbon1 = "M 0 210 C 100 120 200 270 300 170 S 440 120 466 150"
        let ribbon2 = "M 0 290 C 110 220 210 340 310 250 S 430 210 466 240"
        s.path(ribbon1, stroke: "#3CFFB0", sw: 54, op: 0.08)
        s.path(ribbon1, stroke: "#3CFFB0", sw: 30, op: 0.12)
        s.path(ribbon1, stroke: "#B8FFE4", sw: 7, op: 0.30)
        s.path(ribbon2, stroke: "#A56BFF", sw: 50, op: 0.08)
        s.path(ribbon2, stroke: "#A56BFF", sw: 26, op: 0.12)
        s.path(ribbon2, stroke: "#E0CCFF", sw: 6, op: 0.28)
        s.path("M 0 380 C 120 330 240 410 466 350", stroke: "#3CD7FF", sw: 22, op: 0.08)
        return s.out
    }

    private static func waves() -> String {
        var s = SVGBuilder(seed: 53)
        s.glow(380, 90, 120, "#FFFFFF", steps: 6, peak: 0.25)
        for i in 0..<8 {
            let y = 170.0 + Double(i) * 40
            s.waveFill(y: y, amp: 22, color: i % 2 == 0 ? "#FFFFFF" : "#003C8F", op: 0.08 + Double(i) * 0.012, phase: Double(i % 2 == 0 ? 8 : -8))
        }
        for i in 0..<5 {
            s.waveLine(y: 190.0 + Double(i) * 62, amp: 18, color: "#FFFFFF", sw: 1.4, op: 0.28)
        }
        return s.out
    }

    private static func bamboo() -> String {
        var s = SVGBuilder(seed: 67)
        s.glow(233, 60, 200, "#B6FFC9", steps: 7, peak: 0.22)
        let xs: [Double] = [44, 108, 186, 262, 336, 404, 448]
        for (i, x) in xs.enumerated() {
            let w = 14.0 + Double(i % 3) * 4
            s.rect(x - w / 2, 0, w, 466, "#6FCF97", 0.30 + Double(i % 2) * 0.10, rx: 5)
            var y = 36.0 + Double(i * 17 % 40)
            while y < 466 {
                s.rect(x - w / 2 - 2, y, w + 4, 4, "#0B2A1F", 0.55, rx: 2)
                if Int(y) % 3 == 0 {
                    let dir = i % 2 == 0 ? 1.0 : -1.0
                    let lx = x + dir * w / 2
                    let d = "M \(String(format: "%.1f", lx)) \(String(format: "%.1f", y)) q \(String(format: "%.1f", dir * 34)) -14 \(String(format: "%.1f", dir * 60)) 6 q \(String(format: "%.1f", dir * -30)) 14 \(String(format: "%.1f", dir * -60)) -6 Z"
                    s.path(d, fill: "#9BE8B5", op: 0.38)
                }
                y += 66
            }
        }
        return s.out
    }

    private static func blossom() -> String {
        var s = SVGBuilder(seed: 79)
        s.glow(380, 70, 130, "#FFD0E2", steps: 6, peak: 0.25)
        s.path("M -10 124 C 100 152 180 92 300 132 S 430 102 480 62", stroke: "#4A2018", sw: 8, op: 0.85)
        s.path("M 140 128 C 150 170 140 210 160 250", stroke: "#4A2018", sw: 4, op: 0.75)
        s.path("M 330 120 C 350 160 380 170 400 214", stroke: "#4A2018", sw: 4, op: 0.75)
        let spots: [(Double, Double, Double)] = [
            (36, 128, 15), (90, 142, 18), (150, 118, 16), (214, 112, 19), (276, 128, 15), (338, 118, 18),
            (396, 104, 15), (446, 76, 14), (158, 252, 14), (402, 216, 13), (140, 190, 11), (372, 164, 12)
        ]
        for p in spots { s.blossom(p.0, p.1, p.2, "#FFC2D6", "#FFD54A") }
        for _ in 0..<26 {
            let x = s.rnd() * 466
            let y = 250 + s.rnd() * 216
            s.ellipse(x, y, 5, 2.6, fill: "#FFC2D6", op: 0.35 + s.rnd() * 0.4)
        }
        return s.out
    }

    private static func dunes() -> String {
        var s = SVGBuilder(seed: 83)
        s.glow(350, 130, 150, "#FFE0A8", steps: 8, peak: 0.45)
        s.circle(350, 130, 40, "#FFF1CF", 0.95)
        s.path("M 0 300 C 100 250 200 330 320 280 S 440 270 466 290 L 466 466 L 0 466 Z", fill: "#E9A860", op: 0.75)
        s.path("M 0 350 C 120 300 230 380 350 330 S 440 330 466 340 L 466 466 L 0 466 Z", fill: "#C9803F", op: 0.85)
        s.path("M 0 410 C 110 372 220 430 330 392 S 440 390 466 400 L 466 466 L 0 466 Z", fill: "#8C4F22", op: 0.95)
        s.path("M 0 300 C 100 250 200 330 320 280 S 440 270 466 290", stroke: "#FFE6B8", sw: 1.4, op: 0.5)
        return s.out
    }

    private static func goldGeo() -> String {
        var s = SVGBuilder(seed: 97)
        var x = -466.0
        while x < 466 {
            s.path("M \(x) 0 L \(x + 466) 466", stroke: "#C9A24B", sw: 1, op: 0.16)
            s.path("M \(x + 466) 0 L \(x) 466", stroke: "#C9A24B", sw: 1, op: 0.16)
            x += 46
        }
        s.path("M 233 18 L 448 233 L 233 448 L 18 233 Z", stroke: "#E6C46A", sw: 2, op: 0.55)
        s.path("M 233 58 L 408 233 L 233 408 L 58 233 Z", stroke: "#E6C46A", sw: 1.2, op: 0.4)
        s.ring(233, 233, 214, "#E6C46A", 1.6, 0.45)
        s.ring(233, 233, 160, "#E6C46A", 1, 0.3)
        s.circle(233, 18, 4, "#E6C46A", 0.9)
        s.circle(448, 233, 4, "#E6C46A", 0.9)
        s.circle(233, 448, 4, "#E6C46A", 0.9)
        s.circle(18, 233, 4, "#E6C46A", 0.9)
        return s.out
    }

    private static func cityNight() -> String {
        var s = SVGBuilder(seed: 101)
        s.stars(34, x0: 0, y0: 0, x1: 466, y1: 220, color: "#FFFFFF", maxR: 1.4, op: 0.75)
        s.glow(233, 400, 200, "#8A5CFF", steps: 8, peak: 0.35)
        var x = 0.0
        while x < 466 {
            let w = 26.0 + s.rnd() * 30
            let h = 40.0 + s.rnd() * 120
            let top = 466 - h
            s.rect(x, top, w, h, "#0B0F2A", 0.96)
            var wy = top + 8
            while wy < 458 {
                var wx = x + 5
                while wx < x + w - 6 {
                    if s.rnd() > 0.45 { s.rect(wx, wy, 4, 5, "#FFD36B", 0.8) }
                    wx += 9
                }
                wy += 12
            }
            x += w + 2
        }
        return s.out
    }

    private static func lotusPond() -> String {
        var s = SVGBuilder(seed: 113)
        s.glow(233, 40, 180, "#BFFFF0", steps: 6, peak: 0.2)
        for i in 0..<7 {
            s.ellipse(233, 250 + Double(i) * 30, 60 + Double(i) * 28, 10 + Double(i) * 3, stroke: "#A8F0E6", sw: 1.2, op: 0.28 - Double(i) * 0.025)
        }
        let pads: [(Double, Double, Double)] = [(90, 330, 46), (370, 360, 52), (210, 420, 40), (410, 250, 34), (60, 230, 30)]
        for p in pads {
            s.ellipse(p.0, p.1, p.2, p.2 * 0.38, fill: "#2E8B57", op: 0.75)
            s.ellipse(p.0 + p.2 * 0.2, p.1 - p.2 * 0.1, p.2 * 0.45, p.2 * 0.12, fill: "#58C583", op: 0.5)
        }
        let flowers: [(Double, Double, Double)] = [(150, 300, 34), (300, 340, 40), (360, 270, 26)]
        for f in flowers {
            let cx = f.0, cy = f.1, h = f.2
            let side1 = "M \(cx) \(cy) Q \(cx - h * 0.9) \(cy - h * 0.5) \(cx - h * 0.45) \(cy - h * 1.2) Q \(cx - h * 0.1) \(cy - h * 0.6) \(cx) \(cy) Z"
            let side2 = "M \(cx) \(cy) Q \(cx + h * 0.9) \(cy - h * 0.5) \(cx + h * 0.45) \(cy - h * 1.2) Q \(cx + h * 0.1) \(cy - h * 0.6) \(cx) \(cy) Z"
            let mid = "M \(cx) \(cy) Q \(cx - h * 0.45) \(cy - h * 0.7) \(cx) \(cy - h * 1.5) Q \(cx + h * 0.45) \(cy - h * 0.7) \(cx) \(cy) Z"
            s.path(side1, fill: "#FF8FB5", op: 0.9)
            s.path(side2, fill: "#FF8FB5", op: 0.9)
            s.path(mid, fill: "#FFB6D0", op: 0.95)
            s.circle(cx, cy - h * 0.1, h * 0.12, "#FFD54A", 0.95)
        }
        return s.out
    }

    // MARK: Nền AOD (nét mảnh, tối)

    static let aod: [FaceBackdrop] = aodBasic + aodSeasonal

    static let aodBasic: [FaceBackdrop] = [
        FaceBackdrop(id: "aodMountain", title: "Núi viền", top: 0x000000, bottom: 0x050A14, svg: aodMountain()),
        FaceBackdrop(id: "aodStars", title: "Sao thưa", top: 0x000000, bottom: 0x02030A, svg: aodStars()),
        FaceBackdrop(id: "aodWaves", title: "Sóng vạch", top: 0x000000, bottom: 0x04101C, svg: aodWaves()),
        FaceBackdrop(id: "aodRings", title: "Vòng đồng tâm", top: 0x000000, bottom: 0x060810, svg: aodRings()),
        FaceBackdrop(id: "aodDots", title: "Lưới chấm", top: 0x000000, bottom: 0x000000, svg: aodDots()),
        FaceBackdrop(id: "aodMoon", title: "Trăng viền", top: 0x000000, bottom: 0x03050C, svg: aodMoon()),
        FaceBackdrop(id: "aodBamboo", title: "Tre viền", top: 0x000000, bottom: 0x02100A, svg: aodBamboo()),
        FaceBackdrop(id: "aodGold", title: "Đường vàng", top: 0x000000, bottom: 0x0A0803, svg: aodGold())
    ]

    private static func aodMountain() -> String {
        var s = SVGBuilder(seed: 211)
        s.stars(14, x0: 0, y0: 0, x1: 466, y1: 190, color: "#6F7C99", maxR: 1.2, op: 0.6)
        s.ring(340, 110, 26, "#5A6682", 1.4, 0.8)
        s.path("M 0 330 L 70 280 L 130 318 L 200 252 L 270 322 L 340 270 L 410 316 L 466 280", stroke: "#3A4B66", sw: 1.6, op: 0.9)
        s.path("M 0 386 L 80 340 L 160 378 L 240 326 L 320 380 L 400 340 L 466 376", stroke: "#2B3850", sw: 1.4, op: 0.85)
        return s.out
    }

    private static func aodStars() -> String {
        var s = SVGBuilder(seed: 223)
        s.stars(46, x0: 8, y0: 8, x1: 458, y1: 458, color: "#8A97B5", maxR: 1.6, op: 0.6)
        s.sparkle(96, 110, 7, "#8A97B5", 0.6)
        s.sparkle(380, 360, 7, "#8A97B5", 0.55)
        return s.out
    }

    private static func aodWaves() -> String {
        var s = SVGBuilder(seed: 227)
        for i in 0..<7 {
            s.waveLine(y: 200.0 + Double(i) * 36, amp: 12, color: "#2B4A6B", sw: 1.4, op: 0.85 - Double(i) * 0.08, phase: Double(i % 2 == 0 ? 4 : -4))
        }
        return s.out
    }

    private static func aodRings() -> String {
        var s = SVGBuilder(seed: 229)
        var r = 50.0
        while r <= 230 {
            s.ring(233, 233, r, "#2A3340", 1, 0.9)
            r += 36
        }
        return s.out
    }

    private static func aodDots() -> String {
        var s = SVGBuilder(seed: 233)
        var y = 20.0
        while y < 466 {
            var x = 20.0
            while x < 466 {
                let dx = x - 233, dy = y - 233
                if dx * dx + dy * dy < 222 * 222 { s.circle(x, y, 1.3, "#2A3445", 0.9) }
                x += 30
            }
            y += 30
        }
        return s.out
    }

    private static func aodMoon() -> String {
        var s = SVGBuilder(seed: 239)
        s.ring(335, 128, 44, "#7A7560", 1.6, 0.8)
        s.path("M 335 84 C 300 100 300 156 335 172", stroke: "#7A7560", sw: 1.2, op: 0.6)
        s.stars(20, x0: 10, y0: 10, x1: 456, y1: 456, color: "#6F7C99", maxR: 1.3, op: 0.5)
        return s.out
    }

    private static func aodBamboo() -> String {
        var s = SVGBuilder(seed: 241)
        let xs: [Double] = [50, 118, 350, 418]
        for x in xs {
            s.path("M \(x - 8) 0 L \(x - 8) 466", stroke: "#1F4A38", sw: 1.3, op: 0.85)
            s.path("M \(x + 8) 0 L \(x + 8) 466", stroke: "#1F4A38", sw: 1.3, op: 0.85)
            var y = 50.0
            while y < 466 {
                s.path("M \(x - 11) \(y) L \(x + 11) \(y)", stroke: "#2D6B50", sw: 1.4, op: 0.85)
                y += 74
            }
        }
        return s.out
    }

    private static func aodGold() -> String {
        var s = SVGBuilder(seed: 251)
        s.path("M 233 20 L 446 233 L 233 446 L 20 233 Z", stroke: "#4A3C1A", sw: 1.4, op: 0.9)
        s.path("M 233 70 L 396 233 L 233 396 L 70 233 Z", stroke: "#3A2F14", sw: 1.1, op: 0.8)
        s.ring(233, 233, 214, "#3A2F14", 1.2, 0.8)
        return s.out
    }
}

// MARK: - Vẽ nền SVG

extension FaceRenderer {
    private static let backdropCache = NSCache<NSString, UIImage>()

    /// Ảnh SVG (trong suốt) của một nền, vẽ một lần rồi dùng lại.
    private static func backdropImage(_ b: FaceBackdrop) -> UIImage {
        let key = b.id as NSString
        if let c = backdropCache.object(forKey: key) { return c }
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = false
        let box = CGSize(width: size, height: size)
        let img = UIGraphicsImageRenderer(size: box, format: fmt).image { _ in
            MiniSVG.draw(b.svg, box: box, in: CGRect(origin: .zero, size: box), palette: [:])
        }
        backdropCache.setObject(img, forKey: key)
        return img
    }

    /// Vẽ lớp SVG của nền `id` (nếu có) lên ctx hiện tại (gốc trên-trái, 466x466).
    static func drawBackdrop(_ ctx: CGContext, id: String) {
        guard let b = FaceBackdrops.find(id) else { return }
        let img = backdropImage(b)
        UIGraphicsPushContext(ctx)
        img.draw(in: CGRect(x: 0, y: 0, width: size, height: size))
        UIGraphicsPopContext()
    }

    /// Ảnh thu nhỏ (nền chuyển sắc + SVG) cho bộ chọn.
    static func backdropThumb(_ b: FaceBackdrop, px: CGFloat = 112) -> UIImage {
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: px, height: px), format: fmt).image { c in
            let ctx = c.cgContext
            let k = px / size
            ctx.scaleBy(x: k, y: k)
            let colors = [uiRGB(b.top).cgColor, uiRGB(b.bottom).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: nil) {
                ctx.drawLinearGradient(g, start: .zero, end: CGPoint(x: size, y: size), options: [])
            }
            drawBackdrop(ctx, id: b.id)
        }
    }

    private static func uiRGB(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 0xff) / 255, green: CGFloat((v >> 8) & 0xff) / 255, blue: CGFloat(v & 0xff) / 255, alpha: 1)
    }
}

enum BackdropThumbs {
    private static let cache = LockedCache<String, UIImage>()

    static func image(_ b: FaceBackdrop) -> UIImage {
        if let c = cache[b.id] { return c }
        let img = FaceRenderer.backdropThumb(b)
        cache[b.id] = img
        return img
    }
}

// MARK: - Họa tiết trang trí bổ sung (vector)

extension FaceRenderer {
    /// Các họa tiết thêm. Gọi từ `drawDecorPattern` (ctx đã đặt sẵn màu nét, màu tô, độ dày nét; gốc ở tâm).
    static func drawExtraDecor(_ ctx: CGContext, pattern: DecorPattern, radius R: CGFloat, color: UIColor) {
        let pi = CGFloat.pi
        let soft = color.withAlphaComponent(0.35)

        func ring(_ r: CGFloat) {
            ctx.strokeEllipse(in: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r))
        }
        func dot(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            ctx.setFillColor(color.cgColor)
            ctx.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func paint(_ p: CGPath, fill: UIColor?) {
            if let f = fill {
                ctx.setFillColor(f.cgColor)
                ctx.addPath(p)
                ctx.fillPath()
            }
            ctx.addPath(p)
            ctx.strokePath()
        }
        func petal(_ len: CGFloat, _ w: CGFloat) -> CGPath {
            let p = CGMutablePath()
            p.move(to: .zero)
            p.addQuadCurve(to: CGPoint(x: 0, y: -len), control: CGPoint(x: w, y: -len * 0.55))
            p.addQuadCurve(to: .zero, control: CGPoint(x: -w, y: -len * 0.55))
            p.closeSubpath()
            return p
        }
        func spokes(_ n: Int, offset: CGFloat = 0, _ body: () -> Void) {
            for i in 0..<n {
                ctx.saveGState()
                ctx.rotate(by: offset + CGFloat(i) * 2 * pi / CGFloat(n))
                body()
                ctx.restoreGState()
            }
        }
        func spokesIdx(_ n: Int, _ body: (Int) -> Void) {
            for i in 0..<n {
                ctx.saveGState()
                ctx.rotate(by: CGFloat(i) * 2 * pi / CGFloat(n))
                body(i)
                ctx.restoreGState()
            }
        }
        func clipCircle(_ r: CGFloat) {
            ctx.addEllipse(in: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r))
            ctx.clip()
        }
        /// Nửa vòng cung (phía trên hoặc dưới) dựng bằng điểm, không phụ thuộc chiều trục y.
        func arc(_ cx: CGFloat, _ cy: CGFloat, _ r: CGFloat, upper: Bool) -> CGPath {
            let p = CGMutablePath()
            let steps = 14
            for t in 0...steps {
                let a = pi * CGFloat(t) / CGFloat(steps)
                let s = sin(a) * (upper ? -1 : 1)
                let pt = CGPoint(x: cx + cos(a) * r, y: cy + s * r)
                if t == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
            }
            return p
        }

        switch pattern {
        case .cherry:
            func blossom(_ r: CGFloat) {
                for k in 0..<5 {
                    ctx.saveGState()
                    ctx.rotate(by: CGFloat(k) * 2 * pi / 5)
                    paint(petal(r, r * 0.55), fill: soft)
                    ctx.restoreGState()
                }
                dot(0, 0, r * 0.12)
            }
            spokes(10) {
                ctx.translateBy(x: 0, y: -R * 0.80)
                blossom(R * 0.14)
            }
            spokes(5, offset: pi / 5) {
                ctx.translateBy(x: 0, y: -R * 0.48)
                blossom(R * 0.13)
            }
            blossom(R * 0.20)
            ring(R)

        case .waves:
            ctx.saveGState()
            clipCircle(R)
            let s = R * 0.16
            var row = 0
            var y = -R
            while y < R + s {
                let shift: CGFloat = row % 2 == 0 ? 0 : s
                var x = -R - s + shift
                while x < R + s {
                    for k in 1...3 {
                        ctx.addPath(arc(x, y, s * CGFloat(k) / 3.0, upper: true))
                        ctx.strokePath()
                    }
                    x += s * 2
                }
                y += s * 0.5
                row += 1
            }
            ctx.restoreGState()
            ring(R)

        case .hexGrid:
            ctx.saveGState()
            clipCircle(R)
            let s = R * 0.17
            let w = s * 1.7320508
            var row = 0
            var cy = -R - s
            while cy < R + s {
                var cx = -R - w + (row % 2 == 0 ? 0 : w / 2)
                while cx < R + w {
                    let p = CGMutablePath()
                    for k in 0..<6 {
                        let a = pi / 6 + CGFloat(k) * pi / 3
                        let pt = CGPoint(x: cx + cos(a) * s, y: cy + sin(a) * s)
                        if k == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
                    }
                    p.closeSubpath()
                    ctx.addPath(p)
                    ctx.strokePath()
                    cx += w
                }
                cy += s * 1.5
                row += 1
            }
            ctx.restoreGState()
            ring(R)

        case .compass:
            ring(R)
            ring(R * 0.92)
            spokesIdx(32) { i in
                ctx.move(to: CGPoint(x: 0, y: -R * 0.92))
                ctx.addLine(to: CGPoint(x: 0, y: -R * (i % 4 == 0 ? 0.80 : 0.86)))
                ctx.strokePath()
            }
            func point(_ len: CGFloat, _ w: CGFloat) {
                let p = CGMutablePath()
                p.move(to: CGPoint(x: 0, y: -len))
                p.addLine(to: CGPoint(x: w, y: 0))
                p.addLine(to: CGPoint(x: 0, y: len * 0.18))
                p.addLine(to: CGPoint(x: -w, y: 0))
                p.closeSubpath()
                paint(p, fill: soft)
            }
            spokes(4, offset: pi / 4) { point(R * 0.55, R * 0.07) }
            spokes(4) { point(R * 0.78, R * 0.11) }
            ring(R * 0.16)
            dot(0, 0, R * 0.04)

        case .snowflake:
            spokes(6) {
                ctx.move(to: .zero)
                ctx.addLine(to: CGPoint(x: 0, y: -R * 0.94))
                ctx.strokePath()
                for f in [0.34, 0.54, 0.74] as [CGFloat] {
                    let by = -R * f
                    let bl = R * (0.26 - (f - 0.34) * 0.3)
                    ctx.move(to: CGPoint(x: 0, y: by))
                    ctx.addLine(to: CGPoint(x: bl * 0.7, y: by - bl * 0.7))
                    ctx.move(to: CGPoint(x: 0, y: by))
                    ctx.addLine(to: CGPoint(x: -bl * 0.7, y: by - bl * 0.7))
                    ctx.strokePath()
                }
                dot(0, -R * 0.94, R * 0.025)
            }
            ring(R * 0.12)
            dot(0, 0, R * 0.04)

        case .rosette:
            ring(R)
            spokes(24) {
                ctx.strokeEllipse(in: CGRect(x: -R * 0.5, y: -R, width: R, height: R))
            }
            ring(R * 0.5)
            ring(R * 0.1)

        case .chrysanthemum:
            spokes(32) { paint(petal(R, R * 0.09), fill: soft) }
            spokes(24, offset: pi / 24) { paint(petal(R * 0.76, R * 0.08), fill: soft) }
            spokes(16) { paint(petal(R * 0.52, R * 0.07), fill: soft) }
            spokes(12, offset: pi / 12) { paint(petal(R * 0.30, R * 0.06), fill: soft) }
            dot(0, 0, R * 0.05)

        case .laurel:
            for side in [CGFloat(1), CGFloat(-1)] {
                ctx.saveGState()
                ctx.scaleBy(x: side, y: 1)
                for i in 0..<15 {
                    let t = CGFloat(i) / 14
                    let th = pi * 0.10 + t * pi * 0.80
                    let r = R * 0.80
                    ctx.saveGState()
                    ctx.translateBy(x: sin(th) * r, y: cos(th) * r)
                    ctx.rotate(by: pi / 2 - th)
                    ctx.saveGState()
                    ctx.rotate(by: 0.55)
                    paint(petal(R * 0.17, R * 0.06), fill: soft)
                    ctx.restoreGState()
                    ctx.saveGState()
                    ctx.rotate(by: -0.55)
                    paint(petal(R * 0.15, R * 0.055), fill: soft)
                    ctx.restoreGState()
                    ctx.restoreGState()
                }
                ctx.restoreGState()
            }
            ring(R * 0.97)

        case .flowerOfLife:
            let r = R / 3
            ring(r)
            for k in 0..<6 {
                let a = CGFloat(k) * pi / 3
                let x = sin(a) * r, y = -cos(a) * r
                ctx.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
                let x2 = sin(a) * r * 2, y2 = -cos(a) * r * 2
                ctx.strokeEllipse(in: CGRect(x: x2 - r, y: y2 - r, width: 2 * r, height: 2 * r))
                let b = a + pi / 6
                let x3 = sin(b) * r * 1.7320508, y3 = -cos(b) * r * 1.7320508
                ctx.strokeEllipse(in: CGRect(x: x3 - r, y: y3 - r, width: 2 * r, height: 2 * r))
            }
            ring(R)
            ring(R * 0.97)

        case .constellation:
            let pts: [(CGFloat, CGFloat)] = [(-0.80, -0.20), (-0.50, -0.55), (-0.10, -0.72), (0.35, -0.50),
                                              (0.72, -0.14), (0.55, 0.32), (0.10, 0.58), (-0.40, 0.46)]
            let p = CGMutablePath()
            for (i, q) in pts.enumerated() {
                let pt = CGPoint(x: q.0 * R, y: q.1 * R)
                if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
            }
            p.closeSubpath()
            ctx.addPath(p)
            ctx.strokePath()
            for q in pts { dot(q.0 * R, q.1 * R, R * 0.028) }
            let extra: [(CGFloat, CGFloat)] = [(-0.2, -0.3), (0.2, -0.1), (-0.1, 0.2), (0.4, 0.15), (-0.55, 0.1), (0.05, -0.55)]
            for q in extra { dot(q.0 * R, q.1 * R, R * 0.012) }
            ring(R)

        case .scales:
            ctx.saveGState()
            clipCircle(R)
            let s = R * 0.14
            var row = 0
            var y = -R - s
            while y < R + s {
                let shift: CGFloat = row % 2 == 0 ? 0 : s
                var x = -R - 2 * s + shift
                while x < R + 2 * s {
                    for k in 1...2 {
                        ctx.addPath(arc(x, y, s * CGFloat(k) / 2.0, upper: false))
                        ctx.strokePath()
                    }
                    x += s * 2
                }
                y += s * 0.9
                row += 1
            }
            ctx.restoreGState()
            ring(R)

        case .moonPhases:
            let mr = R * 0.085
            for k in 0..<12 {
                let a = CGFloat(k) * pi / 6
                let cx = sin(a) * R * 0.84, cy = -cos(a) * R * 0.84
                ctx.saveGState()
                ctx.translateBy(x: cx, y: cy)
                ring(mr)
                let u = CGFloat(k) / 12
                let sgn: CGFloat = u < 0.5 ? 1 : -1
                let tc = cos(2 * pi * u)
                let path = CGMutablePath()
                let steps = 16
                for t in 0...steps {
                    let al = pi * CGFloat(t) / CGFloat(steps)
                    let pt = CGPoint(x: sgn * mr * sin(al), y: -mr * cos(al))
                    if t == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
                }
                for t in 0...steps {
                    let al = pi - pi * CGFloat(t) / CGFloat(steps)
                    path.addLine(to: CGPoint(x: sgn * mr * tc * sin(al), y: -mr * cos(al)))
                }
                path.closeSubpath()
                ctx.setFillColor(color.cgColor)
                ctx.addPath(path)
                ctx.fillPath()
                ctx.restoreGState()
            }
            ring(R * 0.62)
            ring(R)
            dot(0, 0, R * 0.04)

        default:
            drawFestiveDecor(ctx, pattern: pattern, radius: R)
        }
    }
}
