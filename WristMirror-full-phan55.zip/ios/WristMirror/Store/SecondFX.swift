// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Hiệu ứng chuyển động theo giây: 10 ảnh, mỗi giây đồng hồ hiện một ảnh theo chữ số đơn vị của giây (0...9).
/// Cùng cơ chế "gà mổ thóc mỗi giây" trong file Kozmik Tavuk (dãy ảnh gắn mã số liệu 64).
enum SecondFX: String, CaseIterable, Identifiable {
    case none, dotChase, bloom, arc, pulse
    case comet, radar, sparkle, firework, ticks, sunburst, orbit, rainbow
    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "Không"
        case .dotChase: return "Đốm chạy"
        case .bloom: return "Hoa nở"
        case .arc: return "Cung đầy"
        case .pulse: return "Sóng lan"
        case .comet: return "Sao chổi"
        case .radar: return "Quét tia"
        case .sparkle: return "Lấp lánh"
        case .firework: return "Pháo hoa"
        case .ticks: return "Đuôi vạch"
        case .sunburst: return "Tia nắng"
        case .orbit: return "Quỹ đạo"
        case .rainbow: return "Cầu vồng"
        }
    }
    /// Mô tả ngắn hiện dưới bộ chọn kiểu.
    var detail: String {
        switch self {
        case .none: return ""
        case .dotChase: return "Mười đốm quanh viền, đốm sáng chạy theo từng giây."
        case .bloom: return "Mười hai cánh hoa lớn dần theo từng giây."
        case .arc: return "Cung sáng đầy dần quanh viền mặt."
        case .pulse: return "Hai vòng sóng lan từ tâm ra viền."
        case .comet: return "Đốm sáng có đuôi mờ dần chạy quanh viền, mỗi giây tiến một nấc."
        case .radar: return "Tia quét như radar, vệt sáng mờ dần phía sau."
        case .sparkle: return "Ngôi sao bốn cánh sáng lên lần lượt quanh viền, để lại vệt lấp lánh."
        case .firework: return "Mỗi giây một chùm pháo hoa nổ ở chỗ mới, chùm cũ tàn dần."
        case .ticks: return "Vạch giây quanh viền sáng thành vệt đuôi dài chạy quanh mặt."
        case .sunburst: return "Tia sáng nhọn loe dài dần và xoay nhẹ qua từng giây."
        case .orbit: return "Bốn hành tinh quay trên các vòng quỹ đạo đồng tâm."
        case .rainbow: return "Vòng cung bảy sắc đầy dần (kiểu này dùng màu cầu vồng, bỏ qua màu hiệu ứng)."
        }
    }
    /// Kiểu có dùng "Màu hiệu ứng" hay tự có màu riêng.
    var usesColor: Bool { self != .rainbow && self != .none }
    static let frameCount = 10
}

extension FaceRenderer {
    /// Vẽ một khung (0...9) của hiệu ứng trong toạ độ mặt đồng hồ 466x466 (gốc trên-trái).
    static func drawSecondFX(_ ctx: CGContext, style: SecondFX, color: UIColor, frame f: Int) {
        let c = center
        let n = SecondFX.frameCount
        let f = max(0, min(n - 1, f))
        ctx.saveGState()
        switch style {
        case .none:
            break
        case .dotChase:
            let r: CGFloat = 206
            for i in 0..<n {
                let a = CGFloat(i) * 2 * CGFloat.pi / CGFloat(n) - CGFloat.pi / 2
                let behind = (f - i + n) % n          // 0 = đốm đang sáng, 1 = vừa qua...
                let alpha: CGFloat = behind == 0 ? 1 : (behind <= 4 ? 0.62 - 0.14 * CGFloat(behind) : 0.12)
                let rad: CGFloat = behind == 0 ? 8 : 5.5
                ctx.setFillColor(color.withAlphaComponent(alpha).cgColor)
                ctx.fillEllipse(in: CGRect(x: c + r * cos(a) - rad, y: c + r * sin(a) - rad, width: rad * 2, height: rad * 2))
            }
        case .bloom:
            let petals = 12
            let len = 28 + CGFloat(f) * 9
            let wid = len * 0.36
            for i in 0..<petals {
                ctx.saveGState()
                ctx.translateBy(x: c, y: c)
                ctx.rotate(by: CGFloat(i) * 2 * CGFloat.pi / CGFloat(petals))
                ctx.setFillColor(color.withAlphaComponent(0.34).cgColor)
                ctx.fillEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                ctx.setStrokeColor(color.withAlphaComponent(0.55).cgColor)
                ctx.setLineWidth(1.2)
                ctx.strokeEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                ctx.restoreGState()
            }
        case .arc:
            let r: CGFloat = 207
            ctx.setLineCap(.round)
            ctx.setLineWidth(5)
            ctx.setStrokeColor(color.withAlphaComponent(0.14).cgColor)
            ctx.strokeEllipse(in: CGRect(x: c - r, y: c - r, width: r * 2, height: r * 2))
            let start = -CGFloat.pi / 2
            let end = start + CGFloat(f + 1) * 2 * CGFloat.pi / CGFloat(n)
            ctx.setStrokeColor(color.withAlphaComponent(0.95).cgColor)
            ctx.addArc(center: CGPoint(x: c, y: c), radius: r, startAngle: start, endAngle: end, clockwise: false)
            ctx.strokePath()
        case .pulse:
            for k in 0..<2 {
                let t = (CGFloat(f) + CGFloat(k) * CGFloat(n) / 2).truncatingRemainder(dividingBy: CGFloat(n)) / CGFloat(n)
                let r = 24 + t * 182
                let alpha = (1 - t) * 0.8
                ctx.setLineWidth(3.5 - 1.5 * t)
                ctx.setStrokeColor(color.withAlphaComponent(alpha).cgColor)
                ctx.strokeEllipse(in: CGRect(x: c - r, y: c - r, width: r * 2, height: r * 2))
            }
        case .comet, .radar, .sparkle, .firework, .ticks, .sunburst, .orbit, .rainbow:
            drawSecondFXExtra(ctx, style: style, color: color, frame: f)
        }
        ctx.restoreGState()
    }

    // MARK: Hàm phụ cho các hiệu ứng giây nâng cao

    private static func fxPoint(_ angle: CGFloat, _ r: CGFloat) -> CGPoint {
        CGPoint(x: center + r * cos(angle), y: center + r * sin(angle))
    }

    /// Quầng sáng tròn mờ dần ra rìa.
    private static func fxGlow(_ ctx: CGContext, at p: CGPoint, radius: CGFloat, color: UIColor, alpha: CGFloat) {
        let colors = [color.withAlphaComponent(alpha).cgColor, color.withAlphaComponent(0).cgColor] as CFArray
        let locs: [CGFloat] = [0, 1]
        guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: locs) else { return }
        ctx.drawRadialGradient(g, startCenter: p, startRadius: 0, endCenter: p, endRadius: radius, options: [])
    }

    /// Ngôi sao bốn cánh cong (kiểu lấp lánh).
    private static func fxStar(_ ctx: CGContext, at p: CGPoint, length L: CGFloat, color: UIColor, alpha: CGFloat) {
        let w = L * 0.14
        let path = CGMutablePath()
        path.move(to: CGPoint(x: p.x, y: p.y - L))
        path.addQuadCurve(to: CGPoint(x: p.x + L, y: p.y), control: CGPoint(x: p.x + w, y: p.y - w))
        path.addQuadCurve(to: CGPoint(x: p.x, y: p.y + L), control: CGPoint(x: p.x + w, y: p.y + w))
        path.addQuadCurve(to: CGPoint(x: p.x - L, y: p.y), control: CGPoint(x: p.x - w, y: p.y + w))
        path.addQuadCurve(to: CGPoint(x: p.x, y: p.y - L), control: CGPoint(x: p.x - w, y: p.y - w))
        path.closeSubpath()
        ctx.addPath(path)
        ctx.setFillColor(color.withAlphaComponent(alpha).cgColor)
        ctx.fillPath()
    }

    /// Cung tròn tâm giữa mặt, luôn vẽ theo chiều tăng góc (a0 < a1).
    private static func fxArc(_ ctx: CGContext, radius: CGFloat, from a0: CGFloat, to a1: CGFloat) {
        ctx.addArc(center: CGPoint(x: center, y: center), radius: radius,
                   startAngle: min(a0, a1), endAngle: max(a0, a1), clockwise: false)
    }

    private static func drawSecondFXExtra(_ ctx: CGContext, style: SecondFX, color: UIColor, frame f: Int) {
        let c = center
        let n = SecondFX.frameCount
        let pi = CGFloat.pi
        let step = 2 * pi / CGFloat(n)
        let head = CGFloat(f) * step - pi / 2           // góc của đầu hiệu ứng ở khung f
        switch style {
        case .comet:
            // Sao chổi: đuôi 44 đoạn thon dần + đầu sáng có quầng
            let r: CGFloat = 206
            let span: CGFloat = 2.2
            let segs = 44
            ctx.setLineCap(.round)
            for i in 0..<segs {
                let t0 = CGFloat(i) / CGFloat(segs)
                let t1 = CGFloat(i + 1) / CGFloat(segs)
                ctx.setLineWidth(1.5 + 9 * t1)
                ctx.setStrokeColor(color.withAlphaComponent(CGFloat(pow(Double(t1), 1.6)) * 0.92).cgColor)
                fxArc(ctx, radius: r, from: head - span * (1 - t0), to: head - span * (1 - t1))
                ctx.strokePath()
            }
            let p = fxPoint(head, r)
            fxGlow(ctx, at: p, radius: 30, color: color, alpha: 0.85)
            ctx.setFillColor(UIColor.white.withAlphaComponent(0.96).cgColor)
            ctx.fillEllipse(in: CGRect(x: p.x - 6, y: p.y - 6, width: 12, height: 12))
        case .radar:
            // Quét tia: hình quạt mờ dần phía sau tia dẫn
            let span: CGFloat = 1.25
            let segs = 30
            for i in 0..<segs {
                let t0 = CGFloat(i) / CGFloat(segs)
                let t1 = CGFloat(i + 1) / CGFloat(segs)
                ctx.move(to: CGPoint(x: c, y: c))
                ctx.addArc(center: CGPoint(x: c, y: c), radius: 224,
                           startAngle: head - span * (1 - t0), endAngle: head - span * (1 - t1) + 0.004, clockwise: false)
                ctx.closePath()
                ctx.setFillColor(color.withAlphaComponent(t1 * t1 * 0.5).cgColor)
                ctx.fillPath()
            }
            ctx.setLineCap(.round)
            ctx.setLineWidth(2.2)
            ctx.setStrokeColor(color.withAlphaComponent(0.95).cgColor)
            ctx.move(to: CGPoint(x: c, y: c))
            ctx.addLine(to: fxPoint(head, 224))
            ctx.strokePath()
            fxGlow(ctx, at: fxPoint(head, 206), radius: 22, color: color, alpha: 0.7)
        case .sparkle:
            // Lấp lánh: 10 vị trí quanh viền, sao lớn ở vị trí hiện tại, vệt nhỏ dần phía sau
            let r: CGFloat = 200
            for i in 0..<n {
                let p = fxPoint(CGFloat(i) * step - pi / 2 + step / 2, r)
                let behind = (f - i + n) % n
                switch behind {
                case 0:
                    fxGlow(ctx, at: p, radius: 36, color: color, alpha: 0.7)
                    fxStar(ctx, at: p, length: 30, color: color, alpha: 0.95)
                    fxStar(ctx, at: p, length: 13, color: UIColor.white, alpha: 1)
                case 1, 2, 3:
                    let k = CGFloat(behind)
                    fxStar(ctx, at: p, length: 20 - 4 * k, color: color, alpha: 0.7 - 0.17 * k)
                default:
                    ctx.setFillColor(color.withAlphaComponent(0.28).cgColor)
                    ctx.fillEllipse(in: CGRect(x: p.x - 2.5, y: p.y - 2.5, width: 5, height: 5))
                }
            }
        case .firework:
            // Pháo hoa: chùm mới nổ + hai chùm cũ đang tàn (mỗi giây nổ ở chỗ khác)
            let sparks = 16
            let inner: [CGFloat] = [20, 40, 56]
            let outer: [CGFloat] = [62, 70, 78]
            let alphas: [CGFloat] = [1.0, 0.5, 0.2]
            ctx.setLineCap(.round)
            for k in 0..<3 {
                let idx = (f - k + n) % n
                let a = CGFloat(idx) * step - pi / 2 + (idx % 2 == 0 ? 0 : step / 2)
                let o = fxPoint(a, idx % 2 == 0 ? 122 : 86)
                if k == 0 {
                    fxGlow(ctx, at: o, radius: 70, color: color, alpha: 0.5)
                }
                ctx.setLineWidth(2.6 - 0.6 * CGFloat(k))
                ctx.setStrokeColor(color.withAlphaComponent(alphas[k]).cgColor)
                ctx.setFillColor(UIColor.white.withAlphaComponent(alphas[k]).cgColor)
                for s in 0..<sparks {
                    let ang = CGFloat(s) * 2 * pi / CGFloat(sparks) + CGFloat(idx) * 0.2
                    let ca = cos(ang), sa = sin(ang)
                    if k == 0 {
                        ctx.move(to: CGPoint(x: o.x + ca * inner[k], y: o.y + sa * inner[k]))
                        ctx.addLine(to: CGPoint(x: o.x + ca * outer[k], y: o.y + sa * outer[k]))
                        ctx.strokePath()
                    }
                    let tip = CGPoint(x: o.x + ca * outer[k], y: o.y + sa * outer[k])
                    let rad = 3.2 - 0.8 * CGFloat(k)
                    ctx.fillEllipse(in: CGRect(x: tip.x - rad, y: tip.y - rad, width: rad * 2, height: rad * 2))
                }
            }
        case .ticks:
            // Đuôi vạch: 60 vạch giây, vạch đầu dài và sáng, đuôi mờ dần 30 vạch
            let count = 60
            let headIdx = f * 6 + 3
            ctx.setLineCap(.round)
            for j in 0..<count {
                let a = CGFloat(j) * 2 * pi / CGFloat(count) - pi / 2
                let behind = (headIdx - j + count) % count
                let t = max(0, 1 - CGFloat(behind) / 30)
                let isHead = behind == 0
                let inner: CGFloat = 196 - (isHead ? 8 : 0) - 6 * t
                ctx.setLineWidth(isHead ? 5 : 2.6 + 1.6 * t)
                ctx.setStrokeColor(color.withAlphaComponent(0.14 + 0.86 * CGFloat(pow(Double(t), 1.4))).cgColor)
                ctx.move(to: fxPoint(a, inner))
                ctx.addLine(to: fxPoint(a, 218))
                ctx.strokePath()
            }
            fxGlow(ctx, at: fxPoint(CGFloat(headIdx) * 2 * pi / CGFloat(count) - pi / 2, 207), radius: 26, color: color, alpha: 0.6)
        case .sunburst:
            // Tia nắng: 24 tia nhọn mờ dần ra đầu, dài thêm mỗi giây và xoay nhẹ
            let rays = 24
            let colors = [color.withAlphaComponent(0.9).cgColor, color.withAlphaComponent(0).cgColor] as CFArray
            let locs: [CGFloat] = [0, 1]
            guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: locs) else { break }
            let rot = CGFloat(f) * 0.07
            let mid = CGPoint(x: c, y: c)
            for i in 0..<rays {
                let long = i % 2 == 0
                let len: CGFloat = (long ? 60 : 38) + CGFloat(f) * (long ? 13 : 8)
                let a = CGFloat(i) * 2 * pi / CGFloat(rays) + rot
                let half: CGFloat = long ? 0.09 : 0.065
                let path = CGMutablePath()
                path.move(to: fxPoint(a - half, 26))
                path.addLine(to: fxPoint(a, 26 + len))
                path.addLine(to: fxPoint(a + half, 26))
                path.closeSubpath()
                ctx.saveGState()
                ctx.addPath(path)
                ctx.clip()
                ctx.drawRadialGradient(g, startCenter: mid, startRadius: 26, endCenter: mid, endRadius: 26 + len, options: [])
                ctx.restoreGState()
            }
        case .orbit:
            // Quỹ đạo: 4 vòng đồng tâm, mỗi vòng một hành tinh có vệt đuôi (số vòng quay nguyên nên lặp mượt)
            let radii: [CGFloat] = [70, 118, 166, 208]
            let sizes: [CGFloat] = [6, 7, 8, 9]
            let turns: [CGFloat] = [3, -2, 1, 1]
            let offsets: [CGFloat] = [0, 2.1, 4.2, 1.0]
            ctx.setLineWidth(1.2)
            for k in 0..<4 {
                ctx.setStrokeColor(color.withAlphaComponent(0.13).cgColor)
                ctx.strokeEllipse(in: CGRect(x: c - radii[k], y: c - radii[k], width: radii[k] * 2, height: radii[k] * 2))
            }
            ctx.setLineCap(.round)
            for k in 0..<4 {
                let sign: CGFloat = turns[k] < 0 ? -1 : 1
                let a = -pi / 2 + CGFloat(f) * step * turns[k] + offsets[k]
                let segs = 10
                for i in 0..<segs {
                    let t0 = CGFloat(i) / CGFloat(segs)
                    let t1 = CGFloat(i + 1) / CGFloat(segs)
                    ctx.setLineWidth(1 + (sizes[k] - 2) * t1)
                    ctx.setStrokeColor(color.withAlphaComponent(t1 * 0.6).cgColor)
                    fxArc(ctx, radius: radii[k], from: a - sign * 0.9 * (1 - t0), to: a - sign * 0.9 * (1 - t1))
                    ctx.strokePath()
                }
                let p = fxPoint(a, radii[k])
                fxGlow(ctx, at: p, radius: sizes[k] * 3.2, color: color, alpha: 0.7)
                ctx.setFillColor(UIColor.white.withAlphaComponent(0.95).cgColor)
                ctx.fillEllipse(in: CGRect(x: p.x - sizes[k] / 2, y: p.y - sizes[k] / 2, width: sizes[k], height: sizes[k]))
            }
        case .rainbow:
            // Cầu vồng: 10 đoạn cung mỗi đoạn một sắc, đầy dần theo giây (không dùng màu hiệu ứng)
            let r: CGFloat = 206
            ctx.setLineCap(.butt)
            for i in 0..<n {
                let lit = i <= f
                let col = UIColor(hue: CGFloat(i) / CGFloat(n), saturation: 0.85, brightness: 1,
                                  alpha: lit ? (i == f ? 1 : 0.85) : 0.13)
                ctx.setLineWidth(lit ? (i == f ? 12 : 9) : 6)
                ctx.setStrokeColor(col.cgColor)
                fxArc(ctx, radius: r, from: CGFloat(i) * step - pi / 2 + 0.03, to: CGFloat(i + 1) * step - pi / 2 - 0.03)
                ctx.strokePath()
            }
            let tipColor = UIColor(hue: CGFloat(f) / CGFloat(n), saturation: 0.5, brightness: 1, alpha: 1)
            fxGlow(ctx, at: fxPoint(CGFloat(f + 1) * step - pi / 2 - 0.03, r), radius: 26, color: tipColor, alpha: 0.8)
        default:
            break
        }
    }

    /// 10 ảnh toàn mặt (466x466, nền trong suốt) dùng cho lớp dãy ảnh mã 64.
    static func secondFXFrames(_ d: FaceDesign) -> [HwtRaster] {
        guard d.secondFX != .none else { return [] }
        let side = Int(size)
        let color = UIColor(d.secondFXColor)
        return (0..<SecondFX.frameCount).map { f in
            drawRaster(width: side, height: side) { ctx in
                drawSecondFX(ctx, style: d.secondFX, color: color, frame: f)
            }
        }
    }

    /// Như `secondFXFrames` nhưng cắt về hộp nhỏ nhất chứa mọi điểm không trong suốt của cả 10 khung
    /// (ví dụ "Hoa nở" chỉ cần ~230x230 thay vì 466x466: nhẹ hơn ~4 lần trên đồng hồ).
    static func secondFXCropped(_ d: FaceDesign) -> (x: Int, y: Int, frames: [HwtRaster]) {
        let full = secondFXFrames(d)
        guard let first = full.first else { return (0, 0, []) }
        let w = first.width, h = first.height
        var minX = w, minY = h, maxX = -1, maxY = -1
        for r in full {
            for y in 0..<h {
                let row = y * w
                for x in 0..<w where (r.argb[row + x] >> 24) != 0 {
                    if x < minX { minX = x }
                    if x > maxX { maxX = x }
                    if y < minY { minY = y }
                    if y > maxY { maxY = y }
                }
            }
        }
        guard maxX >= minX, maxY >= minY else { return (0, 0, full) }
        minX = max(0, minX - 2); minY = max(0, minY - 2)
        maxX = min(w - 1, maxX + 2); maxY = min(h - 1, maxY + 2)
        let cw = maxX - minX + 1, ch = maxY - minY + 1
        let frames: [HwtRaster] = full.map { r in
            var out = [UInt32]()
            out.reserveCapacity(cw * ch)
            for y in minY...maxY {
                let base = y * w
                out.append(contentsOf: r.argb[(base + minX)...(base + maxX)])
            }
            return HwtRaster(width: cw, height: ch, argb: out)
        }
        return (minX, minY, frames)
    }

    /// Ảnh thô (MB) của hiệu ứng giây sau khi cắt.
    static func secondFXRawMegabytes(_ d: FaceDesign) -> Double {
        let c = secondFXCropped(d)
        return Double(c.frames.reduce(0) { $0 + $1.width * $1.height * 4 }) / 1_048_576
    }

    /// Ảnh thô (MB) của hoạt ảnh xoay: 24 khung vuông cạnh `decorSide`.
    static func animSpinRawMegabytes(_ d: FaceDesign) -> Double {
        let side = decorSide(animLayer(d))
        return Double(side * side * 4 * AnimFX.frameCount) / 1_048_576
    }
}
