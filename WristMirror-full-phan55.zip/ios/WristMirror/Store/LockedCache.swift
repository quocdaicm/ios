// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Bộ nhớ đệm có khoá, an toàn khi vừa dựng xem trước ở luồng nền vừa vẽ hình nhỏ ở luồng chính.
final class LockedCache<Key: Hashable, Value> {
    private var storage = [Key: Value]()
    private let lock = NSLock()

    subscript(key: Key) -> Value? {
        get { lock.lock(); defer { lock.unlock() }; return storage[key] }
        set { lock.lock(); defer { lock.unlock() }; storage[key] = newValue }
    }
}
