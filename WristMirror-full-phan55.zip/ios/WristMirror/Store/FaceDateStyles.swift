// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Kiểu số + nhãn chữ vector cho khối ngày/tháng (Dương lịch "D lịch" / "Solar", Âm lịch "Â lịch" / "Lunar").
// Dùng chung bộ 17 kiểu số của giờ số (FaceDigitalStyles.swift) cho chữ số và dấu ngăn "/" hoặc "-";
// nhãn chữ được đổi thành path (CoreText) rồi tô cùng kiểu (phẳng / kim loại / quầng sáng) nên là hình vector, không cần font trên đồng hồ.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Nhãn chữ vector

enum DateLabelShapes {
    struct Shape {
        /// Path chữ (cỡ chữ 100, tâm hộp bao ở gốc, y hướng xuống).
        let path: CGPath
        let w: CGFloat
        let h: CGFloat
    }

    private static let cache = LockedCache<String, Shape>()
    private static let lock = NSLock()

    /// Kiểu chữ nhãn: 0 đậm, 1 tròn, 2 có chân, 3 nghiêng, 4 đơn cách, 5 mảnh.
    static let fontTitles = ["Đậm", "Tròn", "Có chân", "Nghiêng", "Đơn cách", "Mảnh"]

    static func font(_ idx: Int) -> UIFont {
        let base = UIFont.systemFont(ofSize: 100, weight: .bold)
        func design(_ d: UIFontDescriptor.SystemDesign, _ w: UIFont.Weight) -> UIFont {
            let f = UIFont.systemFont(ofSize: 100, weight: w)
            if let desc = f.fontDescriptor.withDesign(d) { return UIFont(descriptor: desc, size: 100) }
            return f
        }
        switch idx {
        case 1: return design(.rounded, .heavy)
        case 2: return design(.serif, .bold)
        case 3:
            if let desc = base.fontDescriptor.withSymbolicTraits([.traitBold, .traitItalic]) { return UIFont(descriptor: desc, size: 100) }
            return UIFont.italicSystemFont(ofSize: 100)
        case 4: return UIFont.monospacedSystemFont(ofSize: 100, weight: .bold)
        case 5: return UIFont.systemFont(ofSize: 100, weight: .light)
        default: return base
        }
    }

    static func shape(_ text: String, font idx: Int = 0) -> Shape {
        lock.lock()
        defer { lock.unlock() }
        let key = "\(idx)|\(text)"
        if let c = cache[key] { return c }
        let path = NumeralShapes.textPath(text.precomposedStringWithCanonicalMapping, font: font(idx))
        let b = path.boundingBox
        let s = Shape(path: path, w: b.isNull ? 0 : b.width, h: b.isNull ? 0 : b.height)
        cache[key] = s
        return s
    }

    /// Bốn nhãn có sẵn: tiếng Việt và tiếng Anh, dương lịch và âm lịch.
    static let allLabels = ["D lịch", "Â lịch", "Solar", "Lunar"]
}

// MARK: - Hình thu nhỏ trong bộ chọn kiểu ngày/tháng

enum DateThumbs {
    static let size = CGSize(width: 240, height: 96)
    private static let cache = LockedCache<String, UIImage>()
    private static let lock = NSLock()

    /// Hình "nhãn + 26/11" (hoặc "26-11") theo kiểu số `st`. `lang`: 0 theo app, 1 Việt, 2 Anh.
    static func image(_ st: DigitalStyle, lunar: Bool, sep: Int, lang: Int, font fi: Int = 0) -> UIImage {
        let label = FaceRenderer.dateLabelString(lunar: lunar, lang: lang)
        let sepStr = FaceRenderer.dateSepString(sep)
        let key = "\(st.rawValue)|\(label)|\(sepStr)|\(fi)"
        lock.lock()
        if let c = cache[key] { lock.unlock(); return c }
        lock.unlock()

        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(origin: .zero, size: size))
            let ctx = c.cgContext
            let text = "26" + sepStr + "11"
            if let def = st.def {
                let k: CGFloat = 1.4
                let cl = DigitalShapes.cells(def, scale: k, base: 26)
                let shape = DateLabelShapes.shape(label, font: fi)
                let ls = 17 * k / 100
                let lpad = def.paint == .glow ? 6 : 3
                let lw = Int(ceil(shape.w * ls)) + 2 * lpad
                let lh = Int(ceil(shape.h * ls)) + 2 * lpad
                let total = cl.digitW * 4 + cl.sepW
                let blockH = CGFloat(lh + cl.lineH)
                let top = (size.height - blockH) / 2
                DigitalShapes.drawLabel(ctx, def: def, shape: shape.path, scale: ls,
                                        in: CGRect(x: (size.width - CGFloat(lw)) / 2, y: top, width: CGFloat(lw), height: CGFloat(lh)),
                                        color: .white, own: true)
                var x = (size.width - CGFloat(total)) / 2
                for ch in text {
                    let w = (ch == "/" || ch == "-") ? cl.sepW : cl.digitW
                    DigitalShapes.draw(ctx, def: def, char: ch,
                                       in: CGRect(x: x, y: top + CGFloat(lh), width: CGFloat(w), height: CGFloat(cl.lineH)),
                                       pad: CGFloat(cl.pad), color: .white, own: true)
                    x += CGFloat(w)
                }
            } else {
                let numFont = UIFont.monospacedDigitSystemFont(ofSize: 38, weight: .bold)
                let labFont = UIFont.systemFont(ofSize: 20, weight: .bold)
                let na: [NSAttributedString.Key: Any] = [.font: numFont, .foregroundColor: UIColor.white]
                let la: [NSAttributedString.Key: Any] = [.font: labFont, .foregroundColor: UIColor.white]
                let ns = (text as NSString).size(withAttributes: na)
                let ls = (label as NSString).size(withAttributes: la)
                let top = (size.height - ns.height - ls.height) / 2
                (label as NSString).draw(at: CGPoint(x: (size.width - ls.width) / 2, y: top), withAttributes: la)
                (text as NSString).draw(at: CGPoint(x: (size.width - ns.width) / 2, y: top + ls.height), withAttributes: na)
            }
        }
        lock.lock()
        cache[key] = img
        lock.unlock()
        return img
    }
}
