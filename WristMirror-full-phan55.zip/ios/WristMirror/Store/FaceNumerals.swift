// Số giờ vector: 32 kiểu (Ả Rập/La Mã/Hán/Ả Rập cổ, vàng-bạc-hồng, 4 số, xoay theo vòng, huy hiệu tròn/thoi,
// ngọc, viền rỗng, dạ quang phát sáng...). Chữ được chuyển thành path (CoreText) rồi tô dải màu kim loại.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit
import CoreText

/// Tên case (rawValue) phải trùng khoá trong `NumeralShapes.table`; `.classic` = kiểu cũ (số thường theo font số).
enum NumeralStyle: String, CaseIterable, Identifiable {
    case classic
    case arabicGold, arabicSilver, arabicRose, romanGold, romanSilver, romanRose, roman, cardinalGold, cardinalSilver, cardinal, radialGold, radialSilver, outline, outlineGold, badgeGold, badgeSilver, badgeRose, diamondGold, diamondSilver, gemBlue, gemRuby, lumeMint, lumeGreen, lumeBlue, lumeAqua, lumePurple, lumeOrange, chineseGold, chinese, indicGold, future, sportSilver
    var id: String { rawValue }
    var title: String { self == .classic ? "Số thường" : (NumeralShapes.titles[rawValue] ?? rawValue) }
    var def: NumeralShapes.Def? { NumeralShapes.table[rawValue] }
    /// Có bảng màu riêng (kim loại, ngọc, dạ quang) - tắt "màu gốc" thì suy ra từ màu vạch giờ.
    var hasOwnPalette: Bool { def?.pal != nil }
}

enum NumeralShapes {
    struct Def {
        enum Glyphs { case arabic, roman, chinese, indic, cardinal }
        enum Paint { case flat, metal, glow, outline }
        enum Layout { case upright, radial, circle, diamond }
        var glyphs: Glyphs
        var paint: Paint
        var layout: Layout = .upright
        var pal: HandPal? = nil
        var font: FaceFont? = nil
        var weight: UIFont.Weight = .semibold
        var italic = false
        var size: CGFloat = 44
    }

    static let table: [String: Def] = {
        var t = [String: Def]()
        t["arabicGold"] = Def(glyphs: .arabic, paint: .metal, pal: HP.gold, weight: .bold)
        t["arabicSilver"] = Def(glyphs: .arabic, paint: .metal, pal: HP.silver, weight: .bold)
        t["arabicRose"] = Def(glyphs: .arabic, paint: .metal, pal: HP.rose, weight: .bold)
        t["romanGold"] = Def(glyphs: .roman, paint: .metal, pal: HP.gold, font: .serif, weight: .bold, size: 38)
        t["romanSilver"] = Def(glyphs: .roman, paint: .metal, pal: HP.silver, font: .serif, weight: .bold, size: 38)
        t["romanRose"] = Def(glyphs: .roman, paint: .metal, pal: HP.rose, font: .serif, weight: .bold, size: 38)
        t["roman"] = Def(glyphs: .roman, paint: .flat, font: .serif, size: 38)
        t["cardinalGold"] = Def(glyphs: .cardinal, paint: .metal, pal: HP.gold, weight: .bold, size: 58)
        t["cardinalSilver"] = Def(glyphs: .cardinal, paint: .metal, pal: HP.silver, weight: .bold, size: 58)
        t["cardinal"] = Def(glyphs: .cardinal, paint: .flat, weight: .bold, size: 58)
        t["radialGold"] = Def(glyphs: .arabic, paint: .metal, layout: .radial, pal: HP.gold, weight: .bold, size: 38)
        t["radialSilver"] = Def(glyphs: .arabic, paint: .metal, layout: .radial, pal: HP.silver, weight: .bold, size: 38)
        t["outline"] = Def(glyphs: .arabic, paint: .outline, size: 46)
        t["outlineGold"] = Def(glyphs: .arabic, paint: .outline, pal: HP.gold, size: 46)
        t["badgeGold"] = Def(glyphs: .arabic, paint: .metal, layout: .circle, pal: HP.gold, weight: .bold, size: 30)
        t["badgeSilver"] = Def(glyphs: .arabic, paint: .metal, layout: .circle, pal: HP.silver, weight: .bold, size: 30)
        t["badgeRose"] = Def(glyphs: .arabic, paint: .metal, layout: .circle, pal: HP.rose, weight: .bold, size: 30)
        t["diamondGold"] = Def(glyphs: .arabic, paint: .metal, layout: .diamond, pal: HP.gold, weight: .bold, size: 26)
        t["diamondSilver"] = Def(glyphs: .arabic, paint: .metal, layout: .diamond, pal: HP.silver, weight: .bold, size: 26)
        t["gemBlue"] = Def(glyphs: .arabic, paint: .metal, pal: HP.sapphire, weight: .heavy)
        t["gemRuby"] = Def(glyphs: .arabic, paint: .metal, pal: HP.ruby, weight: .heavy)
        t["lumeMint"] = Def(glyphs: .arabic, paint: .glow, pal: HP.mint, weight: .bold)
        t["lumeGreen"] = Def(glyphs: .arabic, paint: .glow, pal: HP.green, weight: .bold)
        t["lumeBlue"] = Def(glyphs: .arabic, paint: .glow, pal: HP.lblue, weight: .bold)
        t["lumeAqua"] = Def(glyphs: .arabic, paint: .glow, pal: HP.aqua, weight: .bold)
        t["lumePurple"] = Def(glyphs: .arabic, paint: .glow, pal: HP.purple, weight: .bold)
        t["lumeOrange"] = Def(glyphs: .arabic, paint: .glow, pal: HP.orange, weight: .bold)
        t["chineseGold"] = Def(glyphs: .chinese, paint: .metal, pal: HP.gold, weight: .bold, size: 40)
        t["chinese"] = Def(glyphs: .chinese, paint: .flat, weight: .bold, size: 40)
        t["indicGold"] = Def(glyphs: .indic, paint: .metal, pal: HP.gold, weight: .bold)
        t["future"] = Def(glyphs: .arabic, paint: .glow, pal: HP.future, font: .avenirCondensed, weight: .light, size: 46)
        t["sportSilver"] = Def(glyphs: .arabic, paint: .metal, pal: HP.silver, weight: .heavy, italic: true)
        return t
    }()

    static let titles: [String: String] = [
        "arabicGold": "Ả Rập Vàng",
        "arabicSilver": "Ả Rập Bạc",
        "arabicRose": "Ả Rập Hồng",
        "romanGold": "La Mã Vàng",
        "romanSilver": "La Mã Bạc",
        "romanRose": "La Mã Hồng",
        "roman": "La Mã",
        "cardinalGold": "4 Số Vàng",
        "cardinalSilver": "4 Số Bạc",
        "cardinal": "4 Số",
        "radialGold": "Xoay Vàng",
        "radialSilver": "Xoay Bạc",
        "outline": "Viền Rỗng",
        "outlineGold": "Viền Vàng",
        "badgeGold": "Tròn Vàng",
        "badgeSilver": "Tròn Bạc",
        "badgeRose": "Tròn Hồng",
        "diamondGold": "Thoi Vàng",
        "diamondSilver": "Thoi Bạc",
        "gemBlue": "Ngọc Xanh",
        "gemRuby": "Ngọc Đỏ",
        "lumeMint": "Dạ Quang",
        "lumeGreen": "Dạ Quang Lá",
        "lumeBlue": "Dạ Quang Xanh",
        "lumeAqua": "Dạ Quang Ngọc",
        "lumePurple": "Dạ Quang Tím",
        "lumeOrange": "Dạ Quang Cam",
        "chineseGold": "Hán Vàng",
        "chinese": "Hán Tự",
        "indicGold": "Ả Rập Cổ",
        "future": "Tương Lai",
        "sportSilver": "Thể Thao"
    ]

    private static let roman = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
    private static let chinese = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"]
    private static let indicDigits: [Character: String] = ["0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤",
                                                          "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩"]

    private static func label(_ g: Def.Glyphs, _ n: Int) -> String {
        switch g {
        case .arabic, .cardinal: return "\(n)"
        case .roman: return roman[n - 1]
        case .chinese: return chinese[n - 1]
        case .indic: return String("\(n)".map { indicDigits[$0] ?? String($0) }.joined())
        }
    }

    /// Chữ → path (gốc ở tâm hộp bao, trục y hướng xuống như ngữ cảnh UIKit).
    static func textPath(_ s: String, font: UIFont) -> CGPath {
        let path = CGMutablePath()
        let line = CTLineCreateWithAttributedString(NSAttributedString(string: s, attributes: [.font: font]))
        let runs = (CTLineGetGlyphRuns(line) as? [CTRun]) ?? []
        for run in runs {
            let n = CTRunGetGlyphCount(run)
            if n == 0 { continue }
            let attrs = CTRunGetAttributes(run) as NSDictionary
            let runFont: CTFont = (attrs[kCTFontAttributeName as String] as! CTFont?) ?? (font as CTFont)
            var glyphs = [CGGlyph](repeating: 0, count: n)
            var pos = [CGPoint](repeating: .zero, count: n)
            CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
            CTRunGetPositions(run, CFRange(location: 0, length: 0), &pos)
            for i in 0..<n {
                if let gp = CTFontCreatePathForGlyph(runFont, glyphs[i], nil) {
                    path.addPath(gp, transform: CGAffineTransform(translationX: pos[i].x, y: pos[i].y))
                }
            }
        }
        let b = path.boundingBox
        guard !b.isNull, !b.isEmpty else { return path }
        var t = CGAffineTransform(translationX: -b.midX, y: -b.midY).concatenating(CGAffineTransform(scaleX: 1, y: -1))
        return path.copy(using: &t) ?? path
    }

    private static func gradient(_ ctx: CGContext, _ colors: [UIColor], _ stops: [CGFloat], from: CGPoint, to: CGPoint) {
        guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors.map { $0.cgColor } as CFArray,
                                 locations: stops) else { return }
        ctx.drawLinearGradient(g, start: from, end: to, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    /// Tô một path theo kiểu của số (dải kim loại, quầng sáng, viền hoặc màu phẳng).
    private static func paint(_ ctx: CGContext, _ path: CGPath, _ d: Def, pal: HandPal?, color: UIColor, glow: Bool) {
        let bb = path.boundingBox
        switch d.paint {
        case .flat:
            ctx.addPath(path)
            ctx.setFillColor(color.cgColor)
            ctx.fillPath()
        case .outline:
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.addPath(path)
            ctx.setStrokeColor((pal?.light ?? color).cgColor)
            ctx.setLineWidth(2.2)
            ctx.strokePath()
            ctx.restoreGState()
        case .metal:
            guard let p = pal else { return }
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.addPath(path)
            ctx.setStrokeColor(p.deep.withAlphaComponent(0.85).cgColor)
            ctx.setLineWidth(1.6)
            ctx.strokePath()
            ctx.restoreGState()
            ctx.saveGState()
            ctx.addPath(path)
            ctx.clip()
            gradient(ctx, [p.hi, p.light, p.mid, p.dark], [0, 0.3, 0.62, 1],
                     from: CGPoint(x: 0, y: bb.minY), to: CGPoint(x: 0, y: bb.maxY))
            ctx.restoreGState()
        case .glow:
            guard let p = pal else { return }
            if glow {
                ctx.saveGState()
                ctx.setShadow(offset: .zero, blur: 9, color: p.light.withAlphaComponent(0.95).cgColor)
                ctx.addPath(path)
                ctx.setFillColor(p.mid.cgColor)
                ctx.fillPath()
                ctx.restoreGState()
            }
            ctx.saveGState()
            ctx.addPath(path)
            ctx.clip()
            gradient(ctx, [p.hi, p.light, p.mid], [0, 0.45, 1],
                     from: CGPoint(x: 0, y: bb.minY), to: CGPoint(x: 0, y: bb.maxY))
            ctx.restoreGState()
        }
    }

    private static func tube(_ ctx: CGContext, _ path: CGPath, width: CGFloat, pal: HandPal) {
        ctx.saveGState()
        ctx.setLineJoin(.round)
        ctx.addPath(path)
        ctx.setStrokeColor(pal.deep.withAlphaComponent(0.85).cgColor)
        ctx.setLineWidth(width + 1.2)
        ctx.strokePath()
        ctx.addPath(path)
        ctx.setStrokeColor(pal.mid.cgColor)
        ctx.setLineWidth(width)
        ctx.strokePath()
        ctx.addPath(path)
        ctx.setStrokeColor(pal.hi.withAlphaComponent(0.85).cgColor)
        ctx.setLineWidth(max(0.6, width * 0.32))
        ctx.strokePath()
        ctx.restoreGState()
    }

    /// Vẽ 12 số giờ quanh tâm mặt (ctx đã dời gốc về tâm, y hướng xuống).
    static func draw(_ ctx: CGContext, def d: Def, color: UIColor, own: Bool, numberFont: FaceFont) {
        let pal: HandPal? = d.pal.map { own ? $0 : HandPal.derive(color) }
        let glow = own
        var font = (d.font ?? numberFont).text(d.size, d.weight)
        if d.italic, let dsc = font.fontDescriptor.withSymbolicTraits(.traitItalic) {
            font = UIFont(descriptor: dsc, size: d.size)
        }
        let limit: CGFloat = 208
        let base: CGFloat = 182
        let cardinalHours: Set<Int> = [12, 3, 6, 9]

        for n in 1...12 {
            let a = CGFloat(n) * CGFloat.pi / 6
            let ux = sin(a), uy = -cos(a)
            if d.glyphs == .cardinal && !cardinalHours.contains(n) {
                // Giờ còn lại: chấm tròn kim loại
                let rad: CGFloat = 6.5
                let dot = CGMutablePath()
                dot.addEllipse(in: CGRect(x: -rad, y: -rad, width: rad * 2, height: rad * 2))
                ctx.saveGState()
                ctx.translateBy(x: ux * 194, y: uy * 194)
                paint(ctx, dot, Def(glyphs: .arabic, paint: d.paint == .flat ? .flat : .metal, pal: d.pal), pal: pal, color: color, glow: glow)
                ctx.restoreGState()
                continue
            }
            let path = textPath(label(d.glyphs, n), font: font)
            let bb = path.boundingBox
            var halfW = bb.width / 2, halfH = bb.height / 2
            var badge: CGFloat = 0
            if d.layout == .circle || d.layout == .diamond {
                badge = d.size * (d.layout == .circle ? 0.80 : 1.05)
                halfW = badge; halfH = badge
            }
            let ext: CGFloat
            if d.layout == .radial { ext = halfH } else { ext = abs(ux) * halfW + abs(uy) * halfH }
            let r = min(base + (badge > 0 ? 4 : 0), limit - ext)

            ctx.saveGState()
            ctx.translateBy(x: ux * r, y: uy * r)
            if d.layout == .radial { ctx.rotate(by: cos(a) < -0.01 ? a + CGFloat.pi : a) }
            if badge > 0, let p = pal {
                let shape = CGMutablePath()
                if d.layout == .circle {
                    shape.addEllipse(in: CGRect(x: -badge, y: -badge, width: badge * 2, height: badge * 2))
                } else {
                    shape.move(to: CGPoint(x: 0, y: -badge))
                    shape.addLine(to: CGPoint(x: badge * 0.82, y: 0))
                    shape.addLine(to: CGPoint(x: 0, y: badge))
                    shape.addLine(to: CGPoint(x: -badge * 0.82, y: 0))
                    shape.closeSubpath()
                }
                ctx.saveGState()
                ctx.addPath(shape)
                ctx.clip()
                gradient(ctx, [p.dark.withAlphaComponent(0.55), UIColor.black.withAlphaComponent(0.85)], [0, 1],
                         from: CGPoint(x: 0, y: -badge), to: CGPoint(x: 0, y: badge))
                ctx.restoreGState()
                tube(ctx, shape, width: 2.2, pal: p)
            }
            paint(ctx, path, d, pal: pal, color: color, glow: glow)
            ctx.restoreGState()
        }
    }
}

// MARK: - Hình thu nhỏ trong bộ chọn kiểu số

enum NumeralThumbs {
    private static let cache = LockedCache<NumeralStyle, UIImage>()

    static func image(_ st: NumeralStyle) -> UIImage {
        if let c = cache[st] { return c }
        let px: CGFloat = 132
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: CGSize(width: px, height: px), format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(x: 0, y: 0, width: px, height: px))
            let ctx = c.cgContext
            ctx.scaleBy(x: px / FaceRenderer.size, y: px / FaceRenderer.size)
            FaceRenderer.drawMarks(ctx, style: .numerals, color: .white, numberFont: .system, numeral: st, own: true)
        }
        cache[st] = img
        return img
    }
}
