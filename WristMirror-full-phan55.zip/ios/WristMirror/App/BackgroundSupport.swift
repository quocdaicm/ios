// Copyright 2026 Quốc Đại (quocdaicm, https://quocdai.site). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import UIKit
import UserNotifications

// ============================================================================
// Hỗ trợ chạy nền (không có trong bản Android gốc):
//  - Giữ app sống thêm khi đang thao tác với đồng hồ (truyền mặt đồng hồ, xoá, kích hoạt) bằng beginBackgroundTask.
//  - Thông báo cục bộ khi app ở nền: thao tác kết thúc / thất bại, mất kết nối đột ngột.
// Thông báo không chứa dữ liệu nhạy cảm (không ID, không tên mặt đồng hồ). Khi app đang mở thì không hiện.
// ============================================================================
final class BackgroundSupport {
    static let shared = BackgroundSupport()
    private init() {}

    private let lock = NSLock()
    private var taskId: UIBackgroundTaskIdentifier = .invalid
    private var wasOperating = false
    private var wasReady = false
    private var lastLossNotice = Date.distantPast

    /// Gọi từ AppRuntime.publish (luồng bất kỳ).
    func observe(operating: Bool, failed: Bool, ready: Bool) {
        lock.lock()
        let startedOp = operating && !wasOperating
        let endedOp = !operating && wasOperating
        let becameReady = ready && !wasReady
        wasOperating = operating
        wasReady = ready
        lock.unlock()

        if becameReady { requestAuthorization() }
        if startedOp { beginTask() }
        if endedOp {
            endTask()
            notify(failed ? tr("Thao tác với đồng hồ thất bại") : tr("Thao tác với đồng hồ đã kết thúc"),
                   body: tr("Mở Watch face để xem kết quả."))
        }
    }

    /// Mất kết nối ngoài ý muốn khi app ở nền (tối đa 1 thông báo/phút).
    func linkLost(reason: String) {
        let ignored: Set<String> = ["USER_DISCONNECTED", "CONNECTION_REPLACED", "DEVICE_REMOVAL_PENDING"]
        if ignored.contains(reason) { return }
        lock.lock()
        let now = Date()
        let allowed = now.timeIntervalSince(lastLossNotice) > 60
        if allowed { lastLossNotice = now }
        lock.unlock()
        if allowed { notify(tr("Mất kết nối với đồng hồ"), body: tr("Mở Watch face để kết nối lại.")) }
    }

    private func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func beginTask() {
        DispatchQueue.main.async { [self] in
            if taskId != .invalid { return }
            taskId = UIApplication.shared.beginBackgroundTask(withName: "wristmirror.operation") { [weak self] in
                self?.endTask()
            }
        }
    }

    private func endTask() {
        DispatchQueue.main.async { [self] in
            if taskId == .invalid { return }
            UIApplication.shared.endBackgroundTask(taskId)
            taskId = .invalid
        }
    }

    private func notify(_ title: String, body: String) {
        DispatchQueue.main.async {
            if UIApplication.shared.applicationState == .active { return }
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            content.sound = .default
            let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
            UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        }
    }
}
