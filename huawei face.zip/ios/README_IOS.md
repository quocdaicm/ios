# Huawei watch face (iOS) – bản viết lại từ WristMirror bằng Swift/SwiftUI

Build không cần Mac: đẩy thư mục này lên GitHub → tab Actions → "Build IPA" → tải artifact `Huawei-watch-face-ipa` (file `Huawei-watch-face.ipa`) (IPA chưa ký, cần tự ký/cài bằng Sideloadly, AltStore...).

> Người/AI làm tiếp: đọc **HANDOFF.md** trước.

## Các phần
1. Khung dự án, FrameCodec, GattChannel (CoreBluetooth)  ✅
2. Core, TlvView, Wire, DeviceInfo, MiniJson  ✅
3. Mật mã (AES-GCM/CBC, HMAC, HKDF), CryptoSession, LiteAuth, LinkCapabilities, AuthReplyJson  ✅
4. IsoAuth + IsoReplyHandler (xác thực HiChain ISO)  ✅
5. WatchConnection + WatchScanner + WristInitialization + DeviceTelemetry + SafeLog + Keychain store  ✅
6. FacePolicy/VersionPolicy + WireNames + các lớp *State + HwtSource (+ZipArchive) + FileTransfer (giao thức 0x28)  ✅ (chưa biên dịch)
7. WatchfaceManager (thay/xoá/bật mặt đồng hồ) + AppRuntime + Models + SavedWatchStore  ✅ (chưa biên dịch)
8. WatchViewModel + giao diện SwiftUI + đăng nhập Huawei ID (WKWebView)  ✅ (chưa biên dịch)
9. Build GitHub Actions lần đầu, sửa lỗi biên dịch, thử trên đồng hồ thật  ← tiếp theo

## Giấy phép
Apache-2.0 (xem `LICENSE`, `NOTICE`). Tác phẩm phái sinh của WristMirror (Escosis). Chi tiết ghi công: `THIRD_PARTY_NOTICES.md`.

## Giao diện (v11)
- Tên hiển thị app: **Huawei watch face** (`CFBundleDisplayName`); tên target/module nội bộ vẫn là `WristMirror`.
- Nền, logo, vòng mặt số vẽ bằng vector (SwiftUI Canvas, `Views/Theme.swift`); bản SVG gốc ở `design/` (`app-icon.svg`, `logo-mark.svg`, `background-dark.svg`, `background-light.svg`).
- Icon app 1024×1024 và ảnh launch (`LaunchLogo`) được xuất từ SVG trong `design/`.

- Tạo mặt đồng hồ mới: tab Mặt đồng hồ → "Tạo mặt đồng hồ mới" (đổi tên, ảnh nền, màu, kiểu kim, vạch giờ, AOD).
