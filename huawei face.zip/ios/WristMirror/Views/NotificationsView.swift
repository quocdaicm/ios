// Copyright 2026 Quốc Đại (quocdaicm, https://quocdai.site). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import SwiftUI
import UIKit

/// Màn "Thông báo & giờ": bật ANCS (iOS tự chuyển tin nhắn/cuộc gọi/thông báo sang đồng hồ) + nút đồng bộ giờ.
/// App không đọc nội dung tin nhắn hay cuộc gọi; việc chuyển thông báo do iOS thực hiện qua Bluetooth.
struct NotificationsView: View {
    @EnvironmentObject var vm: WatchViewModel
    /// Cùng khoá với GattChannel.requiresANCSKey; áp dụng từ lần kết nối kế tiếp.
    @AppStorage("wm.requires-ancs") private var requiresANCS = false

    private let steps: [(String, String)] = [
        ("Bật ANCS trong app", "Bật công tắc ở trên, rồi ngắt và kết nối lại đồng hồ."),
        ("Ghép nối khi iOS hỏi", "Khi hộp thoại ghép nối Bluetooth hiện ra, chọn Ghép nối."),
        ("Cho phép chia sẻ thông báo", "Cài đặt iPhone > Bluetooth > nút (i) cạnh đồng hồ > bật \"Chia sẻ thông báo hệ thống\" (Share System Notifications), nếu có mục này."),
        ("Bật thông báo cho từng app", "Cài đặt iPhone > Thông báo: kiểm tra Tin nhắn, Điện thoại, Zalo… đã cho phép thông báo."),
        ("Thử nghiệm", "Nhắn thử một tin cho iPhone và xem đồng hồ. Nếu không hiện hoặc kết nối lỗi, tắt công tắc ANCS rồi kết nối lại."),
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HeroCard {
                    HStack(spacing: 14) {
                        Image(systemName: "bell.badge.fill")
                            .font(.system(size: 26, weight: .semibold))
                            .foregroundStyle(Color.white)
                            .frame(width: 56, height: 56)
                            .background(Color.white.opacity(0.16), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Thông báo lên đồng hồ").font(.title3.bold()).foregroundStyle(Color.white)
                            Text("Tin nhắn, cuộc gọi và thông báo app do iOS tự chuyển qua Bluetooth (ANCS).")
                                .font(.footnote).foregroundStyle(Color.white.opacity(0.88))
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    Toggle(isOn: $requiresANCS) {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "bell.badge.fill")
                            Text("Bật ANCS (thử nghiệm)").font(.headline)
                        }
                    }
                    Text(requiresANCS
                         ? "Đã bật. Áp dụng từ lần kết nối kế tiếp: hãy ngắt rồi kết nối lại đồng hồ."
                         : "Đang tắt. Bật lên rồi kết nối lại để iOS ghép nối thông báo với đồng hồ.")
                        .font(.footnote).foregroundStyle(.secondary)
                    if vm.ui.connected {
                        Button { vm.disconnect() } label: {
                            Label("Ngắt kết nối để áp dụng", systemImage: "bolt.slash")
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
                .card()

                VStack(alignment: .leading, spacing: 14) {
                    Text("Các bước thiết lập").font(.headline)
                    ForEach(Array(steps.enumerated()), id: \.offset) { index, step in
                        HStack(alignment: .top, spacing: 12) {
                            Text("\(index + 1)")
                                .font(.footnote.bold())
                                .foregroundStyle(Color.white)
                                .frame(width: 24, height: 24)
                                .background(Theme.gradient, in: Circle())
                            VStack(alignment: .leading, spacing: 2) {
                                Text(step.0).font(.subheadline.weight(.semibold))
                                Text(step.1).font(.footnote).foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    Button {
                        if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                    } label: {
                        Label("Mở Cài đặt iPhone", systemImage: "gearshape")
                    }
                    .buttonStyle(SecondaryButtonStyle())
                }
                .card()

                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 12) {
                        IconBadge(systemName: "clock.arrow.2.circlepath")
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Đồng bộ giờ").font(.headline)
                            HStack(spacing: 4) {
                                Text("Giờ điện thoại:")
                                Text(Date(), style: .time)
                                Text("· " + TimeZone.current.identifier)
                            }
                            .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    Button { vm.syncWatchTime() } label: {
                        Label("Đồng bộ giờ ngay", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(!vm.ui.connected || vm.ui.quarantine || vm.ui.operation.active)
                    Text("App cũng tự gửi giờ mỗi lần kết nối. Cần kết nối đồng hồ trước.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .card()

                Text("Tính năng ANCS chưa được kiểm chứng trên GT 6 Pro. Nếu đồng hồ chỉ nhận thông báo khi ghép qua Huawei Health thì app này không làm thay được. App không đọc, lưu hay gửi nội dung tin nhắn và cuộc gọi.")
                    .font(.footnote).foregroundStyle(.secondary)
                    .padding(.horizontal, 4)
            }
            .padding(16)
        }
        .background(AppBackground())
        .navigationTitle("Thông báo & giờ")
        .navigationBarTitleDisplayMode(.inline)
    }
}
