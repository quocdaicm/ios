// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UserNotifications

/// Lịch nhắc đổi mặt đồng hồ.
struct ScheduleView: View {
    @EnvironmentObject var vm: WatchViewModel
    @ObservedObject var library: HwtLibrary
    @ObservedObject var schedule: FaceSchedule
    @State private var editing: ScheduleEntry?
    @State private var auth: UNAuthorizationStatus = .notDetermined

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Lịch nhắc đổi mặt").font(.headline)
                    Text("Đến giờ, app gửi thông báo. Chạm vào thông báo để app chuẩn bị sẵn file HWT; bạn mở thẻ mặt đồng hồ đích và bấm Thay thế. iOS không cho app tự thay mặt đồng hồ khi nền, và thao tác này luôn cần bạn xác nhận.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .card()

                if auth == .denied {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Thông báo đang bị tắt").font(.subheadline.weight(.semibold))
                        Text("Hãy bật thông báo cho app trong Cài đặt thì lịch nhắc mới hiện.")
                            .font(.footnote).foregroundStyle(.secondary)
                        Button("Mở Cài đặt") {
                            if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                    .card()
                }

                if library.items.isEmpty {
                    Text("Thư viện còn trống. Hãy chọn một file HWT trước để có mặt đồng hồ đặt lịch.")
                        .font(.footnote).foregroundStyle(.secondary).card()
                }

                ForEach(schedule.entries) { entry in row(entry) }

                Button {
                    if let first = library.items.first {
                        editing = ScheduleEntry(itemId: first.id, hour: 8, minute: 0, weekdays: [])
                    }
                } label: { Label("Thêm lịch", systemImage: "plus.circle") }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(library.items.isEmpty || schedule.entries.count >= FaceSchedule.maxEntries)

                if schedule.entries.count >= FaceSchedule.maxEntries {
                    Text("Tối đa \(FaceSchedule.maxEntries) lịch.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .padding(16)
        }
        .background(AppBackground())
        .navigationTitle("Lịch nhắc")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $editing) { entry in
            ScheduleEditor(library: library, schedule: schedule, draft: entry)
        }
        .onAppear { refreshAuth() }
    }

    private func refreshAuth() {
        UNUserNotificationCenter.current().getNotificationSettings { s in
            DispatchQueue.main.async { auth = s.authorizationStatus }
        }
    }

    private func row(_ entry: ScheduleEntry) -> some View {
        let item = library.item(id: entry.itemId)
        return HStack(spacing: 12) {
            ThumbnailView(url: item.flatMap { library.previewURL($0) }, maxPixel: 120)
                .frame(width: 46, height: 46)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(item?.name ?? "Mặt đồng hồ đã bị xoá").font(.subheadline.weight(.semibold)).lineLimit(1)
                Text("\(entry.timeText) · \(entry.daysText)").font(.caption).foregroundStyle(.secondary)
                if item == nil {
                    Text("Lịch này sẽ không nhắc. Hãy sửa hoặc xoá.").font(.caption2).foregroundStyle(Color.orange)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { editing = entry }
            Spacer()
            Toggle("", isOn: Binding(get: { entry.enabled }, set: { on in
                schedule.setEnabled(id: entry.id, on)
                if on { FaceSchedule.requestAuthorization { _ in refreshAuth() } }
            }))
            .labelsHidden()
        }
        .card()
    }
}

struct ScheduleEditor: View {
    @ObservedObject var library: HwtLibrary
    @ObservedObject var schedule: FaceSchedule
    @State var draft: ScheduleEntry
    @Environment(\.dismiss) private var dismiss

    private let order = [2, 3, 4, 5, 6, 7, 1]
    private let labels = [1: "CN", 2: "T2", 3: "T3", 4: "T4", 5: "T5", 6: "T6", 7: "T7"]
    private var isNew: Bool { !schedule.entries.contains { $0.id == draft.id } }

    private var time: Binding<Date> {
        Binding(
            get: { Calendar.current.date(from: DateComponents(hour: draft.hour, minute: draft.minute)) ?? Date() },
            set: { d in
                let c = Calendar.current.dateComponents([.hour, .minute], from: d)
                draft.hour = c.hour ?? 0
                draft.minute = c.minute ?? 0
            })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Mặt đồng hồ").font(.footnote).foregroundStyle(.secondary)
                        Picker("Mặt đồng hồ", selection: $draft.itemId) {
                            ForEach(library.items) { Text($0.name).tag($0.id) }
                        }
                        .pickerStyle(.menu)
                    }
                    .card()

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Giờ nhắc").font(.footnote).foregroundStyle(.secondary)
                        DatePicker("Giờ", selection: time, displayedComponents: .hourAndMinute)
                            .datePickerStyle(.wheel)
                            .labelsHidden()
                            .frame(maxWidth: .infinity)
                    }
                    .card()

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Ngày trong tuần").font(.footnote).foregroundStyle(.secondary)
                        HStack(spacing: 6) {
                            ForEach(order, id: \.self) { d in
                                let on = draft.weekdays.contains(d) || draft.weekdays.isEmpty
                                Button {
                                    var set = Set(draft.weekdays.isEmpty ? [1, 2, 3, 4, 5, 6, 7] : draft.weekdays)
                                    if set.contains(d) { if set.count > 1 { set.remove(d) } } else { set.insert(d) }
                                    draft.weekdays = set.sorted()
                                } label: {
                                    Text(labels[d] ?? "")
                                        .font(.caption.weight(.semibold))
                                        .frame(maxWidth: .infinity, minHeight: 34)
                                        .background(on ? Theme.accent : Color.secondary.opacity(0.15))
                                        .foregroundStyle(on ? Color.white : Color.primary)
                                        .clipShape(Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .card()

                    if !isNew {
                        Button(role: .destructive) { schedule.delete(id: draft.id); dismiss() } label: {
                            Label("Xoá lịch này", systemImage: "trash")
                        }
                        .buttonStyle(SecondaryButtonStyle(color: Color.red))
                    }
                }
                .padding(16)
            }
            .background(AppBackground())
            .navigationTitle(isNew ? "Lịch mới" : "Sửa lịch")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        if schedule.upsert(draft) { FaceSchedule.requestAuthorization() }
                        dismiss()
                    }
                    .disabled(library.item(id: draft.itemId) == nil)
                }
            }
        }
    }
}
