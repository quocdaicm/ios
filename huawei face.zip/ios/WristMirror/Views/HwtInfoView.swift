// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Màn xem thông tin file HWT (chỉ đọc).
struct HwtInfoView: View {
    let url: URL
    @State private var report: HwtReport?
    @State private var failure: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let r = report {
                    content(r)
                } else if let f = failure {
                    Text("Không đọc được file: \(f)").foregroundStyle(Color.orange).card()
                } else {
                    HStack(spacing: 10) { ProgressView(); Text("Đang đọc file") }.card()
                }
            }
            .padding(16)
        }
        .background(AppBackground())
        .navigationTitle("Thông tin file")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            let u = url
            do {
                report = try await Task.detached(priority: .utility) { try HwtInspector.inspect(url: u) }.value
            } catch {
                failure = WMCore.code(error)
            }
        }
    }

    @ViewBuilder private func content(_ r: HwtReport) -> some View {
        VStack(spacing: 6) {
            InfoRow(label: "Tên", value: r.info["title"] ?? "Không có")
            if let cn = r.info["title-cn"], !cn.isEmpty { InfoRow(label: "Tên (CN)", value: cn) }
            InfoRow(label: "Tác giả", value: r.info["author"] ?? "Không có")
            InfoRow(label: "Nhà thiết kế", value: r.info["designer"] ?? "Không có")
            InfoRow(label: "Mã màn hình", value: r.info["screen"] ?? "Không có")
            InfoRow(label: "Phiên bản", value: r.info["version"] ?? "Không có")
        }
        .card()

        VStack(alignment: .leading, spacing: 8) {
            Text("Kiểm tra").font(.headline)
            check(r.hasBin, "watchface.bin (phần app gửi lên đồng hồ)",
                  r.hasBin ? ByteCountFormatter.string(fromByteCount: r.binBytes, countStyle: .file) : "thiếu")
            check(r.hasConfig, "Bản thiết kế watch_face_config.xml", r.hasConfig ? "\(r.layerCount) lớp" : "không có")
            if let c = r.canvas {
                check(true, "Kích thước ảnh nền", "\(c.width) × \(c.height) px")
            }
            ForEach(r.warnings, id: \.self) { w in
                Label(w, systemImage: "exclamationmark.triangle.fill").font(.footnote).foregroundStyle(Color.orange)
            }
        }
        .card()

        if !r.textStyles.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Chữ").font(.headline)
                ForEach(r.textStyles) { s in
                    HStack(spacing: 10) {
                        swatch(s.color)
                        Text(s.color).font(.system(.footnote, design: .monospaced))
                        Spacer()
                        Text("cỡ \(s.size) · \(s.count) chỗ").font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .card()
        }

        if !r.images.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                let total = r.images.reduce(Int64(0)) { $0 + $1.bytes }
                Text("Ảnh (\(r.images.count) · \(ByteCountFormatter.string(fromByteCount: total, countStyle: .file)))").font(.headline)
                ForEach(Array(r.images.sorted { $0.bytes > $1.bytes }.prefix(12)), id: \.name) { i in
                    HStack {
                        Text(i.name).font(.system(.footnote, design: .monospaced))
                        Spacer()
                        Text("\(i.width)×\(i.height) · \(ByteCountFormatter.string(fromByteCount: i.bytes, countStyle: .file))")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                if r.images.count > 12 { Text("… và \(r.images.count - 12) ảnh nhỏ hơn").font(.footnote).foregroundStyle(.secondary) }
            }
            .card()
        }

        Text("Chỉ để xem. Đồng hồ chỉ đọc watchface.bin; ảnh và màu ở đây là bản thiết kế nguồn, sửa chúng không làm đổi mặt đồng hồ thật.")
            .font(.footnote).foregroundStyle(.secondary).padding(.horizontal, 4)
    }

    private func check(_ ok: Bool, _ title: String, _ detail: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "xmark.circle.fill").foregroundStyle(ok ? Color.green : Color.red)
            Text(title).font(.subheadline)
            Spacer()
            Text(detail).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func swatch(_ hex: String) -> some View {
        let c = HwtInspector.parseColor(hex)
        let color = c.map { Color(.sRGB, red: Double($0.r) / 255, green: Double($0.g) / 255, blue: Double($0.b) / 255, opacity: Double($0.a) / 255) } ?? Color.gray
        return RoundedRectangle(cornerRadius: 6, style: .continuous)
            .fill(color)
            .frame(width: 26, height: 26)
            .overlay(RoundedRectangle(cornerRadius: 6, style: .continuous).stroke(Color.secondary.opacity(0.4), lineWidth: 1))
    }
}
