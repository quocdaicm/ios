// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Mẫu thiết kế có sẵn

/// Mẫu mặt đồng hồ vẽ sẵn bằng vector: chạm một lần để áp dụng, rồi chỉnh tiếp từng phần.
struct FacePreset: Identifiable {
    let id: String
    let title: String
    let make: () -> FaceDesign
}

private extension Color {
    /// 0xRRGGBB
    init(wm hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255)
    }
}

enum FacePresets {
    /// Áp mẫu lên thiết kế hiện tại nhưng giữ nguyên tên và tác giả người dùng đã nhập (bỏ ảnh nền vì mẫu là vector).
    static func apply(_ preset: FacePreset, to current: FaceDesign) -> FaceDesign {
        var d = preset.make()
        d.name = current.name
        d.author = current.author
        return d
    }

    private static func base(_ bg1: UInt32, _ bg2: UInt32?) -> FaceDesign {
        var d = FaceDesign()
        d.backgroundColor = Color(wm: bg1)
        if let b = bg2 { d.useGradient = true; d.backgroundColor2 = Color(wm: b) } else { d.useGradient = false }
        d.decor = []
        d.showLunar = false
        return d
    }

    static let all: [FacePreset] = [
        FacePreset(id: "lotus", title: "Hoa sen vàng") {
            var d = FacePresets.base(0x2A0A10, 0x6B1D22)
            d.marks = .ticks; d.marksColor = Color(wm: 0xF2C879)
            d.handStyle = .classic
            d.hourColor = Color(wm: 0xF6DDA4); d.minuteColor = Color(wm: 0xF6DDA4)
            d.secondColor = Color(wm: 0xFF6B4A); d.capColor = Color(wm: 0xF2C879)
            d.decor = [DecorLayer(pattern: .lotus, color: Color(wm: 0xF2C879), opacity: 0.55, scale: 0.85, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xF6DDA4); d.lunarY = 0.70
            d.aodHandColor = Color(wm: 0xF2C879); d.aodMarksColor = Color(wm: 0x8A6A3B)
            return d
        },
        FacePreset(id: "bronze", title: "Trống đồng") {
            var d = FacePresets.base(0x120C05, 0x3A2A10)
            d.marks = .dots; d.marksColor = Color(wm: 0xD9A441)
            d.handStyle = .pointed
            d.hourColor = Color(wm: 0xF1D48A); d.minuteColor = Color(wm: 0xF1D48A)
            d.secondColor = Color(wm: 0xE0572F); d.capColor = Color(wm: 0xD9A441)
            d.decor = [DecorLayer(pattern: .bronzeDrum, color: Color(wm: 0xD9A441), opacity: 0.6, scale: 0.9, spin: .minute)]
            d.aodHandColor = Color(wm: 0xD9A441); d.aodMarksColor = Color(wm: 0x7A5A22)
            return d
        },
        FacePreset(id: "star", title: "Sao vàng") {
            var d = FacePresets.base(0xB5121B, 0x6E0A10)
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD84A)
            d.handStyle = .pointed
            d.hourColor = Color(wm: 0xFFE98A); d.minuteColor = Color(wm: 0xFFE98A)
            d.secondColor = Color.white; d.capColor = Color(wm: 0xFFD84A)
            d.decor = [DecorLayer(pattern: .star, color: Color(wm: 0xFFD84A), opacity: 0.5, scale: 0.62, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xFFE98A); d.lunarY = 0.72
            d.aodHandColor = Color(wm: 0xFFD84A); d.aodMarksColor = Color(wm: 0x8A6A1A)
            return d
        },
        FacePreset(id: "midnight", title: "Đêm xanh") {
            var d = FacePresets.base(0x050B1F, 0x123A7A)
            d.marks = .dots; d.marksColor = Color(wm: 0x7CC4FF)
            d.handStyle = .pointed
            d.hourColor = Color.white; d.minuteColor = Color(wm: 0xBFE1FF)
            d.secondColor = Color(wm: 0x4DA3FF); d.capColor = Color(wm: 0x4DA3FF)
            d.decor = [DecorLayer(pattern: .mandala, color: Color(wm: 0x4DA3FF), opacity: 0.35, scale: 0.85, spin: .hour)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xBFE1FF)
            return d
        },
        FacePreset(id: "ocean", title: "Biển xanh") {
            var d = FacePresets.base(0x021C2E, 0x0B6E8A)
            d.marks = .ticks; d.marksColor = Color.white
            d.handStyle = .bar
            d.hourColor = Color.white; d.minuteColor = Color.white
            d.secondColor = Color(wm: 0xFFB020); d.capColor = Color(wm: 0xFFB020)
            d.decor = [DecorLayer(pattern: .dotRings, color: Color.white, opacity: 0.3, scale: 0.9, spin: .minute)]
            d.lunarColor = Color.white
            return d
        },
        FacePreset(id: "forest", title: "Rừng sâu") {
            var d = FacePresets.base(0x04140B, 0x0F3D24)
            d.marks = .numerals; d.marksColor = Color(wm: 0xF2EBD0)
            d.handStyle = .classic
            d.hourColor = Color(wm: 0xF2EBD0); d.minuteColor = Color(wm: 0xF2EBD0)
            d.secondColor = Color(wm: 0xE8A33D); d.capColor = Color(wm: 0xE8A33D)
            d.decor = [DecorLayer(pattern: .sunburst, color: Color(wm: 0x7BD88F), opacity: 0.25, scale: 0.9, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xF2EBD0); d.lunarY = 0.70
            return d
        },
        FacePreset(id: "neon", title: "Neon") {
            var d = FacePresets.base(0x05000F, 0x2A0050)
            d.marks = .ticks; d.marksColor = Color(wm: 0xFF3DCB)
            d.handStyle = .bar
            d.hourColor = Color(wm: 0x3DF5FF); d.minuteColor = Color(wm: 0x3DF5FF)
            d.secondColor = Color(wm: 0xFF3DCB); d.capColor = Color(wm: 0xFF3DCB)
            d.decor = [DecorLayer(pattern: .gear, color: Color(wm: 0xFF3DCB), opacity: 0.3, scale: 0.8, spin: .second)]
            d.lunarColor = Color(wm: 0x3DF5FF)
            return d
        },
        FacePreset(id: "paper", title: "Giấy cổ") {
            var d = FacePresets.base(0xF1E6CC, nil)
            d.marks = .numerals; d.marksColor = Color(wm: 0x2B2118)
            d.handStyle = .classic; d.handOutline = false
            d.hourColor = Color(wm: 0x2B2118); d.minuteColor = Color(wm: 0x2B2118)
            d.secondColor = Color(wm: 0xB3261E); d.capColor = Color(wm: 0xB3261E)
            d.decor = [DecorLayer(pattern: .ring, color: Color(wm: 0x8A6A3B), opacity: 0.5, scale: 0.9, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0x2B2118); d.lunarY = 0.70
            d.aodHandColor = Color(wm: 0xE9DDBF); d.aodMarksColor = Color(wm: 0x8A6A3B)
            return d
        },
        FacePreset(id: "minimal", title: "Tối giản") {
            var d = FacePresets.base(0x000000, nil)
            d.marks = .ticks; d.marksColor = Color.white
            d.handStyle = .bar
            d.hourColor = Color.white; d.minuteColor = Color.white
            d.secondColor = Color(wm: 0xFF4D5A); d.capColor = Color(wm: 0xFF4D5A)
            return d
        }
    ]
}

/// Ảnh xem trước nhỏ của từng mẫu (vẽ bằng chính bộ vẽ mặt đồng hồ, lưu nhớ tạm).
enum FacePresetThumbs {
    private static var cache = [String: UIImage]()

    static func image(_ p: FacePreset) -> UIImage {
        if let c = cache[p.id] { return c }
        let img = FaceRenderer.image(design: p.make(), ambient: false, pixels: 128, circle: true)
        cache[p.id] = img
        return img
    }
}
