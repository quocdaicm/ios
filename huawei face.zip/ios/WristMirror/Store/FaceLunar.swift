// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Âm lịch (ngày/tháng + "ÂL")

/// Bố cục khối âm lịch: `[chục][đơn vị] / [tháng]` và dòng nhỏ "ÂL" bên dưới.
/// Cấu trúc lấy từ các file HWT thật: ngày âm = 2 dãy ảnh (chục: giá trị 0...3, đơn vị: giá trị 0...9),
/// tháng âm = 1 dãy ảnh (giá trị 1...12), dấu "/" và nhãn "ÂL" là ảnh tĩnh. Số được vẽ vector đúng cỡ điểm ảnh
/// của đồng hồ (không phóng ảnh bitmap nhỏ), nên nét sắc ở mọi cỡ chữ.
struct LunarLayout {
    let font: UIFont
    let labelFont: UIFont
    let digitW: Int
    let lineH: Int
    let slashW: Int
    let labelW: Int
    let labelH: Int
    let x0: Int
    let y1: Int
    let showLabel: Bool

    var tensX: Int { x0 }
    var onesX: Int { x0 + digitW }
    var slashX: Int { x0 + digitW * 2 }
    var monthX: Int { x0 + digitW * 2 + slashW }
    var labelX: Int { (Int(FaceRenderer.size) - labelW) / 2 }
    var labelY: Int { y1 + lineH }
}

extension FaceRenderer {
    static let lunarLabelText = "ÂL"

    static func lunarLayout(_ d: FaceDesign) -> LunarLayout {
        let k = CGFloat(min(1.8, max(0.6, d.lunarSize)))
        let fs = 30 * k
        let font = UIFont.monospacedDigitSystemFont(ofSize: fs, weight: .bold)
        let labelFont = UIFont.systemFont(ofSize: fs * 0.52, weight: .bold)
        func width(_ t: String, _ f: UIFont) -> Int { Int(ceil((t as NSString).size(withAttributes: [.font: f]).width)) + 2 }
        let digitW = width("0", font)
        let lineH = Int(ceil(font.lineHeight)) + 2
        let slashW = width("/", font)
        let labelW = width(lunarLabelText, labelFont)
        let labelH = Int(ceil(labelFont.lineHeight)) + 2
        let total = digitW * 4 + slashW
        let x0 = max(0, (Int(size) - total) / 2)
        let blockH = lineH + (d.lunarLabel ? labelH : 0)
        let cy = Int(size * CGFloat(min(0.9, max(0.1, d.lunarY))))
        let y1 = max(0, min(Int(size) - blockH, cy - blockH / 2))
        return LunarLayout(font: font, labelFont: labelFont, digitW: digitW, lineH: lineH, slashW: slashW,
                           labelW: labelW, labelH: labelH, x0: x0, y1: y1, showLabel: d.lunarLabel)
    }

    /// Vẽ chữ ở giữa hình chữ nhật (gốc trên-trái, ctx kiểu UIKit).
    static func drawLunarText(_ text: String, font: UIFont, color: UIColor, in rect: CGRect) {
        guard !text.isEmpty else { return }
        let s = NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: color])
        let sz = s.size()
        s.draw(at: CGPoint(x: rect.minX + (rect.width - sz.width) / 2, y: rect.minY + (rect.height - sz.height) / 2))
    }

    /// Ngày âm hôm nay (chỉ để xem trước; đồng hồ tự tính ngày âm thật).
    static func lunarToday() -> (day: Int, month: Int) {
        var cal = Calendar(identifier: .chinese)
        cal.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh") ?? TimeZone.current
        let c = cal.dateComponents([.day, .month], from: Date())
        return (min(30, max(1, c.day ?? 1)), min(12, max(1, c.month ?? 1)))
    }

    /// Xem trước: vẽ khối âm lịch vào ctx (toạ độ 466×466, gốc trên-trái).
    static func drawLunarPreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showLunar else { return }
        let L = lunarLayout(d)
        let color = UIColor(d.lunarColor)
        let v = lunarToday()
        UIGraphicsPushContext(ctx)
        func cell(_ t: String, _ x: Int, _ w: Int, _ y: Int, _ h: Int, _ f: UIFont) {
            drawLunarText(t, font: f, color: color, in: CGRect(x: x, y: y, width: w, height: h))
        }
        cell(v.day >= 10 ? "\(v.day / 10)" : "", L.tensX, L.digitW, L.y1, L.lineH, L.font)
        cell("\(v.day % 10)", L.onesX, L.digitW, L.y1, L.lineH, L.font)
        cell("/", L.slashX, L.slashW, L.y1, L.lineH, L.font)
        cell(String(format: "%02d", v.month), L.monthX, L.digitW * 2, L.y1, L.lineH, L.font)
        if L.showLabel { cell(lunarLabelText, L.labelX, L.labelW, L.labelY, L.labelH, L.labelFont) }
        UIGraphicsPopContext()
    }

    /// Các lớp của file HWT: thêm ảnh qua `add` (trả về số ảnh, bắt đầu từ 1).
    static func lunarLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        let L = lunarLayout(d)
        let color = UIColor(d.lunarColor)
        func glyph(_ t: String, w: Int, h: Int, font: UIFont) -> Int {
            add(drawRaster(width: w, height: h) { ctx in
                drawLunarText(t, font: font, color: color, in: CGRect(x: 0, y: 0, width: w, height: h))
            })
        }
        func digit(_ t: String) -> Int { glyph(t, w: L.digitW, h: L.lineH, font: L.font) }

        // Chục ngày (giá trị 0...3). File thật có 5 mục; mục thứ 5 không dùng tới.
        let blank = digit("")
        let t1 = digit("1"), t2 = digit("2"), t3 = digit("3")
        // Đơn vị ngày (giá trị 0...9)
        let ones = (0...9).map { digit("\($0)") }
        // Tháng (giá trị 1...12); mục 0 là mục đệm giống file thật
        let months = (1...12).map { glyph(String(format: "%02d", $0), w: L.digitW * 2, h: L.lineH, font: L.font) }
        let slash = glyph("/", w: L.slashW, h: L.lineH, font: L.font)

        var layers: [HwtLayer] = [
            .array(resources: [blank, t1, t2, t3, t2], x: L.tensX, y: L.y1, valueType: HwtValueType.lunarDayTens, ambient: false),
            .array(resources: ones, x: L.onesX, y: L.y1, valueType: HwtValueType.lunarDayOnes, ambient: false),
            .single(resource: slash, x: L.slashX, y: L.y1, ambient: false),
            .array(resources: [months[0]] + months, x: L.monthX, y: L.y1, valueType: HwtValueType.lunarMonth, ambient: false)
        ]
        if L.showLabel {
            let label = glyph(lunarLabelText, w: L.labelW, h: L.labelH, font: L.labelFont)
            layers.append(.single(resource: label, x: L.labelX, y: L.labelY, ambient: false))
        }
        return layers
    }
}
