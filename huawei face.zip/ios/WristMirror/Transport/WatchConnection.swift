// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

// ============================================================================
// Port từ transport/WatchConnection.java (Phần 5).
// Bộ thực thi giao thức tuần tự: mở kênh BLE → LinkCapabilities → ISO/Lite → CryptoSession →
// khởi tạo → READY. Mọi trạng thái chạy trên MỘT hàng đợi tuần tự (`protoQueue`).
//
// Khác biệt iOS so với bản Java (xem HANDOFF.md mục 5):
//  - Chỉ BLE (GattChannel); bỏ RFCOMM. Không có MAC → dùng UUID của CBPeripheral (chuỗi, viết hoa).
//  - Không có BroadcastReceiver/createBond: iOS tự ghép nối hệ thống khi đọc/ghi characteristic mã hoá,
//    nên giai đoạn "SYSTEM_PAIRING" của bản Java không còn.
//  - Khoá lưu trong Keychain (SecureStore). `learnedSecret` được lưu TRƯỚC khi gửi bước ISO kế tiếp.
//  - Chuỗi mã lỗi (WMFault) giữ nguyên như bản Java; chuỗi mô tả giai đoạn dịch sang tiếng Việt.
// ============================================================================

protocol WatchConnectionListener: AnyObject {
    func onConnection(code: String, detail: String, ready: Bool, connecting: Bool, rebindCount: Int, epoch: Int)
    func onPin(needed: Bool, message: String)
    func onRebind(message: String)
    func onReady(epoch: Int, caps: LinkCapabilities)
    /// Firmware đọc được từ phản hồi sản phẩm mã hoá hợp lệ; chỉ công bố sau READY đã xác minh.
    func onDeviceInfo(epoch: Int, firmware: String)
    /// Model từ 01/07 trường 0A của cùng kết nối; chỉ công bố sau READY.
    func onDeviceModel(epoch: Int, model: String)
    /// Chỉ các trường thực sự có giá trị; nil không ghi đè quan sát trước.
    func onDeviceStats(epoch: Int, serialNumber: String?, batteryPercent: Int?, freeMemoryBytes: Int64?)
    func onPacket(epoch: Int, service: Int, command: Int, plain: [UInt8], encrypted: Bool)
    func onClosed(closedEpoch: Int, reason: String)
}

extension WatchConnectionListener {
    func onDeviceInfo(epoch: Int, firmware: String) {}
    func onDeviceModel(epoch: Int, model: String) {}
    func onDeviceStats(epoch: Int, serialNumber: String?, batteryPercent: Int?, freeMemoryBytes: Int64?) {}
}

final class WatchConnection: LinkChannelListener {
    private let store: SecureStore
    private let log: SafeLog
    private let deviceModel: String
    private let random: (Int) -> [UInt8] = { WMRandom.bytes($0) }

    // Hàng đợi tuần tự thay HandlerThread "gt7-protocol".
    private let protoQueue = DispatchQueue(label: "wristmirror.protocol")
    private static let actorKey = DispatchSpecificKey<Bool>()
    private var isOnActor: Bool { DispatchQueue.getSpecific(key: WatchConnection.actorKey) == true }

    // Trạng thái đọc được từ luồng khác → bọc khoá.
    private let stateLock = NSLock()
    private var _epoch = 0
    private var _ready = false
    private var _address = ""
    private weak var _listener: WatchConnectionListener?
    private var _pendingRemovalGuard: (String) -> Bool = { _ in false }
    private var _knownDeviceModelGuard: (String) -> Bool = { _ in false }

    private(set) var epoch: Int {
        get { stateLock.lock(); defer { stateLock.unlock() }; return _epoch }
        set { stateLock.lock(); _epoch = newValue; stateLock.unlock() }
    }
    private(set) var ready: Bool {
        get { stateLock.lock(); defer { stateLock.unlock() }; return _ready }
        set { stateLock.lock(); _ready = newValue; stateLock.unlock() }
    }
    private(set) var address: String {
        get { stateLock.lock(); defer { stateLock.unlock() }; return _address }
        set { stateLock.lock(); _address = newValue; stateLock.unlock() }
    }
    private var listener: WatchConnectionListener? {
        stateLock.lock(); defer { stateLock.unlock() }; return _listener
    }
    private var pendingRemovalGuard: (String) -> Bool {
        stateLock.lock(); defer { stateLock.unlock() }; return _pendingRemovalGuard
    }
    private var knownDeviceModelGuard: (String) -> Bool {
        stateLock.lock(); defer { stateLock.unlock() }; return _knownDeviceModelGuard
    }

    // Chỉ truy cập trên `protoQueue`.
    private var channel: LinkChannel?
    private var decoder = FrameCodec.Decoder()
    private var caps = LinkCapabilities()
    private var cipher: CryptoSession?
    private var iso: IsoAuth?
    private var lite: LiteAuth?
    private var phase = "IDLE"
    private var huaweiId = ""
    private var usedSavedKey = false
    private var selfId: [UInt8]?
    private var pin: [UInt8]?
    private var stored: [UInt8]?
    private var rebindCount = 0
    private var deadline: Int64 = 0
    private var legacyCounter: Int64 = 0
    private var sessionVerified = false
    private var initUnconfirmed = false
    private var stageSerial = 0
    private var initService = -1, initCommand = -1, nextInit = -1
    private var auxiliaryPending = Set<Int>()
    private var deviceName = "HUAWEI Watch"
    private var telemetry: DeviceTelemetry.ProbeOwner?
    private var observedFirmware: String?, publishedFirmware: String?
    private var observedModel: String?, publishedModel: String?

    /// `deviceModel`: tên model gửi cho đồng hồ ở bước SECURITY (truyền `UIDevice.current.model`).
    init(store: SecureStore, log: SafeLog, deviceModel: String = "iPhone") {
        self.store = store
        self.log = log
        self.deviceModel = deviceModel
        protoQueue.setSpecific(key: WatchConnection.actorKey, value: true)
    }

    func setListener(_ l: WatchConnectionListener?) {
        stateLock.lock(); _listener = l; stateLock.unlock()
    }

    /// Khoá chặn thiết bị đang chờ xoá: chặn cả các tác vụ kết nối cũ trong hàng đợi.
    func setPendingRemovalGuard(_ g: @escaping (String) -> Bool) {
        stateLock.lock(); _pendingRemovalGuard = g; stateLock.unlock()
    }

    /// Chỉ đọc cache model cục bộ; đã biết model thì không trích xuất/công bố lại.
    func setKnownDeviceModelGuard(_ g: @escaping (String) -> Bool) {
        stateLock.lock(); _knownDeviceModelGuard = g; stateLock.unlock()
    }

    /// Chỉ dùng từ hàng đợi giao thức (trong callback của WatchConnection) — LinkCapabilities không an toàn đa luồng.
    var capabilities: LinkCapabilities { caps }

    func post(_ task: @escaping () -> Void) { protoQueue.async(execute: task) }
    func execute(_ task: @escaping () -> Void) { if isOnActor { task() } else { protoQueue.async(execute: task) } }
    func delay(_ ms: Int, _ task: @escaping () -> Void) {
        protoQueue.asyncAfter(deadline: .now() + .milliseconds(ms), execute: task)
    }

    // MARK: Tiện ích

    private func nowMs() -> Int64 { Int64(DispatchTime.now().uptimeNanoseconds / 1_000_000) }
    private func wallMs() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    private static func num(_ value: Int64, _ length: Int) -> [UInt8] {
        var v = UInt64(bitPattern: value)
        var b = [UInt8](repeating: 0, count: length)
        var i = length - 1
        while i >= 0 { b[i] = UInt8(truncatingIfNeeded: v); v >>= 8; i -= 1 }
        return b
    }

    private func optText(_ v: Int64?) -> String { v.map { String($0) } ?? "absent" }

    private func stage(_ code: String, _ detail: String, _ timeout: Int64) {
        phase = code
        stageSerial += 1
        deadline = timeout > 0 ? nowMs() + timeout : 0
        log.record("LINK_STATE", "phase=\(code) rebind_attempt=\(rebindCount)")
        listener?.onConnection(code: code, detail: detail, ready: ready,
                               connecting: code != "IDLE" && code != "FAILED" && code != "READY",
                               rebindCount: rebindCount, epoch: epoch)
    }

    // MARK: Kết nối / ngắt

    /// `deviceId`: UUID của CBPeripheral. `account`: ID Huawei nội bộ (nil/rỗng = dùng giá trị đã lưu).
    func connect(deviceId: String, account: String?) { enqueueConnect(-1, deviceId, account) }

    /// Chỉ kết nối nếu epoch hiện tại vẫn là `expectedEpoch`; kết quả muộn không dựng lại dữ liệu đã xoá.
    func connectIfEpoch(_ expectedEpoch: Int, deviceId: String, account: String?) {
        enqueueConnect(expectedEpoch, deviceId, account)
    }

    private func enqueueConnect(_ expected: Int, _ deviceId: String, _ account: String?) {
        guard let id = DeviceRemovalGuard.canonical(deviceId) else {
            log.record("CONNECT_NOT_QUEUED", "code=DEVICE_ADDRESS_INVALID")
            return
        }
        if pendingRemovalGuard(id) { log.record("CONNECT_NOT_QUEUED", "pending_target=true"); return }
        let generation: Int
        do {
            try store.removals.requireUsable(id)
            generation = store.removals.generation(id)
        } catch {
            log.record("CONNECT_NOT_QUEUED", "code=\(WMCore.code(error))")
            return
        }
        protoQueue.async { [self] in
            if pendingRemovalGuard(id) || (expected >= 0 && epoch != expected)
                || !store.removals.usable(id, generation: generation) {
                log.record("CONNECT_CALLBACK_INVALIDATED", "epoch_or_device_generation_changed=true")
                return
            }
            connectActor(id, account)
        }
    }

    private func connectActor(_ id: String, _ account: String?) {
        rebindCount = 0
        address = id
        do {
            let given = (account ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if given.isEmpty { huaweiId = try store.huaweiId(id) } else { huaweiId = given }
            if huaweiId.isEmpty { throw WMFault("HUAWEI_INTERNAL_ID_REQUIRED") }
            if huaweiId.utf8.count > 128 { throw WMFault("HUAWEI_INTERNAL_ID_TOO_LONG") }
            try store.saveHuaweiId(id, huaweiId)
            try openLink(rebinding: false)
        } catch {
            fail(WMCore.code(error))
        }
    }

    private func openLink(rebinding: Bool) throws {
        try store.removals.requireUsable(address)
        let closingEpoch = epoch
        let hadChannel = channel != nil || ready
        closeLocal()
        if hadChannel { listener?.onClosed(closedEpoch: closingEpoch, reason: "CONNECTION_REPLACED") }
        epoch += 1
        ready = false
        telemetry = DeviceTelemetry.ProbeOwner(epoch: epoch)
        legacyCounter = 0
        caps = LinkCapabilities()
        decoder = FrameCodec.Decoder()
        selfId = try store.identity(address)
        stored = try store.authKey(address)
        usedSavedKey = stored != nil
        pin = nil
        guard let uuid = UUID(uuidString: address) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        let own = epoch
        stage("CONNECTING", rebinding ? "Đang liên kết lại với đồng hồ" : "Đang mở kênh giao tiếp với đồng hồ", 20000)
        tick(own)
        openChannel(uuid, own)
    }

    private func openChannel(_ uuid: UUID, _ own: Int) {
        if epoch != own { return }
        stage("CONNECTING", "Đang kết nối với đồng hồ", 20000)
        let ch = GattChannel(identifier: uuid, epoch: own, listener: self)
        channel = ch
        ch.connect()
    }

    func disconnectIfEpoch(_ expected: Int) {
        protoQueue.async { [self] in if epoch == expected { disconnectActor() } }
    }

    func disconnect() { protoQueue.async { [self] in disconnectActor() } }

    /// Rào chắn tuần tự khi xoá đồng hồ khỏi app: chỉ đóng kênh/phiên của thiết bị đó, không gửi gói xoá/reset.
    /// (iOS không huỷ được ghép nối hệ thống — người dùng tự vào Cài đặt > Bluetooth > "Forget This Device".)
    func stopForRemoval(_ id: String) throws {
        if !isOnActor { throw WMFault("REMOVAL_REQUIRES_PROTOCOL_QUEUE") }
        guard let canon = DeviceRemovalGuard.canonical(id),
              address.caseInsensitiveCompare(canon) == .orderedSame else { return }
        let closingEpoch = epoch
        closeLocal()
        caps.serverNonce = nil
        caps = LinkCapabilities()
        decoder = FrameCodec.Decoder()
        deviceName = "HUAWEI Watch"
        address = ""
        huaweiId = ""
        usedSavedKey = false
        rebindCount = 0
        legacyCounter = 0
        deadline = 0
        epoch += 1
        stage("IDLE", "Đã dừng kết nối của app với đồng hồ này", 0)
        listener?.onPin(needed: false, message: "")
        listener?.onClosed(closedEpoch: closingEpoch, reason: "DEVICE_REMOVAL_PENDING")
    }

    private func disconnectActor() {
        let closingEpoch = epoch
        closeLocal()
        epoch += 1
        stage("IDLE", "Đã ngắt kết nối", 0)
        listener?.onPin(needed: false, message: "")
        listener?.onClosed(closedEpoch: closingEpoch, reason: "USER_DISCONNECTED")
    }

    // MARK: LinkChannelListener (gọi từ hàng đợi GATT → chuyển sang protoQueue)

    func linkDidOpen(epoch own: Int, name: String) {
        protoQueue.async { [self] in
            if own != epoch || store.removals.blocked(address) { return }
            do {
                do { deviceName = try WristInitialization.boundedDeviceName(name) }
                catch { deviceName = "HUAWEI Watch" }
                stage("LINK_PARAMS", "Đọc tham số liên kết", 15000)
                try sendPlain(1, 1, LinkCapabilities.linkRequest())
            } catch {
                fail(WMCore.code(error))
            }
        }
    }

    func linkDidFail(epoch own: Int, error: String) {
        protoQueue.async { [self] in
            if own == epoch && !store.removals.blocked(address) { fail(error) }
        }
    }

    func linkDidReceive(epoch own: Int, bytes: [UInt8]) {
        let data = bytes
        protoQueue.async { [self] in processBytes(own, data) }
    }

    // MARK: Nhận gói

    private func processBytes(_ own: Int, _ data: [UInt8]) {
        if own != epoch || store.removals.blocked(address) { return }
        do {
            let before = decoder.errors
            let packets = try decoder.receive(data, now: nowMs())
            if decoder.errors != before {
                log.record("FRAME_INVALID", "reason=\(decoder.lastError) count=\(decoder.errors)")
            }
            if decoder.errors > 16 { throw WMFault("TOO_MANY_INVALID_FRAMES") }
            for p in packets {
                if own != epoch { return }
                var body = p.body
                let expected = expectedAuthPacket(p.service, p.command)
                let business = ready && WatchConnection.knownBusinessPacket(p.service, p.command)
                if !expected && !business {
                    log.packet(true, p.service, p.command, body.count, nil, false)
                    if ready {
                        listener?.onPacket(epoch: own, service: p.service, command: p.command, plain: body, encrypted: false)
                    }
                    continue
                }
                var encrypted = false
                do {
                    encrypted = try CryptoSession.wrapped(body)
                } catch {
                    if expected { throw error }
                    log.record("RX_NON_TLV_OR_PARTIAL_ENVELOPE_DROPPED",
                               "service=\(p.service) command=\(p.command) no_plaintext_downgrade=true")
                    continue
                }
                if encrypted {
                    guard let c = cipher else { throw WMFault("ENCRYPTED_BEFORE_SESSION_KEY") }
                    body = try c.open(body)
                }
                var fields: [TlvView.Part]? = nil
                if expected {
                    do {
                        fields = try TlvView.decode(body)
                    } catch {
                        // Chỉ thân gói đo từ xa tuỳ chọn đã qua kiểm tra phong bì/GCM mới được bỏ qua;
                        // lỗi phong bì, GCM, khoá, xác thực vẫn đóng kết nối.
                        if !encrypted || !deviceStatsPacket(p.service, p.command) { throw error }
                        _ = telemetry?.complete(own, p.service, p.command)
                        log.record("DEVICE_STATS_UNAVAILABLE",
                                   "service=\(p.service) command=\(p.command) bytes=\(body.count) code=\(WMCore.code(error)) ready_gate=false")
                        continue
                    }
                }
                log.packet(true, p.service, p.command, body.count, fields, encrypted)
                if expected {
                    try handle(own, p.service, p.command, body, fields ?? [], encrypted)
                } else {
                    listener?.onPacket(epoch: own, service: p.service, command: p.command, plain: body, encrypted: encrypted)
                }
            }
        } catch {
            fail((error as? WMFault)?.code ?? "PROTOCOL_RX_FAILED")
        }
    }

    private func expectedAuthPacket(_ service: Int, _ command: Int) -> Bool {
        if deviceStatsPacket(service, command) { return true }
        if cipher != nil && service == 1 && auxiliaryPending.contains(command) { return true }
        if sessionVerified && service == initService && command == initCommand { return true }
        if service != 1 { return false }
        switch phase {
        case "LINK_PARAMS": return command == 1
        case "DEVICE_STATUS": return command == 0x16
        case "SECURITY": return command == 0x33
        case "PIN_REQUEST": return command == 0x2c
        case "ISO_AUTH": return command == 0x28
        case "LITE_AUTH": return command == 0x13
        case "BOND_PARAMS": return command == 0x0f
        case "BOND_KEY": return command == 0x0e
        case "VERIFY_SESSION": return command == 2
        case "COMMAND_CAPS": return command == 3
        default: return false
        }
    }

    /// Phản hồi 01/08 sau khi đã hỏi vẫn được kiểm tra phong bì/GCM; trả lời lặp không thành điều kiện READY.
    private func deviceStatsPacket(_ service: Int, _ command: Int) -> Bool {
        guard cipher != nil, DeviceTelemetry.matches(service, command) else { return false }
        if let t = telemetry {
            if t.pending(epoch, service, command) { return true }
            if service == DeviceTelemetry.configService && command == DeviceTelemetry.batteryCommand
                && t.batteryQueryClaimed(epoch) { return true }
        }
        return sessionVerified && ready
    }

    private static func knownBusinessPacket(_ service: Int, _ command: Int) -> Bool {
        if service == 0x27 { return [1, 2, 3, 5, 6].contains(command) }
        if service == 0x28 { return [2, 3, 4, 5, 7, 8].contains(command) }
        return false
    }

    private func handle(_ own: Int, _ service: Int, _ command: Int, _ body: [UInt8],
                        _ fields: [TlvView.Part], _ encrypted: Bool) throws {
        if service == 1 && command == 1 && phase == "LINK_PARAMS" {
            try caps.parseLink(body)
            stage("DEVICE_STATUS", "Đọc trạng thái trước xác thực", 15000)
            try sendPlain(1, 0x16, WMCore.tlv(1, []))
            return
        }
        if service == 1 && command == 0x16 && phase == "DEVICE_STATUS" {
            if let e = try Wire.number(fields, 0x7f), e != 0, e != 100000 { throw WMFault("DEVICE_STATUS_ERROR") }
            if caps.authMode == 0 { throw WMFault("LEGACY_NORMAL_AUTH_UNSUPPORTED") }
            stage("SECURITY", "Thương lượng thuật toán xác thực", 15000)
            try sendPlain(1, 0x33, caps.securityRequest(selfId: selfId, model: deviceModel))
            return
        }
        if service == 1 && command == 0x33 && phase == "SECURITY" {
            try caps.parseSecurity(body)
            if !caps.iso() && !caps.lite() { throw WMFault("AUTH_TYPE_UNSUPPORTED") }
            if caps.iso(), let s = stored {
                try startIso(pairing: false, secret: s)
            } else if caps.lite() && caps.authVersion == 2 {
                try startLite()
            } else {
                try requestPin()
            }
            return
        }
        if service == 1 && command == 0x2c && phase == "PIN_REQUEST" {
            let ct = try Wire.unique(fields, 1)
            let iv = try Wire.unique(fields, 2)
            var decoded: [UInt8] = []
            do {
                guard let ct = ct, let iv = iv else { throw WMFault("PIN_REPLY_MISSING") }
                let magic = HuaweiCrypto.pinMagic(caps.authVersion)
                if caps.encryptMethod == 1 {
                    decoded = try HuaweiCrypto.aesGcmDecrypt(magic, iv.value, ct.value, nil)
                } else {
                    decoded = try HuaweiCrypto.aesCbcDecrypt(magic, iv.value, ct.value)
                }
                if decoded.isEmpty || decoded.count > 64 { throw WMFault("PIN_REPLY_LENGTH") }
            } catch {
                stage("PIN_INPUT", "Đang chờ mã ghép nối trên đồng hồ, hoặc xác nhận lại ghép nối trên đồng hồ", 120000)
                listener?.onPin(needed: true, message: "Hãy nhập mã ghép nối hiển thị trên đồng hồ rồi tiếp tục.")
                return
            }
            pin = decoded
            listener?.onPin(needed: false, message: "")
            // Chỉ hỏi PIN thủ công khi không lấy được hoặc giải mã PIN thất bại; đã có PIN hợp lệ mà bước xác thực
            // sau đó lỗi thì phải đóng kết nối, không giả vờ vẫn chờ PIN.
            if caps.iso() { try startIso(pairing: true, secret: decoded) } else { try startLite() }
            return
        }
        if service == 1 && command == 0x28 && phase == "ISO_AUTH" { try handleIso(fields); return }
        if service == 1 && command == 0x13 && phase == "LITE_AUTH" {
            guard let l = lite else { throw WMFault("LITE_CONTEXT_MISSING") }
            try l.validate(body)
            stage("BOND_PARAMS", "Đọc tham số liên kết của ứng dụng này", 15000)
            let virtual = try store.virtualMac(address)
            let compact = virtual.replacingOccurrences(of: ":", with: "")
            var req: [UInt8] = []
            req += try WMCore.tlv(1, [])
            req += try WMCore.tlv(3, Array(compact.suffix(6).utf8))
            req += try WMCore.tlv(4, [2])
            req += try WMCore.tlv(5, [])
            req += try WMCore.tlv(7, Array(virtual.utf8))
            req += try WMCore.tlv(9, [])
            try sendPlain(1, 0x0f, req)
            return
        }
        if service == 1 && command == 0x0f && phase == "BOND_PARAMS" {
            guard let counter = try Wire.unique(fields, 9), counter.value.count >= 4 else {
                throw WMFault("BOND_COUNTER_MISSING")
            }
            legacyCounter = try WMCore.number(Array(counter.value[0..<4]))
            var iv = random(16)
            var next = (legacyCounter + 1) & 0xffff_ffff
            if next == 0 { next = 1 }
            let nb = WatchConnection.num(next, 4)
            for i in 0..<4 { iv[12 + i] = nb[i] }
            legacyCounter = next
            guard let l = lite else { throw WMFault("LITE_CONTEXT_MISSING") }
            let key = l.cipherKey()
            let active = l.savedActiveKey()
            let enc: [UInt8]
            if caps.encryptMethod == 1 || caps.deviceSupportType == 4 {
                enc = try HuaweiCrypto.aesGcmEncrypt(key, iv, active, nil)
            } else {
                enc = try HuaweiCrypto.aesCbcEncrypt(key, iv, active)
            }
            let virtual = try store.virtualMac(address).replacingOccurrences(of: ":", with: "")
            stage("BOND_KEY", "Hoàn tất liên kết giao thức", 15000)
            var req: [UInt8] = []
            req += try WMCore.tlv(1, [])
            req += try WMCore.tlv(3, [0])
            req += try WMCore.tlv(5, Array(virtual.suffix(6).utf8))
            req += try WMCore.tlv(6, enc)
            req += try WMCore.tlv(7, iv)
            try sendPlain(1, 0x0e, req)
            return
        }
        if service == 1 && command == 0x0e && phase == "BOND_KEY" {
            if let e = try Wire.number(fields, 0x7f), e != 0, e != 100000 { throw WMFault("BOND_KEY_REJECTED") }
            guard let l = lite else { throw WMFault("LITE_CONTEXT_MISSING") }
            let key = l.savedActiveKey()
            try store.saveAuthKey(address, key)
            try activateCandidate(key)
            return
        }
        if service == 1 && command == 2 && phase == "VERIFY_SESSION" {
            if !encrypted { throw WMFault("SESSION_KEY_PROBE_REPLY_NOT_ENCRYPTED") }
            try WatchConnection.checkInitHeader(fields, "SERVICE_CAPABILITIES_REJECTED")
            try caps.parseServices(body)
            sessionVerified = true
            log.record("SESSION_VERIFIED", "encrypted_service_reply=true initialization_complete=false")
            stage("COMMAND_CAPS", "Phiên đã được xác minh, đang đọc khả năng của thiết bị", 15000)
            try sendEncrypted(1, 3, caps.commandsForSupportedServices())
            return
        }
        if service == 1 && command == 3 && phase == "COMMAND_CAPS" {
            try WatchConnection.checkInitHeader(fields, "COMMAND_CAPABILITIES_REJECTED")
            try caps.parseCommands(body)
            try advanceInit(0)
            return
        }
        if cipher != nil && DeviceTelemetry.matches(service, command) {
            // Gói pin 01/08 dạng rõ vẫn được chấp nhận như app gốc (chỉ trong phạm vi yêu cầu đã gửi);
            // nó không phải bằng chứng phiên — vẫn cần 01/02 mã hoá và READY mới công bố.
            if !encrypted && (service != DeviceTelemetry.configService || command != DeviceTelemetry.batteryCommand) {
                log.record("DEVICE_STATS_UNAVAILABLE", "service=\(service) command=\(command) encrypted=false ready_gate=false")
                return
            }
            guard own == epoch, let t = telemetry, t.complete(own, service, command) else {
                log.record("DEVICE_STATS_UNOWNED_REPLY", "service=\(service) command=\(command) published=false")
                return
            }
            do {
                try WatchConnection.checkInitHeader(fields, "DEVICE_STATS_REJECTED")
                if service == DeviceInfo.service && command == DeviceInfo.productCommand {
                    observeProductInfo(own, fields)
                } else {
                    let stats = try DeviceTelemetry.parse(service, command, fields)
                    t.observe(own, stats)
                    publishDeviceInformation(own)
                }
                log.record("DEVICE_STATS_REPLY", "service=\(service) command=\(command) encrypted=\(encrypted) ready_gate=false")
            } catch {
                log.record("DEVICE_STATS_UNAVAILABLE",
                           "service=\(service) command=\(command) code=\(WMCore.code(error)) ready_gate=false")
            }
            return
        }
        if cipher != nil && service == 1 && auxiliaryPending.remove(command) != nil {
            do {
                try WatchConnection.checkInitHeader(fields, "AUXILIARY_REPLY_ERROR")
                log.record("INIT_AUX_REPLY", "command=\(command) received=true ready_gate=false")
            } catch {
                log.record("INIT_AUX_UNAVAILABLE", "command=\(command) code=\(WMCore.code(error)) ready_gate=false")
            }
            return
        }
        if sessionVerified && service == initService && command == initCommand {
            try handleInitReply(body, fields)
            return
        }
        if ready { listener?.onPacket(epoch: epoch, service: service, command: command, plain: body, encrypted: encrypted) }
    }

    // MARK: Thông tin thiết bị

    /// Tên, firmware, seri, model được kiểm tra độc lập; có thể dùng tên sớm, phần còn lại chỉ công bố sau READY.
    private func observeProductInfo(_ own: Int, _ fields: [TlvView.Part]) {
        if own != epoch { return }
        guard let t = telemetry else { return }
        do {
            if let fw = try WristInitialization.productFirmware(fields) { observedFirmware = fw }
        } catch {
            log.record("DEVICE_INFO_UNAVAILABLE", "source=01/07 field=07 code=\(WMCore.code(error)) keep_unknown=true")
        }
        if observedModel == nil && !knownDeviceModelGuard(address) {
            do { observedModel = try DeviceInfo.model(fields) }
            catch {
                log.record("DEVICE_MODEL_UNAVAILABLE", "source=01/07 field=0A code=\(WMCore.code(error)) keep_cache=true")
            }
        }
        do {
            let s = try DeviceTelemetry.parse(DeviceInfo.service, DeviceInfo.productCommand, fields)
            t.observe(own, s)
        } catch {
            log.record("DEVICE_STATS_UNAVAILABLE", "service=1 command=7 field=9 code=\(WMCore.code(error)) ready_gate=false")
        }
        do { deviceName = try WristInitialization.productName(fields, fallback: deviceName) }
        catch {
            log.record("PRODUCT_NAME_UNAVAILABLE", "source=01/07 code=\(WMCore.code(error)) keep_name=true")
        }
        publishDeviceInformation(own)
    }

    private func canPublish(_ own: Int) -> Bool {
        own == epoch && sessionVerified && ready && cipher != nil && telemetry != nil && listener != nil
    }

    private func publishDeviceInformation(_ own: Int) {
        if !canPublish(own) { return }
        if let fw = observedFirmware, fw != publishedFirmware {
            publishedFirmware = fw // đánh dấu trước callback để chống tái nhập
            log.record("DEVICE_INFO_OBSERVED", "source=01/07 field=07 firmware_valid=true")
            listener?.onDeviceInfo(epoch: own, firmware: fw)
        }
        if !canPublish(own) { return }
        if let model = observedModel, publishedModel == nil, !knownDeviceModelGuard(address),
           !store.removals.blocked(address), !pendingRemovalGuard(address) {
            publishedModel = model
            log.record("DEVICE_MODEL_OBSERVED", "source=01/07 field=0A model_valid=true")
            listener?.onDeviceModel(epoch: own, model: model)
        }
        if !canPublish(own) { return }
        if let t = telemetry, let update = t.publication(own, sessionVerified: sessionVerified, ready: ready) {
            log.record("DEVICE_STATS_OBSERVED",
                       "serial_valid=\(update.serialNumber != nil) battery_valid=\(update.batteryPercent != nil) music_storage_display_valid=\(update.freeMemoryBytes != nil)")
            listener?.onDeviceStats(epoch: own, serialNumber: update.serialNumber,
                                    batteryPercent: update.batteryPercent, freeMemoryBytes: update.freeMemoryBytes)
        }
    }

    // MARK: PIN

    private func requestPin() throws {
        stage("PIN_REQUEST", "Yêu cầu thông tin ghép nối giao thức từ đồng hồ", 15000)
        try sendPlain(1, 0x2c, WMCore.tlv(1, []))
    }

    func submitPin(expectedEpoch: Int, entered: String?) {
        protoQueue.async { [self] in
            if epoch != expectedEpoch || store.removals.blocked(address) || phase != "PIN_INPUT" { return }
            do {
                let input = Array((entered ?? "").trimmingCharacters(in: .whitespacesAndNewlines).utf8)
                if input.count < 1 || input.count > 64 { throw WMFault("PIN_INPUT_LENGTH") }
                pin = input
                listener?.onPin(needed: false, message: "")
                if caps.iso() { try startIso(pairing: true, secret: input) } else { try startLite() }
            } catch {
                fail(WMCore.code(error))
            }
        }
    }

    // MARK: Xác thực Lite / ISO

    private func startLite() throws {
        lite?.close()
        let l = try LiteAuth(caps: caps, pin: pin, saved: stored, random: random)
        lite = l
        stage("LITE_AUTH", "Xác minh bằng chứng xác thực Lite của thiết bị", 15000)
        try sendPlain(1, 0x13, l.requestBody(pin: pin))
    }

    private func startIso(pairing: Bool, secret: [UInt8]) throws {
        iso?.close()
        guard let sid = selfId else { throw WMFault("CLIENT_IDENTITY_REQUIRED") }
        usedSavedKey = !pairing
        let a = try IsoAuth(pairing: pairing, self32: sid, pinRawOrSavedSecret: secret,
                            requestId: wallMs(), random: random)
        iso = a
        stage("ISO_AUTH",
              pairing ? "Xác minh bằng chứng ghép nối giao thức mới" : "Dùng khoá bền của ứng dụng để thương lượng khoá phiên mới",
              15000)
        try sendPlain(1, 0x28, a.requestTlv(a.startRequest()))
    }

    private func handleIso(_ fields: [TlvView.Part]) throws {
        guard let a = iso else { throw WMFault("ISO_CONTEXT_MISSING") }
        log.record("ISO_REPLY_SHAPE", IsoReplyHandler.describe(a, fields))
        do {
            let reply = try IsoReplyHandler.apply(a, fields)
            if reply.kind == .peerRejected { try peerRejected(); return }
            if reply.kind == .controlCompletion {
                log.record("ISO_CONTROL_COMPLETION", "operation=\(a.operation) tag1_json_parsed=false initialized=false")
                if let candidate = reply.candidate {
                    try activateCandidate(candidate)
                } else {
                    guard let learned = try store.authKey(address) else { throw WMFault("ISO_PAIR_SECRET_NOT_STORED") }
                    try startIso(pairing: false, secret: learned)
                }
                return
            }
            // QUAN TRỌNG: lưu learnedSecret TRƯỚC khi gửi bước kế tiếp (xem chú thích đầu IsoAuth.swift).
            try saveLearnedSecret()
            stage("ISO_AUTH", "Xác minh giai đoạn ISO \(a.expectedStage())", 15000)
            if let next = reply.next { try sendPlain(1, 0x28, a.requestTlv(next)) }
        } catch is IsoPeerError {
            try saveLearnedSecret()
            try peerRejected()
        } catch {
            try saveLearnedSecret()
            throw error
        }
    }

    private func saveLearnedSecret() throws {
        guard let a = iso, let learned = a.learnedSecret() else { return }
        try store.saveAuthKey(address, learned)
    }

    private func peerRejected() throws {
        guard let a = iso else { throw WMFault("ISO_CONTEXT_MISSING") }
        if a.operation == 2 && usedSavedKey && rebindCount == 0 {
            stage("REBIND_CONFIRM", "Thiết bị từ chối khoá giao thức đã lưu, có thể liên kết lại", 120000)
            listener?.onRebind(message: "Thiết bị đã từ chối khoá giao thức được lưu. Liên kết lại có thể thay đổi quan hệ kết nối giữa đồng hồ và các ứng dụng khác. Bạn có muốn tiếp tục không?")
        } else {
            throw WMFault("ISO_PEER_ERROR")
        }
    }

    /// Người dùng đồng ý liên kết lại: xoá khoá đã lưu rồi mở lại kết nối.
    func confirmRebind(expectedEpoch: Int) {
        protoQueue.async { [self] in
            if epoch != expectedEpoch || phase != "REBIND_CONFIRM" || rebindCount != 0 { return }
            do {
                let consentAddress = address
                try store.clearAuthKey(consentAddress)
                rebindCount = 1
                closeLocal()
                epoch += 1
                let consentEpoch = epoch
                stage("REBINDING", "Đang liên kết lại với đồng hồ", 15000)
                protoQueue.asyncAfter(deadline: .now() + .milliseconds(800)) { [self] in
                    if epoch != consentEpoch || phase != "REBINDING" || address != consentAddress { return }
                    do { try openLink(rebinding: true) } catch { fail(WMCore.code(error)) }
                }
            } catch {
                fail(WMCore.code(error))
            }
        }
    }

    // MARK: Phiên mã hoá + khởi tạo

    private func activateCandidate(_ key: [UInt8]) throws {
        cipher?.close()
        cipher = try CryptoSession(sessionKey: key, method: caps.encryptMethod,
                                   supportType: caps.deviceSupportType, counter: legacyCounter, random: random)
        sessionVerified = false
        initUnconfirmed = false
        initService = -1; initCommand = -1; nextInit = -1
        auxiliaryPending.removeAll()
        auxiliaryPending.insert(5)
        if telemetry == nil || telemetry?.epoch != epoch { telemetry = DeviceTelemetry.ProbeOwner(epoch: epoch) }
        // Phải nhận quyền sở hữu TRƯỚC khi gửi bất kỳ gói/callback nào.
        let initialQueries = telemetry?.markInitializationRequests(epoch) ?? false
        stage("VERIFY_SESSION", "Xác thực đạt; đọc sản phẩm/khả năng và đồng bộ giờ điện thoại; chờ phản hồi mã hoá của phiên", 15000)
        // Thứ tự đã kiểm chứng: 07 + 05 + 08 + 02; 07/08 dùng lại truy vấn này, không gửi bù ở READY/Home/làm mới.
        if initialQueries { try sendEncrypted(1, 7, WristInitialization.productRequest()) }
        let offsetMs = TimeZone.current.secondsFromGMT(for: Date()) * 1000
        try sendEncrypted(1, 5, WristInitialization.timeRequest(utcMillis: wallMs(), offsetMillis: offsetMs))
        if initialQueries { try sendEncrypted(1, 8, WMCore.tlv(1, [])) }
        try sendEncrypted(1, 2, LinkCapabilities.servicesRequest())
    }

    private static func checkInitHeader(_ fields: [TlvView.Part], _ code: String) throws {
        if let e = try Wire.number(fields, 0x7f), e != 0, e != 100000 { throw WMFault(code) }
    }

    /// Bước khởi tạo tuỳ chọn: nếu 1500 ms không có phản hồi thì đi tiếp (không phải bằng chứng xác thực).
    private func initRequest(_ code: String, _ detail: String, _ service: Int, _ command: Int,
                             _ body: [UInt8], _ next: Int, isOptional: Bool) throws {
        if !sessionVerified || cipher == nil || ready { throw WMFault("INITIALIZATION_SESSION_REQUIRED") }
        initService = service; initCommand = command; nextInit = next
        stage(code, detail, isOptional ? 0 : 15000)
        let own = epoch
        let serial = stageSerial
        try sendEncrypted(service, command, body)
        if isOptional {
            protoQueue.asyncAfter(deadline: .now() + .milliseconds(Int(WristInitialization.optionalWaitMs))) { [self] in
                if epoch != own || stageSerial != serial || phase != code || ready || !sessionVerified { return }
                initUnconfirmed = true
                initService = -1; initCommand = -1; nextInit = -1
                log.record("INIT_OPTIONAL_TIMEOUT", "phase=\(code) continued=true acknowledgment_confirmed=false")
                do { try advanceInit(next) } catch { fail(WMCore.code(error)) }
            }
        }
    }

    private func handleInitReply(_ body: [UInt8], _ fields: [TlvView.Part]) throws {
        let current = phase
        let next = nextInit
        initService = -1; initCommand = -1; nextInit = -1
        do {
            try WatchConnection.checkInitHeader(
                fields, current == "CONNECT_NOTIFY" ? "CONNECT_NOTIFY_REJECTED" : "INIT_OPTIONAL_REPLY_ERROR")
            if current == "EXPAND_CAPS" { try caps.parseExpand(body) }
            if current == "ACCOUNT" {
                let result = try Wire.unique(fields, 2)
                let text: String
                if let r = result, let first = r.value.first { text = String(first) } else { text = "absent" }
                log.record("ACCOUNT_REPLY", "result=\(text) account_switch_sent=false")
            }
            let he = try? Wire.number(fields, 0x7f)
            log.record("INIT_REPLY", "phase=\(current) received=true header_error=\(optText(he)) default_success_assumed=false")
        } catch {
            if current == "CONNECT_NOTIFY" { throw error }
            initUnconfirmed = true
            log.record("INIT_OPTIONAL_UNCONFIRMED", "phase=\(current) code=\(WMCore.code(error)) continued=true")
        }
        try advanceInit(next)
    }

    private func skipped(_ code: String) {
        log.record("INIT_SKIPPED", "phase=\(code) supported_or_requested=false")
    }

    private func advanceInit(_ step: Int) throws {
        if !sessionVerified || cipher == nil || ready || phase == "FAILED" || phase == "IDLE" {
            throw WMFault("INITIALIZATION_SESSION_REQUIRED")
        }
        switch step {
        case 0:
            if caps.hasCommand(1, 0x37) {
                try initRequest("EXPAND_CAPS", "Đọc khả năng mở rộng", 1, 0x37, WMCore.tlv(1, []), 1, isOptional: true)
                return
            }
            skipped("EXPAND_CAPS"); try advanceInit(1)
        case 1:
            if caps.accountSupported() && !huaweiId.isEmpty {
                try initRequest("ACCOUNT", "Gửi kèm ID Huawei", 0x1a, 5, caps.accountRequest(huaweiId), 2, isOptional: true)
                return
            }
            skipped("ACCOUNT"); try advanceInit(2)
        case 2:
            if caps.hasCommand(1, 0x31) {
                try initRequest("SETTINGS", "Đọc các mục cài đặt khởi tạo", 1, 0x31, WristInitialization.settingsRequest(), 3, isOptional: true)
                return
            }
            skipped("SETTINGS"); try advanceInit(3)
        case 3:
            if caps.hasCommand(1, 0x30) {
                stage("AGREEMENT_CONFIRM", "Tiếp tục hoàn tất khởi tạo kết nối", 120000)
                return
            }
            skipped("AGREEMENTS"); try advanceInit(4)
        case 4:
            if caps.hasCommand(1, 0x3f) {
                try initRequest("REVERSE_CAPS", "Gửi khai báo khả năng ngược của giao thức gốc", 1, 0x3f, WristInitialization.reverseRequest(), 5, isOptional: true)
                return
            }
            skipped("REVERSE_CAPS"); try advanceInit(5)
        case 5:
            if caps.bit(109) {
                try initRequest("SETUP_DEVICE", "Khởi tạo trạng thái kết nối nhiều thiết bị", 1, 0x3e, WristInitialization.setupRequest(deviceName: deviceName), 6, isOptional: true)
                return
            }
            skipped("SETUP_DEVICE"); try advanceInit(6)
        case 6:
            if caps.hasCommand(1, 0x12) {
                try initRequest("ACTIVITY_TYPES", "Đọc hỗ trợ loại hoạt động", 1, 0x12, WMCore.tlv(1, []), 7, isOptional: true)
                return
            }
            skipped("ACTIVITY_TYPES"); try advanceInit(7)
        case 7:
            if caps.bit(109) {
                try initRequest("WEAR_STATUS", "Đọc trạng thái đeo", 1, 0x3d, WMCore.tlv(1, []), 8, isOptional: true)
                return
            }
            skipped("WEAR_STATUS"); try advanceInit(8)
        case 8:
            if caps.hasCommand(1, 0x35) {
                try initRequest("CONNECT_NOTIFY", "Báo đồng hồ khởi tạo kết nối xong, chờ phản hồi của yêu cầu hiện tại", 1, 0x35, WristInitialization.connectedRequest(), 9, isOptional: false)
                return
            }
            skipped("CONNECT_NOTIFY"); try finishReady()
        case 9:
            try finishReady()
        default:
            throw WMFault("INITIALIZATION_STEP_INVALID")
        }
    }

    /// Đồng ý điều khoản: không ghi nhớ, không mặc định; mỗi lần là một lựa chọn rõ ràng gắn với kết nối hiện tại.
    func respondAgreements(expectedEpoch: Int, accept: Bool) {
        protoQueue.async { [self] in
            if epoch != expectedEpoch || phase != "AGREEMENT_CONFIRM" || !sessionVerified || cipher == nil || ready { return }
            do {
                if accept {
                    log.record("AGREEMENT_CHOICE", "explicit_accept=true")
                    try initRequest("AGREEMENTS", "Gửi ba khai báo điều khoản bạn đã đồng ý rõ ràng", 1, 0x30,
                                    WristInitialization.agreementsRequest(millis: wallMs()), 4, isOptional: true)
                } else {
                    log.record("AGREEMENT_CHOICE", "explicit_accept=false sent=false")
                    try advanceInit(4)
                }
            } catch {
                fail(WMCore.code(error))
            }
        }
    }

    private func finishReady() throws {
        guard sessionVerified, cipher != nil else { throw WMFault("VERIFIED_SESSION_REQUIRED") }
        if ready { return }
        let own = epoch
        let supportsStorage = caps.hasService(DeviceTelemetry.musicService)
            && caps.hasCommand(DeviceTelemetry.musicService, DeviceTelemetry.musicStorageCommand)
        let storageProbe = telemetry?.markReadyStorageRequest(own, sessionVerified: sessionVerified, ready: true,
                                                              supported: supportsStorage) ?? false
        ready = true
        initService = -1; initCommand = -1; nextInit = -1
        log.record("INITIALIZATION_COMPLETE",
                   "session_verified=true optional_unconfirmed=\(initUnconfirmed) coexistence_verified=false")
        stage("READY", initUnconfirmed ? "Kết nối đã sẵn sàng, một số phản hồi khởi tạo chưa được xác nhận" : "Khởi tạo kết nối hoàn tất", 0)
        listener?.onReady(epoch: own, caps: caps)
        publishDeviceInformation(own)
        if own != epoch || !ready || !sessionVerified || cipher == nil { return }
        log.record("DEVICE_STATS_PROBE",
                   "product_reused=true battery_reused=true music_storage_supported=\(storageProbe) additional_read_queries=\(storageProbe ? 1 : 0) repeat_on_refresh=false")
        if storageProbe { try sendStorageProbe(own) }
    }

    /// Chỉ gửi một lần từ cửa READY; lỗi gửi tuỳ chọn không thử lại.
    private func sendStorageProbe(_ own: Int) throws {
        guard own == epoch, ready, sessionVerified, let c = cipher, let t = telemetry,
              t.pending(own, DeviceTelemetry.musicService, DeviceTelemetry.musicStorageCommand) else { return }
        let body = try DeviceTelemetry.musicStorageRequest()
        let payload = try c.seal(body)
        let parsed = try TlvView.decode(body)
        log.packet(false, DeviceTelemetry.musicService, DeviceTelemetry.musicStorageCommand, body.count, parsed, true)
        do {
            guard let ch = channel else { throw WMFault("CHANNEL_NOT_READY") }
            let frames = try FrameCodec.encode(service: DeviceTelemetry.musicService,
                                               command: DeviceTelemetry.musicStorageCommand,
                                               body: payload, maxFrameBytes: caps.sliceSize)
            try ch.send(frames: frames, peerMtu: caps.mtu, intervalMs: caps.intervalMs)
        } catch {
            _ = t.complete(own, DeviceTelemetry.musicService, DeviceTelemetry.musicStorageCommand)
            log.record("DEVICE_STATS_UNAVAILABLE",
                       "service=37 command=4 code=\(WMCore.code(error)) retry=false ready_gate=false")
        }
    }

    // MARK: Gửi gói

    /// Gửi gói điều khiển mã hoá (chỉ khi đã READY).
    func sendControl(_ service: Int, _ command: Int, _ body: [UInt8]) throws {
        if !ready || cipher == nil { throw WMFault("AUTHENTICATED_CONNECTION_REQUIRED") }
        try sendEncrypted(service, command, body)
    }

    /// Gửi lại giờ + múi giờ của điện thoại (cùng lệnh 01/05 như lúc khởi tạo). Chỉ khi đã READY.
    func syncTime() throws {
        if !ready || cipher == nil { throw WMFault("AUTHENTICATED_CONNECTION_REQUIRED") }
        // Cho phép nhận phản hồi 01/05 muộn mà không bị coi là gói lạ.
        auxiliaryPending.insert(5)
        let offsetMs = TimeZone.current.secondsFromGMT(for: Date()) * 1000
        try sendEncrypted(1, 5, WristInitialization.timeRequest(utcMillis: wallMs(), offsetMillis: offsetMs))
    }

    /// Gửi gói truyền file 0x28 (chỉ khi đã READY).
    func sendFile(_ command: Int, _ body: [UInt8], encrypt: Bool) throws {
        if !ready || cipher == nil { throw WMFault("AUTHENTICATED_CONNECTION_REQUIRED") }
        try send(0x28, command, body, encrypt: encrypt)
    }

    private func sendPlain(_ service: Int, _ command: Int, _ body: [UInt8]) throws {
        try send(service, command, body, encrypt: false)
    }

    private func sendEncrypted(_ service: Int, _ command: Int, _ body: [UInt8]) throws {
        if cipher == nil { throw WMFault("SESSION_KEY_REQUIRED") }
        try send(service, command, body, encrypt: true)
    }

    private func send(_ service: Int, _ command: Int, _ body: [UInt8], encrypt: Bool) throws {
        try store.removals.requireUsable(address)
        guard let ch = channel else { throw WMFault("CHANNEL_NOT_READY") }
        let payload: [UInt8]
        if encrypt {
            guard let c = cipher else { throw WMFault("SESSION_KEY_REQUIRED") }
            payload = try c.seal(body)
        } else {
            payload = body
        }
        let parsed = try? TlvView.decode(body)
        log.packet(false, service, command, body.count, parsed, encrypt)
        let frames = try FrameCodec.encode(service: service, command: command, body: payload, maxFrameBytes: caps.sliceSize)
        try ch.send(frames: frames, peerMtu: caps.mtu, intervalMs: caps.intervalMs)
    }

    // MARK: Hết giờ / lỗi / dọn dẹp

    private func tick(_ own: Int) {
        protoQueue.asyncAfter(deadline: .now() + 1) { [self] in
            if epoch != own || phase == "IDLE" || phase == "FAILED" { return }
            if deadline != 0 && nowMs() > deadline {
                // Đồng hồ im lặng với khoá đã lưu (op2): khoá cũ/không còn khớp → đề nghị liên kết lại thay vì báo lỗi.
                if phase == "ISO_AUTH", let a = iso, a.operation == 2, usedSavedKey, rebindCount == 0 {
                    log.record("ISO_SAVED_KEY_TIMEOUT", "offering_rebind=true")
                    do { try peerRejected(); tick(own); return } catch { }
                }
                fail("CONNECTION_STAGE_TIMEOUT_\(phase)"); return
            }
            tick(own)
        }
    }

    func protocolFailure(_ code: String) { execute { [self] in fail(code) } }

    private func fail(_ code: String) {
        let closingEpoch = epoch
        log.record("LINK_FAILED", "code=\(code)")
        closeLocal()
        ready = false
        epoch += 1
        stage("FAILED", code, 0)
        listener?.onPin(needed: false, message: "")
        listener?.onClosed(closedEpoch: closingEpoch, reason: code)
    }

    private func closeLocal() {
        ready = false
        sessionVerified = false
        initService = -1; initCommand = -1; nextInit = -1
        auxiliaryPending.removeAll()
        telemetry = nil
        observedFirmware = nil; publishedFirmware = nil
        observedModel = nil; publishedModel = nil
        stageSerial += 1
        channel?.close(); channel = nil
        cipher?.close(); cipher = nil
        iso?.close(); iso = nil
        lite?.close(); lite = nil
        stored = nil; selfId = nil; pin = nil
        decoder.clear()
    }
}
