// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Số liệu do đồng hồ cập nhật: pin, bước chân, nhịp tim, calo, thời tiết
//
// Cấu trúc lấy từ các file HWT thật (Kozmik Kule / Kristal / Ultimate, màn hình HWHD09):
// - Số (pin, bước chân, nhịp tim, calo, nhiệt độ) là lớp loại 3: 10 ảnh chữ số 0...9, ảnh dấu trừ, một ảnh đơn vị
//   ghép sau số (ví dụ "%", "bpm", "°") và mã loại số liệu (HwtDataType). Đồng hồ tự ghép chữ số và cập nhật.
// - Tình trạng thời tiết là dãy ảnh theo mã 53 (giá trị 0...10), dùng cho cả biểu tượng lẫn tên tình trạng.
// Xem trước dùng số liệu mẫu cố định; số thật do đồng hồ cập nhật.

/// Một mục số liệu: bật/tắt, màu, cỡ chữ, vị trí.
struct DataWidget {
    var show = false
    var color = Color.white
    var size = 1.0
    /// Vị trí ngang của MÉP TRÁI khối (tỉ lệ 0.1 ... 0.9 bề ngang mặt đồng hồ).
    var x = 0.5
    /// Vị trí dọc của tâm khối (tỉ lệ 0.1 ... 0.9).
    var y = 0.5
    /// Hiện đơn vị (%, bpm, kcal…) sau số.
    var unit = true
}

/// Các mục số đơn giản (một số + đơn vị).
enum DataKind: CaseIterable {
    case battery, steps, heart, calories

    var dataType: Int {
        switch self {
        case .battery: return HwtDataType.battery
        case .steps: return HwtDataType.steps
        case .heart: return HwtDataType.heartRate
        case .calories: return HwtDataType.calories
        }
    }

    /// Số chữ số tối đa dành chỗ (để khối không tràn khỏi mặt đồng hồ).
    var maxDigits: Int {
        switch self {
        case .battery: return 3
        case .steps: return 6
        case .heart: return 3
        case .calories: return 5
        }
    }

    /// Số liệu mẫu cho ảnh xem trước.
    var sample: Int {
        switch self {
        case .battery: return 86
        case .steps: return 8432
        case .heart: return 72
        case .calories: return 412
        }
    }

    var suffix: String {
        switch self {
        case .battery: return "%"
        case .steps: return " bước"
        case .heart: return " bpm"
        case .calories: return " kcal"
        }
    }
}

extension FaceDesign {
    func dataWidget(_ kind: DataKind) -> DataWidget {
        switch kind {
        case .battery: return battery
        case .steps: return steps
        case .heart: return heart
        case .calories: return calories
        }
    }
}

/// Bố cục một số + đơn vị (căn trái: (x, y) là góc trên-trái của chữ số đầu tiên).
struct DataNumberLayout {
    let font: UIFont
    let suffixFont: UIFont
    let digitW: Int
    let lineH: Int
    let suffix: String
    let suffixW: Int
    let x: Int
    let y: Int
}

/// Bố cục khối thời tiết: biểu tượng + nhiệt độ (+ tên tình trạng, + cao/thấp).
struct WeatherLayout {
    let numFont: UIFont
    let degFont: UIFont
    let digitW: Int
    let lineH: Int
    let degW: Int
    let iconS: Int
    let gap: Int
    let x: Int
    let y: Int
    let rowH: Int
    let showText: Bool
    let textFont: UIFont
    let textW: Int
    let textH: Int
    let showRange: Bool
    let rangeFont: UIFont
    let rangeDegFont: UIFont
    let rangeDigitW: Int
    let rangeLineH: Int
    let rangeDegW: Int
    let arrowW: Int
    let groupW: Int
    let rangeGap: Int

    var iconY: Int { y + (rowH - iconS) / 2 }
    var numX: Int { x + iconS + gap }
    var numY: Int { y + (rowH - lineH) / 2 }
    var textY: Int { y + rowH + 2 }
    var rangeY: Int { y + rowH + 2 + (showText ? textH + 2 : 0) }
    var loX: Int { x + groupW + rangeGap }

    init(_ d: FaceDesign) {
        let k = FaceRenderer.dataScale(d.weather.size)
        let nf = UIFont.monospacedDigitSystemFont(ofSize: 34 * k, weight: .bold)
        let df = UIFont.systemFont(ofSize: 30 * k, weight: .bold)
        let dw = FaceRenderer.dataTextWidth("0", nf)
        let lh = Int(ceil(nf.lineHeight)) + 2
        let degw = FaceRenderer.dataTextWidth("°", df)
        let iS = Int((40 * k).rounded())
        let g = Int((6 * k).rounded())
        let rh = max(iS, lh)

        let tf = UIFont.systemFont(ofSize: 15 * k, weight: .semibold)
        let tw = FaceRenderer.weatherNames.map { FaceRenderer.dataTextWidth($0, tf) }.max() ?? 80
        let th = Int(ceil(tf.lineHeight)) + 2

        let rf = UIFont.monospacedDigitSystemFont(ofSize: 20 * k, weight: .semibold)
        let rdf = UIFont.systemFont(ofSize: 18 * k, weight: .semibold)
        let rdw = FaceRenderer.dataTextWidth("0", rf)
        let rlh = Int(ceil(rf.lineHeight)) + 2
        let rdeg = FaceRenderer.dataTextWidth("°", rdf)
        let aw = FaceRenderer.dataTextWidth("↑", rf)
        let gw = aw + rdw * 2 + rdeg
        let rgap = rdw

        var bw = iS + g + dw * 3 + degw
        var bh = rh
        if d.weatherText { bw = max(bw, tw); bh += th + 2 }
        if d.weatherRange { bw = max(bw, gw * 2 + rgap); bh += rlh + 2 }
        let side = Int(FaceRenderer.size)
        let left = max(0, min(side - bw, Int(FaceRenderer.size * FaceRenderer.dataUnit(d.weather.x))))
        let top = max(0, min(side - bh, Int(FaceRenderer.size * FaceRenderer.dataUnit(d.weather.y)) - bh / 2))

        numFont = nf
        degFont = df
        digitW = dw
        lineH = lh
        degW = degw
        iconS = iS
        gap = g
        x = left
        y = top
        rowH = rh
        showText = d.weatherText
        textFont = tf
        textW = tw
        textH = th
        showRange = d.weatherRange
        rangeFont = rf
        rangeDegFont = rdf
        rangeDigitW = rdw
        rangeLineH = rlh
        rangeDegW = rdeg
        arrowW = aw
        groupW = gw
        rangeGap = rgap
    }
}

extension FaceRenderer {
    /// Tên tình trạng thời tiết theo mã 0...10 (thứ tự như file HWT thật).
    static let weatherNames = ["Không có dữ liệu", "Nắng", "Trời quang", "Ít mây", "Nhiều mây", "Mưa",
                               "Dông", "Tuyết", "Bão cát", "Mù", "Sương mù"]

    /// Biểu tượng SF Symbols và các màu (lớp chính trước) cho từng tình trạng 0...10.
    private static var weatherSymbols: [(name: String, colors: [UIColor])] {
        let white = UIColor.white
        let gray = UIColor(white: 0.72, alpha: 1)
        let yellow = UIColor(red: 1.0, green: 0.80, blue: 0.20, alpha: 1)
        let cyan = UIColor(red: 0.35, green: 0.78, blue: 1.0, alpha: 1)
        let sand = UIColor(red: 0.80, green: 0.62, blue: 0.38, alpha: 1)
        return [
            ("cloud.fill", [gray, gray]),
            ("sun.max.fill", [yellow, yellow]),
            ("moon.stars.fill", [yellow, white]),
            ("cloud.sun.fill", [white, yellow]),
            ("cloud.fill", [white, white]),
            ("cloud.rain.fill", [white, cyan]),
            ("cloud.bolt.rain.fill", [white, yellow, cyan]),
            ("cloud.snow.fill", [white, cyan]),
            ("sun.dust.fill", [yellow, sand]),
            ("sun.haze.fill", [yellow, gray]),
            ("cloud.fog.fill", [white, gray])
        ]
    }

    static func dataScale(_ s: Double) -> CGFloat { CGFloat(min(1.8, max(0.6, s))) }
    static func dataUnit(_ v: Double) -> CGFloat { CGFloat(min(0.9, max(0.1, v))) }

    static func dataTextWidth(_ t: String, _ f: UIFont) -> Int {
        Int(ceil((t as NSString).size(withAttributes: [.font: f]).width)) + 2
    }

    // MARK: Bố cục

    static func dataNumberLayout(_ kind: DataKind, _ w: DataWidget) -> DataNumberLayout {
        let k = dataScale(w.size)
        let font = UIFont.monospacedDigitSystemFont(ofSize: 34 * k, weight: .bold)
        let sfont = UIFont.systemFont(ofSize: 15 * k, weight: .semibold)
        let digitW = dataTextWidth("0", font)
        let lineH = Int(ceil(font.lineHeight)) + 2
        let suffix = w.unit ? kind.suffix : ""
        let suffixW = suffix.isEmpty ? 0 : dataTextWidth(suffix, sfont)
        let total = digitW * kind.maxDigits + suffixW
        let side = Int(size)
        let x = max(0, min(side - total, Int(size * dataUnit(w.x))))
        let y = max(0, min(side - lineH, Int(size * dataUnit(w.y)) - lineH / 2))
        return DataNumberLayout(font: font, suffixFont: sfont, digitW: digitW, lineH: lineH,
                                suffix: suffix, suffixW: suffixW, x: x, y: y)
    }

    // MARK: Vẽ chữ

    /// Vẽ đơn vị cùng đường cơ sở với chữ số (ctx kiểu UIKit, gốc trên-trái).
    static func drawSuffixText(_ text: String, font: UIFont, numFont: UIFont, color: UIColor, in rect: CGRect) {
        guard !text.isEmpty else { return }
        let numTop = (rect.height - numFont.lineHeight) / 2
        let baseline = rect.minY + numTop + numFont.ascender
        let s = NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: color])
        s.draw(at: CGPoint(x: rect.minX + 1, y: baseline - font.ascender))
    }

    /// Vẽ chuỗi số căn trái, mỗi chữ số một ô rộng `digitW`. Trả về toạ độ x ngay sau chữ số cuối.
    @discardableResult
    static func drawNumberString(_ text: String, font: UIFont, digitW: Int, lineH: Int, x: Int, y: Int, color: UIColor) -> Int {
        var cx = x
        for ch in text {
            drawLunarText(String(ch), font: font, color: color, in: CGRect(x: cx, y: y, width: digitW, height: lineH))
            cx += digitW
        }
        return cx
    }

    static func drawWeatherSymbol(_ index: Int, in rect: CGRect) {
        let symbols = weatherSymbols
        guard index >= 0, index < symbols.count else { return }
        let s = symbols[index]
        let cfg = UIImage.SymbolConfiguration(pointSize: rect.height * 0.78, weight: .regular)
            .applying(UIImage.SymbolConfiguration(paletteColors: s.colors))
        guard let img = UIImage(systemName: s.name, withConfiguration: cfg)?.withRenderingMode(.alwaysOriginal) else { return }
        let sz = img.size
        guard sz.width > 0, sz.height > 0 else { return }
        let k = min(rect.width / sz.width, rect.height / sz.height)
        let w = sz.width * k, h = sz.height * k
        img.draw(in: CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h))
    }

    private static let rangeHighColor = UIColor(red: 1.0, green: 0.62, blue: 0.25, alpha: 1)
    private static let rangeLowColor = UIColor(red: 0.30, green: 0.85, blue: 0.85, alpha: 1)
    private static let sampleCondition = 3
    private static let sampleTemp = 18
    private static let sampleHigh = 21
    private static let sampleLow = 12

    // MARK: Xem trước

    static func drawDataPreview(_ ctx: CGContext, design d: FaceDesign) {
        UIGraphicsPushContext(ctx)
        for kind in DataKind.allCases {
            let w = d.dataWidget(kind)
            guard w.show else { continue }
            let L = dataNumberLayout(kind, w)
            let color = UIColor(w.color)
            let end = drawNumberString(String(kind.sample), font: L.font, digitW: L.digitW, lineH: L.lineH, x: L.x, y: L.y, color: color)
            drawSuffixText(L.suffix, font: L.suffixFont, numFont: L.font, color: color.withAlphaComponent(0.75),
                           in: CGRect(x: end, y: L.y, width: L.suffixW, height: L.lineH))
        }
        if d.weather.show { drawWeatherPreview(d) }
        UIGraphicsPopContext()
    }

    private static func drawWeatherPreview(_ d: FaceDesign) {
        let L = WeatherLayout(d)
        let color = UIColor(d.weather.color)
        drawWeatherSymbol(sampleCondition, in: CGRect(x: L.x, y: L.iconY, width: L.iconS, height: L.iconS))
        let end = drawNumberString(String(sampleTemp), font: L.numFont, digitW: L.digitW, lineH: L.lineH, x: L.numX, y: L.numY, color: color)
        drawSuffixText("°", font: L.degFont, numFont: L.numFont, color: color,
                       in: CGRect(x: end, y: L.numY, width: L.degW, height: L.lineH))
        if L.showText {
            NSAttributedString(string: weatherNames[sampleCondition], attributes: [.font: L.textFont, .foregroundColor: color.withAlphaComponent(0.85)])
                .draw(at: CGPoint(x: L.x, y: L.textY + 1))
        }
        if L.showRange {
            func group(_ arrow: String, _ value: Int, _ gx: Int, _ tint: UIColor) {
                drawLunarText(arrow, font: L.rangeFont, color: tint, in: CGRect(x: gx, y: L.rangeY, width: L.arrowW, height: L.rangeLineH))
                let e = drawNumberString(String(value), font: L.rangeFont, digitW: L.rangeDigitW, lineH: L.rangeLineH,
                                         x: gx + L.arrowW, y: L.rangeY, color: color)
                drawSuffixText("°", font: L.rangeDegFont, numFont: L.rangeFont, color: color,
                               in: CGRect(x: e, y: L.rangeY, width: L.rangeDegW, height: L.rangeLineH))
            }
            group("↑", sampleHigh, L.x, rangeHighColor)
            group("↓", sampleLow, L.loX, rangeLowColor)
        }
    }

    // MARK: Lớp HWT

    /// Lớp HWT của tất cả mục số liệu đang bật. Bộ chữ số cùng cỡ và màu được dùng chung để tiết kiệm ảnh.
    static func dataLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        var layers = [HwtLayer]()
        var cache = [String: (digits: [Int], minus: Int)]()

        func digitSet(_ font: UIFont, _ digitW: Int, _ lineH: Int, _ color: UIColor) -> (digits: [Int], minus: Int) {
            let key = "\(font.pointSize)|\(digitW)|\(lineH)|\(color)"
            if let c = cache[key] { return c }
            var ids = [Int]()
            for n in 0...9 {
                ids.append(add(glyphRaster("\(n)", w: digitW, h: lineH, font: font, color: color)))
            }
            let minus = add(glyphRaster("-", w: digitW, h: lineH, font: font, color: color))
            let pair = (digits: ids, minus: minus)
            cache[key] = pair
            return pair
        }

        func suffixImage(_ text: String, _ font: UIFont, _ numFont: UIFont, _ w: Int, _ h: Int, _ color: UIColor) -> Int {
            if text.isEmpty || w <= 0 { return 0 }
            return add(drawRaster(width: w, height: h) { _ in
                drawSuffixText(text, font: font, numFont: numFont, color: color, in: CGRect(x: 0, y: 0, width: w, height: h))
            })
        }

        for kind in DataKind.allCases {
            let w = d.dataWidget(kind)
            guard w.show else { continue }
            let L = dataNumberLayout(kind, w)
            let color = UIColor(w.color)
            let set = digitSet(L.font, L.digitW, L.lineH, color)
            let suffix = suffixImage(L.suffix, L.suffixFont, L.font, L.suffixW, L.lineH, color.withAlphaComponent(0.75))
            layers.append(.number(digits: set.digits, minus: set.minus, suffix: suffix, x: L.x, y: L.y,
                                  align: 0, dataType: kind.dataType, ambient: false))
        }

        guard d.weather.show else { return layers }
        let L = WeatherLayout(d)
        let color = UIColor(d.weather.color)

        // Biểu tượng tình trạng (mã 53, giá trị 0...10).
        var icons = [Int]()
        for i in 0..<weatherNames.count {
            let s = L.iconS
            icons.append(add(drawRaster(width: s, height: s) { _ in
                drawWeatherSymbol(i, in: CGRect(x: 0, y: 0, width: s, height: s))
            }))
        }
        layers.append(.array(resources: icons, x: L.x, y: L.iconY, valueType: HwtValueType.weatherCondition, ambient: false))

        // Nhiệt độ hiện tại + "°".
        let tempSet = digitSet(L.numFont, L.digitW, L.lineH, color)
        let deg = suffixImage("°", L.degFont, L.numFont, L.degW, L.lineH, color)
        layers.append(.number(digits: tempSet.digits, minus: tempSet.minus, suffix: deg, x: L.numX, y: L.numY,
                              align: 0, dataType: HwtDataType.temperature, ambient: false))

        // Tên tình trạng (cùng mã 53).
        if L.showText {
            var names = [Int]()
            let tint = color.withAlphaComponent(0.85)
            for name in weatherNames {
                let w = L.textW, h = L.textH
                let font = L.textFont
                names.append(add(drawRaster(width: w, height: h) { _ in
                    NSAttributedString(string: name, attributes: [.font: font, .foregroundColor: tint])
                        .draw(at: CGPoint(x: 0, y: 1))
                }))
            }
            layers.append(.array(resources: names, x: L.x, y: L.textY, valueType: HwtValueType.weatherCondition, ambient: false))
        }

        // Nhiệt độ cao nhất / thấp nhất.
        if L.showRange {
            let rangeSet = digitSet(L.rangeFont, L.rangeDigitW, L.rangeLineH, color)
            let rangeDeg = suffixImage("°", L.rangeDegFont, L.rangeFont, L.rangeDegW, L.rangeLineH, color)
            let up = add(glyphRaster("↑", w: L.arrowW, h: L.rangeLineH, font: L.rangeFont, color: rangeHighColor))
            let down = add(glyphRaster("↓", w: L.arrowW, h: L.rangeLineH, font: L.rangeFont, color: rangeLowColor))
            layers.append(.single(resource: up, x: L.x, y: L.rangeY, ambient: false))
            layers.append(.number(digits: rangeSet.digits, minus: rangeSet.minus, suffix: rangeDeg, x: L.x + L.arrowW, y: L.rangeY,
                                  align: 0, dataType: HwtDataType.tempHigh, ambient: false))
            layers.append(.single(resource: down, x: L.loX, y: L.rangeY, ambient: false))
            layers.append(.number(digits: rangeSet.digits, minus: rangeSet.minus, suffix: rangeDeg, x: L.loX + L.arrowW, y: L.rangeY,
                                  align: 0, dataType: HwtDataType.tempLow, ambient: false))
        }
        return layers
    }
}
