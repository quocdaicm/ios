// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import PhotosUI

/// Trạng thái màn hình "Tạo mặt đồng hồ": giữ thiết kế, vẽ lại ảnh xem trước mỗi khi thiết kế đổi.
final class StudioModel: ObservableObject {
    @Published var design = FaceDesign() {
        didSet { refreshPreview() }
    }
    @Published private(set) var dayPreview: UIImage?
    @Published private(set) var aodPreview: UIImage?
    @Published private(set) var building = false

    private static let previewPixels = 320

    init() { refreshPreview() }

    private func refreshPreview() {
        dayPreview = FaceRenderer.image(design: design, ambient: false, pixels: StudioModel.previewPixels, circle: true)
        aodPreview = FaceRenderer.image(design: design, ambient: true, pixels: StudioModel.previewPixels, circle: true)
    }

    func setPhoto(_ image: UIImage?) {
        var d = design
        d.photo = image.map { FaceRenderer.downscale($0, maxSide: 1600) }
        d.photoZoom = 1; d.photoPanX = 0; d.photoPanY = 0
        design = d
    }

    /// Dựng file .hwt ở luồng nền rồi gọi `completion` trên main.
    func export(completion: @escaping (Result<URL, Error>) -> Void) {
        guard !building else { return }
        let snapshot = design
        building = true
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let result: Result<URL, Error>
            do {
                let bytes = try FaceBuilder.build(snapshot)
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("wm-studio-\(UUID().uuidString)", isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(FaceBuilder.fileName(snapshot.name))
                try Data(bytes).write(to: url, options: .atomic)
                result = .success(url)
            } catch {
                result = .failure(error)
            }
            DispatchQueue.main.async {
                self?.building = false
                completion(result)
            }
        }
    }
}

struct StudioView: View {
    @EnvironmentObject var vm: WatchViewModel
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = StudioModel()
    @State private var pickerItem: PhotosPickerItem?
    @State private var errorText: String?

    private var busy: Bool { vm.ui.operation.active || model.building }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                previewCard
                presetCard
                nameCard
                backgroundCard
                decorCard
                lunarCard
                marksCard
                handsCard
                aodCard
                saveButton
            }
            .padding(16)
        }
        .background(AppBackground())
        .navigationTitle("Tạo mặt đồng hồ")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Không tạo được mặt đồng hồ", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button("Đóng", role: .cancel) {}
        } message: {
            Text(errorText ?? "")
        }
    }

    // MARK: Xem trước

    private var previewCard: some View {
        HStack(spacing: 16) {
            previewCircle(model.dayPreview, title: "Ban ngày")
            previewCircle(model.aodPreview, title: "AOD (màn hình tắt)")
        }
        .frame(maxWidth: .infinity)
        .card()
    }

    private func previewCircle(_ image: UIImage?, title: String) -> some View {
        VStack(spacing: 6) {
            ZStack {
                Circle().fill(Color.black)
                if let image = image {
                    Image(uiImage: image).resizable().scaledToFit().clipShape(Circle())
                }
            }
            .frame(maxWidth: 160, maxHeight: 160)
            .aspectRatio(1, contentMode: .fit)
            Text(title).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Mẫu có sẵn

    private var presetCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Mẫu có sẵn").font(.headline)
            Text("Chạm để áp dụng một mẫu vector, rồi chỉnh tiếp bên dưới. Tên và tác giả của bạn được giữ nguyên.")
                .font(.footnote).foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(FacePresets.all) { preset in
                        Button {
                            pickerItem = nil
                            model.design = FacePresets.apply(preset, to: model.design)
                        } label: {
                            VStack(spacing: 4) {
                                Image(uiImage: FacePresetThumbs.image(preset))
                                    .resizable()
                                    .frame(width: 72, height: 72)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                                Text(preset.title).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .card()
    }

    // MARK: Tên

    private var nameCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Tên và tác giả").font(.headline)
            TextField("Tên mặt đồng hồ", text: $model.design.name)
                .textFieldStyle(.roundedBorder)
            TextField("Tác giả (không bắt buộc)", text: $model.design.author)
                .textFieldStyle(.roundedBorder)
        }
        .card()
    }

    // MARK: Nền

    private var backgroundCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Nền").font(.headline)

            PhotosPicker(selection: $pickerItem, matching: .images) {
                Label(model.design.photo == nil ? "Chọn ảnh nền" : "Đổi ảnh nền", systemImage: "photo")
            }
            .buttonStyle(SecondaryButtonStyle())
            .onChange(of: pickerItem) { item in
                guard let item = item else { return }
                _ = item.loadTransferable(type: Data.self) { result in
                    DispatchQueue.main.async {
                        if case .success(let data?) = result, let img = UIImage(data: data) {
                            model.setPhoto(img)
                        } else {
                            errorText = "Không đọc được ảnh đã chọn."
                        }
                    }
                }
            }

            if model.design.photo != nil {
                slider("Phóng to", value: $model.design.photoZoom, range: 1...3)
                slider("Dịch ngang", value: $model.design.photoPanX, range: -1...1)
                slider("Dịch dọc", value: $model.design.photoPanY, range: -1...1)
                slider("Làm tối ảnh", value: $model.design.photoDim, range: 0...0.8)
                Button(role: .destructive) {
                    pickerItem = nil
                    model.setPhoto(nil)
                } label: { Label("Bỏ ảnh nền", systemImage: "xmark.circle") }
                    .buttonStyle(SecondaryButtonStyle(color: Color.red))
            } else {
                ColorPicker("Màu nền", selection: $model.design.backgroundColor, supportsOpacity: false)
                Toggle("Chuyển sắc", isOn: $model.design.useGradient)
                if model.design.useGradient {
                    ColorPicker("Màu nền thứ hai", selection: $model.design.backgroundColor2, supportsOpacity: false)
                }
            }
        }
        .card()
    }

    // MARK: Lớp trang trí

    private var decorCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Lớp trang trí").font(.headline)
            Text("Họa tiết vector vẽ sẵn. Chọn Giờ, Phút hoặc Giây để lớp tự quay theo thời gian; Tĩnh là đứng yên. Không hiện ở AOD.")
                .font(.footnote).foregroundStyle(.secondary)
            ForEach($model.design.decor) { $layer in
                decorEditor($layer)
            }
            if model.design.decor.count < FaceRenderer.maxDecor {
                Button {
                    model.design.decor.append(DecorLayer())
                } label: { Label("Thêm lớp trang trí", systemImage: "plus.circle") }
                    .buttonStyle(SecondaryButtonStyle())
            }
        }
        .card()
    }

    private func decorEditor(_ layer: Binding<DecorLayer>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(DecorPattern.allCases) { p in
                        Button {
                            layer.wrappedValue.pattern = p
                        } label: {
                            VStack(spacing: 3) {
                                Image(uiImage: DecorThumbs.image(p))
                                    .resizable()
                                    .frame(width: 56, height: 56)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(layer.wrappedValue.pattern == p ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                    )
                                Text(p.title).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            ColorPicker("Màu", selection: layer.color, supportsOpacity: false)
            slider("Độ đậm", value: layer.opacity, range: 0.1...1)
            slider("Kích thước", value: layer.scale, range: 0.2...0.95)
            Picker("Chuyển động", selection: layer.spin) {
                ForEach(DecorSpin.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Button(role: .destructive) {
                let id = layer.wrappedValue.id
                model.design.decor.removeAll { $0.id == id }
            } label: { Label("Xóa lớp này", systemImage: "trash") }
                .buttonStyle(SecondaryButtonStyle(color: Color.red))
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.primary.opacity(0.05)))
    }

    // MARK: Âm lịch

    private var lunarCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Thông tin trên mặt đồng hồ").font(.headline)
            Text("Ngày, giờ, pin, bước chân, nhịp tim, calo, thời tiết do đồng hồ tự cập nhật; không hiện ở AOD. Xem trước dùng ngày giờ hiện tại và số liệu mẫu.")
                .font(.footnote).foregroundStyle(.secondary)
            InfoSettingsView(design: $model.design)
        }
    }

    // MARK: Vạch giờ

    private var marksCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Vạch giờ").font(.headline)
            Picker("Kiểu", selection: $model.design.marks) {
                ForEach(FaceDesign.Marks.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.marks != .none {
                ColorPicker("Màu vạch giờ", selection: $model.design.marksColor, supportsOpacity: false)
            }
        }
        .card()
    }

    // MARK: Kim

    private var handsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Kim").font(.headline)
            Picker("Kiểu kim", selection: $model.design.handStyle) {
                ForEach(FaceDesign.HandStyle.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            ColorPicker("Kim giờ", selection: $model.design.hourColor, supportsOpacity: false)
            ColorPicker("Kim phút", selection: $model.design.minuteColor, supportsOpacity: false)
            Toggle("Hiện kim giây", isOn: $model.design.showSecond)
            if model.design.showSecond {
                ColorPicker("Kim giây", selection: $model.design.secondColor, supportsOpacity: false)
            }
            ColorPicker("Núm giữa", selection: $model.design.capColor, supportsOpacity: false)
            slider("Độ dày kim", value: $model.design.handWidth, range: 0.6...1.8)
            Toggle("Viền tối quanh kim", isOn: $model.design.handOutline)
        }
        .card()
    }

    // MARK: AOD

    private var aodCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("AOD (màn hình tắt)").font(.headline)
            Text("Nền đen và ít điểm sáng sẽ tiết kiệm pin hơn.")
                .font(.footnote).foregroundStyle(.secondary)
            Picker("Nền AOD", selection: $model.design.aodBackground) {
                ForEach(FaceDesign.AodBackground.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.aodBackground == .dimmed {
                slider("Độ sáng nền", value: $model.design.aodBrightness, range: 0.05...0.6)
            }
            ColorPicker("Màu kim AOD", selection: $model.design.aodHandColor, supportsOpacity: false)
            Toggle("Hiện vạch giờ", isOn: $model.design.aodShowMarks)
            if model.design.aodShowMarks && model.design.marks != .none {
                ColorPicker("Màu vạch giờ AOD", selection: $model.design.aodMarksColor, supportsOpacity: false)
            }
        }
        .card()
    }

    // MARK: Lưu

    private var saveButton: some View {
        VStack(spacing: 8) {
            Button {
                model.export { result in
                    switch result {
                    case .success(let url):
                        vm.importHwt(url, displayName: url.lastPathComponent)
                        dismiss()
                    case .failure(let error):
                        errorText = "Mã lỗi: \(WMCore.code(error))"
                    }
                }
            } label: {
                if model.building {
                    HStack(spacing: 8) { ProgressView(); Text("Đang tạo file HWT") }
                } else {
                    Label("Tạo và thêm vào thư viện", systemImage: "wand.and.stars")
                }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)
            Text("File được lưu vào Thư viện; từ đó bạn có thể gửi lên đồng hồ như mọi file HWT khác.")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
    }

    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.footnote).foregroundStyle(.secondary)
            Slider(value: value, in: range)
        }
    }
}
