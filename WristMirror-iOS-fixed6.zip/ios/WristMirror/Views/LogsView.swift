import SwiftUI

/// Tương đương LogsScreen.kt (được mở từ Cài đặt).
struct LogsView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        ScrollView {
            Text(vm.ui.logs.isEmpty ? "Chưa có nhật ký." : vm.ui.logs.joined(separator: "\n"))
                .font(.system(.caption2, design: .monospaced))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .textSelection(.enabled)
        }
        .navigationTitle("Nhật ký")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                ShareLink(item: vm.logsText())
                Button(role: .destructive) { vm.clearLogs() } label: { Image(systemName: "trash") }
            }
        }
    }
}
