import SwiftUI
import UIKit

/// Tab "Thiết bị" – bố cục như DeviceScreen.kt: thẻ đồng hồ đang chọn, lịch sử, "Thêm thiết bị".
struct DeviceView: View {
    @EnvironmentObject var vm: WatchViewModel
    let onOpenFaces: () -> Void

    init(onOpenFaces: @escaping () -> Void) { self.onOpenFaces = onOpenFaces }

    private enum DeviceWindow: Identifiable {
        case discovery
        case history(String)
        case huaweiId(String)
        var id: String {
            switch self {
            case .discovery: return "discovery"
            case .history(let a): return "history-" + a
            case .huaweiId(let a): return "id-" + a
            }
        }
    }

    @State private var window: DeviceWindow?

    private var selected: NearbyWatch? {
        guard let a = vm.ui.selectedDeviceAddress else { return nil }
        return vm.ui.devices.first { $0.address == a }
            ?? vm.ui.savedDevices.first { $0.address == a }?.nearby()
    }

    private func device(for address: String) -> NearbyWatch {
        vm.ui.devices.first { $0.address == address }
            ?? vm.ui.savedDevices.first { $0.address == address }?.nearby()
            ?? NearbyWatch(address: address, name: "Thiết bị chưa rõ tên", bonded: false)
    }

    var body: some View {
        NavigationStack {
            List {
                selectedCard
                if vm.ui.operation.active || (vm.ui.operation.failed && !vm.ui.operation.detail.isEmpty) {
                    Section {
                        if vm.ui.operation.active { ProgressView() }
                        Text(vm.ui.operation.detail)
                            .foregroundStyle(vm.ui.operation.failed ? Color.red : Color.primary)
                    }
                }
                if !vm.ui.savedDevices.isEmpty { historySection }
                Section {
                    Button { window = .discovery } label: {
                        HStack {
                            Image(systemName: "magnifyingglass")
                            VStack(alignment: .leading) {
                                Text("Thêm thiết bị")
                                Text("Tìm đồng hồ ở gần").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
                        }
                    }
                    .foregroundStyle(.primary)
                    .disabled(vm.ui.connecting || vm.ui.removing || vm.ui.operation.active)
                }
            }
            .navigationTitle("Thiết bị")
            .sheet(item: $window) { w in
                switch w {
                case .discovery:
                    DiscoverySheet { picked in window = .huaweiId(picked.address) }
                        .environmentObject(vm)
                case .history(let address):
                    HistorySheet(device: device(for: address),
                                 onConfigure: { window = .huaweiId(address) },
                                 onClose: { window = nil })
                        .environmentObject(vm)
                case .huaweiId(let address):
                    HuaweiIdSheet(device: device(for: address)) { window = nil }
                        .environmentObject(vm)
                }
            }
        }
    }

    // MARK: Thẻ đồng hồ đang chọn

    private var selectedCard: some View {
        Section {
            VStack(alignment: .leading, spacing: 6) {
                Text(selected?.name ?? "Chưa chọn đồng hồ").font(.headline)
                Text(summary).font(.footnote).foregroundStyle(.secondary)
                if vm.ui.connecting { ProgressView() }
            }
            .padding(.vertical, 2)
            if let d = selected {
                if vm.ui.connected || vm.ui.connecting {
                    if vm.ui.connected {
                        Button("Mở mặt đồng hồ") { onOpenFaces() }
                            .disabled(vm.ui.quarantine)
                    }
                    Button("Ngắt kết nối", role: .destructive) { vm.disconnect() }
                } else {
                    Button("Kết nối đồng hồ") {
                        vm.connect(d, huaweiId: vm.ui.huaweiIdDirty ? vm.ui.huaweiIdInput : "")
                    }
                    .disabled(!canConnect)
                }
                Button("Cấu hình Huawei ID") { window = .huaweiId(d.address) }
                    .disabled(vm.ui.connecting || vm.ui.operation.active || vm.ui.removing)
                Button("Xoá khỏi app", role: .destructive) { vm.requestRemoval(d) }
                    .disabled(vm.ui.connecting || vm.ui.removing || vm.ui.operation.active)
            }
        }
    }

    private var canConnect: Bool {
        !vm.ui.removing && !vm.ui.operation.active
            && (vm.ui.accountConfigured || !vm.ui.huaweiIdInput.trimmingCharacters(in: .whitespaces).isEmpty)
    }

    private var summary: String {
        if selected == nil { return "Hãy tìm đồng hồ ở gần, chọn rồi cấu hình Huawei ID để kết nối." }
        if vm.ui.removing { return "Đang xoá dữ liệu cục bộ của đồng hồ này." }
        if vm.ui.quarantine { return "Thao tác thiết bị đã tạm dừng, hãy ngắt rồi kết nối lại." }
        if vm.ui.connected { return "Đang kết nối. Quản lý mặt đồng hồ ở tab Mặt đồng hồ." }
        if vm.ui.connecting { return "Đang thiết lập kết nối, có thể huỷ rồi chọn lại thiết bị." }
        if !vm.ui.accountConfigured && vm.ui.huaweiIdInput.trimmingCharacters(in: .whitespaces).isEmpty {
            return "Hãy cấu hình Huawei ID cho đồng hồ này trước."
        }
        if vm.ui.huaweiIdDirty { return "Huawei ID có thay đổi chưa lưu." }
        return "Sau khi kết nối có thể quản lý mặt đồng hồ."
    }

    // MARK: Lịch sử

    private var historySection: some View {
        Section("Thiết bị đã dùng") {
            ForEach(Array(vm.ui.savedDevices.enumerated()), id: \.element.id) { index, d in
                Button { window = .history(d.address) } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(d.name.isEmpty ? "Thiết bị chưa rõ tên" : d.name)
                            Text(historySummary(d, index)).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
                    }
                }
                .foregroundStyle(.primary)
                .disabled(vm.ui.removing)
            }
        }
    }

    private func historySummary(_ d: SavedWatch, _ index: Int) -> String {
        if vm.ui.connected && d.address.caseInsensitiveCompare(vm.ui.deviceAddress) == .orderedSame { return "Đang kết nối" }
        if vm.ui.selectedDeviceAddress == d.address && vm.ui.connecting { return "Đang kết nối…" }
        if vm.ui.selectedDeviceAddress == d.address { return "Đã chọn, chạm để xem thao tác" }
        if index == 0 { return "Kết nối lần trước, chạm để xem thao tác" }
        return "Chạm để xem thao tác"
    }
}

// MARK: - Thêm thiết bị (DiscoveryDialog)

private struct DiscoverySheet: View {
    @EnvironmentObject var vm: WatchViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    let onPick: (NearbyWatch) -> Void

    init(onPick: @escaping (NearbyWatch) -> Void) { self.onPick = onPick }

    private var filtered: [NearbyWatch] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        if q.isEmpty { return vm.ui.devices }
        return vm.ui.devices.filter { $0.name.lowercased().contains(q) || $0.address.lowercased().contains(q) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("Tên thiết bị hoặc mã", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button(vm.ui.scanning ? "Dừng tìm" : "Tìm đồng hồ ở gần") {
                        if vm.ui.scanning { vm.stopScan() } else { vm.scan() }
                    }
                    if vm.ui.statusMessage.contains("Cài đặt") || vm.ui.statusMessage.contains("Bluetooth đang tắt") {
                        Text(vm.ui.statusMessage).font(.footnote).foregroundStyle(.red)
                        Button("Mở Cài đặt") {
                            if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                        }
                    }
                    Text(vm.ui.scanning ? "Đang tìm, chạm vào thiết bị để chọn và cấu hình Huawei ID."
                                        : "Để đồng hồ gần điện thoại, bật Bluetooth và để thiết bị có thể được phát hiện.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    if filtered.isEmpty {
                        Text(!query.isEmpty && !vm.ui.devices.isEmpty ? "Không có thiết bị khớp"
                             : (vm.ui.scanning ? "Đang tìm đồng hồ của bạn" : "Chưa phát hiện thiết bị"))
                            .foregroundStyle(.secondary)
                    }
                    ForEach(filtered) { d in
                        Button {
                            vm.stopScan()
                            vm.selectDevice(d)
                            onPick(d)
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(d.name.isEmpty ? "Thiết bị chưa rõ tên" : d.name)
                                    Text(vm.ui.selectedDeviceAddress == d.address ? "Đã chọn, chạm để cấu hình Huawei ID"
                                         : "Chạm để chọn và cấu hình Huawei ID")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if let r = d.rssi { Text("\(r) dBm").font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                        .foregroundStyle(.primary)
                    }
                }
            }
            .navigationTitle("Thêm thiết bị")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Đóng") { vm.stopScan(); dismiss() } } }
        }
        .onAppear { if !vm.ui.scanning { vm.scan() } }
    }
}

// MARK: - Thao tác với thiết bị trong lịch sử (HistoryOperationSheet)

private struct HistorySheet: View {
    @EnvironmentObject var vm: WatchViewModel
    let device: NearbyWatch
    let onConfigure: () -> Void
    let onClose: () -> Void

    private var targetConnected: Bool {
        vm.ui.connected && device.address.caseInsensitiveCompare(vm.ui.deviceAddress) == .orderedSame
    }
    private var canConnect: Bool {
        !vm.ui.connected && !vm.ui.connecting && !vm.ui.removing && !vm.ui.operation.active
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text(device.name.isEmpty ? "Thiết bị chưa rõ tên" : device.name).font(.headline)
                    Text(device.address).font(.caption2).foregroundStyle(.secondary)
                }
                Section {
                    Button("Kết nối đồng hồ") {
                        vm.selectDevice(device)
                        vm.connect(device, huaweiId: "")
                        onClose()
                    }
                    .disabled(!canConnect)
                    Text(canConnect ? "Dùng Huawei ID đã lưu cho đồng hồ này."
                         : (targetConnected ? "Thiết bị này đang được kết nối." : "Hãy ngắt kết nối hiện tại trước khi kết nối thiết bị này."))
                        .font(.footnote).foregroundStyle(.secondary)
                    Button("Cấu hình Huawei ID") { onConfigure() }
                        .disabled(vm.ui.connecting || vm.ui.operation.active)
                    Button("Xoá khỏi app", role: .destructive) {
                        vm.requestRemoval(device)
                        onClose()
                    }
                    .disabled(vm.ui.connecting || vm.ui.removing || vm.ui.operation.active)
                } footer: {
                    Text("iOS không cho app huỷ ghép nối hệ thống. Để huỷ hẳn: Cài đặt iOS > Bluetooth > (i) > Forget This Device.")
                }
            }
            .navigationTitle("Thao tác thiết bị")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Đóng") { onClose() } } }
        }
    }
}

// MARK: - Cấu hình Huawei ID (HuaweiIdAcquisition)

private struct HuaweiIdSheet: View {
    @EnvironmentObject var vm: WatchViewModel
    let device: NearbyWatch
    let onClose: () -> Void
    @State private var draft = ""
    @State private var loaded = false
    @State private var showWeb = false
    @State private var error = ""

    init(device: NearbyWatch, onClose: @escaping () -> Void) { self.device = device; self.onClose = onClose }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(device.name.isEmpty ? "Thiết bị chưa rõ tên" : device.name).font(.headline)
                    TextField("Huawei ID (số)", text: $draft)
                        .keyboardType(.numberPad)
                    if !error.isEmpty { Text(error).font(.footnote).foregroundStyle(.red) }
                } footer: {
                    Text("ID này phải trùng với ID đã dùng để ghép đồng hồ trong Huawei Health. Nhập sai có thể khiến đồng hồ hỏi xoá dữ liệu – đừng bấm xác nhận. Chỉ lưu trong Keychain trên máy này.")
                }
                Section {
                    Button("Lấy từ tài khoản Huawei…") { showWeb = true }
                    Button("Lưu") {
                        if vm.saveHuaweiIdForDevice(device, value: draft) { onClose() }
                        else { error = "Không lưu được. Hãy kiểm tra ID hoặc thử lại khi không đang kết nối." }
                    }
                    .disabled(draft.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .navigationTitle("Cấu hình Huawei ID")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Đóng") { onClose() } } }
            .sheet(isPresented: $showWeb) {
                HuaweiIdWebSheet { id in
                    draft = id
                    showWeb = false
                }
            }
            .onAppear {
                if !loaded { draft = vm.readHuaweiIdForDevice(device) ?? ""; loaded = true }
            }
        }
    }
}
