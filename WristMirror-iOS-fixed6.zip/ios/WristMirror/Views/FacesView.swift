import SwiftUI
import UniformTypeIdentifiers

/// Tab "Mặt đồng hồ" – bố cục như FacesScreen.kt: thẻ file HWT (mở rộng được), thao tác trang, danh sách thẻ mặt đồng hồ.
struct FacesView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var importing = false
    @State private var showSource = false
    @State private var expandedId: String?

    private var busy: Bool { vm.ui.operation.active }

    var body: some View {
        NavigationStack {
            List {
                sourceSection
                Section {
                    Button { vm.refreshFaces() } label: {
                        Text(vm.ui.listRefreshing ? "Đang làm mới" : "Làm mới danh sách")
                    }
                    .disabled(!vm.ui.connected || vm.ui.listRefreshing || busy)
                    Button("Chọn file HWT") {
                        vm.logPick("BUTTON_TAPPED")
                        importing = true
                    }
                    .disabled(busy)
                    Button("Xoá bộ nhớ đệm đã nhập") { vm.clearCache() }
                        .disabled(busy)
                }
                Section("Mặt đồng hồ trên đồng hồ") {
                    if !vm.ui.connected {
                        placeholder("Chưa kết nối đồng hồ", "Hãy kết nối đồng hồ ở tab Thiết bị.")
                    } else if vm.ui.listRefreshing {
                        HStack { ProgressView(); Text("Đang đọc mặt đồng hồ") }
                    } else if !vm.ui.listReady {
                        placeholder("Đang chờ đọc mặt đồng hồ", "Chạm làm mới và chờ đồng hồ trả về danh sách.")
                    } else if vm.ui.faces.isEmpty {
                        placeholder("Đồng hồ trả về danh sách rỗng", "Chạm làm mới để thử lại.")
                    }
                    if vm.ui.quarantine {
                        Text("Thao tác thiết bị đã tạm dừng, hãy ngắt rồi kết nối lại.").foregroundStyle(.orange)
                    }
                    ForEach(vm.ui.faces) { face in
                        FaceCard(face: face,
                                 expanded: expandedId == face.id,
                                 toggle: { withAnimation { expandedId = (expandedId == face.id) ? nil : face.id } })
                    }
                }
            }
            .navigationTitle("Mặt đồng hồ")
            // Dùng UIDocumentPickerViewController (asCopy) thay cho .fileImporter của SwiftUI:
            // nhận mọi loại file (.item) và nhận bản sao trong thư mục tạm, không cần quyền security-scoped.
            .sheet(isPresented: $importing) {
                HwtDocumentPicker(
                    onPick: { url in
                        importing = false
                        vm.logPick("RESULT ext=\(url.pathExtension.lowercased())")
                        vm.importHwt(url)
                    },
                    onCancel: {
                        importing = false
                        vm.logPick("CANCELLED")
                        vm.cancelHwtPick()
                    }
                )
                .ignoresSafeArea()
            }
        }
    }

    private func placeholder(_ title: String, _ message: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
            Text(message).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private var sourceSection: some View {
        Section("File HWT") {
            if let s = vm.ui.source {
                if let p = s.previewPath, let img = UIImage(contentsOfFile: p) {
                    Image(uiImage: img).resizable().scaledToFit().frame(maxHeight: 160).frame(maxWidth: .infinity)
                }
                Button {
                    withAnimation { showSource.toggle() }
                } label: {
                    HStack {
                        Text("File HWT: \(s.fileName)").lineLimit(1).truncationMode(.middle)
                        Spacer()
                        Image(systemName: showSource ? "chevron.up" : "chevron.down").font(.footnote)
                    }
                }
                .foregroundStyle(.primary)
                if showSource {
                    row("Tên mặt đồng hồ", s.title)
                    row("Dung lượng file gốc", ByteCountFormatter.string(fromByteCount: s.sourceBytes, countStyle: .file))
                    row("Nội dung sẽ truyền", ByteCountFormatter.string(fromByteCount: Int64(s.payloadBytes), countStyle: .file))
                    row("Phiên bản file", s.xmlVersion.isEmpty ? "Không có" : s.xmlVersion)
                }
            } else {
                Text("File HWT: chưa chọn").foregroundStyle(.secondary)
            }
            if vm.ui.operation.kind == "source" && vm.ui.operation.active {
                HStack { ProgressView(); Text(vm.ui.operation.detail) }
            }
        }
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(k).font(.footnote).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(v).font(.footnote).multilineTextAlignment(.trailing)
        }
    }
}

/// Thẻ mặt đồng hồ mở rộng được (FaceCard + FaceCardActions của Android).
struct FaceCard: View {
    @EnvironmentObject var vm: WatchViewModel
    let face: FaceItem
    let expanded: Bool
    let toggle: () -> Void

    private var locked: Bool {
        !vm.ui.connected || !vm.ui.listReady || vm.ui.listRefreshing || vm.ui.quarantine || vm.ui.operation.active
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: toggle) {
                HStack {
                    Text(face.title).font(.headline).lineLimit(1)
                    Spacer()
                    if face.current { Text("Đang dùng").font(.caption).foregroundStyle(.secondary) }
                    Image(systemName: expanded ? "chevron.up" : "chevron.down").font(.footnote)
                }
            }
            .foregroundStyle(.primary)
            if expanded {
                VStack(spacing: 6) {
                    info("Phiên bản", face.version.isEmpty ? "Đồng hồ không cung cấp" : face.version)
                    info("ID", face.id)
                    info("Loại", face.kind)
                }
                Divider()
                HStack {
                    Button("Thay thế") { vm.requestReplacement(face: face, epoch: vm.ui.connectionEpoch) }
                        .disabled(!face.selectable || vm.ui.source == nil)
                    Button("Bật") { vm.requestActivation(face: face, epoch: vm.ui.connectionEpoch) }
                        .disabled(!face.activatable || face.current)
                    Button("Xoá", role: .destructive) { vm.requestDeletion(face: face, epoch: vm.ui.connectionEpoch) }
                        .disabled(!face.selectable)
                }
                .buttonStyle(.bordered)
                .disabled(locked)
            }
        }
        .padding(.vertical, 4)
    }

    private func info(_ k: String, _ v: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(k).font(.footnote).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(v).font(.footnote).multilineTextAlignment(.trailing)
        }
    }
}

/// Bộ chọn file của hệ thống (UIKit), nhận mọi loại file.
struct HwtDocumentPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.item], asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void
        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let u = urls.first { onPick(u) } else { onCancel() }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}
