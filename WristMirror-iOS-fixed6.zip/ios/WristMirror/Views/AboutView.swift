import SwiftUI

/// Tương đương AboutScreen.kt.
struct AboutView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Wrist Mirror (腕镜)").font(.title2.bold())
                    Text("v\(vm.ui.appVersion)").font(.subheadline).foregroundStyle(.secondary)
                }
                Text("Công cụ cài mặt đồng hồ HWT bên thứ ba cho đồng hồ Huawei bằng phương pháp thay thế; dành cho phần lớn thiết bị dùng giao thức mặt đồng hồ tương thích như GT, FIT.")
                    .font(.subheadline)
            }
            Section("Dự án") {
                Link("Mã nguồn gốc (Android)", destination: URL(string: "https://github.com/Escosis/WristMirror")!)
            }
            Section {
                Text("Bản iOS là bản viết lại bằng Swift/SwiftUI/CoreBluetooth, giấy phép Apache-2.0. Hãy tự chịu rủi ro; app không chép mã hay SDK của Huawei Health.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Giới thiệu")
        .navigationBarTitleDisplayMode(.inline)
    }
}
