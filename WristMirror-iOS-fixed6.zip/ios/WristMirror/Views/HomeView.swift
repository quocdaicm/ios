import SwiftUI

/// Tab "Trang chủ" – tương đương HomeScreen.kt: trạng thái kết nối + thông tin thiết bị, chạm để sao chép.
struct HomeView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var copiedKey = ""

    private var title: String {
        if vm.ui.connected || vm.ui.connecting {
            return vm.ui.watchName.isEmpty ? "Thiết bị chưa rõ tên" : vm.ui.watchName
        }
        guard let a = vm.ui.selectedDeviceAddress, !a.isEmpty else { return "Chưa có thiết bị trong lịch sử" }
        let name = vm.ui.savedDevices.first { $0.address == a }?.name
            ?? vm.ui.devices.first { $0.address == a }?.name
        return (name?.isEmpty == false ? name : nil) ?? "Thiết bị chưa rõ tên"
    }

    private var statusText: String {
        vm.ui.connected ? "Đã kết nối" : (vm.ui.connecting ? "Đang kết nối" : "Chưa kết nối")
    }

    private var statusColor: Color {
        vm.ui.connected ? .green : (vm.ui.connecting ? .orange : .gray)
    }

    private func known(_ s: String?) -> String? {
        guard let s = s?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty, s != "Không rõ" else { return nil }
        return s
    }

    private var rows: [(String, String?)] {
        let selected = vm.ui.selectedDeviceAddress
        let saved = vm.ui.savedDevices.first { $0.address == selected }
        let model = known(vm.ui.deviceModel) ?? known(saved?.model)
        let serial = known(vm.ui.serialNumber) ?? known(saved?.serialNumber)
        let address = known(vm.ui.deviceAddress) ?? selected
        var resolution: String? = nil
        if let w = vm.ui.width, let h = vm.ui.height { resolution = "\(w) × \(h)" }
        let live = vm.ui.connected
        return [
            ("Mã model", model),
            ("Mã thiết bị (UUID Bluetooth)", address),
            ("Số sê-ri", serial),
            ("Phiên bản firmware", live ? known(vm.ui.firmware) : nil),
            ("Độ phân giải mặt đồng hồ", live ? resolution : nil),
            ("Pin", live ? vm.ui.batteryPercent.map { "\($0)%" } : nil),
            ("Bộ nhớ trống", live ? vm.ui.freeMemoryBytes.map { Self.memory($0) } : nil),
        ]
    }

    static func memory(_ bytes: Int64) -> String {
        let mb = Double(bytes) / 1_048_576.0
        return mb >= 1024 ? String(format: "%.2f GB", mb / 1024.0) : String(format: "%.0f MB", mb)
    }

    private func copy(_ key: String, _ value: String) {
        // Hết hạn sau 60 giây, giống cờ IS_SENSITIVE của Android.
        UIPasteboard.general.setItems([["public.utf8-plain-text": value]],
                                      options: [.expirationDate: Date().addingTimeInterval(60)])
        copiedKey = key
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { if copiedKey == key { copiedKey = "" } }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Phiên bản ứng dụng \(vm.ui.appVersion)").font(.caption).foregroundStyle(.secondary)
                        Text(title).font(.title2.bold()).lineLimit(2)
                        HStack(spacing: 8) {
                            Circle().fill(statusColor).frame(width: 9, height: 9)
                            Text(statusText).font(.subheadline)
                        }
                        if vm.ui.connecting || vm.ui.connected {
                            Text(vm.ui.detail).font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }
                Section("Thông tin thiết bị") {
                    ForEach(rows, id: \.0) { row in
                        let value = row.1
                        Button {
                            if let v = value { copy(row.0, v) }
                        } label: {
                            HStack(alignment: .firstTextBaseline) {
                                Text(row.0).foregroundStyle(.primary)
                                Spacer(minLength: 12)
                                Text(copiedKey == row.0 ? "Đã sao chép" : (value ?? "Chưa rõ"))
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.trailing)
                                    .textSelection(.disabled)
                            }
                        }
                        .disabled(value == nil)
                    }
                }
            }
            .navigationTitle("Trang chủ")
        }
    }
}
