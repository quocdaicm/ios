// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import SwiftUI

// ============================================================================
// Port từ WatchViewModel.kt (Phần 8). Giữ nguyên các quy tắc an toàn của bản Android:
//  - mọi thao tác ghi lên đồng hồ phải qua một "prompt" xác nhận có token (confirmAction);
//  - thao tác theo từng thẻ mặt đồng hồ: chụp (id, version, type, expandType) + epoch + form revision
//    lúc bấm, kiểm tra lại ngay trước khi gửi (FRESH_DEVICE_LIST_REQUIRED, SELECTED_FACE_CHANGED...);
//  - không bao giờ chọn "thẻ đầu tiên/đang dùng" thay người dùng.
// Đã bỏ: cập nhật app, giới thiệu lần đầu, huỷ ghép nối hệ thống (iOS), foreground service.
// Observer của runtime có thể gọi từ luồng bất kỳ => luôn DispatchQueue.main.async trước khi đổi @Published.
// ============================================================================

final class WatchViewModel: ObservableObject, AppActions, AppRuntimeObserver {
    @Published private(set) var ui = AppUiState()

    private let runtime = AppRuntime.shared
    private let scanner = WatchScanner()
    private let defaults = UserDefaults.standard
    private let ioQueue = DispatchQueue(label: "wristmirror.hwt-io")
    /// Thư viện file HWT (tự lưu mỗi file đã nhập).
    let library = HwtLibrary()
    /// Lịch nhắc đổi mặt đồng hồ (thông báo cục bộ).
    let schedule = FaceSchedule()
    private var tokenCounter: Int64 = Int64(DispatchTime.now().uptimeNanoseconds & 0x3fffffffffff)

    private var credentialEpoch = -1
    private var savedEditorId = ""
    private var lastRuntimeMessage = ""
    private var appliedOperationRevision: Int64 = -1
    private var appliedReplacementDialogRevision: Int64 = -1
    private var appliedDeletionDialogRevision: Int64 = -1
    private var appliedActivationDialogRevision: Int64 = -1
    private var scanGeneration = 0
    private var filePickToken: Int64?
    private var source: HwtSource?
    private var sourcePayload: HwtSource.Snapshot?
    private var fileOnlyPreview = false
    private var preparing = false
    private var pending: Pending?
    private var deletionPreparation: DeletionPrep?
    private var sessionDevice: NearbyWatch?
    private var queuedConnectEpoch: Int?
    private var rememberedReadyEpoch = -1
    private var agreementSkippedEpoch = -1

    private struct RowTarget {
        let rendered: FaceItem
        let face: TlvView.Face
        let epoch: Int
        let address: String
        let formRevision: Int64
        let operationRevision: Int64
    }
    private struct Pick { let row: RowTarget; let version: String }
    private struct DeletionPrep { let token: Int64; let row: RowTarget }
    private struct Pending { let token: Int64; let action: () throws -> Void; let cancel: () -> Void }

    private var privateFiles: URL {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true))
            ?? FileManager.default.temporaryDirectory
        return base
    }

    init() {
        schedule.nameProvider = { [library] id in library.item(id: id)?.name }
        library.onChange = { [weak self] in self?.schedule.resync() }
        schedule.resync()
        let theme = ThemeMode(rawValue: defaults.string(forKey: "wm.theme") ?? "system") ?? .system
        ui.theme = theme
        if let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String, !v.isEmpty { ui.appVersion = v }
        let history = runtime.history.devices()
        ui.savedDevices = history
        ui.autoConnect = runtime.history.autoConnect()
        ui.introductionPending = !defaults.bool(forKey: "wm.introduction-acknowledged")
        if let first = history.first(where: { !removalBlocks($0.address) }) {
            ui.selectedDeviceAddress = first.address
            ui.watchName = first.name
            restoreHuaweiId(first.address)
        }
        let lines = runtime.logs.snapshot().split(separator: "\n").map(String.init)
        ui.logs = lines
        runtime.logs.setListener { [weak self] rows in
            DispatchQueue.main.async { self?.ui.logs = rows }
        }
        runtime.addObserver(self) // gọi changed() ngay một lần
    }

    deinit {
        runtime.removeObserver(self)
        scanner.stop()
    }

    // MARK: Tiện ích

    private func nextToken() -> Int64 { tokenCounter += 1; return tokenCounter }

    private func removalBlocks(_ address: String?) -> Bool {
        guard let a = address else { return false }
        return runtime.secure.removals.blocked(a)
    }

    private func message(_ text: String) {
        runtime.logs.record("UI_NOTICE", text)
        ui.statusMessage = text
        ui.noticeSerial += 1
        ui.noticeMessage = text
    }

    private func busyLocally() -> Bool {
        preparing || filePickToken != nil || deletionPreparation != nil || replacementActive() || runtime.watchfaces.busy()
    }

    private func replacementActive() -> Bool {
        let s = runtime.snapshot()
        return (s.replacementDialog?.operation.active ?? false) || (s.deletionDialog?.operation.active ?? false) || (s.activationDialog?.operation.active ?? false)
    }

    // MARK: Chuỗi hiển thị (tiếng Việt)

    private func phaseLabel(_ code: String) -> String {
        switch code {
        case "IDLE": return "Chưa kết nối"
        case "CONNECTING": return "Đang kết nối đồng hồ"
        case "SYSTEM_PAIRING": return "Chờ ghép nối hệ thống"
        case "LINK_PARAMS", "DEVICE_STATUS": return "Đọc tham số liên kết"
        case "SECURITY", "LITE_AUTH", "ISO_AUTH", "BOND_PARAMS", "BOND_KEY": return "Xác thực thiết bị"
        case "PIN_REQUEST", "PIN_INPUT": return "Chờ mã ghép nối"
        case "VERIFY_SESSION": return "Kiểm tra khoá phiên"
        case "COMMAND_CAPS", "EXPAND_CAPS": return "Đã xác thực, đọc khả năng thiết bị"
        case "ACCOUNT", "SETTINGS", "AGREEMENTS", "REVERSE_CAPS", "SETUP_DEVICE", "ACTIVITY_TYPES", "WEAR_STATUS", "CONNECT_NOTIFY": return "Đã xác thực, hoàn tất khởi tạo"
        case "AGREEMENT_CONFIRM": return "Hoàn tất khởi tạo"
        case "REBIND_CONFIRM", "REBINDING": return "Liên kết lại giao thức"
        case "READY": return "Sẵn sàng"
        default: return "Kết nối chưa hoàn tất"
        }
    }

    private func connectionDetail(_ s: AppRuntime.Snapshot) -> String {
        switch s.code {
        case "AGREEMENT_CONFIRM": return "Tiếp tục khởi tạo kết nối"
        case "SYSTEM_PAIRING": return "Hãy xác nhận ghép nối trên iPhone và đồng hồ"
        case "ACCOUNT": return "Đồng bộ Huawei ID"
        case "PIN_REQUEST": return "Đang xin thông tin ghép nối từ đồng hồ"
        case "PIN_INPUT": return "Nhập mã hiển thị trên đồng hồ"
        case "BOND_PARAMS": return "Đọc tham số liên kết giao thức"
        case "BOND_KEY": return "Hoàn tất liên kết giao thức"
        case "REBINDING": return "Đang liên kết lại giao thức"
        default: return s.detail
        }
    }

    private func operationLabel(_ kind: String, _ stage: String, _ active: Bool, _ failed: Bool) -> String {
        switch stage {
        case "LISTED": return (!active && !failed) ? "Đã thay mặt đồng hồ" : (failed ? "Chưa xác nhận được kết quả thay" : "Đang đối chiếu kết quả thay")
        case "DELETED": return (!active && !failed) ? "Đã xoá mặt đồng hồ" : (failed ? "Chưa xác nhận được kết quả xoá" : "Đang đối chiếu kết quả xoá")
        case "ACTIVATED": return (!active && !failed) ? "Đã bật mặt đồng hồ" : (failed ? "Chưa xác nhận được kết quả bật" : "Đang đối chiếu kết quả bật")
        case "NO_TRANSFER": return "Đồng hồ không yêu cầu file, không truyền gì"
        case "PRECHECK_FAILED":
            if kind == "deletion" { return "Chưa xoá: chưa gửi lệnh nào tới đồng hồ" }
            if kind == "activation" { return "Chưa bật: hãy làm mới rồi thử lại" }
            return "Chưa thay: chưa gửi lệnh nào tới đồng hồ"
        case "TIMED_OUT": return "Quá thời gian, hãy kết nối lại và truy vấn"
        case "FAILED", "CANCELLED": return "Thao tác chưa hoàn tất đáng tin cậy, hãy kết nối lại và truy vấn"
        case "WAIT_OPERATION", "WAIT_DEVICE": return "Chờ đồng hồ chấp nhận"
        case "TRANSFERRING": return "Đang truyền nội dung"
        case "WAIT_REPORT", "WAIT_POST": return "Chờ báo cáo từ đồng hồ và xác nhận của app"
        case "WAIT_LIST":
            if kind == "deletion" { return "Đối chiếu hai danh sách mới sau khi xoá" }
            if kind == "activation" { return "Đối chiếu mặt đồng hồ hiện tại" }
            return "Đối chiếu danh sách phiên bản mới"
        default: return stage
        }
    }

    private func replacementError(_ code: String) -> String {
        switch code {
        case "FRESH_DEVICE_LIST_REQUIRED": return "Danh sách đã cũ hoặc đang truy vấn, chưa gửi lệnh thay. Hãy làm mới rồi chọn lại HWT."
        case "SELECTED_FACE_CHANGED", "SELECTED_ID_NOT_UNIQUE", "VERSION_CHANGED": return "Mặt đồng hồ hoặc phiên bản đã đổi, chưa gửi lệnh thay. Hãy làm mới và chọn lại."
        case "SELECTED_CONNECTION_CHANGED": return "Kết nối đã đổi, chưa gửi lệnh thay. Hãy chọn lại trên đồng hồ hiện tại."
        case "PAYLOAD_SNAPSHOT_UNAVAILABLE": return "Bản sao file cục bộ không còn hợp lệ. Hãy chọn lại HWT."
        case "SOURCE_SELECTION_CHANGED": return "File HWT đã đổi, hãy bấm thay thế lại."
        default: return "Chưa thay, chưa gửi lệnh: \(code)"
        }
    }

    private func deletionError(_ code: String) -> String {
        switch code {
        case "FRESH_DEVICE_LIST_REQUIRED": return "Danh sách đã cũ hoặc đang truy vấn, chưa gửi lệnh xoá. Hãy làm mới rồi xác nhận lại."
        case "SELECTED_FACE_CHANGED", "SELECTED_ID_NOT_UNIQUE", "DELETE_PREPARATION_CHANGED": return "Mặt đồng hồ hoặc phiên bản gốc đã đổi, chưa gửi lệnh xoá. Hãy làm mới và chọn lại."
        case "SELECTED_CONNECTION_CHANGED": return "Kết nối đã đổi, chưa gửi lệnh xoá. Hãy chọn lại trên đồng hồ hiện tại."
        default: return "Chưa xoá, chưa gửi lệnh: \(code)"
        }
    }

    private func activationError(_ code: String) -> String {
        switch code {
        case "FRESH_DEVICE_LIST_REQUIRED": return "Danh sách đã cũ hoặc đang truy vấn, hãy làm mới rồi bật lại"
        case "SELECTED_FACE_CHANGED", "SELECTED_ID_NOT_UNIQUE": return "Mặt đồng hồ hoặc phiên bản gốc đã đổi, hãy làm mới và thử lại từ đúng thẻ"
        case "SELECTED_CONNECTION_CHANGED": return "Kết nối đã đổi, hãy thử lại từ thẻ trên đồng hồ hiện tại"
        case "SELECT_EXISTING_ACTIVATABLE_FACE": return "Tài nguyên hoặc loại của mặt đồng hồ này chưa được xác nhận, không thể bật"
        default: return "Chưa bật: \(code)"
        }
    }

    private func runtimeError(_ kind: String, _ stage: String, _ code: String) -> String {
        if kind == "replacement" && stage == "PRECHECK_FAILED" { return replacementError(code) }
        if kind == "deletion" && stage == "PRECHECK_FAILED" { return deletionError(code) }
        if kind == "activation" && stage == "PRECHECK_FAILED" { return activationError(code) }
        switch code {
        case "WATCHFACE_OPERATION_BUSY", "WAIT_FOR_CURRENT_OPERATION_OR_QUERY": return "Hãy đợi thao tác hoặc truy vấn hiện tại xong"
        case "CONNECT_AND_AUTHENTICATE_FIRST": return "Hãy kết nối đồng hồ trước"
        case "LIST_QUERY_TIMEOUT_RECONNECT": return "Đọc danh sách mặt đồng hồ quá thời gian, hãy kết nối lại rồi làm mới"
        case "DEVICE_LIST_ERROR": return "Đồng hồ không trả danh sách hợp lệ, hãy làm mới lại"
        case "RECONNECT_AFTER_UNCERTAIN_FILE_RESULT": return "Thao tác trước chưa kết thúc đáng tin cậy, hãy kết nối lại rồi làm mới"
        case "DELETE_PREPARATION_CHANGED": return "Mặt đồng hồ đã đổi, hãy làm mới danh sách rồi chọn lại"
        default: return "Thao tác chưa hoàn tất: \(code)"
        }
    }

    // MARK: Ánh xạ Snapshot -> AppUiState

    private func replacementIdentityMatches(_ d: ReplacementDialogInfo?, _ i: WatchfaceManager.ReplacementIdentity?) -> Bool {
        guard let d = d, let i = i else { return false }
        return d.operation.kind == "replacement" && d.token == i.token && d.connectionEpoch == i.epoch && d.targetId == i.id && d.targetVersion == i.version
    }
    private func deletionIdentityMatches(_ d: ReplacementDialogInfo?, _ i: WatchfaceManager.DeletionIdentity?) -> Bool {
        guard let d = d, let i = i else { return false }
        return d.operation.kind == "deletion" && d.token == i.token && d.connectionEpoch == i.epoch && d.targetId == i.id && d.targetVersion == i.version
    }
    private func activationIdentityMatches(_ d: ReplacementDialogInfo?, _ i: WatchfaceManager.ActivationIdentity?) -> Bool {
        guard let d = d, let i = i else { return false }
        return d.operation.kind == "activation" && d.token == i.token && d.connectionEpoch == i.epoch && d.targetId == i.id && d.targetVersion == i.version
    }

    private func rebuilt(_ d: ReplacementDialogInfo, detail: String, fileName: String? = nil, interrupt: Bool? = nil) -> ReplacementDialogInfo {
        var op = d.operation
        op.detail = detail
        return ReplacementDialogInfo(token: d.token, connectionEpoch: d.connectionEpoch, targetId: d.targetId, targetVersion: d.targetVersion,
                                     title: d.title, fileName: fileName ?? d.fileName, operation: op, interruptRequested: interrupt ?? d.interruptRequested)
    }

    private func replacementDialog(_ s: AppRuntime.Snapshot) -> ReplacementDialogInfo? {
        guard let d = s.replacementDialog, replacementIdentityMatches(d, s.replacementDialogIdentity) else { return nil }
        let o = d.operation
        let detail: String
        if o.stage == "PRECHECK_FAILED" { detail = replacementError(o.detail) }
        else if o.stage == "CANCELLED" && o.detail == "USER_CANCELLED_BEFORE_SEND" { detail = "Đã huỷ thay, chưa gửi lệnh nào tới đồng hồ" }
        else if o.stage == "CANCELLED" { detail = "Đã huỷ thay, hãy kết nối lại và truy vấn" }
        else { detail = operationLabel(o.kind, o.stage, o.active, o.failed) }
        return rebuilt(d, detail: detail)
    }
    private func deletionDialog(_ s: AppRuntime.Snapshot) -> ReplacementDialogInfo? {
        guard let d = s.deletionDialog, deletionIdentityMatches(d, s.deletionDialogIdentity) else { return nil }
        let o = d.operation
        let detail = o.stage == "PRECHECK_FAILED" ? deletionError(o.detail) : operationLabel(o.kind, o.stage, o.active, o.failed)
        return rebuilt(d, detail: detail, fileName: "", interrupt: false)
    }
    private func activationDialog(_ s: AppRuntime.Snapshot) -> ReplacementDialogInfo? {
        guard let d = s.activationDialog, activationIdentityMatches(d, s.activationDialogIdentity) else { return nil }
        let o = d.operation
        let detail = o.stage == "PRECHECK_FAILED" ? activationError(o.detail) : operationLabel(o.kind, o.stage, o.active, o.failed)
        return rebuilt(d, detail: detail, fileName: "", interrupt: false)
    }

    // AppRuntimeObserver (luồng bất kỳ)
    func changed(_ state: AppRuntime.Snapshot) {
        DispatchQueue.main.async { [weak self] in self?.apply(state) }
    }

    func rebindRequested(_ message: String) {
        let requested = runtime.connection.epoch
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let current = self.runtime.snapshot()
            if !self.removalBlocks(self.runtime.connection.address), requested == self.runtime.connection.epoch,
               current.epoch == requested, current.code == "REBIND_CONFIRM" {
                self.prompt(kind: "rebind", title: "Liên kết lại giao thức?",
                            message: "Liên kết lại có thể làm thay đổi quan hệ kết nối giữa đồng hồ và các app khác. Tiếp tục?",
                            danger: true, positive: "Xác nhận liên kết lại",
                            action: { [weak self] in self?.runtime.connection.confirmRebind(expectedEpoch: requested) },
                            cancel: { [weak self] in self?.runtime.connection.disconnectIfEpoch(requested) })
            }
        }
    }

    func deletionPrepared(_ face: TlvView.Face, epoch: Int) {} // không dùng: yêu cầu xoá có callback riêng

    private func apply(_ s: AppRuntime.Snapshot) {
        let current = runtime.snapshot()
        if s.epoch != runtime.connection.epoch || s.epoch != current.epoch
            || s.operationRevision != current.operationRevision
            || s.replacementDialogRevision != current.replacementDialogRevision
            || s.deletionDialogRevision != current.deletionDialogRevision
            || s.activationDialogRevision != current.activationDialogRevision
            || s.replacementIdentity !== current.replacementIdentity || s.replacementDialogIdentity !== current.replacementDialogIdentity
            || s.deletionIdentity !== current.deletionIdentity || s.deletionDialogIdentity !== current.deletionDialogIdentity
            || s.activationIdentity !== current.activationIdentity || s.activationDialogIdentity !== current.activationDialogIdentity
            || s.operationRevision < appliedOperationRevision || s.replacementDialogRevision < appliedReplacementDialogRevision
            || s.deletionDialogRevision < appliedDeletionDialogRevision || s.activationDialogRevision < appliedActivationDialogRevision {
            return
        }
        appliedOperationRevision = s.operationRevision
        appliedReplacementDialogRevision = s.replacementDialogRevision
        appliedDeletionDialogRevision = s.deletionDialogRevision
        appliedActivationDialogRevision = s.activationDialogRevision
        if let q = queuedConnectEpoch, q != s.epoch { queuedConnectEpoch = nil }
        let address = SavedWatchStore.canonicalAddress(runtime.connection.address)
        if removalBlocks(address) && (s.ready || s.connecting) { return }
        let device = address.flatMap { deviceMetadata($0) }
        if let a = address, ui.selectedDeviceAddress == a, credentialEpoch != s.epoch, (s.ready || s.connecting) {
            credentialEpoch = s.epoch
            restoreHuaweiId(a)
        }
        let faces: [FaceItem] = s.faces.map { f in
            FaceItem(id: f.id, version: f.version, rawType: f.type ?? 0, expandType: f.expandType,
                     name: s.names["\(f.id)_\(f.version)"], current: FacePolicy.isCurrent(f),
                     selectable: FacePolicy.eligible(f), kind: FacePolicy.kind(f), activatable: FacePolicy.canActivate(f))
        }
        let replacement = replacementDialog(s), deletion = deletionDialog(s), activation = activationDialog(s)
        let dialog = replacement ?? deletion ?? activation
        let op: OperationInfo
        if preparing {
            op = OperationInfo(kind: "source", stage: "PREPARING", detail: "Đang đọc và đóng băng HWT cục bộ", progress: nil, active: true, failed: false)
        } else if let d = dialog, d.operation.active || !s.active {
            op = d.operation
        } else if fileOnlyPreview && !s.active && !s.failed {
            op = OperationInfo()
        } else {
            op = OperationInfo(kind: s.kind, stage: s.stage, detail: operationLabel(s.kind, s.stage, s.active, s.failed), progress: s.progress, active: s.active, failed: s.failed)
        }
        if s.ready { queuedConnectEpoch = nil }
        let queued = queuedConnectEpoch != nil
        var status = ui.statusMessage
        if s.kind == "replacement" && s.stage == "PRECHECK_FAILED" && !s.message.isEmpty { status = replacementError(s.message) }
        else if s.kind == "deletion" && s.stage == "PRECHECK_FAILED" && !s.message.isEmpty { status = deletionError(s.message) }
        else if s.kind == "activation" && s.stage == "PRECHECK_FAILED" && !s.message.isEmpty { status = activationError(s.message) }
        else if !s.message.isEmpty { status = s.message }
        else if (s.ready && ui.phaseCode != "READY") || (ui.listRefreshing && !s.listRefreshing) { status = "" }

        ui.phaseCode = s.code
        ui.connectionEpoch = s.epoch
        ui.phase = queued ? "Đang kết nối đồng hồ" : phaseLabel(s.code)
        ui.detail = connectionDetail(s)
        ui.connected = s.ready
        ui.connecting = !s.ready && (s.connecting || queued)
        ui.watchName = queued ? (sessionDevice?.name ?? ui.watchName) : (device?.name ?? ui.watchName)
        ui.deviceAddress = s.deviceAddress
        ui.serialNumber = s.serialNumber
        ui.firmware = s.firmware
        ui.deviceModel = s.deviceModel
        ui.batteryPercent = s.batteryPercent
        ui.freeMemoryBytes = s.freeMemoryBytes
        ui.width = s.width; ui.height = s.height; ui.capability = s.capability
        ui.faces = faces
        ui.listReady = s.listReady
        ui.listRefreshing = s.listRefreshing
        ui.selectedId = nil
        ui.operation = op
        ui.replacementDialog = replacement
        ui.deletionDialog = deletion
        ui.activationDialog = activation
        ui.needsPin = s.needsPin
        ui.pinMessage = s.pinMessage.isEmpty ? ui.pinMessage : s.pinMessage
        ui.rebindCount = s.rebind
        ui.quarantine = (s.failed && !s.ready) || runtime.watchfaces.reconnectRequired(s.epoch)
        ui.statusMessage = status

        if s.message != lastRuntimeMessage {
            lastRuntimeMessage = s.message
            if !s.message.isEmpty { message(runtimeError(s.kind, s.stage, s.message)) }
        }
        syncSuccessfulHistory(s)
        // Bỏ qua bước "thoả thuận" như bản Android (không gửi đồng ý).
        if s.code == "AGREEMENT_CONFIRM", s.epoch == runtime.connection.epoch, runtime.snapshot().code == s.code, !runtime.connection.ready {
            if agreementSkippedEpoch != s.epoch {
                agreementSkippedEpoch = s.epoch
                runtime.connection.respondAgreements(expectedEpoch: s.epoch, accept: false)
            }
        }
        if ui.prompt?.kind == "rebind" && runtime.snapshot().code != "REBIND_CONFIRM" { invalidatePrompt() }
    }

    private func deviceMetadata(_ address: String) -> NearbyWatch? {
        if let d = sessionDevice, d.address.caseInsensitiveCompare(address) == .orderedSame { return d }
        return ui.savedDevices.first { $0.address.caseInsensitiveCompare(address) == .orderedSame }?.nearby()
    }

    /// Ghi lịch sử khi READY (Java successfulHistory): chỉ đúng đồng hồ đang READY, đúng thế hệ xoá.
    private func syncSuccessfulHistory(_ s: AppRuntime.Snapshot) {
        defer { ui.savedDevices = runtime.history.devices() }
        guard s.code == "READY", s.ready, runtime.connection.ready, s.epoch == runtime.connection.epoch,
              queuedConnectEpoch == nil,
              let address = SavedWatchStore.canonicalAddress(runtime.connection.address),
              !removalBlocks(address), s.deviceAddress.caseInsensitiveCompare(address) == .orderedSame else { return }
        let generation = runtime.secure.removals.generation(address)
        guard runtime.secure.removals.usable(address, generation: generation),
              let device = deviceMetadata(address) else { return }
        do {
            if rememberedReadyEpoch != s.epoch {
                _ = try runtime.history.remember(device)
                rememberedReadyEpoch = s.epoch
            }
            _ = try runtime.history.rememberModel(address, model: s.deviceModel, expectedGeneration: generation)
            _ = try runtime.history.rememberSerial(address, serialNumber: s.serialNumber, expectedGeneration: generation)
        } catch {
            runtime.logs.record("DEVICE_HISTORY_ERROR", "code=\(WMCore.code(error))")
        }
    }

    // MARK: Huawei ID

    private func savedHuaweiId(_ address: String?) -> String {
        guard let a = address, !removalBlocks(a) else { return "" }
        do { return try runtime.secure.huaweiId(a) }
        catch { message("Không đọc được Huawei ID của thiết bị này: \(WMCore.code(error))"); return "" }
    }

    private func restoreHuaweiId(_ address: String?) {
        let id = savedHuaweiId(address)
        savedEditorId = id
        ui.huaweiIdInput = id
        ui.accountConfigured = !id.trimmingCharacters(in: .whitespaces).isEmpty
        ui.huaweiIdDirty = false
    }

    private func validHuaweiId(_ id: String) -> Bool {
        if id.isEmpty || id.utf8.count > 128 { return false }
        if id.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) { return false }
        if id.allSatisfy({ $0.isASCII && $0.isNumber }) && id.count > 19 { return false }
        return true
    }

    func setHuaweiId(_ value: String) {
        guard ui.selectedDeviceAddress != nil, !removalBlocks(ui.selectedDeviceAddress), ui.huaweiIdInput != value else { return }
        ui.huaweiIdInput = value
        ui.huaweiIdDirty = value.trimmingCharacters(in: .whitespaces) != savedEditorId
        ui.connectionFormRevision += 1
    }

    func saveHuaweiId() {
        guard !removalBlocks(ui.selectedDeviceAddress), !ui.connecting, !busyLocally(), ui.prompt == nil, !ui.needsPin, !ui.removing else { return }
        guard let address = ui.selectedDeviceAddress else { message("Hãy chọn một đồng hồ trước"); return }
        let id = ui.huaweiIdInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard validHuaweiId(id) else { message("Hãy nhập Huawei ID hợp lệ"); return }
        do {
            try runtime.secure.saveHuaweiId(address, id)
            savedEditorId = id
            ui.huaweiIdInput = id; ui.huaweiIdDirty = false; ui.accountConfigured = true
            ui.connectionFormRevision += 1
            message(ui.connected ? "Đã lưu Huawei ID, có hiệu lực từ lần kết nối sau" : "Đã lưu Huawei ID")
        } catch { message("Lưu Huawei ID thất bại: \(WMCore.code(error))") }
    }

    func readHuaweiIdForDevice(_ device: NearbyWatch) -> String? {
        guard let a = SavedWatchStore.canonicalAddress(device.address), !removalBlocks(a), !ui.connecting, !ui.needsPin else { return nil }
        return try? runtime.secure.huaweiId(a)
    }

    func saveHuaweiIdForDevice(_ device: NearbyWatch, value: String) -> Bool {
        guard let a = SavedWatchStore.canonicalAddress(device.address), !removalBlocks(a), !ui.connecting, !ui.needsPin else { return false }
        let id = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard validHuaweiId(id) else { message("Hãy nhập Huawei ID hợp lệ"); return false }
        do { try runtime.secure.saveHuaweiId(a, id) } catch { message("Lưu Huawei ID thất bại: \(WMCore.code(error))"); return false }
        if ui.selectedDeviceAddress == a { savedEditorId = id; ui.huaweiIdInput = id; ui.huaweiIdDirty = false; ui.accountConfigured = true }
        return true
    }

    // MARK: Cài đặt

    func setTheme(_ mode: ThemeMode) { defaults.set(mode.rawValue, forKey: "wm.theme"); ui.theme = mode }
    func setAutoConnect(_ enabled: Bool) { runtime.history.setAutoConnect(enabled); ui.autoConnect = enabled }

    // MARK: Màn giới thiệu + tự kết nối khi mở app (giống StartupConnectionOpportunity của Android)

    private var startupTaken = false

    func introductionInteractionIsCurrent() -> Bool { ui.introductionPending }

    /// Chỉ trả true khi đã lưu dấu "đã đọc"; sau đó dùng cơ hội khởi động (nếu còn).
    @discardableResult
    func acknowledgeIntroduction() -> Bool {
        defaults.set(true, forKey: "wm.introduction-acknowledged")
        guard defaults.bool(forKey: "wm.introduction-acknowledged") else { return false }
        ui.introductionPending = false
        connectAtStartup()
        return true
    }

    /// Giới thiệu chưa đọc thì không tiêu thụ cơ hội; lần thử đầu tiên sau đó luôn tiêu thụ (kể cả khi tắt/không có thiết bị).
    func takeStartupDevice() -> NearbyWatch? {
        if ui.introductionPending || startupTaken { return nil }
        startupTaken = true
        let s = runtime.snapshot()
        let eligible = ui.autoConnect && queuedConnectEpoch == nil && !ui.removing
            && !runtime.connection.ready && !s.ready && !s.connecting && !s.active && !s.needsPin
            && s.code != "REBIND_CONFIRM" && !ui.connecting && !ui.scanning && !busyLocally()
        if !eligible { return nil }
        guard let saved = ui.savedDevices.first(where: { !removalBlocks($0.address) }) else { return nil }
        let device = saved.nearby()
        selectDevice(device)
        if !ui.accountConfigured {
            message("Không đọc được Huawei ID của đồng hồ lần trước, hãy nhập lại rồi kết nối")
            return nil
        }
        return device
    }

    /// Gọi khi giao diện xuất hiện lần đầu.
    func connectAtStartup() {
        guard let device = takeStartupDevice() else { return }
        connect(device, huaweiId: "")
    }

    // MARK: Quét & chọn & kết nối

    func scan() {
        guard !ui.removing else { return }
        scanGeneration += 1
        let gen = scanGeneration
        ui.scanning = true
        ui.statusMessage = "Đang tìm đồng hồ ở gần"
        scanner.start(onItems: { [weak self] items in
            guard let self = self, self.scanGeneration == gen else { return }
            self.ui.devices = items.map { NearbyWatch(address: $0.id, name: $0.name, bonded: $0.advertisesHuaweiService, rssi: $0.rssi, transport: "BLE", likelyHuawei: true) }
        }, onStopped: { [weak self] reason in
            guard let self = self, self.scanGeneration == gen else { return }
            self.ui.scanning = false
            switch reason {
            case "BLUETOOTH_PERMISSION_REQUIRED": self.ui.statusMessage = "Hãy cấp quyền Bluetooth cho Huawei watch face trong Cài đặt"
            case "BLUETOOTH_DISABLED": self.ui.statusMessage = "Bluetooth đang tắt, hãy bật rồi quét lại"
            case "BLUETOOTH_UNSUPPORTED": self.ui.statusMessage = "Thiết bị này không hỗ trợ Bluetooth LE"
            default: self.ui.statusMessage = reason
            }
        })
    }

    func stopScan() { scanGeneration += 1; scanner.stop(); ui.scanning = false }

    func selectDevice(_ device: NearbyWatch) {
        guard !ui.removing, deletionPreparation == nil, !replacementActive() else { return }
        guard let address = SavedWatchStore.canonicalAddress(device.address) else { message("Mã thiết bị không hợp lệ"); return }
        if ui.selectedDeviceAddress != address, ui.prompt != nil { invalidatePrompt() }
        ui.selectedDeviceAddress = address
        ui.watchName = device.name
        ui.connectionFormRevision += 1
        credentialEpoch = runtime.connection.epoch
        restoreHuaweiId(address)
    }

    func connect(_ device: NearbyWatch, huaweiId: String) {
        let expectedEpoch = runtime.connection.epoch
        if ui.removing || busyLocally() { message("Hãy kết thúc thao tác hiện tại trước"); return }
        guard let address = SavedWatchStore.canonicalAddress(device.address) else { message("Mã thiết bị không hợp lệ"); return }
        if removalBlocks(address) { message("Dữ liệu thiết bị này đang được xoá, chưa kết nối lại"); return }
        let generation = runtime.secure.removals.generation(address)
        let id = huaweiId.trimmingCharacters(in: .whitespacesAndNewlines)
        if !id.isEmpty && (id.utf8.count > 128 || (id.allSatisfy { $0.isASCII && $0.isNumber } && id.count > 19)) {
            message("Độ dài Huawei ID không được hỗ trợ"); return
        }
        if ui.selectedDeviceAddress != address { selectDevice(device) }
        if id.isEmpty {
            restoreHuaweiId(address)
            if !ui.accountConfigured { message("Đồng hồ này chưa có Huawei ID đã lưu, hãy nhập rồi kết nối"); return }
        } else { setHuaweiId(id) }
        var requested = device
        requested = NearbyWatch(address: address, name: device.name, bonded: device.bonded, rssi: device.rssi, transport: device.transport, likelyHuawei: device.likelyHuawei)
        let revision = ui.connectionFormRevision
        let action: () throws -> Void = { [weak self] in
            guard let self = self else { return }
            if expectedEpoch != self.runtime.connection.epoch || revision != self.ui.connectionFormRevision
                || !self.runtime.secure.removals.usable(address, generation: generation) {
                self.message("Trạng thái kết nối đã đổi, hãy kết nối lại thiết bị đã chọn"); return
            }
            if self.ui.removing || self.removalBlocks(address) || self.busyLocally() {
                self.message("Thao tác hiện tại chưa xong, chưa chuyển kết nối"); return
            }
            self.stopScan(); self.invalidatePrompt()
            self.sessionDevice = requested
            self.queuedConnectEpoch = expectedEpoch
            self.ui.watchName = requested.name
            self.ui.selectedDeviceAddress = address
            self.ui.connectionFormRevision += 1
            self.ui.connecting = true
            self.ui.statusMessage = ""
            self.runtime.connection.connectIfEpoch(expectedEpoch, deviceId: address, account: id.isEmpty ? nil : id)
        }
        let looksOdd = !id.isEmpty && (!id.allSatisfy { $0.isASCII && $0.isNumber } || id.count == 11)
        if looksOdd {
            prompt(kind: "account-warning", title: "Xác nhận Huawei ID",
                   message: "Có thể đây không phải Huawei ID. Hãy đối chiếu với ID đang dùng trong Huawei Health rồi quyết định có tiếp tục không.",
                   danger: false, positive: "Xác nhận dùng", action: action)
        } else {
            try? action()
        }
    }

    func disconnect() {
        if replacementActive() { message("Hãy đợi thao tác hiện tại xong"); return }
        invalidatePrompt()
        ui.connectionFormRevision += 1
        runtime.connection.disconnect()
        message("Đã yêu cầu ngắt kết nối")
    }

    /// iOS không huỷ ghép nối hệ thống được: chỉ xoá dữ liệu cục bộ của WristMirror.
    func requestRemoval(_ device: NearbyWatch) {
        if busyLocally() || ui.operation.active { message("Hãy kết thúc thao tác mặt đồng hồ trước"); return }
        guard pending == nil, let address = SavedWatchStore.canonicalAddress(device.address) else { return }
        prompt(kind: "remove", title: "Xoá dữ liệu đồng hồ?",
               message: "\(device.name)\nMã: \(address)\n\nXoá bản ghi, Huawei ID và khoá xác thực của đồng hồ này trong Huawei watch face. Mặt đồng hồ trên đồng hồ không bị ảnh hưởng.\n\nĐể huỷ ghép nối hệ thống: Cài đặt > Bluetooth > (i) > Forget This Device.",
               danger: true, positive: "Xoá dữ liệu", action: { [weak self] in
            guard let self = self else { return }
            self.ui.removing = true
            self.stopScan()
            self.runtime.removeDevice(address) { code in
                DispatchQueue.main.async {
                    self.ui.removing = false
                    self.ui.savedDevices = self.runtime.history.devices()
                    if let code = code { self.message("Chưa xoá được dữ liệu: \(code)"); return }
                    self.ui.devices.removeAll { $0.address.caseInsensitiveCompare(address) == .orderedSame }
                    if self.ui.selectedDeviceAddress?.caseInsensitiveCompare(address) == .orderedSame {
                        self.ui.selectedDeviceAddress = nil
                        self.ui.huaweiIdInput = ""; self.ui.accountConfigured = false; self.ui.huaweiIdDirty = false
                        self.savedEditorId = ""; self.credentialEpoch = -1
                        self.ui.connectionFormRevision += 1
                    }
                    if self.sessionDevice?.address.caseInsensitiveCompare(address) == .orderedSame {
                        self.sessionDevice = nil; self.queuedConnectEpoch = nil; self.rememberedReadyEpoch = -1
                    }
                    self.message("Đã xoá dữ liệu cục bộ của đồng hồ")
                }
            }
        })
    }

    func submitPin(expectedEpoch: Int, pin: String) {
        guard !removalBlocks(runtime.connection.address), expectedEpoch == runtime.connection.epoch,
              ui.connectionEpoch == expectedEpoch, ui.needsPin else { return }
        ui.needsPin = false
        runtime.connection.submitPin(expectedEpoch: expectedEpoch, entered: pin)
    }

    func cancelPin(expectedEpoch: Int) {
        guard expectedEpoch == runtime.connection.epoch, ui.connectionEpoch == expectedEpoch, ui.needsPin else { return }
        ui.connectionFormRevision += 1
        runtime.connection.disconnectIfEpoch(expectedEpoch)
    }

    // MARK: Danh sách mặt đồng hồ

    func refreshFaces() {
        guard !ui.removing, !removalBlocks(runtime.connection.address), !preparing, deletionPreparation == nil, !replacementActive() else { return }
        ui.statusMessage = ""
        runtime.logs.record("LIST_REFRESH", "request=read_face_list")
        runtime.watchfaces.refresh()
    }

    func selectFace(_ id: String) {} // đã tắt: dùng các hàm theo thẻ

    // MARK: Chọn & nạp HWT

    func prepareHwtPick() -> Bool {
        // Bộ chọn trước đó có thể đã bị đóng mà không báo kết quả: thu hồi token cũ để mở lại được.
        if ui.pickingHwt { filePickToken = nil; ui.pickingHwt = false }
        guard !ui.removing, !busyLocally(), canChooseHwt() else { return false }
        filePickToken = nextToken()
        fileOnlyPreview = true
        ui.pickingHwt = true
        if !ui.operation.failed { ui.operation = OperationInfo() }
        apply(runtime.snapshot())
        runtime.logs.record("SOURCE_PICK_OPENED", "no_command_sent=true")
        return true
    }

    private func canChooseHwt() -> Bool {
        !ui.removing && !ui.operation.active && !ui.connecting && ui.operationDialog == nil && ui.prompt == nil && !ui.needsPin
    }

    /// Ghi vết bộ chọn file vào nhật ký (chỉ metadata, không có tên/nội dung file).
    func logPick(_ event: String) {
        runtime.logs.record("PICK_EVENT", event)
    }

    func cancelHwtPick() {
        filePickToken = nil
        ui.pickingHwt = false
        apply(runtime.snapshot())
    }

    /// Thoả mãn yêu cầu của AppActions (protocol không nhận tham số mặc định).
    func importHwt(_ url: URL) {
        importHwt(url, displayName: nil)
    }

    func importHwt(_ url: URL, displayName: String?) {
        importHwt(url, displayName: displayName, onLibrary: nil)
    }

    /// `onLibrary` được gọi (ngoài luồng chính) sau khi file vào thư viện: (mục, true nếu là mục mới tạo).
    func importHwt(_ url: URL, displayName: String?, onLibrary: ((HwtLibraryItem, Bool) -> Void)?) {
        // Bộ chọn file mở không điều kiện (như HuaSideload); kiểm tra bận ở đây và báo lỗi rõ ràng.
        // Không chặn theo trạng thái kết nối: đọc/đóng băng HWT cục bộ không cần đồng hồ.
        if ui.removing || preparing || deletionPreparation != nil || replacementActive() || runtime.watchfaces.busy()
            || ui.operation.active || ui.operationDialog != nil || ui.prompt != nil {
            message("Đang bận thao tác khác, hãy chọn lại HWT sau")
            cancelHwtPick()
            return
        }
        filePickToken = nil
        fileOnlyPreview = true
        if !ui.operation.failed { ui.operation = OperationInfo() }
        runtime.logs.record("SOURCE_PICK_OPENED", "no_command_sent=true")
        preparing = true
        ui.pickingHwt = false
        ui.operation = OperationInfo(kind: "source", stage: "PREPARING", detail: "Đang đọc và đóng băng HWT cục bộ", progress: nil, active: true, failed: false)
        runtime.logs.record("SOURCE_READ_STARTED", "no_command_sent=true")
        let dir = privateFiles
        let fileName = displayName ?? url.lastPathComponent
        ioQueue.async { [weak self] in
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var loaded: HwtSource?
            do {
                let imported = try HwtSource.load(from: url, privateFiles: dir)
                loaded = imported
                let payload = try imported.freeze(.bin)
                try payload.verify()
                let existedBefore = self?.library.all().contains { $0.sourceHash == imported.sourceHash } ?? false
                let added = self?.library.add(original: imported.original, preview: imported.preview, sourceHash: imported.sourceHash,
                                              title: imported.title, fileName: fileName, xmlVersion: imported.xmlVersion)
                if let callback = onLibrary, let item = added { callback(item, !existedBefore) }
                let size = (try? FileManager.default.attributesOfItem(atPath: imported.original.path)[.size] as? NSNumber)?.int64Value ?? 0
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.preparing = false
                    let old = self.source
                    self.source = imported; self.sourcePayload = payload
                    if let o = old { self.cleanAsync(o) }
                    self.runtime.logs.record("SOURCE_IMPORTED", "bytes=\(payload.size) sha256=\(payload.hash) source_sha256=\(imported.sourceHash) xml_not_rewritten=true no_command_sent=true")
                    self.ui.source = SourceInfo(title: imported.title, fileName: fileName, sourceBytes: size, payloadBytes: payload.size,
                                                xmlVersion: imported.xmlVersion, sha256: payload.hash,
                                                previewPath: imported.preview?.path, previewSha256: imported.previewHash)
                    self.ui.operation = OperationInfo()
                    self.apply(self.runtime.snapshot())
                    self.message("HWT đã sẵn sàng, hãy mở thẻ mặt đồng hồ đích rồi bấm Thay thế")
                }
            } catch {
                if let l = loaded { DispatchQueue.main.async { self?.cleanAsync(l) } }
                let code = WMCore.code(error)
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.runtime.logs.record("SOURCE_ERROR", "code=\(code) no_command_sent=true")
                    self.preparing = false
                    self.ui.operation = OperationInfo()
                    self.apply(self.runtime.snapshot())
                    self.message("Đọc HWT thất bại: \(code)")
                }
            }
        }
    }

    /// Chạm vào thông báo lịch nhắc: nạp sẵn file HWT của mục đó (người dùng vẫn tự bấm Thay thế).
    func openScheduled(itemId: String) {
        guard let item = library.item(id: itemId) else { message("Mặt đồng hồ trong lịch không còn trong thư viện"); return }
        useFromLibrary(item)
    }

    /// Dùng lại một file HWT trong thư viện (đi qua đúng luồng nạp/đóng băng như chọn file mới).
    func useFromLibrary(_ item: HwtLibraryItem) {
        guard let url = library.fileURL(item) else { message("File trong thư viện không còn, hãy chọn lại HWT"); return }
        importHwt(url, displayName: item.fileName)
    }

    private func cleanAsync(_ s: HwtSource) {
        let dir = privateFiles
        let target = s.directory
        ioQueue.async { [weak self] in
            do { try HwtSource.cleanup(privateFiles: dir, directory: target) }
            catch { self?.runtime.logs.record("CACHE_ERROR", "code=\(WMCore.code(error))") }
        }
    }

    /// Gửi lại giờ điện thoại cho đồng hồ (nút "Đồng bộ giờ ngay").
    func syncWatchTime() {
        guard ui.connected, !ui.quarantine, !ui.operation.active else {
            message("Hãy kết nối đồng hồ và chờ thao tác hiện tại kết thúc")
            return
        }
        do {
            try runtime.connection.syncTime()
            runtime.logs.record("TIME_SYNC", "request=manual")
            message("Đã gửi giờ điện thoại cho đồng hồ")
        } catch {
            runtime.logs.record("TIME_SYNC_ERROR", "code=\(WMCore.code(error))")
            message("Không gửi được giờ, hãy thử kết nối lại")
        }
    }

    func clearCache() {
        if busyLocally() { message("Hãy kết thúc thao tác mặt đồng hồ trước"); return }
        invalidatePrompt()
        let old = source
        source = nil; sourcePayload = nil
        if let o = old { cleanAsync(o) }
        ui.source = nil
        message("Đã xoá bộ nhớ đệm đã nhập")
    }

    // MARK: Kiểm tra theo từng thẻ

    private func matchesRow(_ row: FaceItem, _ face: TlvView.Face) -> Bool {
        row.id == face.id && row.version == face.version && face.type == row.rawType && face.expandType == row.expandType
    }

    private func canOperateFaces() -> Bool {
        !ui.removing && ui.connected && ui.listReady && !ui.listRefreshing && !ui.quarantine && !ui.operation.active
            && !ui.pickingHwt && !ui.connecting && ui.operationDialog == nil && ui.prompt == nil && !ui.needsPin
    }

    private func rowContextIsCurrent(_ t: RowTarget, _ s: AppRuntime.Snapshot) -> Bool {
        !ui.removing && !removalBlocks(t.address)
            && t.epoch == runtime.connection.epoch && s.epoch == t.epoch && ui.connectionEpoch == t.epoch
            && runtime.connection.ready && s.ready && !s.connecting && !ui.connecting && queuedConnectEpoch == nil
            && runtime.connection.address.caseInsensitiveCompare(t.address) == .orderedSame
            && s.deviceAddress.caseInsensitiveCompare(t.address) == .orderedSame
            && ui.selectedDeviceAddress?.caseInsensitiveCompare(t.address) == .orderedSame
            && ui.connectionFormRevision == t.formRevision && s.operationRevision == t.operationRevision
    }

    private func captureRow(_ rendered: FaceItem, epoch: Int) throws -> RowTarget {
        let s = runtime.snapshot()
        if !canOperateFaces() { throw WMFault("FRESH_DEVICE_LIST_REQUIRED") }
        if s.active || s.connecting || s.needsPin || s.replacementDialog != nil || s.deletionDialog != nil || s.activationDialog != nil {
            throw WMFault("WATCHFACE_OPERATION_BUSY")
        }
        guard let address = SavedWatchStore.canonicalAddress(runtime.connection.address) else { throw WMFault("SELECTED_CONNECTION_CHANGED") }
        let visible = ui.faces.filter { $0.id == rendered.id }
        guard visible.count == 1, let v = visible.first else { throw WMFault("SELECTED_ID_NOT_UNIQUE") }
        if v.version != rendered.version || v.rawType != rendered.rawType || v.expandType != rendered.expandType { throw WMFault("SELECTED_FACE_CHANGED") }
        let actualList = s.faces.filter { $0.id == rendered.id }
        guard actualList.count == 1, let actual = actualList.first else { throw WMFault("SELECTED_ID_NOT_UNIQUE") }
        if !matchesRow(rendered, actual) { throw WMFault("SELECTED_FACE_CHANGED") }
        let target = RowTarget(rendered: rendered, face: actual, epoch: epoch, address: address,
                               formRevision: ui.connectionFormRevision, operationRevision: s.operationRevision)
        _ = try currentRow(target)
        return target
    }

    private func currentRow(_ t: RowTarget, deletionFresh: Bool = false) throws -> (TlvView.Face, AppRuntime.Snapshot) {
        let s = runtime.snapshot()
        if !rowContextIsCurrent(t, s) { throw WMFault("SELECTED_CONNECTION_CHANGED") }
        if preparing || filePickToken != nil || s.needsPin { throw WMFault("WATCHFACE_OPERATION_BUSY") }
        if runtime.watchfaces.reconnectRequired(t.epoch) { throw WMFault("RECONNECT_AFTER_UNCERTAIN_FILE_RESULT") }
        let fresh = deletionFresh ? runtime.watchfaces.deletionListFresh(expectedEpoch: t.epoch) : runtime.watchfaces.replacementListFresh(expectedEpoch: t.epoch)
        if !s.listReady || !fresh { throw WMFault("FRESH_DEVICE_LIST_REQUIRED") }
        let list = s.faces.filter { $0.id == t.rendered.id }
        guard list.count == 1, let actual = list.first else { throw WMFault("SELECTED_ID_NOT_UNIQUE") }
        if !matchesRow(t.rendered, actual) { throw WMFault("SELECTED_FACE_CHANGED") }
        return (actual, s)
    }

    private func currentDeletionFace(_ t: RowTarget) throws -> TlvView.Face {
        let actual = try currentRow(t, deletionFresh: true).0
        if !FacePolicy.eligible(actual) { throw WMFault("SELECTED_FACE_CHANGED") }
        return actual
    }

    private func currentActivationFace(_ t: RowTarget) throws -> TlvView.Face {
        let actual = try currentRow(t).0
        if !FacePolicy.canActivate(actual) { throw WMFault("SELECT_EXISTING_ACTIVATABLE_FACE") }
        return actual
    }

    private func currentPickFace(_ p: Pick) throws -> TlvView.Face {
        let (actual, s) = try currentRow(p.row)
        if !FacePolicy.eligible(actual) { throw WMFault("SELECT_EXISTING_ORDINARY_FACE") }
        if try VersionPolicy.next(id: actual.id, baseline: actual.version, listed: s.faces) != p.version { throw WMFault("VERSION_CHANGED") }
        return actual
    }

    // MARK: Thay thế

    func requestReplacement() {}

    func requestReplacement(face: FaceItem, epoch: Int) {
        if ui.removing || removalBlocks(runtime.connection.address) || preparing || filePickToken != nil || deletionPreparation != nil
            || replacementActive() || runtime.watchfaces.busy() || pending != nil || ui.prompt != nil || ui.needsPin { return }
        guard let imported = source else { message("Hãy chọn file HWT trước"); return }
        guard let payload = sourcePayload else { replacementUiRejected("PAYLOAD_SNAPSHOT_UNAVAILABLE"); return }
        do {
            let row = try captureRow(face, epoch: epoch)
            let (observed, snapshot) = try currentRow(row)
            if !FacePolicy.eligible(observed) { throw WMFault("SELECT_EXISTING_ORDINARY_FACE") }
            let target = Pick(row: row, version: try VersionPolicy.next(id: observed.id, baseline: observed.version, listed: snapshot.faces))
            let current = try currentPickFace(target)
            if payload.source !== imported || !FileManager.default.fileExists(atPath: payload.file.path) { throw WMFault("PAYLOAD_SNAPSHOT_UNAVAILABLE") }
            let title = row.rendered.title
            let filename = ui.source?.fileName ?? imported.title
            let warn = FacePolicy.isCurrent(current) ? "\nMặt đồng hồ này đang dùng, đồng hồ có thể chuyển hiển thị khi thay." : ""
            prompt(kind: "replacement", title: "Thay mặt đồng hồ này?",
                   message: "\(title)\nID: \(current.id)\nFile: \(filename)\n\(current.version) → \(target.version)\nNội dung truyền: \(payload.size) B\(warn)\n\nSẽ ghi đè nội dung hiện có của ID này.",
                   danger: true, positive: "Thay thế", action: { [weak self] in
                try self?.startReplacement(target, imported, payload, title, filename)
            })
        } catch { replacementUiRejected(WMCore.code(error)) }
    }

    private func startReplacement(_ target: Pick, _ imported: HwtSource, _ payload: HwtSource.Snapshot, _ title: String, _ fileName: String) throws {
        let face = target.row.face
        let request = runtime.watchfaces.newReplacementRequest(face: face, version: target.version, epoch: target.row.epoch)
        if !runtime.openReplacementDialog(request, title: title, fileName: fileName) { throw WMFault("WATCHFACE_OPERATION_BUSY") }
        fileOnlyPreview = true
        apply(runtime.snapshot())
        runtime.logs.record("REPLACE_UI_CONFIRM", "id=\(face.id) version=\(target.version) captured_epoch=\(target.row.epoch) token_consumed=true")
        do {
            let actual = try currentPickFace(target)
            if source !== imported || sourcePayload !== payload { throw WMFault("SOURCE_SELECTION_CHANGED") }
            if runtime.watchfaces.busy() { throw WMFault("WATCHFACE_OPERATION_BUSY") }
            runtime.watchfaces.beginReplacement(face: actual, version: target.version, source: payload, epoch: target.row.epoch, request: request)
        } catch { replacementUiRejected(WMCore.code(error), identity: request.identity) }
    }

    private func replacementUiRejected(_ code: String, identity: WatchfaceManager.ReplacementIdentity? = nil) {
        runtime.logs.record("REPLACE_UI_PRECHECK_FAILED", "code=\(code) command_sent=false upload_sent=false")
        if let id = identity {
            runtime.rejectReplacementDialog(id, code: code)
            apply(runtime.snapshot())
        } else {
            ui.operation = OperationInfo(kind: "replacement", stage: "PRECHECK_FAILED", detail: replacementError(code), progress: nil, active: false, failed: true)
        }
        ui.statusMessage = replacementError(code)
    }

    func interruptReplacement(token: Int64) {
        guard ReplacementDialogPolicy.canInterrupt(ui.replacementDialog, token: token),
              let identity = runtime.snapshot().replacementDialogIdentity,
              replacementIdentityMatches(ui.replacementDialog, identity) else { return }
        _ = runtime.interruptReplacement(identity)
        apply(runtime.snapshot())
    }

    func dismissReplacementResult(token: Int64) {
        guard ReplacementDialogPolicy.canDismiss(ui.replacementDialog, token: token),
              let identity = runtime.snapshot().replacementDialogIdentity,
              replacementIdentityMatches(ui.replacementDialog, identity) else { return }
        _ = runtime.dismissReplacementResult(identity)
        apply(runtime.snapshot())
    }

    // MARK: Bật

    func requestActivation() {}

    func requestActivation(face: FaceItem, epoch: Int) {
        if ui.removing || removalBlocks(runtime.connection.address) || preparing || filePickToken != nil || deletionPreparation != nil
            || replacementActive() || runtime.watchfaces.busy() || pending != nil || ui.prompt != nil || ui.needsPin { return }
        var identity: WatchfaceManager.ActivationIdentity?
        do {
            let row = try captureRow(face, epoch: epoch)
            let actual = try currentActivationFace(row)
            if FacePolicy.isCurrent(actual) { message("Mặt đồng hồ này đang được dùng"); return }
            let request = runtime.watchfaces.newActivationRequest(face: actual, epoch: epoch)
            identity = request.identity
            if !runtime.openActivationDialog(request, title: row.rendered.title) { throw WMFault("WATCHFACE_OPERATION_BUSY") }
            fileOnlyPreview = true
            apply(runtime.snapshot())
            runtime.logs.record("ACTIVATE_UI_REQUEST", "id=\(actual.id) version=\(actual.version) captured_epoch=\(epoch) token_consumed=true original_version=true file_budget=0")
            let current = try currentActivationFace(row)
            if runtime.watchfaces.busy() { throw WMFault("WATCHFACE_OPERATION_BUSY") }
            runtime.watchfaces.beginActivation(face: current, epoch: epoch, request: request)
        } catch {
            let code = WMCore.code(error)
            if let id = identity { runtime.rejectActivationDialog(id, code: code) }
            apply(runtime.snapshot())
            message(activationError(code))
        }
    }

    func dismissActivationResult(token: Int64) {
        guard ReplacementDialogPolicy.canDismiss(ui.activationDialog, token: token),
              let identity = runtime.snapshot().activationDialogIdentity,
              activationIdentityMatches(ui.activationDialog, identity) else { return }
        _ = runtime.dismissActivationResult(identity)
        apply(runtime.snapshot())
    }

    // MARK: Xoá

    func requestDeletion() {}

    func requestDeletion(face: FaceItem, epoch: Int) {
        if pending != nil || deletionPreparation != nil || ui.prompt != nil || ui.needsPin || filePickToken != nil { return }
        if ui.removing || removalBlocks(runtime.connection.address) || preparing || replacementActive() || runtime.watchfaces.busy() { return }
        do {
            let row = try captureRow(face, epoch: epoch)
            if !FacePolicy.eligible(row.face) { throw WMFault("SELECT_EXISTING_ORDINARY_FACE") }
            let captured = DeletionPrep(token: nextToken(), row: row)
            deletionPreparation = captured
            runtime.logs.record("DELETE_PREPARE", "token=\(captured.token) id=\(row.face.id) version=\(row.face.version) captured_epoch=\(epoch) new_list_required=true")
            let cb = DeletionPreparationCallback(
                onPrepared: { [weak self] prepared, preparedEpoch in
                    DispatchQueue.main.async {
                        guard let self = self, let p = self.deletionPreparation, p.token == captured.token else { return }
                        self.deletionPreparation = nil
                        self.confirmDeletion(captured, prepared, preparedEpoch)
                    }
                },
                onFailure: { [weak self] code in
                    DispatchQueue.main.async {
                        guard let self = self, let p = self.deletionPreparation, p.token == captured.token else { return }
                        self.deletionPreparation = nil
                        let cur = self.runtime.snapshot()
                        if self.rowContextIsCurrent(captured.row, cur), !self.replacementActive(), !cur.active, self.pending == nil, self.ui.prompt == nil {
                            self.apply(cur); self.message(self.deletionError(code))
                        }
                    }
                })
            runtime.watchfaces.prepareDeletion(face: row.face, epoch: epoch, callback: cb)
        } catch {
            deletionPreparation = nil
            message(deletionError(WMCore.code(error)))
        }
    }

    private func confirmDeletion(_ prep: DeletionPrep, _ prepared: TlvView.Face, _ epoch: Int) {
        let row = prep.row
        if !rowContextIsCurrent(row, runtime.snapshot()) { return }
        if preparing || filePickToken != nil || deletionPreparation != nil || replacementActive() || runtime.watchfaces.busy() || pending != nil || ui.prompt != nil || ui.needsPin { return }
        do {
            if epoch != row.epoch || !matchesRow(row.rendered, prepared) { throw WMFault("DELETE_PREPARATION_CHANGED") }
            let actual = try currentDeletionFace(row)
            let title = row.rendered.title
            let warn = FacePolicy.isCurrent(actual) ? "\nMặt đồng hồ này đang dùng, sau khi xoá đồng hồ có thể chuyển sang mặt khác." : ""
            prompt(kind: "deletion", title: "Xoá mặt đồng hồ này?",
                   message: "\(title)\nID: \(actual.id)\nPhiên bản gốc: \(actual.version)\(warn)\n\nSẽ gỡ mặt đồng hồ khỏi đồng hồ, không thể khôi phục trực tiếp.",
                   danger: true, positive: "Xoá", action: { [weak self] in try self?.startDeletion(row, title) }, ownedToken: prep.token)
        } catch { message(deletionError(WMCore.code(error))) }
    }

    private func startDeletion(_ row: RowTarget, _ title: String) throws {
        let face = row.face
        let request = runtime.watchfaces.newDeletionRequest(face: face, epoch: row.epoch)
        if !runtime.openDeletionDialog(request, title: title) { throw WMFault("WATCHFACE_OPERATION_BUSY") }
        fileOnlyPreview = true
        apply(runtime.snapshot())
        runtime.logs.record("DELETE_UI_CONFIRM", "id=\(face.id) version=\(face.version) captured_epoch=\(row.epoch) token_consumed=true file_budget=0")
        do {
            let actual = try currentDeletionFace(row)
            if runtime.watchfaces.busy() { throw WMFault("WATCHFACE_OPERATION_BUSY") }
            runtime.watchfaces.beginDeletion(face: actual, epoch: row.epoch, request: request)
        } catch {
            let code = WMCore.code(error)
            runtime.logs.record("DELETE_UI_PRECHECK_FAILED", "code=\(code) command_sent=false upload_sent=false")
            runtime.rejectDeletionDialog(request.identity, code: code)
            apply(runtime.snapshot())
            ui.statusMessage = deletionError(code)
        }
    }

    func dismissDeletionResult(token: Int64) {
        guard ReplacementDialogPolicy.canDismiss(ui.deletionDialog, token: token),
              let identity = runtime.snapshot().deletionDialogIdentity,
              deletionIdentityMatches(ui.deletionDialog, identity) else { return }
        _ = runtime.dismissDeletionResult(identity)
        apply(runtime.snapshot())
    }

    // MARK: Prompt xác nhận có token

    private func prompt(kind: String, title: String, message: String, danger: Bool, positive: String,
                        action: @escaping () throws -> Void, cancel: @escaping () -> Void = {}, ownedToken: Int64? = nil) {
        invalidatePrompt()
        let token = ownedToken ?? nextToken()
        pending = Pending(token: token, action: action, cancel: cancel)
        ui.prompt = ActionPrompt(token: token, kind: kind, title: title, message: message, destructive: danger, positiveLabel: positive)
    }

    private func invalidatePrompt() {
        pending = nil
        deletionPreparation = nil
        ui.prompt = nil
    }

    func confirmAction(token: Int64) {
        guard let p = pending, p.token == token, ui.prompt?.token == token else { return }
        pending = nil
        ui.prompt = nil
        do { try p.action() }
        catch {
            let code = WMCore.code(error)
            runtime.logs.record("UI_ACTION_ERROR", "code=\(code)")
            message("Thao tác chưa bắt đầu: \(code)")
        }
    }

    func dismissAction(token: Int64) {
        guard let p = pending, p.token == token else { return }
        let connectionCancel = ui.prompt?.kind == "account-warning"
        pending = nil
        ui.prompt = nil
        if connectionCancel { ui.connectionFormRevision += 1 }
        p.cancel()
    }

    // MARK: Nhật ký

    func exportLogs(to url: URL) {
        do { try runtime.logs.snapshot().write(to: url, atomically: true, encoding: .utf8); message("Đã xuất nhật ký đã lược bỏ thông tin nhạy cảm") }
        catch { message("Xuất nhật ký thất bại") }
    }

    func logsText() -> String { runtime.logs.snapshot() }

    func clearLogs() {
        if !runtime.watchfaces.busy() && !replacementActive() && !preparing && deletionPreparation == nil { runtime.logs.clear() }
        else { message("Đang thao tác, giữ lại nhật ký") }
    }
}
