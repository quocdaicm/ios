// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

private extension Color {
    /// 0xRRGGBB
    init(hex6 hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255)
    }
}

/// Nền AOD có sẵn (tối để tiết kiệm pin).
struct AodPalette: Identifiable {
    let id: String
    let title: String
    let top: Color
    let bottom: Color
}

extension FaceDesign {
    static let aodPalettes: [AodPalette] = [
        AodPalette(id: "navy", title: "Xanh đêm", top: Color(hex6: 0x000000), bottom: Color(hex6: 0x0A1830)),
        AodPalette(id: "wine", title: "Đỏ rượu", top: Color(hex6: 0x0B0204), bottom: Color(hex6: 0x2A0A14)),
        AodPalette(id: "forest", title: "Xanh rừng", top: Color(hex6: 0x00110A), bottom: Color(hex6: 0x06281C)),
        AodPalette(id: "violet", title: "Tím", top: Color(hex6: 0x0B0616), bottom: Color(hex6: 0x261240)),
        AodPalette(id: "bronze", title: "Đồng", top: Color(hex6: 0x0D0803), bottom: Color(hex6: 0x2E1D08)),
        AodPalette(id: "ocean", title: "Biển", top: Color(hex6: 0x000A14), bottom: Color(hex6: 0x0B2A44)),
        AodPalette(id: "rose", title: "Hồng", top: Color(hex6: 0x14040C), bottom: Color(hex6: 0x401428)),
        AodPalette(id: "ash", title: "Xám", top: Color(hex6: 0x000000), bottom: Color(hex6: 0x202020))
    ]

    /// Mặt đồng hồ mặc định của Studio: bố cục và hiệu ứng lấy từ file HWT mẫu của chủ app
    /// (nền chuyển sắc xanh lam → đỏ rượu, hoa sen vàng quay theo kim giây, giờ số trong khung bát giác,
    /// thứ trong khung viên thuốc, dương/âm lịch, pin, nhịp tim, thời tiết, tên, hiệu ứng giây "Hoa nở"
    /// và lá thu rơi). Các vị trí là tỉ lệ 0...1 đã quy đổi ngược từ toạ độ điểm ảnh của file mẫu.
    /// `FaceDesign()` vẫn là thiết kế trống để các mẫu có sẵn (FacePresets) xuất phát từ đó.
    static var themeDefault: FaceDesign {
        var d = FaceDesign()
        let gold = Color(hex6: 0xF2C879)

        // Nền
        d.backgroundColor = Color(red: 0.0, green: 54.0 / 255, blue: 73.0 / 255)
        d.backgroundColor2 = Color(red: 60.0 / 255, green: 6.0 / 255, blue: 26.0 / 255)
        d.useGradient = true

        // Hoa sen vàng quay theo kim giây
        d.decor = [DecorLayer(pattern: .lotus, color: gold, opacity: 0.3, scale: 0.95, spin: .second)]

        // Vạch giờ (chấm vàng)
        d.marks = .dots
        d.marksColor = gold

        // Dương lịch / âm lịch
        d.showSolar = true
        d.solarColor = .white
        d.solarSize = 1.0
        d.solarX = 0.76
        d.solarY = 0.435
        d.solarLabel = true
        d.showLunar = true
        d.lunarColor = Color(hex6: 0xF6DDA4)
        d.lunarSize = 1.0
        d.lunarX = 0.752
        d.lunarY = 0.585
        d.lunarLabel = true

        // Thứ trong tuần
        d.showWeekday = true
        d.weekdayColor = .white
        d.weekdaySize = 0.82
        d.weekdayX = 0.213
        d.weekdayY = 0.5

        // Giờ số
        d.showDigital = true
        d.digitalColor = Color(hex6: 0xFFD9A8)
        d.digitalSize = 1.0
        d.digitalX = 0.5
        d.digitalY = 0.151

        // Tên
        d.showName = true
        d.nameText = "Quốc Đại"
        d.nameColor = Color(hex6: 0xFFD9A8)
        d.nameSize = 0.85
        d.nameX = 0.5
        d.nameY = 0.87
        d.nameStyle = 1

        // Số liệu: pin (trái), nhịp tim (phải dưới), thời tiết (trái dưới, có tên tình trạng)
        d.battery.show = true
        d.battery.color = Color(hex6: 0xFECB3E)
        d.battery.size = 1.05
        d.battery.x = 0.1
        d.battery.y = 0.396
        d.battery.icon = true
        d.heart.show = true
        d.heart.color = .white
        d.heart.size = 1.0
        d.heart.x = 0.572
        d.heart.y = 0.72
        d.heart.icon = true
        d.weather.show = true
        d.weather.color = .white
        d.weather.size = 1.0
        d.weather.x = 0.224
        d.weather.y = 0.735
        d.weatherIcon = true
        d.weatherText = true
        d.weatherRange = false

        // Khung nền: giờ số (bát giác viền cam) và thứ (viên thuốc viền vàng)
        d.plates["digital"] = PlateStyle(shape: 4, fill: .black, line: Color(hex6: 0xFEB43F), opacity: 1.0, outline: true)
        d.plates["weekday"] = PlateStyle(shape: 1, fill: .black, line: Color(hex6: 0xFDC700), opacity: 0.2, outline: true)

        // Kim: nhọn, giờ xanh lam, phút cam, giây đỏ cam, không viền tối
        d.handStyle = .pointed
        d.hourColor = Color(hex6: 0x74A7FF)
        d.minuteColor = Color(hex6: 0xFF8648)
        d.secondColor = Color(hex6: 0xFF4015)
        d.capColor = Color(hex6: 0xA67B01)
        d.showSecond = true
        d.handWidth = 0.9
        d.handOutline = false

        // Chuyển động theo giây: Hoa nở
        d.secondFX = .bloom
        d.secondFXColor = Color(hex6: 0xFFEBD3)

        // Hoạt ảnh nền: lá thu rơi (48 khung, 30 ms, mật độ tối đa)
        d.animOn = true
        d.animKind = .leaves
        d.animFallFrames = 48
        d.animInterval = 30
        d.animDensity = 1.0
        d.animLoopMode = 3

        // AOD: giữ nền gốc, kim vàng nhạt, vạch giờ nâu vàng
        d.aodBackground = .original
        d.aodHandColor = Color(hex6: 0xFFD977)
        d.aodShowMarks = true
        d.aodMarksColor = Color(hex6: 0x8A6A3B)
        return d
    }
}
