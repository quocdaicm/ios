# HANDOFF – WristMirror iOS (đọc file này đầu tiên nếu bạn là AI/lập trình viên làm tiếp)

## 1. Mục tiêu
Viết lại app Android **WristMirror (腕镜)** (Kotlin/Java, repo gốc `WristMirror-main.zip`, giấy phép Apache-2.0)
thành app **iPhone** bằng **Swift + SwiftUI + CoreBluetooth**. App kết nối BLE tới đồng hồ Huawei (GT/FIT…),
xác thực (HiChain ISO / Lite), đọc danh sách mặt đồng hồ, rồi dùng "phương pháp thay thế" để cài
file mặt đồng hồ HWT cục bộ lên một slot mặt đồng hồ thường có sẵn (xem README gốc, mục "替换法的原理").

Người dùng dùng tài khoản Claude miễn phí (sợ hết token) nên công việc được chia thành nhiều phần,
mỗi phần giao ngay bằng một file zip. Người dùng giải nén các zip chồng lên cùng một thư mục.
Build **không cần Mac**: GitHub Actions (`.github/workflows/build.yml`) dùng XcodeGen (`project.yml`)
rồi `xcodebuild` ra IPA chưa ký (người dùng tự ký/cài bằng Sideloadly/AltStore).

## 2. Nguồn Java để port (CẦN file `WristMirror-main.zip` gốc)
Giải nén, nguồn ở: `Escosis-WristMirror-*/app/src/main/java/io/github/escosis/hwtfaceswap/`
Nếu bạn không có zip gốc, hãy yêu cầu người dùng gửi lại. KHÔNG bịa chi tiết giao thức khi chưa đọc Java.

## 3. Trạng thái port (Java → Swift)
Đường dẫn Swift: `WristMirror/…`

| Java | Swift | Trạng thái |
|---|---|---|
| protocol/FrameCodec.java | Protocol/FrameCodec.swift (+ `WMFault`) | ✅ Phần 1 |
| transport/LinkChannel.java, GattChannel.java | Transport/LinkChannel.swift, GattChannel.swift | ✅ Phần 1 (chưa thử trên thiết bị thật) |
| protocol/Core.java | Protocol/Core.swift (`WMCore`) | ✅ Phần 2 |
| protocol/TlvView.java | Protocol/TlvView.swift | ✅ Phần 2 |
| protocol/Wire.java | Protocol/Wire.swift | ✅ Phần 2 |
| protocol/DeviceInfo.java | Protocol/DeviceInfo.swift | ✅ Phần 2 |
| protocol/MiniJson.java | Protocol/MiniJson.swift (`JSONValue`, `JSONObject`) | ✅ Phần 2 |
| protocol/HuaweiCrypto.java | Protocol/HuaweiCrypto.swift + AESPrimitives.swift | ✅ Phần 3 |
| protocol/CryptoSession.java | Protocol/CryptoSession.swift | ✅ Phần 3 |
| protocol/LiteAuth.java | Protocol/LiteAuth.swift | ✅ Phần 3 |
| protocol/LinkCapabilities.java | Protocol/LinkCapabilities.swift (bảng lệnh sinh tự động từ Java) | ✅ Phần 3 |
| protocol/AuthReplyJson.java | Protocol/AuthReplyJson.swift | ✅ Phần 3 |
| protocol/IsoAuth.java, IsoReplyHandler.java | Protocol/IsoAuth.swift, IsoReplyHandler.swift | ✅ Phần 4 |
| transport/WatchConnection.java (39KB) | Transport/WatchConnection.swift (`WatchConnection`, `WatchConnectionListener`) | ✅ Phần 5 (chưa biên dịch/chưa thử máy thật) |
| transport/WatchScanner.java (4.6KB) | Transport/WatchScanner.swift | ✅ Phần 5 (chỉ BLE, khoá = UUID) |
| protocol/WristInitialization.java | Protocol/WristInitialization.swift | ✅ Phần 5 |
| protocol/WireNames.java | Protocol/WireNames.swift (`WireNames.request/parseResponse`) | ✅ Phần 6 (chưa biên dịch) |
| protocol/DeviceTelemetry.java | Protocol/DeviceTelemetry.swift (`DeviceTelemetry`, `.Stats`, `.ProbeOwner`) | ✅ Phần 5 |
| protocol/ActivationState, DeletionState, NameQueryState, ReplacementState .java | Protocol/ActivationState/DeletionState/NameQueryState/ReplacementState.swift (class) | ✅ Phần 6 (chưa biên dịch) |
| store/SecureStore.java | Store/KeychainStore.swift (class `SecureStore`, Keychain) | ✅ Phần 5 |
| store/SafeLog.java | Store/SafeLog.swift | ✅ Phần 5 |
| lifecycle/DeviceRemovalJournal.java | Store/DeviceRemovalGuard.swift | ✅ Phần 5 (rút gọn: chỉ chặn + bộ đếm thế hệ, không có huỷ ghép nối hệ thống) |
| protocol/FileTransfer.java (33KB) | Protocol/FileTransfer.swift | ✅ Phần 6 (chưa biên dịch) |
| protocol/HwtSource.java (12.5KB) | Protocol/HwtSource.swift + Protocol/ZipArchive.swift (bộ đọc ZIP + CRC32 tự viết) | ✅ Phần 6 (chưa biên dịch) |
| protocol/FacePolicy.java, VersionPolicy.java | Protocol/FacePolicy.swift, VersionPolicy.swift | ✅ Phần 6 (chưa biên dịch) |
| transport/WatchfaceManager.java (51KB) | Transport/WatchfaceManager.swift (`WatchfaceManager`, `WatchfaceManagerListener`) | ✅ Phần 7 (chưa biên dịch) |
| AppRuntime.java (29KB) | App/AppRuntime.swift (`AppRuntime.shared`, `Snapshot`, `AppRuntimeObserver`) | ✅ Phần 7 (chưa biên dịch) |
| AppModels.kt | App/Models.swift (`AppUiState`, `FaceItem`, `OperationInfo`, `ReplacementDialogInfo`, protocol `AppActions`…) | ✅ Phần 7 (làm sớm vì AppRuntime cần) |
| store/SavedWatchStore.kt | Store/SavedWatchStore.swift (UserDefaults, khoá = UUID) | ✅ Phần 7 |
| WatchViewModel.kt (85KB) | App/WatchViewModel.swift (ObservableObject, implements `AppActions` + `AppRuntimeObserver`) | ✅ Phần 8 (chưa biên dịch) |
| ui/*.kt (Compose/Miuix) | Views/RootView, DeviceView, FacesView, LogsView, SettingsView (SwiftUI, rút gọn) | ✅ Phần 8 (chưa biên dịch) |
| account/HuaweiId*.kt (WebView đăng nhập Huawei ID) | Views/HuaweiIdWebView.swift (WKWebView nonPersistent + chính sách URL + cookie `uid`) | ✅ Phần 8 (chưa biên dịch) |
| lifecycle/DeviceRemoval*.java, platform/AndroidSystemUnpair.java | — | ❌ Không port nguyên: iOS không cho app huỷ ghép nối hệ thống. Chỉ xoá dữ liệu cục bộ + hướng dẫn người dùng vào Cài đặt > Bluetooth > "Forget This Device". |
| UpdateChecker/UpdateDialog/UpdateReleaseParser/UpdateVersion, ConnectionService.java | — | ❌ Bỏ (tính năng riêng của Android; BLE nền dùng `UIBackgroundModes: bluetooth-central` đã khai báo trong project.yml) |

Thứ tự: Phần 6 ✅ → 7 ✅ → 8 ✅ → **Phần 9 = build GitHub Actions lần đầu, sửa lỗi biên dịch theo log, thử máy thật** ← tiếp theo. Cập nhật bảng này + `README_IOS.md` sau mỗi phần.

## 4. Quy ước code đã dùng (giữ nhất quán)
- Byte luôn là `[UInt8]` (Java `byte[]`, đã xử lý dấu: Java `b & 255` ⇒ `Int(b)`).
- Lỗi giao thức: `throw WMFault("MA_LOI")`; **giữ nguyên chuỗi mã lỗi của Java** (log/UI dựa vào chúng). `WMCore.code(error)` lấy mã.
- Java `long epoch` ⇒ `Int`. Java `Long` có thể null ⇒ `Int64?`.
- JSON: `JSONObject` giữ thứ tự khoá (như LinkedHashMap); chỉ số nguyên, cấm khoá trùng.
- **Cạm bẫy Swift**: `try` không được đứng bên phải toán tử `?:`/`+` không có ngoặc. Dùng `if/else` hoặc đặt một `try` ở đầu biểu thức.
- Giữ nguyên các giới hạn kích thước/ngân sách của bản Java (đây là phần phòng thủ có chủ đích).
- Đa luồng: GattChannel chạy trên `DispatchQueue` tuần tự; callback trả về qua `LinkChannelListener` kèm `epoch` để bỏ qua kết nối cũ.

## 5. Khác biệt iOS cần xử lý (đã biết)
- **Chỉ BLE (GATT)** dùng được: Android có thêm RFCOMM (Bluetooth Classic) – iOS không cho app thường dùng ⇒ bỏ `RfcommChannel`.
- iOS không có địa chỉ MAC; đồng hồ được nhận diện bằng `CBPeripheral.identifier` (UUID). Mọi chỗ Java lưu MAC phải đổi sang UUID (lưu dạng String).
- iOS tự xử lý MTU/CCCD; ghép nối hệ thống xảy ra tự động khi truy cập characteristic mã hoá. Không tự huỷ ghép nối được.
- GATT hằng số: service `FE86`, ghi `FE01`, nhận `FE02` (đã cài trong GattChannel).
- Lưu Secret/khoá vào **Keychain** (không dùng UserDefaults). Ghi `learnedSecret` TRƯỚC khi gửi bước S4 của ISO (xem chú thích đầu IsoAuth.swift).
- Không có `SecureRandom`: dùng `WMRandom.bytes(n)` (SecRandomCopyBytes).
- AES-GCM tự cài (`AESGCMManual`) vì IV 16 byte; thuật toán đã được đối chiếu với thư viện chuẩn bằng mô phỏng Python (khớp).
- Đọc file HWT: HWT là container ZIP chứa `watchface.bin`. Foundation không có API ZIP ⇒ tự viết bộ đọc ZIP tối thiểu (parse central directory; giải nén kiểu deflate bằng `import Compression` với `COMPRESSION_ZLIB`, là raw-deflate). Nhớ giữ giới hạn `WMCore.maxSource/maxMember` và chống ZIP-bomb/path traversal như bản Java.
- Chọn file trong app: `UIDocumentPickerViewController`/`.fileImporter` (cần `startAccessingSecurityScopedResource`).
- Đăng nhập Huawei ID: `WKWebView` (cookie/session quản lý trong `WKWebsiteDataStore`); tham khảo `account/*.kt`.
- Quét thiết bị: bản Java lọc theo cách nào thì đọc `WatchScanner.java`; trên iOS nên thử `scanForPeripherals(withServices: nil)` rồi lọc theo tên/manufacturer data nếu đồng hồ không quảng bá FE86.

## 6. Luồng nghiệp vụ (từ README gốc – xác nhận lại bằng Java khi port)
1. Kết nối BLE → `LinkCapabilities` (link params 01/…, security, services, commands, expand) → xác thực ISO (`IsoAuth`) hoặc Lite (`LiteAuth`) theo `caps.iso()`/`caps.lite()`.
2. Sau khi có khoá phiên: `CryptoSession.seal/open` bọc mọi gói nghiệp vụ (phong bì TLV 7c/7d/7e).
3. Đọc danh sách mặt đồng hồ `0x27/0x02` (`Wire.list`, `Wire.faces`), giữ ID, phiên bản, cờ type thô.
4. Chuẩn bị tải: lấy `watchface.bin` từ HWT, đóng băng + kiểm tra băm.
5. Thay thế: `0x27/0x03` với phiên bản +1 ở trường số cuối (`Wire.operation`); chỉ khi phản hồi thật có `error=0, need=1` mới truyền file; `need=0` thì dừng.
6. Truyền file bằng giao thức `0x28` (FileTransfer): đăng ký file, nhận file ID, thương lượng đơn vị/mã hoá, trả lời digest/chunk/final.
7. Xác minh: kết quả truyền và báo cáo áp dụng được ghi riêng; truy vấn lại danh sách mặt đồng hồ, kiểm tra cùng ID với phiên bản ứng viên. Không coi "100%" là thành công.
- Xoá mặt đồng hồ: `Wire.deletion` (op=2, đúng phiên bản đang cài), xong thì truy vấn lại danh sách.

## 7. Chưa được kiểm chứng (RỦI RO)
- **Chưa có đoạn Swift nào được biên dịch** (môi trường tạo ra không có `swiftc`). Lần build GitHub Actions đầu tiên sẽ lộ lỗi cú pháp/kiểu; sửa theo log.
- GattChannel chưa thử trên đồng hồ thật (đặc biệt: đồng hồ có quảng bá service FE86 không; có cần ghép nối hệ thống trước không).
- Chỉ logic GCM đã được kiểm chứng bằng mô phỏng; các phần mật mã còn lại (HKDF/HMAC/PBKDF2/ISO) port theo Java, chưa có test vector.
- Nên thêm unit test (XCTest) dùng lại các test của Java nếu có (`app/src/test`… trong zip gốc không có thư mục test, chỉ có tác vụ `testDebugUnitTest` trong README).

## 8. Cách làm tiếp
1. Đọc Java của phần kế tiếp (xem bảng mục 3), port từng file, giữ mã lỗi/giới hạn.
2. Đặt file đúng thư mục `WristMirror/<Protocol|Transport|Store|App|Views>/`.
3. Cập nhật bảng trạng thái ở mục 3 và `README_IOS.md`.
4. Đóng zip chỉ chứa file mới/đổi (giải nén chồng lên được), hoặc zip toàn bộ dự án.
5. Giấy phép: giữ Apache-2.0; không chép mã/SDK của Huawei Health (xem `THIRD_PARTY_NOTICES.md` của bản gốc, nên copy sang dự án iOS).

## 9. Ghi chú Phần 5 (dành cho Phần 6/7/8)
- **Khoá thiết bị = UUID của `CBPeripheral`** (chuỗi viết hoa; chuẩn hoá bằng `DeviceRemovalGuard.canonical`). Mọi chỗ Java dùng MAC đều đã đổi.
- `WatchConnection(store:log:deviceModel:)`; truyền `UIDevice.current.model` cho `deviceModel`. Giữ một tham chiếu mạnh tới `WatchConnection` (GattChannel giữ listener yếu). `setListener` giữ yếu.
- Gọi từ UI: `connect(deviceId:account:)`, `submitPin(expectedEpoch:entered:)`, `confirmRebind(expectedEpoch:)`, `respondAgreements(expectedEpoch:accept:)`, `disconnect()`.
- Sau READY: `sendControl(service,command,body)` (gói 0x27, mã hoá) và `sendFile(command,body,encrypt:)` (0x28); gói nghiệp vụ nhận về qua `onPacket` (đã giải mã). `post/execute/delay` chạy trên hàng đợi giao thức; `capabilities` chỉ đọc trên hàng đợi này.
- Giai đoạn `SYSTEM_PAIRING` của bản Java không còn (iOS tự ghép nối khi truy cập characteristic mã hoá).
- `stopForRemoval(id)` (thay `stopForUnpair`) bắt buộc gọi trên hàng đợi giao thức: `connection.post { try? connection.stopForRemoval(id) }`. Quy trình xoá đồng hồ: `removals.beginRemoval` → `stopForRemoval` → `store.clearDevice` → `removals.finishRemoval` (nếu lỗi: `cancelRemoval`).
- Chuỗi mô tả giai đoạn (UI) đã dịch sang tiếng Việt; mã giai đoạn/mã lỗi giữ nguyên tiếng Anh như Java.
- `WatchScanner` lọc theo tên (huawei/honor/watch/华为/荣耀) HOẶC quảng bá service FE86; callback trên main queue.
- Chưa có đoạn Swift nào được biên dịch (xem mục 7). Các điểm dễ lỗi khi build lần đầu: các chuỗi `+` dài của `[UInt8]`, `try` trong biểu thức, `private(set)` trên thuộc tính tính toán ở `WatchConnection`.

## 10. Ghi chú Phần 6 (dành cho Phần 7/8)
- `FacePolicy.isCurrent(face)` (Java `FacePolicy.current`), `eligible`, `canActivate`, `kind` (nhãn tiếng Việt), `defaultSelection`.
- `VersionPolicy.next(id:baseline:listed:)` → phiên bản ứng viên (chỉ +1 trường cuối).
- `WireNames.request(faces:language:)` (rỗng ⇒ bỏ qua gửi), `WireNames.parseResponse(fields)` → `Response{names, orderedNames, ids, malformedNameCount}`.
- Các lớp `*State` là **class** (tham chiếu, đổi được như Java). `Action` là enum `.none/.query/.upload/.activate`. Tham số nhãn: `operation(error:need:echo:)`, `report(type:error:)`, `list(_:generation:ownQuery:serial:)` (Deletion: `querySerial:`), `ReplacementState.list(_:queryGeneration:ownQuery:)`.
- `NameQueryState.next(now:)`/`expire(now:)` dùng mili-giây `Int64`.
- `HwtSource.load(from: URL, privateFiles: URL)`: UI phải gọi `startAccessingSecurityScopedResource()` quanh lời gọi. `privateFiles` nên là Application Support. `freeze(.bin)` → `Snapshot` (chỉ-đọc 0o400); `HwtSource.cleanup(privateFiles:directory:)` xoá thư mục `source-<uuid>`.
- `ZipArchive` chỉ hỗ trợ stored/deflate, không mã hoá, không ZIP64; deflate dùng `Compression` (`COMPRESSION_ZLIB` = raw deflate). Chưa thử trên file HWT thật.
- `FileTransfer(id:installedProtocolVersion:frozen:)`: `metadataBody()` (gửi 0x28/0x02, seal=true) → `onPacket(command:body:transactionsCrypted:)` trả `[Outgoing(command, encrypt, body)]`; bên gọi (WatchfaceManager, Phần 7) gửi qua `WatchConnection.sendFile(command:body:encrypt:)`. Đọc kết quả: `peerResultRaw`, `resultObserved`, `peerComplete`, `completionFailure`. Gọi `close()` khi xong.
- Danh tính file: dùng `systemNumber:systemFileNumber` thay cho `fileKey` của Java; kiểm tra symlink qua `.type == .typeRegular`.
- Rủi ro biên dịch cần soi ở build đầu: `ZipArchive.stream` (con trỏ `compression_stream` trong closure), `HwtSource` (init throwing với nhiều `let`), `FileTransfer.init` (dùng `self` sau khi gán đủ thuộc tính).

## 11. Ghi chú Phần 7 (dành cho Phần 8)
**Đã sửa nhỏ ở Phần 6:** `DeletionState.markNonTargetListIncomplete()` (Java ghi trực tiếp `consecutiveAbsences`/`reason`).

### WatchfaceManager (Transport/WatchfaceManager.swift)
- `WatchfaceManager(connection:log:)`, `setListener(_:)` (weak). Listener = `WatchfaceManagerListener` (các hàm `onReplacement*/onDeletion*/onActivation*` có mặc định như Java `default`). `AppRuntime` là listener duy nhất.
- `AppRuntime` đã chuyển gói: `onPacket` → `watchfaces.packet(epoch:service:command:body:encrypted:)`, `onReady` → `authenticated(epoch:)`, `onClosed` → `closed(closedEpoch:reason:)`.
- Thao tác (gọi từ UI, thread bất kỳ): `refresh()`, `newReplacementRequest(face:version:epoch:)` → `beginReplacement(face:version:source:epoch:request:)`, `cancelReplacement(_:)`, `prepareDeletion(face:epoch:callback:)` (`DeletionPreparationCallback{onPrepared,onFailure}`), `newDeletionRequest` → `beginDeletion(face:epoch:request:)`, `newActivationRequest` → `beginActivation(face:epoch:request:)`.
- `version` truyền cho thay thế = `try VersionPolicy.next(id:baseline:listed:)` tính ở UI (manager kiểm lại, sai ⇒ `VERSION_CHANGED`).
- `source` = `HwtSource.Snapshot` từ `HwtSource.freeze(.bin)` (đã đóng băng trước khi xác nhận).
- Cờ đọc từ UI: `busy()`, `faces()`, `replacementListFresh(expectedEpoch:)` (5 phút), `deletionListFresh(expectedEpoch:)` (30 giây), `reconnectRequired(_:)`.
- Khác Java: so sánh danh sách bằng `listToken` (không dùng tham chiếu); `summaryOwner/previousOwner` là token `Int64`; `error()` đổi tên `reportError`; không có SecurityException.

### AppRuntime (App/AppRuntime.swift)
- `AppRuntime.shared` tạo `SecureStore`, `SafeLog`, `WatchConnection(deviceModel: UIDevice.current.model)`, `WatchfaceManager`, `SavedWatchStore`. Giữ tham chiếu mạnh tới nó suốt vòng đời app.
- `addObserver(_:)` (weak) nhận `AppRuntime.Snapshot`; **callback đến từ luồng bất kỳ ⇒ ViewModel phải `DispatchQueue.main.async` trước khi cập nhật @Published.**
- Phiên hộp thoại: `openReplacementDialog/openDeletionDialog/openActivationDialog`, `reject*Dialog`, `interruptReplacement`, `dismiss*Result`, đúng ngữ nghĩa token như Java.
- `removeDevice(_:completion:)` thay DeviceRemovalController: beginRemoval → stopForRemoval → clearDevice → history.removeDevice → finishRemoval (lỗi ⇒ cancelRemoval). Từ chối nếu đang thao tác (`WATCHFACE_OPERATION_BUSY`).
- `onRuntimeState` thay `ConnectionService.runtimeState` (tuỳ chọn, để trống nếu không cần).
- Chuỗi hiển thị mặc định đã dịch sang tiếng Việt (`"Chưa kết nối"`, `"Đang bắt đầu thay thế"`…).

### Việc Phần 8 phải làm (đọc `WatchViewModel.kt` + `ui/*.kt` + `account/HuaweiId*.kt`)
1. `WatchViewModel.swift`: ObservableObject cài `AppActions` + `AppRuntimeObserver`; chuyển `Snapshot` → `AppUiState` (`FaceItem` từ `TlvView.Face` + `FacePolicy.kind/eligible/canActivate/isCurrent` + tên từ `names["id_version"]`). Gọi `history.remember/rememberModel/rememberSerial` khi READY (đọc Kotlin để biết điều kiện). `HwtSource.load` + `startAccessingSecurityScopedResource` + `freeze`.
2. Quét thiết bị bằng `WatchScanner`; chọn → `connection.connect(deviceId:account:)`.
3. Views SwiftUI (Home/Device/Faces/Settings/Logs/About + các sheet xác nhận/tiến độ), `.fileImporter` chọn .hwt.
4. `HuaweiIdWebView` (WKWebView) thay `account/*.kt` (xem `HuaweiIdWebPolicy.kt` để giữ chính sách URL cho phép).
5. Thay `WristMirrorApp.swift` (màn hình giữ chỗ) bằng root view thật.
6. Build đầu tiên trên GitHub Actions: sửa lỗi biên dịch theo log (xem mục 7, 9, 10 + các điểm dễ lỗi mới: `sync { }` đa câu lệnh trả `Bool` trong AppRuntime, lớp `Op` lồng `private` trong WatchfaceManager).

## 12. Ghi chú Phần 8 (dành cho Phần 9: sửa lỗi build + hoàn thiện)
**Đã làm:** `App/WatchViewModel.swift`, `Views/{RootView,DeviceView,FacesView,LogsView,SettingsView,HuaweiIdWebView}.swift`, thay `WristMirrorApp.swift` (root view thật, `@StateObject WatchViewModel`).
- ViewModel giữ nguyên các rào an toàn của Kotlin: prompt xác nhận có token (`confirmAction`), chụp thẻ (`RowTarget`: id/version/type/expandType + epoch + formRevision + operationRevision) rồi `currentRow` kiểm tra lại trước khi gửi; xoá dùng `prepareDeletion` (cần danh sách mới) rồi mới hiện prompt; thay thế `VersionPolicy.next` +1.
- Lịch sử đồng hồ (`history.remember/rememberModel/rememberSerial`) ghi trong `syncSuccessfulHistory` khi READY.
- Bước `AGREEMENT_CONFIRM` tự bỏ qua (`respondAgreements(accept:false)`) như Android.
- UI chọn file: `prepareHwtPick()` → `.fileImporter` → `importHwt(url)` (security-scoped + `HwtSource.load/freeze/verify` trên `ioQueue`). Nếu người dùng đóng bộ chọn không chọn gì, `FacesView` thu hồi token sau 0,5 giây.
- Huawei ID: nhập tay hoặc "Lấy từ tài khoản…" (WKWebView `nonPersistent`, chỉ https vmall.com/huawei.com, đọc đúng cookie `uid` hợp lệ & nhất quán, điền vào ô nhập — người dùng vẫn phải bấm **Lưu**).
- **Cố ý bỏ/rút gọn so với Android:** màn giới thiệu lần đầu, kiểm tra cập nhật, huỷ ghép nối hệ thống, lịch sử thao tác nhiều cửa sổ (HistoryDeviceWindow/HistoryOperationSheet), CardExpansionScroll, đồng hồ/ảnh preview nâng cao (`HwtPreview` chỉ hiện ảnh preview nếu có), `autoConnect` mới lưu cờ (chưa tự kết nối khi mở app — cần `takeStartupDevice` như Kotlin).
- Việc còn lại gợi ý: (1) build Actions & sửa lỗi; (2) thử BLE thật (FE86/FE01/FE02, có cần ghép nối hệ thống không); (3) tự kết nối khi mở app; (4) icon/AppIcon; (5) XCTest cho FrameCodec/HuaweiCrypto/ZipArchive.
- Điểm dễ lỗi biên dịch ở Phần 8: `@Published private(set) var ui` bị sửa từng trường (ổn), closure `() throws -> Void` có `[weak self]` trong `prompt(...)`, `try` trong đối số `Pick(...)`, `alert(_:isPresented:presenting:actions:message:)`, `onChange(of:)` dạng 1 tham số (iOS 16).

## Cập nhật: đồng bộ bố cục/luồng với Android (vòng sửa sau lần thử máy thật đầu tiên)
- Đối chiếu `WatchConnection.java` ↔ `.swift`: trình tự giai đoạn và lệnh gửi (LINK_PARAMS → DEVICE_STATUS → SECURITY → ISO/LITE → … → READY, các initRequest) trùng khớp; chỉ khác bước SYSTEM_PAIRING (chỉ Android/RFCOMM).
- `GattChannel`: kích thước mỗi lần ghi giới hạn theo ATT MTU−3 (iOS báo 512 cho `.withResponse` → ghi dài làm hỏng gói ISO 539 byte).
- `WatchConnection.tick`: ISO_AUTH timeout với khoá đã lưu (op2) → hiện hộp thoại "liên kết lại" thay vì báo lỗi.
- Tự kết nối khi mở app (`takeStartupDevice`/`connectAtStartup`, một cơ hội mỗi lần chạy như `StartupConnectionOpportunity`), màn giới thiệu lần đầu (`IntroductionView`, cờ `wm.introduction-acknowledged`).
- Giao diện 4 tab như Android: Trang chủ (HomeView) / Thiết bị (DeviceView: thẻ đồng hồ, lịch sử, Thêm thiết bị, thao tác lịch sử, cấu hình Huawei ID) / Mặt đồng hồ (thẻ mở rộng) / Cài đặt (tự kết nối, chủ đề, Nhật ký, Giới thiệu).
- Chưa làm: kiểm tra cập nhật (không áp dụng cho IPA), BLE state restoration, huỷ ghép nối hệ thống & RFCOMM (iOS không hỗ trợ).

## Cập nhật: đối chiếu Bluetooth với Huawei Health iOS 17.0.104 (IPA) và bản vá BLE
Đối chiếu binary Huawei (Info.plist + chuỗi): cùng service FE86/FE01/FE02; Huawei có thêm restore state (4 lớp quản lý BLE),
ANCS (`RequiresANCS`), `connectionEventDidOccur`, fastConnect/connectDeviceRetry, EA protocol `com.huawei.smartband` (MFi, bỏ qua).
Đã thêm vào WristMirror:
- `GattChannel`: `CBCentralManager` có `RestoreIdentifierKey` (`GattChannel.restoreIdentifier`) + `willRestoreState`; `resume(_:)` xử lý ngoại vi đã connected/connecting/disconnected;
  `registerForConnectionEvents` + `connectionEventDidOccur`; connect options NotifyOnConnection/Disconnection; `RequiresANCS` chỉ khi UserDefaults `wm.requires-ancs` = true
  (công tắc trong SettingsView, mặc định tắt); `close()` nhả central để kênh sau dùng lại restore id. Scanner KHÔNG dùng restore id.
- `AppRuntime.scheduleReconnect`: khi `GATT_CONNECTION_CLOSED` + bật "Tự kết nối" → thử nối lại 2/4/8/16/30 s (reset khi READY; bỏ qua nếu epoch đổi/đang xoá thiết bị).
- Khôi phục trạng thái chỉ hữu ích khi bật "Tự kết nối khi mở app" (channel chỉ được tạo lúc kết nối).
- Chưa biên dịch, chưa thử máy thật. Cần test: tắt/bật BT đồng hồ (tự nối lại), vuốt tắt app rồi đưa đồng hồ lại gần (restore), bật ANCS có làm hỏng ISO auth không.

## Cập nhật: chạy nền + thông báo + nút mở Cài đặt
- `App/BackgroundSupport.swift` (mới): `observe(operating:failed:ready:)` gọi từ `AppRuntime.publish` — `beginBackgroundTask` khi thao tác (thay/xoá/kích hoạt mặt đồng hồ) bắt đầu, kết thúc khi xong; thông báo cục bộ khi app ở nền (thao tác kết thúc/thất bại, mất kết nối — `linkLost` gọi từ `AppRuntime.onClosed`, tối đa 1/phút). Xin quyền thông báo lần đầu khi kết nối READY. Không hiện khi app đang mở.
- `DeviceView`: khi lỗi quyền Bluetooth/Bluetooth tắt, hiện nút "Mở Cài đặt".
- Lưu ý: nền ~30 s cho beginBackgroundTask; việc app còn chạy khi khoá màn hình chủ yếu nhờ `bluetooth-central` khi đang nhận/ghi BLE. Cần thử truyền file thật với màn hình khoá.
- Thông báo "kết thúc" có thể hiện cả khi người dùng huỷ thao tác (chưa phân biệt huỷ/thành công).

## Cập nhật: AppIcon
- `WristMirror/Assets.xcassets/AppIcon.appiconset` (1 ảnh 1024×1024 RGB không alpha, kiểu "single size" cần Xcode 14+); `project.yml` thêm `ASSETCATALOG_COMPILER_APPICON_NAME: AppIcon`. XcodeGen tự gom Assets.xcassets vì nằm trong `sources: [WristMirror]`.

## Sửa lỗi build (GitHub Actions, Xcode 16.4)
- `GattChannel.connectionEventDidOccur`: `CBConnectionEvent.peripheralConnected` không có trong Swift → so sánh `event.rawValue != 1` (1 = connected). Đây là lỗi biên dịch duy nhất ở lần build đầu có log (các phần Swift khác biên dịch được tới bước này; có thể còn lỗi lộ ra sau khi sửa).

## Giấy phép / ghi công (đã làm)
- `NOTICE`, `THIRD_PARTY_NOTICES.md` (bản iOS), `LICENSE` (thêm dòng "Modifications ... Quốc Đại (quocdaicm)"), bản thông báo Android gốc lưu ở `docs/UPSTREAM_THIRD_PARTY_NOTICES_ANDROID.md`.
- Mọi file Swift có header ghi nguồn gốc (Escosis/WristMirror, Apache-2.0) + việc sửa đổi; `BackgroundSupport.swift` chỉ ghi bản quyền riêng. Màn "Giới thiệu > Giấy phép và ghi công" (`LicensesView`) hiển thị trong app.
- Chưa có zip WristMirror gốc trong tay để kiểm tra có file NOTICE của upstream không; nếu có, chép nội dung vào `NOTICE`.

## Cập nhật: nâng cấp giao diện
- `Views/Theme.swift` (mới): `Theme` (màu accent, gradient), `AppBackground`, `.card()`, `HeroCard`, `PrimaryButtonStyle`/`SecondaryButtonStyle(color:)` (có `init` tường minh vì thuộc tính `@Environment` private), `StatusPill`, `BatteryRing`, `WatchGlyph`, `InfoRow`.
- `HomeView`: thẻ hero gradient (tên, trạng thái, vòng pin) + thẻ thông tin thiết bị (chạm để sao chép) + chân trang ghi công. `FacesView`: List → ScrollView/LazyVStack gồm thẻ file HWT, nút (Chọn file HWT dạng nút chính), thẻ mặt đồng hồ (viền accent + nhãn "Đang dùng", nút Thay thế/Bật/Xoá). `DeviceView`/`SettingsView`/`AboutView`/sheet: nền `AppBackground` + `scrollContentBackground(.hidden)`; hero ở đầu DeviceView và AboutView (ghi công tác giả bản iOS ngay đầu). `IntroductionView`: thẻ + nút chính.
- Không đổi logic ViewModel; chỉ đổi phần trình bày. Mọi API dùng được trên iOS 16.
- Chưa biên dịch bản này; điểm dễ lỗi: `ForEach(Array(rows.enumerated()), id: \.offset) { index, row in }` trong HomeView, `.listRowBackground(Theme.gradient)`, `if vm.ui.connected, let b = ...` trong ViewBuilder.

## Cập nhật: giao diện mới + đổi tên "Huawei watch face"
- `Views/Theme.swift` viết lại: `AppBackground` (nền vector gradient + quầng sáng + 2 mặt số mờ, tự đổi sáng/tối), `WatchMark`/`BrandLogo`/`WatchGlyph` (logo vector bằng Canvas), `GlassBackground`/`card()`/`glassRows()` (thẻ kính mờ), `HeroCard`, `PrimaryButtonStyle`/`SecondaryButtonStyle`, `IconBadge`, `BrandHeader`.
- `DeviceView` chuyển từ List sang ScrollView + thẻ (hero, nút thao tác, lịch sử, thêm thiết bị); các sheet vẫn là List/Form nhưng nền kính mờ.
- Thêm `design/*.svg` (nguồn), AppIcon mới, `LaunchLogo` + `LaunchBackground` cho màn khởi động (`UILaunchScreen` trong project.yml).
- Đổi tên hiển thị: `CFBundleDisplayName`, mô tả quyền Bluetooth, chuỗi trong app, tên IPA/artifact trong workflow. Giữ nguyên bundle id và tên target để không phá build/khoá Keychain.
- CHƯA biên dịch bản UI mới (không có Xcode ở môi trường sửa): nếu build lỗi, xem log ở `Views/Theme.swift` và các view trên trước.

## Cập nhật: màn "Thông báo & giờ" + đồng bộ giờ thủ công
- `Views/NotificationsView.swift` (mới, mở từ Cài đặt): công tắc ANCS (khoá `wm.requires-ancs`, như trước), các bước thiết lập, nút "Đồng bộ giờ ngay".
- `WatchConnection.syncTime()` gửi lại lệnh 01/05 (cùng lệnh lúc khởi tạo) và cho phép nhận phản hồi 01/05 qua `auxiliaryPending`; `WatchViewModel.syncWatchTime()` gọi hàm này (chỉ khi READY, không quarantine, không đang thao tác).
- Thông báo tin nhắn/cuộc gọi do iOS gửi qua ANCS, app không đọc nội dung. CHƯA kiểm chứng ANCS với GT 6 Pro; chưa biên dịch.
- Chưa làm (thiếu mã lệnh giao thức, cần nguồn Android/Gadgetbridge + thử máy thật): tìm đồng hồ, báo thức, đẩy lịch.

## Cập nhật: Phần A – unit test
- `WristMirrorTests/ProtocolTests.swift`: test FrameCodec (CRC16, khung đơn/chia lát, nhận từng byte, CRC hỏng, resync), HuaweiCrypto (SHA256, HMAC, HKDF RFC 5869, AES-GCM IV 16 byte/12 byte, AAD, tag hỏng, CBC), ZipArchive (deflate/stored, CRC, giới hạn kích thước, file rác).
- Test vector sinh độc lập bằng Python (hashlib/hmac/cryptography/zlib), không lấy từ Swift.
- `project.yml` thêm target `WristMirrorTests` + scheme `WristMirror` (build.yml giữ nguyên). Chạy test: GitHub → Actions → "Unit tests" → Run workflow; log ở artifact `test-log`.
- Chưa chạy được trên Xcode (môi trường sửa không có swiftc). Nếu test đỏ: xem log để biết là test sai hay code Swift sai — vector là chuẩn nên đỏ ở GCM/HKDF/CBC nhiều khả năng là bug thật.

## Cập nhật: Phần B – Thư viện mặt đồng hồ
- `Store/HwtLibrary.swift` (mới): lưu bản sao file .hwt + ảnh xem trước trong Application Support/hwt-library/<id>/ (`face.hwt`, `preview.image`) + `index.json`. Chống trùng theo SHA-256 file gốc (`HwtSource.sourceHash`), tối đa 200 mục, tên tối đa 60 ký tự. Không bị `clearCache` xoá (khác `local-hwt`).
- Tự lưu: `WatchViewModel.importHwt` gọi `library.add(...)` trên `ioQueue` sau khi `payload.verify()` thành công. Dùng lại: `useFromLibrary(item)` → `importHwt(url, displayName:)` (đi qua đúng luồng nạp/đóng băng/kiểm tra cũ).
- `Views/LibraryView.swift` (mới): `LibrarySection` (lưới thẻ có ảnh preview, đặt trong `FacesView` giữa nút thao tác và danh sách mặt đồng hồ), `LibraryDetailView` (xem ảnh lớn, đổi tên, Dùng file này, Chia sẻ qua `ShareLink`, Xoá có xác nhận), `ThumbnailView` (thu nhỏ bằng ImageIO, không nạp ảnh gốc).
- Test: `WristMirrorTests/LibraryTests.swift`.
- Chưa biên dịch. Điểm dễ lỗi: `.task(id: url)` với `URL?`, `Task.detached{}.value` trả `UIImage?`, `sheet(item:)` cần `HwtLibraryItem: Identifiable`, `Date.formatted`.

## Cập nhật: Phần C – Lịch nhắc đổi mặt đồng hồ
- **Là lịch NHẮC, không tự thay mặt đồng hồ**: iOS không cho app chạy nền đúng giờ, và thay/xoá mặt đồng hồ luôn cần người dùng xác nhận (rào an toàn của Android được giữ nguyên). Đến giờ → thông báo cục bộ → chạm vào → app chuyển sang tab Mặt đồng hồ và nạp sẵn file HWT (`openScheduled` → `useFromLibrary`); người dùng tự mở thẻ mặt đồng hồ đích và bấm Thay thế.
- `Store/FaceSchedule.swift` (mới): `ScheduleEntry` (itemId, giờ, phút, thứ 1–7 theo Calendar, bật/tắt), `FaceSchedule` (lưu UserDefaults `wm.face-schedule`, tối đa 8 lịch × 7 ngày = 56 thông báo < 64 của iOS, `requests(for:nameFor:)` tạo `UNCalendarNotificationTrigger` lặp hàng tuần, id `wm.schedule.<entry>.<thứ>`), `ScheduleNotificationRouter` (UNUserNotificationCenterDelegate: nhận chạm thông báo, nhớ lại nếu app chưa sẵn sàng, hiện banner khi app đang mở).
- Lịch trỏ tới mục thư viện đã xoá thì không đặt thông báo (UI cảnh báo cam). `HwtLibrary.onChange` → `schedule.resync()` để tên trong thông báo luôn đúng.
- `Views/ScheduleView.swift` (mới): danh sách lịch, bật/tắt, thêm/sửa/xoá; mở từ nút "Lịch nhắc" ở mục Thư viện (tab Mặt đồng hồ). Quyền thông báo xin khi lưu lịch/bật công tắc; nếu bị từ chối có nút "Mở Cài đặt".
- `WristMirrorApp.init` gán delegate thông báo; `RootView.onAppear` gán handler chuyển tab.
- Test: `WristMirrorTests/ScheduleTests.swift`.
- Chưa biên dịch/chưa thử máy thật. Cần thử: chạm thông báo khi app đã tắt hẳn (mở nguội) có chuyển tab và nạp file không; đổi múi giờ.
- Lưu ý riêng tư: nội dung thông báo lịch có TÊN do người dùng tự đặt cho mặt đồng hồ (khác thông báo cũ trong BackgroundSupport vốn không chứa tên).

## Cập nhật: Phần D – Màn xem thông tin file HWT (chỉ đọc)
- `Protocol/HwtInspector.swift` (mới): đọc file .hwt (ZIP ngoài → `description.xml` + `com.huawei.watchface` → ZIP trong: `watchface.bin`, `watchface/watch_face_config.xml`, `watchface/res/*.png`) và trả `HwtReport` (tên/tác giả/mã màn hình/phiên bản, có `watchface.bin` không + dung lượng, số lớp, kiểu chữ gom theo màu+cỡ, danh sách ảnh với kích thước PNG đọc từ IHDR, kích thước ảnh nền, cảnh báo). Có giới hạn: config ≤ 1 MB, ≤ 400 ảnh, mỗi ảnh ≤ 4 MB, tổng ≤ 48 MB; XMLParser không giải thực thể ngoài.
- `Views/HwtInfoView.swift` (mới): mở từ `LibraryDetailView` ("Xem thông tin file"). KHÔNG có chức năng sửa.
- **Vì sao không có màn sửa:** đồng hồ chỉ đọc `watchface.bin` (đã biên dịch, định dạng Huawei không công khai). Sửa PNG/XML nguồn không đổi mặt đồng hồ thật; `hashCode` còn chứa SHA-256 của 3 file ngoài. Thử tìm màu chữ `#FFFFF7D9` trong bin: không có trường màu riêng, byte tương ứng (D9F7FFFF) xuất hiện >1000 lần (nhiều khả năng là điểm ảnh) ⇒ vá trực tiếp là không an toàn.
- Mặt đồng hồ mẫu `p0228Long_5.hwt` (HWHD09, 466×466): bin 1.657.718 byte, 89 ảnh, 33 lớp, 3 loại chữ cùng màu #FFFFF7D9 (cỡ 20 ×4, cỡ 26 ×1).
- Test: `WristMirrorTests/InspectorTests.swift` (dùng nguyên `watch_face_config.xml` thật; kỳ vọng tính bằng Python). Chưa biên dịch; điểm dễ lỗi: tên lồng `HwtReport.Image` vs SwiftUI `Image`, raw string `#"""` trong test.

## Cập nhật: Phần E – Tạo mặt đồng hồ mới (Studio)
- **Định dạng `watchface.bin` đã giải mã được** (đối chiếu từ Light_Speed.hwt, Donen.hwt và GalaxyWatchUltra.hwt; bản tham chiếu Python dựng lại đúng từng byte `watchface.bin` của Light_Speed và Donen từ `watch_face_config.xml` + PNG):
  - Header 16 byte: `u16 = 2`, `u16 độ dài bố cục`, `u32 độ dài bảng`, `u32 độ dài phần sau bảng`, `u32 = 0`; rồi bố cục (protobuf), bảng `(offset, size)` 8 byte/ảnh, 8 byte `55 55 55 55 01 00 00 01`, rồi các bản ghi ảnh nối nhau.
  - Bố cục protobuf: field 1 = phần tử (index, 0, 0, "", các lớp field 5); lớp ảnh tĩnh `type=1` (field 4: tên "NNN", vị trí, ambient, 0); lớp kim `type=5` (field 8: tên, rect, điểm xoay, 0, 360, value_type 150/153/154 = giờ/phút/giây, ambient); field 2 = title, field 3 = title-cn (UTF-8).
  - Ảnh: `45 23 88 88` + rộng/cao u16 + luồng từ 32-bit LE (ARGB không nhân trước alpha): điểm ảnh rời và đoạn lặp `[0x23456789][điểm ảnh][số lần]` khi lặp từ 4 lần. Kiểu GalaxyWatchUltra: file `com.huawei.watchface` chính là `watchface.bin` trần (54 ảnh) và không có `hashCode`.
  - `hashCode` = SHA-256 (hex in hoa) của `description.xml`, `com.huawei.watchface`, `ability.xml`, rồi một hằng số giống hệt ở mọi file mẫu.
- `Protocol/HwtBuilder.swift` (mới): RLE mã hoá/giải mã, ghi protobuf, ghi ZIP (stored), dựng `.hwt` hoàn chỉnh + tự kiểm tra giải mã lại từng ảnh.
- `Store/FaceDesign.swift` (mới): mô hình thiết kế (nền màu/chuyển sắc/ảnh, vạch giờ, 3 kiểu kim, màu từng kim, AOD) + bộ vẽ CoreGraphics + `FaceBuilder.build`.
- `Views/StudioView.swift` (mới): nút "Tạo mặt đồng hồ mới" ở tab Mặt đồng hồ. Tạo xong file được nạp qua `vm.importHwt` nên vào Thư viện như mọi file HWT.
- Test: `WristMirrorTests/BuilderTests.swift` (bố cục so với bin thật; RLE; ZIP; gói HWT đọc lại bằng `HwtInspector`).
- **Chưa biên dịch, chưa thử trên đồng hồ thật.** Cần thử: (1) build/test trên GitHub Actions; (2) gửi một mặt đồng hồ tạo ra lên đồng hồ xem có hiển thị, kim chạy đúng, AOD đúng không; (3) ZIP ngoài ghi dạng "stored" (không nén) khác file gốc (deflate) – nếu đồng hồ/ứng dụng chê thì thêm nén.
- Phạm vi hiện tại: chỉ mặt đồng hồ kim (analog) màn 466×466. Chưa có ô dữ liệu (nhịp tim, bước chân, pin, ngày giờ số) – cần giải mã thêm kiểu lớp `text` / `selected_res` từ file mẫu có widget.
