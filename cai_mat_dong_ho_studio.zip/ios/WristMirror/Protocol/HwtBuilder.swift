// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import CryptoKit

// MARK: - Ảnh điểm ảnh

/// Ảnh ARGB (mỗi điểm ảnh 1 từ 32-bit: A<<24 | R<<16 | G<<8 | B), alpha KHÔNG nhân trước.
struct HwtRaster: Equatable {
    let width: Int
    let height: Int
    var argb: [UInt32]

    init(width: Int, height: Int, argb: [UInt32]) {
        self.width = width
        self.height = height
        self.argb = argb
    }

    init(width: Int, height: Int, fill: UInt32 = 0) {
        self.init(width: width, height: height, argb: [UInt32](repeating: fill, count: width * height))
    }
}

// MARK: - Mã hoá ảnh trong watchface.bin (RLE)

/// Định dạng ảnh trong `watchface.bin` (đã giải mã ngược từ các file HWT thật, khớp từng byte):
/// `45 23 88 88` + rộng(u16) + cao(u16), sau đó là dòng từ 32-bit little-endian:
/// các điểm ảnh rời (literal) và các đoạn `[0x23456789][điểm ảnh lặp][số lần lặp]` (chỉ dùng khi lặp từ 4 lần trở lên).
enum HwtRLE {
    static let marker: UInt32 = 0x2345_6789
    static let minRun = 4
    static let magic: [UInt8] = [0x45, 0x23, 0x88, 0x88]

    /// Điểm ảnh trùng đúng giá trị dấu hiệu sẽ làm hỏng luồng; đổi bit thấp của kênh xanh (không nhìn thấy được).
    static func sanitize(_ img: HwtRaster) -> HwtRaster {
        guard img.argb.contains(marker) else { return img }
        return HwtRaster(width: img.width, height: img.height, argb: img.argb.map { $0 == marker ? ($0 ^ 1) : $0 })
    }

    static func encode(_ source: HwtRaster) -> [UInt8] {
        let img = sanitize(source)
        let px = img.argb
        let n = px.count
        var words = [UInt32]()
        words.reserveCapacity(n / 2 + 16)

        func runLength(_ at: Int) -> Int {
            let v = px[at]
            var j = at + 1
            while j < n && px[j] == v { j += 1 }
            return j - at
        }

        var i = 0
        while i < n {
            let r = runLength(i)
            if r >= minRun {
                words.append(marker); words.append(px[i]); words.append(UInt32(r))
                i += r
            } else if !words.isEmpty {
                words.append(marker); words.append(0); words.append(0)
            }
            while i < n {
                if runLength(i) >= minRun { break }
                words.append(px[i]); i += 1
            }
        }

        var out = [UInt8]()
        out.reserveCapacity(8 + words.count * 4)
        out.append(contentsOf: magic)
        out.append(UInt8(img.width & 0xff)); out.append(UInt8((img.width >> 8) & 0xff))
        out.append(UInt8(img.height & 0xff)); out.append(UInt8((img.height >> 8) & 0xff))
        for w in words {
            out.append(UInt8(w & 0xff)); out.append(UInt8((w >> 8) & 0xff))
            out.append(UInt8((w >> 16) & 0xff)); out.append(UInt8((w >> 24) & 0xff))
        }
        return out
    }

    /// Giải mã một bản ghi (dùng để tự kiểm tra và cho test).
    static func decode(_ b: [UInt8]) throws -> HwtRaster {
        guard b.count >= 8, Array(b[0..<4]) == magic else { throw WMFault("RLE_MAGIC") }
        let w = Int(b[4]) | (Int(b[5]) << 8)
        let h = Int(b[6]) | (Int(b[7]) << 8)
        guard w > 0, h > 0, (b.count - 8) % 4 == 0 else { throw WMFault("RLE_HEADER") }
        let count = (b.count - 8) / 4
        func word(_ k: Int) -> UInt32 {
            let o = 8 + k * 4
            return UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
        }
        var out = [UInt32]()
        out.reserveCapacity(w * h)
        var i = 0
        while i < count && word(i) != marker { out.append(word(i)); i += 1 }
        while i < count {
            guard word(i) == marker, i + 2 < count else { throw WMFault("RLE_STREAM") }
            let run = word(i + 1)
            let cnt = Int(word(i + 2))
            guard cnt >= 0, out.count + cnt <= w * h else { throw WMFault("RLE_OVERFLOW") }
            if cnt > 0 { out.append(contentsOf: [UInt32](repeating: run, count: cnt)) }
            i += 3
            while i < count && word(i) != marker { out.append(word(i)); i += 1 }
        }
        guard out.count == w * h else { throw WMFault("RLE_PIXEL_COUNT") }
        return HwtRaster(width: w, height: h, argb: out)
    }
}

// MARK: - Mô tả mặt đồng hồ (bố cục)

struct HwtRect: Equatable {
    var x: Int, y: Int, w: Int, h: Int
}

enum HwtValueType {
    static let hour = 150
    static let minute = 153
    static let second = 154
}

/// Một lớp trong mặt đồng hồ. `resource` là số của ảnh `A100_NNN.png` (bắt đầu từ 1).
enum HwtLayer: Equatable {
    /// Ảnh tĩnh đặt tại (x, y).
    case single(resource: Int, x: Int, y: Int, ambient: Bool)
    /// Kim quay quanh `pivot` (toạ độ trong ảnh kim) đặt tại tâm của `rect`.
    case hand(resource: Int, rect: HwtRect, pivotX: Int, pivotY: Int, valueType: Int, ambient: Bool)
}

struct HwtFaceSpec {
    var title: String
    var titleCN: String
    var author: String
    var version: String = "1.0.0"
    /// Phần tử 0 = "background", phần tử 1 = "time".
    var elements: [[HwtLayer]]
    /// Ảnh theo thứ tự A100_001, A100_002, …
    var images: [HwtRaster]

    static let elementLabels = ["background", "time"]
}

// MARK: - Ghi protobuf tối giản

struct HwtProto {
    private(set) var bytes = [UInt8]()

    static func varint(_ value: Int) -> [UInt8] {
        var n = UInt64(max(0, value))
        var out = [UInt8]()
        while true {
            let c = UInt8(n & 0x7f)
            n >>= 7
            if n != 0 { out.append(c | 0x80) } else { out.append(c); return out }
        }
    }

    mutating func int(_ field: Int, _ value: Int) {
        bytes += HwtProto.varint(field << 3)
        bytes += HwtProto.varint(value)
    }

    mutating func data(_ field: Int, _ payload: [UInt8]) {
        bytes += HwtProto.varint((field << 3) | 2)
        bytes += HwtProto.varint(payload.count)
        bytes += payload
    }

    mutating func string(_ field: Int, _ s: String) { data(field, Array(s.utf8)) }

    mutating func message(_ field: Int, _ build: (inout HwtProto) -> Void) {
        var m = HwtProto()
        build(&m)
        data(field, m.bytes)
    }
}

// MARK: - ZIP (stored) ghi file

/// Bộ ghi ZIP tối thiểu: chỉ "stored" (không nén), không ZIP64. Đủ cho gói HWT (vài MB).
struct HwtZipWriter {
    private var out = [UInt8]()
    private var central = [UInt8]()
    private var count = 0

    private static func le16(_ v: Int) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff)] }
    private static func le32(_ v: UInt32) -> [UInt8] {
        [UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)]
    }

    private static func dosDateTime(_ date: Date) -> (time: Int, date: Int) {
        let c = Calendar(identifier: .gregorian).dateComponents(in: TimeZone(secondsFromGMT: 0)!, from: date)
        let year = max(1980, min(2107, c.year ?? 2026))
        let t = ((c.hour ?? 0) << 11) | ((c.minute ?? 0) << 5) | ((c.second ?? 0) / 2)
        let d = ((year - 1980) << 9) | ((c.month ?? 1) << 5) | (c.day ?? 1)
        return (t, d)
    }

    mutating func addDirectory(_ name: String, date: Date = Date()) {
        append(name: name.hasSuffix("/") ? name : name + "/", data: [], isDirectory: true, date: date)
    }

    mutating func add(name: String, data: [UInt8], date: Date = Date()) {
        append(name: name, data: data, isDirectory: false, date: date)
    }

    private mutating func append(name: String, data: [UInt8], isDirectory: Bool, date: Date) {
        let nameBytes = Array(name.utf8)
        var crc = CRC32()
        crc.update(data)
        let checksum = crc.checksum
        let size = UInt32(truncatingIfNeeded: data.count)
        let offset = UInt32(truncatingIfNeeded: out.count)
        let stamp = HwtZipWriter.dosDateTime(date)

        out += HwtZipWriter.le32(0x0403_4b50)
        out += HwtZipWriter.le16(10)
        out += HwtZipWriter.le16(0x0800)
        out += HwtZipWriter.le16(0)
        out += HwtZipWriter.le16(stamp.time)
        out += HwtZipWriter.le16(stamp.date)
        out += HwtZipWriter.le32(checksum)
        out += HwtZipWriter.le32(size)
        out += HwtZipWriter.le32(size)
        out += HwtZipWriter.le16(nameBytes.count)
        out += HwtZipWriter.le16(0)
        out += nameBytes
        out += data

        central += HwtZipWriter.le32(0x0201_4b50)
        central += HwtZipWriter.le16(20)
        central += HwtZipWriter.le16(10)
        central += HwtZipWriter.le16(0x0800)
        central += HwtZipWriter.le16(0)
        central += HwtZipWriter.le16(stamp.time)
        central += HwtZipWriter.le16(stamp.date)
        central += HwtZipWriter.le32(checksum)
        central += HwtZipWriter.le32(size)
        central += HwtZipWriter.le32(size)
        central += HwtZipWriter.le16(nameBytes.count)
        central += HwtZipWriter.le16(0)
        central += HwtZipWriter.le16(0)
        central += HwtZipWriter.le16(0)
        central += HwtZipWriter.le16(0)
        central += HwtZipWriter.le32(isDirectory ? 0x10 : 0)
        central += HwtZipWriter.le32(offset)
        central += nameBytes
        count += 1
    }

    func finish() -> [UInt8] {
        var result = out
        let centralOffset = UInt32(truncatingIfNeeded: result.count)
        result += central
        result += HwtZipWriter.le32(0x0605_4b50)
        result += HwtZipWriter.le16(0)
        result += HwtZipWriter.le16(0)
        result += HwtZipWriter.le16(count)
        result += HwtZipWriter.le16(count)
        result += HwtZipWriter.le32(UInt32(truncatingIfNeeded: central.count))
        result += HwtZipWriter.le32(centralOffset)
        result += HwtZipWriter.le16(0)
        return result
    }
}

// MARK: - Biên dịch + đóng gói HWT

enum HwtBuilder {
    static let maxImages = 200
    static let maxDimension = 1000

    /// `ability.xml` của các file HWT mẫu (đồng hồ HWHD09): giữ nguyên từng ký tự.
    static let abilityXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n        <attribute>\n            <dataType>00000000000000000000000000000000,00000000000000000000000000000000,0000000000000000000000</dataType>\n            <valueType>00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000001001100000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,00000000000000000000000000000000,0000</valueType>\n            <xmlType>00001001000000000000000000000000,00</xmlType>\n        </attribute>"

    /// Giá trị thứ 4 trong `hashCode` giống hệt ở mọi file HWT mẫu (không phụ thuộc nội dung).
    static let constantHash = "A75D19EA7A43F155C52B564310E34E463A05BC2CC110326121290C645829106D"

    static func resourceName(_ n: Int) -> String { String(format: "A100_%03d.png", n) }

    // MARK: Bố cục (protobuf)

    static func layoutBytes(_ spec: HwtFaceSpec) -> [UInt8] {
        var root = HwtProto()
        for (ei, layers) in spec.elements.enumerated() {
            root.message(1) { el in
                el.int(1, ei); el.int(2, 0); el.int(3, 0); el.string(4, "")
                for (li, layer) in layers.enumerated() {
                    el.message(5) { l in
                        l.int(1, li)
                        switch layer {
                        case let .single(resource, x, y, ambient):
                            l.int(2, 1)
                            l.message(4) { p in
                                p.string(1, String(format: "%03d", resource))
                                p.message(2) { q in q.int(1, x); q.int(2, y) }
                                p.int(5, ambient ? 1 : 0)
                                p.int(6, 0)
                            }
                        case let .hand(resource, rect, pivotX, pivotY, valueType, ambient):
                            l.int(2, 5)
                            l.message(8) { p in
                                p.string(1, String(format: "%03d", resource))
                                p.message(2) { q in q.int(1, rect.x); q.int(2, rect.y); q.int(3, rect.w); q.int(4, rect.h) }
                                p.message(3) { q in q.int(1, pivotX); q.int(2, pivotY) }
                                p.int(4, 0)
                                p.int(5, 360)
                                p.int(6, valueType)
                                p.int(9, ambient ? 1 : 0)
                            }
                        }
                    }
                }
            }
        }
        root.string(2, spec.title)
        root.string(3, spec.titleCN)
        return root.bytes
    }

    // MARK: watchface.bin

    static func binData(_ spec: HwtFaceSpec) -> [UInt8] {
        let layout = layoutBytes(spec)
        let records = spec.images.map { HwtRLE.encode($0) }
        var table = [UInt8]()
        var offset = 8
        func le32(_ v: Int) -> [UInt8] {
            [UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)]
        }
        for r in records {
            table += le32(offset); table += le32(r.count)
            offset += r.count
        }
        var post: [UInt8] = [0x55, 0x55, 0x55, 0x55, 0x01, 0x00, 0x00, 0x01]
        for r in records { post += r }
        var out = [UInt8]()
        out.reserveCapacity(16 + layout.count + table.count + post.count)
        func le16(_ v: Int) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff)] }
        out += le16(2)
        out += le16(layout.count)
        out += le32(table.count)
        out += le32(post.count)
        out += le32(0)
        out += layout
        out += table
        out += post
        return out
    }

    // MARK: XML

    static func xmlEscape(_ s: String) -> String {
        var r = ""
        for ch in s {
            switch ch {
            case "&": r += "&amp;"
            case "<": r += "&lt;"
            case ">": r += "&gt;"
            case "\"": r += "&quot;"
            case "'": r += "&apos;"
            default:
                // Bỏ ký tự điều khiển
                if let u = ch.unicodeScalars.first, u.value < 32 { r += " " } else { r.append(ch) }
            }
        }
        return r
    }

    static func configXML(_ spec: HwtFaceSpec) -> String {
        var s = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<watchface>\r\n"
        for (ei, layers) in spec.elements.enumerated() {
            let label = ei < HwtFaceSpec.elementLabels.count ? HwtFaceSpec.elementLabels[ei] : "element\(ei)"
            s += "    <element label=\"\(label)\" is_support_option=\"false\" res_preview=\"\">\r\n"
            for (li, layer) in layers.enumerated() {
                switch layer {
                case let .single(resource, x, y, ambient):
                    s += "        <layer index=\"\(li + 1)\" draw_type=\"single_res\" ambient_mode=\"\(ambient ? 1 : 0)\" res_name=\"\(resourceName(resource))\" res_position=\"\(x),\(y)\"/>\r\n"
                case let .hand(resource, r, px, py, vt, ambient):
                    s += "        <layer index=\"\(li + 1)\" draw_type=\"hand_res\" value_type=\"\(vt)\" ambient_mode=\"\(ambient ? 1 : 0)\" res_left=\"\(resourceName(resource))\" rotate_start_angel=\"0\" rotate_end_angel=\"360\" rotate_point_hand=\"\(px),\(py)\" rotate_rect=\"\(r.x),\(r.y),\(r.w),\(r.h)\"/>\r\n"
                }
            }
            s += "    </element>\r\n"
        }
        s += "</watchface>"
        return s
    }

    static func descriptionXML(_ spec: HwtFaceSpec) -> String {
        let t = xmlEscape(spec.title), cn = xmlEscape(spec.titleCN), a = xmlEscape(spec.author)
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n  <HwTheme>\n        <title>\(t)</title>\n        <title-cn>\(cn)</title-cn>\n        <author>\(a)</author>\n        <designer>\(a)</designer>\n        <screen>HWHD09</screen>\n        <version>\(xmlEscape(spec.version))</version>\n        <font>Default</font>\n        <font-cn>默认</font-cn>\n        <briefinfo></briefinfo>     \n  </HwTheme>"
    }

    // MARK: Kiểm tra

    static func validate(_ spec: HwtFaceSpec, pngs: [[UInt8]]) throws {
        guard !spec.images.isEmpty, spec.images.count <= maxImages, pngs.count == spec.images.count else {
            throw WMFault("BUILD_IMAGE_COUNT")
        }
        for img in spec.images {
            guard img.width > 0, img.height > 0, img.width <= maxDimension, img.height <= maxDimension,
                  img.argb.count == img.width * img.height else { throw WMFault("BUILD_IMAGE_SIZE") }
        }
        for layers in spec.elements {
            for layer in layers {
                switch layer {
                case let .single(r, _, _, _):
                    guard r >= 1, r <= spec.images.count else { throw WMFault("BUILD_RESOURCE_REF") }
                case let .hand(r, rect, px, py, _, _):
                    guard r >= 1, r <= spec.images.count else { throw WMFault("BUILD_RESOURCE_REF") }
                    guard rect.x >= 0, rect.y >= 0, rect.w > 0, rect.h > 0, px >= 0, py >= 0 else { throw WMFault("BUILD_HAND_GEOMETRY") }
                }
            }
        }
        guard !spec.title.isEmpty, spec.title.utf8.count <= 120, spec.titleCN.utf8.count <= 120 else {
            throw WMFault("BUILD_TITLE")
        }
    }

    // MARK: Đóng gói .hwt

    /// Ảnh xem trước (JPEG) cho gói HWT.
    struct Previews {
        var cover: [UInt8]
        var aod: [UInt8]
        var icon: [UInt8]
    }

    /// Dựng nguyên một file `.hwt` (ZIP ngoài chứa `com.huawei.watchface` là ZIP trong chứa `watchface.bin`).
    /// `pngs[i]` là PNG của ảnh `A100_(i+1).png`, phải khớp với `spec.images[i]`.
    static func build(spec: HwtFaceSpec, pngs: [[UInt8]], previews: Previews, date: Date = Date()) throws -> [UInt8] {
        try validate(spec, pngs: pngs)

        let bin = binData(spec)
        // Tự kiểm tra: giải mã lại từng ảnh trong bin phải trùng ảnh đầu vào (chặn lỗi mã hoá âm thầm).
        for img in spec.images {
            let rec = HwtRLE.encode(img)
            guard let back = try? HwtRLE.decode(rec), back == HwtRLE.sanitize(img) else { throw WMFault("BUILD_SELF_CHECK") }
        }

        var inner = HwtZipWriter()
        inner.addDirectory("watchface/", date: date)
        inner.addDirectory("watchface/res/", date: date)
        for (i, png) in pngs.enumerated() {
            inner.add(name: "watchface/res/" + resourceName(i + 1), data: png, date: date)
        }
        let description = Array(descriptionXML(spec).utf8)
        inner.add(name: "watchface/watch_face_config.xml", data: Array(configXML(spec).utf8), date: date)
        inner.add(name: "watchface/watch_face_info.xml", data: description, date: date)
        inner.add(name: "watchface.bin", data: bin, date: date)
        let innerBytes = inner.finish()

        let ability = Array(abilityXML.utf8)
        func hexUpper(_ b: [UInt8]) -> String {
            SHA256.hash(data: Data(b)).map { String(format: "%02X", $0) }.joined()
        }
        let hashCode = [hexUpper(description), hexUpper(innerBytes), hexUpper(ability), constantHash].joined(separator: ",")

        var outer = HwtZipWriter()
        outer.add(name: "ability.xml", data: ability, date: date)
        outer.add(name: "com.huawei.watchface", data: innerBytes, date: date)
        outer.add(name: "description.xml", data: description, date: date)
        outer.add(name: "hashCode", data: Array(hashCode.utf8), date: date)
        outer.addDirectory("preview/", date: date)
        outer.add(name: "preview/aod.jpg", data: previews.aod, date: date)
        outer.add(name: "preview/cover.jpg", data: previews.cover, date: date)
        outer.add(name: "preview/icon_small.jpg", data: previews.icon, date: date)
        return outer.finish()
    }
}
