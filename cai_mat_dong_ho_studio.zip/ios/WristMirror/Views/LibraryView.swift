// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import ImageIO

/// Tải ảnh thu nhỏ từ file (không nạp ảnh gốc vào bộ nhớ).
enum Thumbnail {
    static func load(url: URL, maxPixel: CGFloat) -> UIImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }
}

struct ThumbnailView: View {
    let url: URL?
    let maxPixel: CGFloat
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let image = image {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                Image(systemName: "clock").font(.largeTitle).foregroundStyle(.secondary)
            }
        }
        .task(id: url) {
            guard let u = url else { image = nil; return }
            let px = maxPixel
            image = await Task.detached(priority: .utility) { Thumbnail.load(url: u, maxPixel: px) }.value
        }
    }
}

/// Mục "Thư viện" trong tab Mặt đồng hồ.
struct LibrarySection: View {
    @EnvironmentObject var vm: WatchViewModel
    @ObservedObject var library: HwtLibrary
    @State private var selected: HwtLibraryItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Thư viện").font(.headline)
                Spacer()
                NavigationLink {
                    ScheduleView(library: library, schedule: vm.schedule)
                } label: {
                    Label("Lịch nhắc", systemImage: "bell")
                        .font(.caption.weight(.semibold))
                }
                if !library.items.isEmpty {
                    Text("\(library.items.count) mặt · \(ByteCountFormatter.string(fromByteCount: library.totalBytes, countStyle: .file))")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.leading, 4)

            if library.items.isEmpty {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Thư viện còn trống")
                    Text("Mỗi file HWT bạn chọn sẽ tự được lưu ở đây để dùng lại.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .card()
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 12)], spacing: 12) {
                    ForEach(library.items) { item in
                        Button { selected = item } label: { tile(item) }
                            .buttonStyle(.plain)
                    }
                }
            }
        }
        .sheet(item: $selected) { item in
            LibraryDetailView(library: library, itemId: item.id)
                .environmentObject(vm)
        }
    }

    private func tile(_ item: HwtLibraryItem) -> some View {
        VStack(spacing: 8) {
            ThumbnailView(url: library.previewURL(item), maxPixel: 360)
                .frame(height: 110)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            Text(item.name).font(.subheadline.weight(.semibold)).lineLimit(1)
            Text(ByteCountFormatter.string(fromByteCount: item.bytes, countStyle: .file))
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .card()
    }
}

/// Chi tiết một mục thư viện: xem ảnh lớn, đổi tên, dùng, chia sẻ, xoá.
struct LibraryDetailView: View {
    @EnvironmentObject var vm: WatchViewModel
    @ObservedObject var library: HwtLibrary
    let itemId: String
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var loaded = false
    @State private var confirmDelete = false

    private var item: HwtLibraryItem? { library.items.first { $0.id == itemId } }
    private var busy: Bool { vm.ui.operation.active || vm.ui.pickingHwt }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if let item = item {
                        ThumbnailView(url: library.previewURL(item), maxPixel: 900)
                            .frame(maxHeight: 280)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Tên").font(.footnote).foregroundStyle(.secondary)
                            TextField("Tên mặt đồng hồ", text: $name)
                                .textFieldStyle(.roundedBorder)
                                .submitLabel(.done)
                                .onSubmit { library.rename(id: itemId, to: name) }
                        }
                        .card()

                        VStack(spacing: 6) {
                            InfoRow(label: "Tên trong file", value: item.title)
                            InfoRow(label: "File gốc", value: item.fileName)
                            InfoRow(label: "Dung lượng", value: ByteCountFormatter.string(fromByteCount: item.bytes, countStyle: .file))
                            InfoRow(label: "Phiên bản file", value: item.xmlVersion.isEmpty ? "Không có" : item.xmlVersion)
                            InfoRow(label: "Ngày thêm", value: item.addedAt.formatted(date: .abbreviated, time: .shortened))
                        }
                        .card()

                        if let url = library.fileURL(item) {
                            NavigationLink {
                                HwtInfoView(url: url)
                            } label: { Label("Xem thông tin file", systemImage: "info.circle") }
                                .buttonStyle(SecondaryButtonStyle())
                        }

                        Button {
                            library.rename(id: itemId, to: name)
                            vm.useFromLibrary(item)
                            dismiss()
                        } label: { Label("Dùng file này", systemImage: "checkmark.circle") }
                            .buttonStyle(PrimaryButtonStyle())
                            .disabled(busy || library.fileURL(item) == nil)

                        HStack(spacing: 10) {
                            if let url = library.fileURL(item) {
                                ShareLink(item: url) { Label("Chia sẻ", systemImage: "square.and.arrow.up") }
                                    .buttonStyle(SecondaryButtonStyle())
                            }
                            Button { confirmDelete = true } label: { Label("Xoá", systemImage: "trash") }
                                .buttonStyle(SecondaryButtonStyle(color: Color.red))
                        }
                    } else {
                        Text("Mục này đã bị xoá.").foregroundStyle(.secondary).card()
                    }
                }
                .padding(16)
            }
            .background(AppBackground())
            .navigationTitle("Thư viện")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { library.rename(id: itemId, to: name); dismiss() }
                }
            }
            .confirmationDialog("Xoá khỏi thư viện?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Xoá", role: .destructive) { library.delete(id: itemId); dismiss() }
                Button("Huỷ", role: .cancel) {}
            } message: {
                Text("Chỉ xoá bản lưu trong app, không ảnh hưởng đồng hồ.")
            }
            .onAppear {
                if !loaded, let i = item { name = i.name; loaded = true }
            }
        }
    }
}
