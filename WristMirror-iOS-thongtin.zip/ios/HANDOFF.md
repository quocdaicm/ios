# HANDOFF – WristMirror iOS (đọc file này đầu tiên nếu bạn là AI/lập trình viên làm tiếp)

## 1. Mục tiêu
Viết lại app Android **WristMirror (腕镜)** (Kotlin/Java, repo gốc `WristMirror-main.zip`, giấy phép Apache-2.0)
thành app **iPhone** bằng **Swift + SwiftUI + CoreBluetooth**. App kết nối BLE tới đồng hồ Huawei (GT/FIT…),
xác thực (HiChain ISO / Lite), đọc danh sách mặt đồng hồ, rồi dùng "phương pháp thay thế" để cài
file mặt đồng hồ HWT cục bộ lên một slot mặt đồng hồ thường có sẵn (xem README gốc, mục "替换法的原理").

Người dùng dùng tài khoản Claude miễn phí (sợ hết token) nên công việc được chia thành nhiều phần,
mỗi phần giao ngay bằng một file zip. Người dùng giải nén các zip chồng lên cùng một thư mục.
Build **không cần Mac**: GitHub Actions (`.github/workflows/build.yml`) dùng XcodeGen (`project.yml`)
rồi `xcodebuild` ra IPA chưa ký (người dùng tự ký/cài bằng Sideloadly/AltStore).

## 2. Nguồn Java để port (CẦN file `WristMirror-main.zip` gốc)
Giải nén, nguồn ở: `Escosis-WristMirror-*/app/src/main/java/io/github/escosis/hwtfaceswap/`
Nếu bạn không có zip gốc, hãy yêu cầu người dùng gửi lại. KHÔNG bịa chi tiết giao thức khi chưa đọc Java.

## 3. Trạng thái port (Java → Swift)
Đường dẫn Swift: `WristMirror/…`

| Java | Swift | Trạng thái |
|---|---|---|
| protocol/FrameCodec.java | Protocol/FrameCodec.swift (+ `WMFault`) | ✅ Phần 1 |
| transport/LinkChannel.java, GattChannel.java | Transport/LinkChannel.swift, GattChannel.swift | ✅ Phần 1 (chưa thử trên thiết bị thật) |
| protocol/Core.java | Protocol/Core.swift (`WMCore`) | ✅ Phần 2 |
| protocol/TlvView.java | Protocol/TlvView.swift | ✅ Phần 2 |
| protocol/Wire.java | Protocol/Wire.swift | ✅ Phần 2 |
| protocol/DeviceInfo.java | Protocol/DeviceInfo.swift | ✅ Phần 2 |
| protocol/MiniJson.java | Protocol/MiniJson.swift (`JSONValue`, `JSONObject`) | ✅ Phần 2 |
| protocol/HuaweiCrypto.java | Protocol/HuaweiCrypto.swift + AESPrimitives.swift | ✅ Phần 3 |
| protocol/CryptoSession.java | Protocol/CryptoSession.swift | ✅ Phần 3 |
| protocol/LiteAuth.java | Protocol/LiteAuth.swift | ✅ Phần 3 |
| protocol/LinkCapabilities.java | Protocol/LinkCapabilities.swift (bảng lệnh sinh tự động từ Java) | ✅ Phần 3 |
| protocol/AuthReplyJson.java | Protocol/AuthReplyJson.swift | ✅ Phần 3 |
| protocol/IsoAuth.java, IsoReplyHandler.java | Protocol/IsoAuth.swift, IsoReplyHandler.swift | ✅ Phần 4 |
| transport/WatchConnection.java (39KB) | Transport/WatchConnection.swift (`WatchConnection`, `WatchConnectionListener`) | ✅ Phần 5 (chưa biên dịch/chưa thử máy thật) |
| transport/WatchScanner.java (4.6KB) | Transport/WatchScanner.swift | ✅ Phần 5 (chỉ BLE, khoá = UUID) |
| protocol/WristInitialization.java | Protocol/WristInitialization.swift | ✅ Phần 5 |
| protocol/WireNames.java | Protocol/WireNames.swift (`WireNames.request/parseResponse`) | ✅ Phần 6 (chưa biên dịch) |
| protocol/DeviceTelemetry.java | Protocol/DeviceTelemetry.swift (`DeviceTelemetry`, `.Stats`, `.ProbeOwner`) | ✅ Phần 5 |
| protocol/ActivationState, DeletionState, NameQueryState, ReplacementState .java | Protocol/ActivationState/DeletionState/NameQueryState/ReplacementState.swift (class) | ✅ Phần 6 (chưa biên dịch) |
| store/SecureStore.java | Store/KeychainStore.swift (class `SecureStore`, Keychain) | ✅ Phần 5 |
| store/SafeLog.java | Store/SafeLog.swift | ✅ Phần 5 |
| lifecycle/DeviceRemovalJournal.java | Store/DeviceRemovalGuard.swift | ✅ Phần 5 (rút gọn: chỉ chặn + bộ đếm thế hệ, không có huỷ ghép nối hệ thống) |
| protocol/FileTransfer.java (33KB) | Protocol/FileTransfer.swift | ✅ Phần 6 (chưa biên dịch) |
| protocol/HwtSource.java (12.5KB) | Protocol/HwtSource.swift + Protocol/ZipArchive.swift (bộ đọc ZIP + CRC32 tự viết) | ✅ Phần 6 (chưa biên dịch) |
| protocol/FacePolicy.java, VersionPolicy.java | Protocol/FacePolicy.swift, VersionPolicy.swift | ✅ Phần 6 (chưa biên dịch) |
| transport/WatchfaceManager.java (51KB) | Transport/WatchfaceManager.swift (`WatchfaceManager`, `WatchfaceManagerListener`) | ✅ Phần 7 (chưa biên dịch) |
| AppRuntime.java (29KB) | App/AppRuntime.swift (`AppRuntime.shared`, `Snapshot`, `AppRuntimeObserver`) | ✅ Phần 7 (chưa biên dịch) |
| AppModels.kt | App/Models.swift (`AppUiState`, `FaceItem`, `OperationInfo`, `ReplacementDialogInfo`, protocol `AppActions`…) | ✅ Phần 7 (làm sớm vì AppRuntime cần) |
| store/SavedWatchStore.kt | Store/SavedWatchStore.swift (UserDefaults, khoá = UUID) | ✅ Phần 7 |
| WatchViewModel.kt (85KB) | App/WatchViewModel.swift (ObservableObject, implements `AppActions` + `AppRuntimeObserver`) | ✅ Phần 8 (chưa biên dịch) |
| ui/*.kt (Compose/Miuix) | Views/RootView, DeviceView, FacesView, LogsView, SettingsView (SwiftUI, rút gọn) | ✅ Phần 8 (chưa biên dịch) |
| account/HuaweiId*.kt (WebView đăng nhập Huawei ID) | Views/HuaweiIdWebView.swift (WKWebView nonPersistent + chính sách URL + cookie `uid`) | ✅ Phần 8 (chưa biên dịch) |
| lifecycle/DeviceRemoval*.java, platform/AndroidSystemUnpair.java | — | ❌ Không port nguyên: iOS không cho app huỷ ghép nối hệ thống. Chỉ xoá dữ liệu cục bộ + hướng dẫn người dùng vào Cài đặt > Bluetooth > "Forget This Device". |
| UpdateChecker/UpdateDialog/UpdateReleaseParser/UpdateVersion, ConnectionService.java | — | ❌ Bỏ (tính năng riêng của Android; BLE nền dùng `UIBackgroundModes: bluetooth-central` đã khai báo trong project.yml) |

Thứ tự: Phần 6 ✅ → 7 ✅ → 8 ✅ → **Phần 9 = build GitHub Actions lần đầu, sửa lỗi biên dịch theo log, thử máy thật** ← tiếp theo. Cập nhật bảng này + `README_IOS.md` sau mỗi phần.

## 4. Quy ước code đã dùng (giữ nhất quán)
- Byte luôn là `[UInt8]` (Java `byte[]`, đã xử lý dấu: Java `b & 255` ⇒ `Int(b)`).
- Lỗi giao thức: `throw WMFault("MA_LOI")`; **giữ nguyên chuỗi mã lỗi của Java** (log/UI dựa vào chúng). `WMCore.code(error)` lấy mã.
- Java `long epoch` ⇒ `Int`. Java `Long` có thể null ⇒ `Int64?`.
- JSON: `JSONObject` giữ thứ tự khoá (như LinkedHashMap); chỉ số nguyên, cấm khoá trùng.
- **Cạm bẫy Swift**: `try` không được đứng bên phải toán tử `?:`/`+` không có ngoặc. Dùng `if/else` hoặc đặt một `try` ở đầu biểu thức.
- Giữ nguyên các giới hạn kích thước/ngân sách của bản Java (đây là phần phòng thủ có chủ đích).
- Đa luồng: GattChannel chạy trên `DispatchQueue` tuần tự; callback trả về qua `LinkChannelListener` kèm `epoch` để bỏ qua kết nối cũ.

## 5. Khác biệt iOS cần xử lý (đã biết)
- **Chỉ BLE (GATT)** dùng được: Android có thêm RFCOMM (Bluetooth Classic) – iOS không cho app thường dùng ⇒ bỏ `RfcommChannel`.
- iOS không có địa chỉ MAC; đồng hồ được nhận diện bằng `CBPeripheral.identifier` (UUID). Mọi chỗ Java lưu MAC phải đổi sang UUID (lưu dạng String).
- iOS tự xử lý MTU/CCCD; ghép nối hệ thống xảy ra tự động khi truy cập characteristic mã hoá. Không tự huỷ ghép nối được.
- GATT hằng số: service `FE86`, ghi `FE01`, nhận `FE02` (đã cài trong GattChannel).
- Lưu Secret/khoá vào **Keychain** (không dùng UserDefaults). Ghi `learnedSecret` TRƯỚC khi gửi bước S4 của ISO (xem chú thích đầu IsoAuth.swift).
- Không có `SecureRandom`: dùng `WMRandom.bytes(n)` (SecRandomCopyBytes).
- AES-GCM tự cài (`AESGCMManual`) vì IV 16 byte; thuật toán đã được đối chiếu với thư viện chuẩn bằng mô phỏng Python (khớp).
- Đọc file HWT: HWT là container ZIP chứa `watchface.bin`. Foundation không có API ZIP ⇒ tự viết bộ đọc ZIP tối thiểu (parse central directory; giải nén kiểu deflate bằng `import Compression` với `COMPRESSION_ZLIB`, là raw-deflate). Nhớ giữ giới hạn `WMCore.maxSource/maxMember` và chống ZIP-bomb/path traversal như bản Java.
- Chọn file trong app: `UIDocumentPickerViewController`/`.fileImporter` (cần `startAccessingSecurityScopedResource`).
- Đăng nhập Huawei ID: `WKWebView` (cookie/session quản lý trong `WKWebsiteDataStore`); tham khảo `account/*.kt`.
- Quét thiết bị: bản Java lọc theo cách nào thì đọc `WatchScanner.java`; trên iOS nên thử `scanForPeripherals(withServices: nil)` rồi lọc theo tên/manufacturer data nếu đồng hồ không quảng bá FE86.

## 6. Luồng nghiệp vụ (từ README gốc – xác nhận lại bằng Java khi port)
1. Kết nối BLE → `LinkCapabilities` (link params 01/…, security, services, commands, expand) → xác thực ISO (`IsoAuth`) hoặc Lite (`LiteAuth`) theo `caps.iso()`/`caps.lite()`.
2. Sau khi có khoá phiên: `CryptoSession.seal/open` bọc mọi gói nghiệp vụ (phong bì TLV 7c/7d/7e).
3. Đọc danh sách mặt đồng hồ `0x27/0x02` (`Wire.list`, `Wire.faces`), giữ ID, phiên bản, cờ type thô.
4. Chuẩn bị tải: lấy `watchface.bin` từ HWT, đóng băng + kiểm tra băm.
5. Thay thế: `0x27/0x03` với phiên bản +1 ở trường số cuối (`Wire.operation`); chỉ khi phản hồi thật có `error=0, need=1` mới truyền file; `need=0` thì dừng.
6. Truyền file bằng giao thức `0x28` (FileTransfer): đăng ký file, nhận file ID, thương lượng đơn vị/mã hoá, trả lời digest/chunk/final.
7. Xác minh: kết quả truyền và báo cáo áp dụng được ghi riêng; truy vấn lại danh sách mặt đồng hồ, kiểm tra cùng ID với phiên bản ứng viên. Không coi "100%" là thành công.
- Xoá mặt đồng hồ: `Wire.deletion` (op=2, đúng phiên bản đang cài), xong thì truy vấn lại danh sách.

## 7. Chưa được kiểm chứng (RỦI RO)
- **Chưa có đoạn Swift nào được biên dịch** (môi trường tạo ra không có `swiftc`). Lần build GitHub Actions đầu tiên sẽ lộ lỗi cú pháp/kiểu; sửa theo log.
- GattChannel chưa thử trên đồng hồ thật (đặc biệt: đồng hồ có quảng bá service FE86 không; có cần ghép nối hệ thống trước không).
- Chỉ logic GCM đã được kiểm chứng bằng mô phỏng; các phần mật mã còn lại (HKDF/HMAC/PBKDF2/ISO) port theo Java, chưa có test vector.
- Nên thêm unit test (XCTest) dùng lại các test của Java nếu có (`app/src/test`… trong zip gốc không có thư mục test, chỉ có tác vụ `testDebugUnitTest` trong README).

## 8. Cách làm tiếp
1. Đọc Java của phần kế tiếp (xem bảng mục 3), port từng file, giữ mã lỗi/giới hạn.
2. Đặt file đúng thư mục `WristMirror/<Protocol|Transport|Store|App|Views>/`.
3. Cập nhật bảng trạng thái ở mục 3 và `README_IOS.md`.
4. Đóng zip chỉ chứa file mới/đổi (giải nén chồng lên được), hoặc zip toàn bộ dự án.
5. Giấy phép: giữ Apache-2.0; không chép mã/SDK của Huawei Health (xem `THIRD_PARTY_NOTICES.md` của bản gốc, nên copy sang dự án iOS).

## 9. Ghi chú Phần 5 (dành cho Phần 6/7/8)
- **Khoá thiết bị = UUID của `CBPeripheral`** (chuỗi viết hoa; chuẩn hoá bằng `DeviceRemovalGuard.canonical`). Mọi chỗ Java dùng MAC đều đã đổi.
- `WatchConnection(store:log:deviceModel:)`; truyền `UIDevice.current.model` cho `deviceModel`. Giữ một tham chiếu mạnh tới `WatchConnection` (GattChannel giữ listener yếu). `setListener` giữ yếu.
- Gọi từ UI: `connect(deviceId:account:)`, `submitPin(expectedEpoch:entered:)`, `confirmRebind(expectedEpoch:)`, `respondAgreements(expectedEpoch:accept:)`, `disconnect()`.
- Sau READY: `sendControl(service,command,body)` (gói 0x27, mã hoá) và `sendFile(command,body,encrypt:)` (0x28); gói nghiệp vụ nhận về qua `onPacket` (đã giải mã). `post/execute/delay` chạy trên hàng đợi giao thức; `capabilities` chỉ đọc trên hàng đợi này.
- Giai đoạn `SYSTEM_PAIRING` của bản Java không còn (iOS tự ghép nối khi truy cập characteristic mã hoá).
- `stopForRemoval(id)` (thay `stopForUnpair`) bắt buộc gọi trên hàng đợi giao thức: `connection.post { try? connection.stopForRemoval(id) }`. Quy trình xoá đồng hồ: `removals.beginRemoval` → `stopForRemoval` → `store.clearDevice` → `removals.finishRemoval` (nếu lỗi: `cancelRemoval`).
- Chuỗi mô tả giai đoạn (UI) đã dịch sang tiếng Việt; mã giai đoạn/mã lỗi giữ nguyên tiếng Anh như Java.
- `WatchScanner` lọc theo tên (huawei/honor/watch/华为/荣耀) HOẶC quảng bá service FE86; callback trên main queue.
- Chưa có đoạn Swift nào được biên dịch (xem mục 7). Các điểm dễ lỗi khi build lần đầu: các chuỗi `+` dài của `[UInt8]`, `try` trong biểu thức, `private(set)` trên thuộc tính tính toán ở `WatchConnection`.

## 10. Ghi chú Phần 6 (dành cho Phần 7/8)
- `FacePolicy.isCurrent(face)` (Java `FacePolicy.current`), `eligible`, `canActivate`, `kind` (nhãn tiếng Việt), `defaultSelection`.
- `VersionPolicy.next(id:baseline:listed:)` → phiên bản ứng viên (chỉ +1 trường cuối).
- `WireNames.request(faces:language:)` (rỗng ⇒ bỏ qua gửi), `WireNames.parseResponse(fields)` → `Response{names, orderedNames, ids, malformedNameCount}`.
- Các lớp `*State` là **class** (tham chiếu, đổi được như Java). `Action` là enum `.none/.query/.upload/.activate`. Tham số nhãn: `operation(error:need:echo:)`, `report(type:error:)`, `list(_:generation:ownQuery:serial:)` (Deletion: `querySerial:`), `ReplacementState.list(_:queryGeneration:ownQuery:)`.
- `NameQueryState.next(now:)`/`expire(now:)` dùng mili-giây `Int64`.
- `HwtSource.load(from: URL, privateFiles: URL)`: UI phải gọi `startAccessingSecurityScopedResource()` quanh lời gọi. `privateFiles` nên là Application Support. `freeze(.bin)` → `Snapshot` (chỉ-đọc 0o400); `HwtSource.cleanup(privateFiles:directory:)` xoá thư mục `source-<uuid>`.
- `ZipArchive` chỉ hỗ trợ stored/deflate, không mã hoá, không ZIP64; deflate dùng `Compression` (`COMPRESSION_ZLIB` = raw deflate). Chưa thử trên file HWT thật.
- `FileTransfer(id:installedProtocolVersion:frozen:)`: `metadataBody()` (gửi 0x28/0x02, seal=true) → `onPacket(command:body:transactionsCrypted:)` trả `[Outgoing(command, encrypt, body)]`; bên gọi (WatchfaceManager, Phần 7) gửi qua `WatchConnection.sendFile(command:body:encrypt:)`. Đọc kết quả: `peerResultRaw`, `resultObserved`, `peerComplete`, `completionFailure`. Gọi `close()` khi xong.
- Danh tính file: dùng `systemNumber:systemFileNumber` thay cho `fileKey` của Java; kiểm tra symlink qua `.type == .typeRegular`.
- Rủi ro biên dịch cần soi ở build đầu: `ZipArchive.stream` (con trỏ `compression_stream` trong closure), `HwtSource` (init throwing với nhiều `let`), `FileTransfer.init` (dùng `self` sau khi gán đủ thuộc tính).

## 11. Thêm thông tin vào HWT có sẵn + Studio (mới, CHƯA biên dịch/chưa thử máy thật)
Mã dữ liệu (valueType) đọc từ 2 file HWT thật (Versaled, p0187VietNam), giải mã bằng script Python:
- Dương lịch: tháng 51 (13 mục, mục 0 đệm), chục ngày 70 (4 mục 0..3), đơn vị ngày 71 (10 mục).
- Âm lịch: tháng 92, chục ngày 93 (5 mục), đơn vị ngày 94.
- Thứ: 52, 8 mục (mục 0 đệm lặp "Thứ hai"; 1 = thứ hai ... 7 = chủ nhật).
- Giờ số 24h: chục giờ 59 (3 mục), giờ 60 (10), chục phút 61 (6), phút 62 (10); 63/64 = chục/đơn vị giây (chưa dùng).
- Kim: 150 giờ, 153 phút, 154 giây. Mã 50 (3 mục) có trong Versaled, chưa rõ nghĩa.
- CHƯA CÓ mã: pin, thời tiết/nhiệt độ, bước chân, nhịp tim (không có trong 2 file mẫu). Cần một file HWT có các mục này (mặt Rolex trong ảnh người dùng gửi) rồi đọc valueType tương tự.
- File HWT thật: `com.huawei.watchface` KHÔNG phải ZIP mà chính là `watchface.bin`; không có hashCode, ability.xml, ảnh xem trước. Thứ tự phần tử: 0 (nền), 3, 2 (ngày), 1 (giờ). Code đã xử lý (nhánh không ZIP).
Code:
- `Store/FaceLunar.swift` (khối ngày/tháng dùng chung âm/dương), `Store/FaceInfo.swift` (thứ, giờ số, tên, gom `infoLayers`/`drawInfoPreview`), `Store/HwtLunarPatch.swift` (chèn vào HWT có sẵn, `HwtLunarPatch.apply`; từ chối nếu file đã có mã trùng), `Views/InfoSettingsView.swift` (UI dùng chung Studio + "Thêm thông tin" trong chi tiết thư viện).
- Phần chèn vào bin đã mô phỏng bằng Python trên 2 file thật (header, bảng ảnh, phần tử mới, ảnh cũ nguyên vẹn). Cả hai file mẫu đã có âm lịch + giờ số nên sẽ bị từ chối nếu bật các mục đó; dùng được "Tên" và "Dương lịch"/"Thứ" khi file chưa có.
- Test: `LunarPatchTests` trong `BuilderTests.swift`. Việc kế tiếp: build GitHub Actions, thử máy thật, thêm pin/thời tiết/bước/nhịp tim khi có file mẫu.
