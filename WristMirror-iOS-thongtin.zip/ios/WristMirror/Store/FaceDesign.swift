// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

// MARK: - Thiết kế mặt đồng hồ (dữ liệu người dùng chỉnh)

/// Mặt đồng hồ kim (analog) cho màn hình HWHD09 (466×466): nền, vạch giờ, 3 kim, và chế độ AOD (màn hình tắt).
struct FaceDesign {
    enum Marks: String, CaseIterable, Identifiable {
        case none, ticks, dots, numerals
        var id: String { rawValue }
        var title: String {
            switch self {
            case .none: return "Không"
            case .ticks: return "Vạch"
            case .dots: return "Chấm"
            case .numerals: return "Số"
            }
        }
    }

    enum HandStyle: String, CaseIterable, Identifiable {
        case bar, pointed, classic
        var id: String { rawValue }
        var title: String {
            switch self {
            case .bar: return "Thanh"
            case .pointed: return "Nhọn"
            case .classic: return "Cổ điển"
            }
        }
    }

    enum AodBackground: String, CaseIterable, Identifiable {
        case black, dimmed
        var id: String { rawValue }
        var title: String { self == .black ? "Nền đen" : "Nền mờ" }
    }

    var name = "Mặt đồng hồ của tôi"
    var author = ""

    // Nền
    var backgroundColor = Color(red: 0.03, green: 0.05, blue: 0.13)
    var useGradient = true
    var backgroundColor2 = Color(red: 0.10, green: 0.26, blue: 0.58)
    var photo: UIImage?
    var photoZoom = 1.0
    var photoPanX = 0.0
    var photoPanY = 0.0
    var photoDim = 0.2

    // Lớp trang trí (họa tiết vector, có thể quay theo kim)
    var decor: [DecorLayer] = []

    // Âm lịch (ngày/tháng âm do đồng hồ cập nhật)
    var showLunar = false
    var lunarColor = Color.white
    var lunarSize = 1.0
    /// Vị trí dọc của khối âm lịch (tỉ lệ 0.1 ... 0.9 chiều cao mặt đồng hồ).
    var lunarY = 0.68
    var lunarLabel = true
    var lunarX = 0.5

    // Dương lịch (ngày/tháng dương do đồng hồ cập nhật)
    var showSolar = false
    var solarColor = Color.white
    var solarSize = 1.0
    var solarX = 0.5
    var solarY = 0.55
    var solarLabel = true

    // Thứ trong tuần
    var showWeekday = false
    var weekdayColor = Color.white
    var weekdaySize = 1.0
    var weekdayX = 0.5
    var weekdayY = 0.40

    // Giờ số (HH:MM)
    var showDigital = false
    var digitalColor = Color.white
    var digitalSize = 1.0
    var digitalX = 0.5
    var digitalY = 0.30

    // Tên hiển thị (chữ tĩnh do người dùng nhập)
    var showName = false
    var nameText = ""
    var nameColor = Color.white
    var nameSize = 1.0
    var nameX = 0.5
    var nameY = 0.80
    var nameStyle = 0

    // Vạch giờ
    var marks: Marks = .ticks
    var marksColor = Color.white

    // Kim
    var handStyle: HandStyle = .classic
    var hourColor = Color.white
    var minuteColor = Color.white
    var secondColor = Color(red: 1.0, green: 0.30, blue: 0.35)
    var capColor = Color(red: 1.0, green: 0.30, blue: 0.35)
    var showSecond = true
    var handWidth = 1.0
    var handOutline = true

    // AOD
    var aodBackground: AodBackground = .black
    var aodBrightness = 0.25
    var aodShowMarks = true
    var aodHandColor = Color(white: 0.85)
    var aodMarksColor = Color(white: 0.5)
}

// MARK: - Vẽ

enum FaceRenderer {
    static let size: CGFloat = 466
    static let center: CGFloat = 233

    enum HandKind {
        case hour, minute, second
        var valueType: Int {
            switch self {
            case .hour: return HwtValueType.hour
            case .minute: return HwtValueType.minute
            case .second: return HwtValueType.second
            }
        }
    }

    struct HandGeometry {
        var reach: CGFloat
        var tail: CGFloat
        var width: CGFloat
    }

    static func geometry(_ kind: HandKind, ambient: Bool, design: FaceDesign) -> HandGeometry {
        let k = CGFloat(min(1.8, max(0.6, design.handWidth)))
        switch kind {
        case .hour:
            return ambient ? HandGeometry(reach: 118, tail: 20, width: 20 * k) : HandGeometry(reach: 125, tail: 24, width: 24 * k)
        case .minute:
            return ambient ? HandGeometry(reach: 178, tail: 22, width: 16 * k) : HandGeometry(reach: 185, tail: 28, width: 20 * k)
        case .second:
            return HandGeometry(reach: 205, tail: 42, width: 7 * k)
        }
    }

    // MARK: Nền

    static func photoRect(_ img: UIImage, zoom: Double, panX: Double, panY: Double) -> CGRect {
        let iw = max(1, img.size.width), ih = max(1, img.size.height)
        let base = max(size / iw, size / ih)
        let s = base * CGFloat(max(1.0, zoom))
        let w = iw * s, h = ih * s
        let px = CGFloat(max(-1, min(1, panX))), py = CGFloat(max(-1, min(1, panY)))
        return CGRect(x: (size - w) / 2 + px * (w - size) / 2, y: (size - h) / 2 + py * (h - size) / 2, width: w, height: h)
    }

    private static func drawBase(_ ctx: CGContext, _ d: FaceDesign) {
        let full = CGRect(x: 0, y: 0, width: size, height: size)
        if let photo = d.photo {
            ctx.setFillColor(UIColor.black.cgColor)
            ctx.fill(full)
            UIGraphicsPushContext(ctx)
            photo.draw(in: photoRect(photo, zoom: d.photoZoom, panX: d.photoPanX, panY: d.photoPanY))
            UIGraphicsPopContext()
            if d.photoDim > 0 {
                ctx.setFillColor(UIColor.black.withAlphaComponent(CGFloat(min(0.9, d.photoDim))).cgColor)
                ctx.fill(full)
            }
        } else if d.useGradient {
            let colors = [UIColor(d.backgroundColor).cgColor, UIColor(d.backgroundColor2).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: nil) {
                ctx.drawLinearGradient(g, start: CGPoint(x: 0, y: 0), end: CGPoint(x: size, y: size), options: [])
            } else {
                ctx.setFillColor(UIColor(d.backgroundColor).cgColor); ctx.fill(full)
            }
        } else {
            ctx.setFillColor(UIColor(d.backgroundColor).cgColor)
            ctx.fill(full)
        }
    }

    static func drawBackground(_ ctx: CGContext, design d: FaceDesign, ambient: Bool) {
        let full = CGRect(x: 0, y: 0, width: size, height: size)
        if ambient {
            if d.aodBackground == .black {
                ctx.setFillColor(UIColor.black.cgColor)
                ctx.fill(full)
            } else {
                drawBase(ctx, d)
                ctx.setFillColor(UIColor.black.withAlphaComponent(CGFloat(1.0 - min(0.6, max(0.05, d.aodBrightness)))).cgColor)
                ctx.fill(full)
            }
            if d.aodShowMarks { drawMarks(ctx, style: d.marks, color: UIColor(d.aodMarksColor)) }
        } else {
            drawBase(ctx, d)
            drawStaticDecor(ctx, d)
            drawMarks(ctx, style: d.marks, color: UIColor(d.marksColor))
        }
    }

    static func drawMarks(_ ctx: CGContext, style: FaceDesign.Marks, color: UIColor) {
        guard style != .none else { return }
        ctx.saveGState()
        ctx.translateBy(x: center, y: center)
        ctx.setFillColor(color.cgColor)
        ctx.setStrokeColor(color.cgColor)
        ctx.setLineCap(.round)
        switch style {
        case .none:
            break
        case .ticks:
            for i in 0..<60 {
                let major = i % 5 == 0
                ctx.saveGState()
                ctx.rotate(by: CGFloat(i) * CGFloat.pi / 30)
                ctx.setLineWidth(major ? 6 : 2.5)
                let outer = center - 10
                let inner = outer - (major ? 26 : 10)
                ctx.move(to: CGPoint(x: 0, y: -outer))
                ctx.addLine(to: CGPoint(x: 0, y: -inner))
                ctx.strokePath()
                ctx.restoreGState()
            }
        case .dots:
            for i in 0..<60 {
                let a = CGFloat(i) * CGFloat.pi / 30
                let major = i % 5 == 0
                let r: CGFloat = major ? 205 : 218
                let rad: CGFloat = major ? 7 : 2.5
                ctx.fillEllipse(in: CGRect(x: sin(a) * r - rad, y: -cos(a) * r - rad, width: rad * 2, height: rad * 2))
            }
        case .numerals:
            let font = UIFont.systemFont(ofSize: 44, weight: .semibold)
            for n in 1...12 {
                let a = CGFloat(n) * CGFloat.pi / 6
                let r: CGFloat = 180
                let s = NSAttributedString(string: "\(n)", attributes: [.font: font, .foregroundColor: color])
                let sz = s.size()
                UIGraphicsPushContext(ctx)
                s.draw(at: CGPoint(x: sin(a) * r - sz.width / 2, y: -cos(a) * r - sz.height / 2))
                UIGraphicsPopContext()
            }
            for i in 0..<60 {
                ctx.saveGState()
                ctx.rotate(by: CGFloat(i) * CGFloat.pi / 30)
                ctx.setLineWidth(i % 5 == 0 ? 3 : 1.5)
                ctx.move(to: CGPoint(x: 0, y: -(center - 8)))
                ctx.addLine(to: CGPoint(x: 0, y: -(center - 8 - 8)))
                ctx.strokePath()
                ctx.restoreGState()
            }
        }
        ctx.restoreGState()
    }

    // MARK: Kim

    /// Vẽ một kim trong toạ độ cục bộ: trục xoay ở gốc (0,0), đầu kim hướng lên (0, -reach).
    static func drawHand(_ ctx: CGContext, kind: HandKind, geo: HandGeometry, style: FaceDesign.HandStyle,
                         color: UIColor, outline: Bool) {
        let w = geo.width
        let path = CGMutablePath()
        let effective: FaceDesign.HandStyle = kind == .second ? .bar : style
        switch effective {
        case .bar:
            path.addRoundedRect(in: CGRect(x: -w / 2, y: -geo.reach, width: w, height: geo.reach + geo.tail),
                                cornerWidth: w / 2, cornerHeight: w / 2)
        case .pointed:
            path.move(to: CGPoint(x: 0, y: -geo.reach))
            path.addLine(to: CGPoint(x: w / 2, y: 0))
            path.addLine(to: CGPoint(x: w * 0.3, y: geo.tail))
            path.addLine(to: CGPoint(x: -w * 0.3, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: 0))
            path.closeSubpath()
        case .classic:
            let shoulder = -geo.reach + w * 1.3
            path.move(to: CGPoint(x: 0, y: -geo.reach))
            path.addLine(to: CGPoint(x: w / 2, y: shoulder))
            path.addLine(to: CGPoint(x: w / 2, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: shoulder))
            path.closeSubpath()
        }

        ctx.saveGState()
        ctx.setLineJoin(.round)
        if outline {
            ctx.addPath(path)
            ctx.setStrokeColor(UIColor.black.withAlphaComponent(0.55).cgColor)
            ctx.setLineWidth(2.5)
            ctx.strokePath()
        }
        ctx.addPath(path)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()

        if effective == .classic {
            // Rãnh tối ở giữa thân kim
            let groove = CGMutablePath()
            let gw = max(2, w * 0.3)
            groove.addRoundedRect(in: CGRect(x: -gw / 2, y: -geo.reach + w * 1.9, width: gw, height: geo.reach - w * 1.9 + geo.tail * 0.6),
                                  cornerWidth: gw / 2, cornerHeight: gw / 2)
            ctx.addPath(groove)
            ctx.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
            ctx.fillPath()
        }
        if kind == .second {
            // Đối trọng ở đuôi kim giây
            let rad = max(3.5, w * 0.9)
            ctx.setFillColor(color.cgColor)
            ctx.fillEllipse(in: CGRect(x: -rad, y: geo.tail * 0.55 - rad, width: rad * 2, height: rad * 2))
        }
        ctx.restoreGState()
    }

    struct HandImage {
        let raster: HwtRaster
        let pivotX: Int
        let pivotY: Int
    }

    /// Ảnh của một kim (nền trong suốt) kèm vị trí trục xoay trong ảnh.
    static func handImage(_ kind: HandKind, ambient: Bool, design d: FaceDesign) -> HandImage {
        let geo = geometry(kind, ambient: ambient, design: d)
        let pad = 5
        var w = Int(ceil(geo.width)) + pad * 2
        if kind == .second { w = max(w, Int(ceil(max(3.5, geo.width * 0.9) * 2)) + pad * 2) }
        if w % 2 != 0 { w += 1 }
        let pivotY = Int(ceil(geo.reach)) + pad
        let h = pivotY + Int(ceil(geo.tail)) + pad + 2
        let color: UIColor
        switch kind {
        case .hour: color = UIColor(ambient ? d.aodHandColor : d.hourColor)
        case .minute: color = UIColor(ambient ? d.aodHandColor : d.minuteColor)
        case .second: color = UIColor(d.secondColor)
        }
        let outline = d.handOutline && !ambient
        let raster = drawRaster(width: w, height: h) { ctx in
            ctx.translateBy(x: CGFloat(w) / 2, y: CGFloat(pivotY))
            drawHand(ctx, kind: kind, geo: geo, style: d.handStyle, color: color, outline: outline)
        }
        return HandImage(raster: raster, pivotX: w / 2, pivotY: pivotY)
    }

    static func capImage(design d: FaceDesign) -> HwtRaster {
        let dia = 24
        return drawRaster(width: dia, height: dia) { ctx in
            let c = CGFloat(dia) / 2
            ctx.setFillColor(UIColor.black.withAlphaComponent(0.5).cgColor)
            ctx.fillEllipse(in: CGRect(x: 0.5, y: 0.5, width: CGFloat(dia) - 1, height: CGFloat(dia) - 1))
            ctx.setFillColor(UIColor(d.capColor).cgColor)
            ctx.fillEllipse(in: CGRect(x: c - 9.5, y: c - 9.5, width: 19, height: 19))
        }
    }

    // MARK: Ghép cả mặt (xem trước)

    static func drawComposite(_ ctx: CGContext, design d: FaceDesign, ambient: Bool,
                              hour: Int = 10, minute: Int = 8, second: Int = 35,
                              scale: CGFloat = 1, circle: Bool = false) {
        ctx.saveGState()
        ctx.scaleBy(x: scale, y: scale)
        if circle {
            ctx.addEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            ctx.clip()
        }
        drawBackground(ctx, design: d, ambient: ambient)
        if !ambient { drawInfoPreview(ctx, design: d) }

        func hand(_ kind: HandKind, angle: CGFloat) {
            let geo = geometry(kind, ambient: ambient, design: d)
            let color: UIColor
            switch kind {
            case .hour: color = UIColor(ambient ? d.aodHandColor : d.hourColor)
            case .minute: color = UIColor(ambient ? d.aodHandColor : d.minuteColor)
            case .second: color = UIColor(d.secondColor)
            }
            ctx.saveGState()
            ctx.translateBy(x: center, y: center)
            ctx.rotate(by: angle)
            drawHand(ctx, kind: kind, geo: geo, style: d.handStyle, color: color, outline: d.handOutline && !ambient)
            ctx.restoreGState()
        }
        let hAngle = (CGFloat(hour % 12) + CGFloat(minute) / 60) * CGFloat.pi / 6
        let mAngle = (CGFloat(minute) + CGFloat(second) / 60) * CGFloat.pi / 30
        let sAngle = CGFloat(second) * CGFloat.pi / 30
        if !ambient {
            for l in d.decor where l.spin != .none {
                let a: CGFloat
                switch l.spin {
                case .hour: a = hAngle
                case .minute: a = mAngle
                default: a = sAngle
                }
                ctx.saveGState()
                ctx.translateBy(x: center, y: center)
                ctx.rotate(by: a)
                drawDecorLayer(ctx, l)
                ctx.restoreGState()
            }
        }
        hand(.hour, angle: hAngle)
        hand(.minute, angle: mAngle)
        if !ambient {
            if d.showSecond { hand(.second, angle: sAngle) }
            ctx.saveGState()
            ctx.translateBy(x: center - 12, y: center - 12)
            let cap = capImage(design: d)
            if let cg = cgImage(cap) {
                // cgImage có gốc trên-trái; ctx đã lật (y xuống) nên lật ngược lại khi vẽ
                ctx.translateBy(x: 0, y: 24)
                ctx.scaleBy(x: 1, y: -1)
                ctx.draw(cg, in: CGRect(x: 0, y: 0, width: 24, height: 24))
            }
            ctx.restoreGState()
        }
        ctx.restoreGState()
    }

    /// Ảnh xem trước dạng UIImage (nền đen ngoài vòng tròn khi `circle`).
    static func image(design d: FaceDesign, ambient: Bool, pixels: Int, circle: Bool) -> UIImage {
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let r = UIGraphicsImageRenderer(size: CGSize(width: pixels, height: pixels), format: fmt)
        return r.image { c in
            UIColor.black.setFill()
            c.fill(CGRect(x: 0, y: 0, width: pixels, height: pixels))
            drawComposite(c.cgContext, design: d, ambient: ambient, scale: CGFloat(pixels) / size, circle: circle)
        }
    }

    // MARK: Điểm ảnh <-> ảnh

    /// Vẽ vào bộ đệm RGBA (gốc trên-trái) rồi đổi sang ARGB không nhân trước alpha.
    static func drawRaster(width: Int, height: Int, _ draw: (CGContext) -> Void) -> HwtRaster {
        var buf = [UInt8](repeating: 0, count: width * height * 4)
        buf.withUnsafeMutableBytes { raw in
            guard let ctx = CGContext(data: raw.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
            ctx.translateBy(x: 0, y: CGFloat(height))
            ctx.scaleBy(x: 1, y: -1)
            ctx.setAllowsAntialiasing(true)
            ctx.interpolationQuality = .high
            UIGraphicsPushContext(ctx)
            draw(ctx)
            UIGraphicsPopContext()
        }
        var px = [UInt32](repeating: 0, count: width * height)
        for i in 0..<(width * height) {
            let o = i * 4
            let a = UInt32(buf[o + 3])
            if a == 0 { continue }
            var r = UInt32(buf[o]), g = UInt32(buf[o + 1]), b = UInt32(buf[o + 2])
            if a < 255 {
                r = min(255, (r * 255 + a / 2) / a)
                g = min(255, (g * 255 + a / 2) / a)
                b = min(255, (b * 255 + a / 2) / a)
            }
            px[i] = (a << 24) | (r << 16) | (g << 8) | b
        }
        return HwtRaster(width: width, height: height, argb: px)
    }

    static func cgImage(_ r: HwtRaster) -> CGImage? {
        var bytes = [UInt8](repeating: 0, count: r.width * r.height * 4)
        for (i, p) in r.argb.enumerated() {
            bytes[i * 4] = UInt8((p >> 16) & 0xff)
            bytes[i * 4 + 1] = UInt8((p >> 8) & 0xff)
            bytes[i * 4 + 2] = UInt8(p & 0xff)
            bytes[i * 4 + 3] = UInt8((p >> 24) & 0xff)
        }
        guard let provider = CGDataProvider(data: Data(bytes) as CFData) else { return nil }
        return CGImage(width: r.width, height: r.height, bitsPerComponent: 8, bitsPerPixel: 32,
                       bytesPerRow: r.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    static func pngData(_ r: HwtRaster) -> [UInt8]? {
        guard let cg = cgImage(r) else { return nil }
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(out, UTType.png.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dest, cg, nil)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return [UInt8](out as Data)
    }

    /// Thu nhỏ ảnh quá lớn (giới hạn bộ nhớ); trả nguyên ảnh nếu đã đủ nhỏ.
    static func downscale(_ img: UIImage, maxSide: CGFloat) -> UIImage {
        let longest = max(img.size.width, img.size.height)
        guard longest > maxSide, longest > 0 else { return img }
        let k = maxSide / longest
        let newSize = CGSize(width: (img.size.width * k).rounded(), height: (img.size.height * k).rounded())
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { _ in
            img.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}

// MARK: - Dựng file HWT từ thiết kế

enum FaceBuilder {
    static func cleanTitle(_ s: String) -> String {
        let t = HwtLibrary.cleanName(s)
        return t.isEmpty ? "Mặt đồng hồ" : t
    }

    static func fileName(_ name: String) -> String {
        let base = cleanTitle(name).unicodeScalars.map { sc -> String in
            if CharacterSet.alphanumerics.contains(sc) && sc.isASCII { return String(sc) }
            return "_"
        }.joined()
        let trimmed = base.split(separator: "_").joined(separator: "_")
        return (trimmed.isEmpty ? "face" : String(trimmed.prefix(40))) + ".hwt"
    }

    /// Dựng toàn bộ file `.hwt` (byte). Chạy được ở luồng nền.
    static func build(_ design: FaceDesign, date: Date = Date()) throws -> [UInt8] {
        let c = Int(FaceRenderer.center)
        var images = [HwtRaster]()
        func add(_ r: HwtRaster) -> Int { images.append(r); return images.count }

        // A100_001: ảnh thu nhỏ (vòng tròn, trong suốt ở góc)
        _ = add(FaceRenderer.drawRaster(width: 250, height: 250) { ctx in
            FaceRenderer.drawComposite(ctx, design: design, ambient: false, scale: 250 / FaceRenderer.size, circle: true)
        })
        let side = Int(FaceRenderer.size)
        let bgDay = add(FaceRenderer.drawRaster(width: side, height: side) { FaceRenderer.drawBackground($0, design: design, ambient: false) })
        let bgAod = add(FaceRenderer.drawRaster(width: side, height: side) { FaceRenderer.drawBackground($0, design: design, ambient: true) })

        func handLayer(_ kind: FaceRenderer.HandKind, ambient: Bool) -> HwtLayer {
            let h = FaceRenderer.handImage(kind, ambient: ambient, design: design)
            let id = add(h.raster)
            let rect = HwtRect(x: c - h.pivotY, y: c - h.pivotY, w: h.pivotY * 2, h: h.pivotY * 2)
            return .hand(resource: id, rect: rect, pivotX: h.pivotX, pivotY: h.pivotY, valueType: kind.valueType, ambient: ambient)
        }

        let lunar: [HwtLayer] = FaceRenderer.infoActive(design) ? FaceRenderer.infoLayers(design, add: add) : []

        var time = [HwtLayer]()
        for l in design.decor.prefix(FaceRenderer.maxDecor) where l.spin != .none {
            guard let vt = l.spin.valueType else { continue }
            let side = FaceRenderer.decorSide(l)
            let id = add(FaceRenderer.drawRaster(width: side, height: side) { ctx in
                ctx.translateBy(x: CGFloat(side) / 2, y: CGFloat(side) / 2)
                FaceRenderer.drawDecorLayer(ctx, l)
            })
            let rect = HwtRect(x: c - side / 2, y: c - side / 2, w: side, h: side)
            time.append(.hand(resource: id, rect: rect, pivotX: side / 2, pivotY: side / 2, valueType: vt, ambient: false))
        }
        time.append(handLayer(.hour, ambient: false))
        time.append(handLayer(.minute, ambient: false))
        if design.showSecond { time.append(handLayer(.second, ambient: false)) }
        let cap = add(FaceRenderer.capImage(design: design))
        time.append(.single(resource: cap, x: c - 12, y: c - 12, ambient: false))
        time.append(handLayer(.hour, ambient: true))
        time.append(handLayer(.minute, ambient: true))

        let title = cleanTitle(design.name)
        let author = HwtLibrary.cleanName(design.author)
        let background: [HwtLayer] = [.single(resource: bgDay, x: 0, y: 0, ambient: false),
                                      .single(resource: bgAod, x: 0, y: 0, ambient: true)]
        // File thật vẽ theo thứ tự: nền (0), ngày (2), giờ (1) nên âm lịch nằm dưới kim.
        let elements: [[HwtLayer]] = lunar.isEmpty ? [background, time] : [background, lunar, time]
        let ids: [Int]? = lunar.isEmpty ? nil : [0, 2, 1]
        let spec = HwtFaceSpec(title: title, titleCN: title, author: author.isEmpty ? "WristMirror" : author,
                               version: "1.0.0",
                               elements: elements,
                               images: images,
                               elementIDs: ids)

        var pngs = [[UInt8]]()
        for img in images {
            guard let p = FaceRenderer.pngData(img) else { throw WMFault("BUILD_PNG") }
            pngs.append(p)
        }

        func jpeg(_ ambient: Bool, _ px: Int) throws -> [UInt8] {
            let img = FaceRenderer.image(design: design, ambient: ambient, pixels: px, circle: true)
            guard let d = img.jpegData(compressionQuality: 0.9) else { throw WMFault("BUILD_JPEG") }
            return [UInt8](d)
        }
        let previews = HwtBuilder.Previews(cover: try jpeg(false, 480), aod: try jpeg(true, 960), icon: try jpeg(false, 390))
        return try HwtBuilder.build(spec: spec, pngs: pngs, previews: previews, date: date)
    }
}
