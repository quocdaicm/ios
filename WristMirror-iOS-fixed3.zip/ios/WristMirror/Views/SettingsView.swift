import SwiftUI

/// Tương đương SettingsScreen.kt: tự kết nối, chủ đề, nhật ký, giới thiệu.
struct SettingsView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("Tự kết nối khi mở app", isOn: Binding(get: { vm.ui.autoConnect }, set: { vm.setAutoConnect($0) }))
                } footer: {
                    Text("Khi mở app, tự kết nối với đồng hồ đã kết nối thành công gần nhất.")
                }
                Section {
                    Picker("Chủ đề", selection: Binding(get: { vm.ui.theme }, set: { vm.setTheme($0) })) {
                        Text("Theo hệ thống").tag(ThemeMode.system)
                        Text("Sáng").tag(ThemeMode.light)
                        Text("Tối").tag(ThemeMode.dark)
                    }
                } footer: {
                    Text("Chọn giao diện của app.")
                }
                Section {
                    NavigationLink("Nhật ký hoạt động") { LogsView() }
                    NavigationLink("Giới thiệu") { AboutView() }
                }
                Section {
                    Button("Xoá bộ nhớ đệm HWT đã nhập") { vm.clearCache() }
                } footer: {
                    Text("Huỷ ghép nối: Cài đặt iOS > Bluetooth > (i) > Forget This Device.")
                }
            }
            .navigationTitle("Cài đặt")
        }
    }
}
