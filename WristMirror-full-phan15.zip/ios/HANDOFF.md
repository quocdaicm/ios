# HANDOFF – WristMirror iOS (đọc file này đầu tiên nếu bạn là AI/lập trình viên làm tiếp)

## 1. Mục tiêu
Viết lại app Android **WristMirror (腕镜)** (Kotlin/Java, repo gốc `WristMirror-main.zip`, giấy phép Apache-2.0)
thành app **iPhone** bằng **Swift + SwiftUI + CoreBluetooth**. App kết nối BLE tới đồng hồ Huawei (GT/FIT…),
xác thực (HiChain ISO / Lite), đọc danh sách mặt đồng hồ, rồi dùng "phương pháp thay thế" để cài
file mặt đồng hồ HWT cục bộ lên một slot mặt đồng hồ thường có sẵn (xem README gốc, mục "替换法的原理").

Người dùng dùng tài khoản Claude miễn phí (sợ hết token) nên công việc được chia thành nhiều phần,
mỗi phần giao ngay bằng một file zip. Người dùng giải nén các zip chồng lên cùng một thư mục.
Build **không cần Mac**: GitHub Actions (`.github/workflows/build.yml`) dùng XcodeGen (`project.yml`)
rồi `xcodebuild` ra IPA chưa ký (người dùng tự ký/cài bằng Sideloadly/AltStore).

## 2. Nguồn Java để port (CẦN file `WristMirror-main.zip` gốc)
Giải nén, nguồn ở: `Escosis-WristMirror-*/app/src/main/java/io/github/escosis/hwtfaceswap/`
Nếu bạn không có zip gốc, hãy yêu cầu người dùng gửi lại. KHÔNG bịa chi tiết giao thức khi chưa đọc Java.

## 3. Trạng thái port (Java → Swift)
Đường dẫn Swift: `WristMirror/…`

| Java | Swift | Trạng thái |
|---|---|---|
| protocol/FrameCodec.java | Protocol/FrameCodec.swift (+ `WMFault`) | ✅ Phần 1 |
| transport/LinkChannel.java, GattChannel.java | Transport/LinkChannel.swift, GattChannel.swift | ✅ Phần 1 (chưa thử trên thiết bị thật) |
| protocol/Core.java | Protocol/Core.swift (`WMCore`) | ✅ Phần 2 |
| protocol/TlvView.java | Protocol/TlvView.swift | ✅ Phần 2 |
| protocol/Wire.java | Protocol/Wire.swift | ✅ Phần 2 |
| protocol/DeviceInfo.java | Protocol/DeviceInfo.swift | ✅ Phần 2 |
| protocol/MiniJson.java | Protocol/MiniJson.swift (`JSONValue`, `JSONObject`) | ✅ Phần 2 |
| protocol/HuaweiCrypto.java | Protocol/HuaweiCrypto.swift + AESPrimitives.swift | ✅ Phần 3 |
| protocol/CryptoSession.java | Protocol/CryptoSession.swift | ✅ Phần 3 |
| protocol/LiteAuth.java | Protocol/LiteAuth.swift | ✅ Phần 3 |
| protocol/LinkCapabilities.java | Protocol/LinkCapabilities.swift (bảng lệnh sinh tự động từ Java) | ✅ Phần 3 |
| protocol/AuthReplyJson.java | Protocol/AuthReplyJson.swift | ✅ Phần 3 |
| protocol/IsoAuth.java, IsoReplyHandler.java | Protocol/IsoAuth.swift, IsoReplyHandler.swift | ✅ Phần 4 |
| transport/WatchConnection.java (39KB) | Transport/WatchConnection.swift (`WatchConnection`, `WatchConnectionListener`) | ✅ Phần 5 (chưa biên dịch/chưa thử máy thật) |
| transport/WatchScanner.java (4.6KB) | Transport/WatchScanner.swift | ✅ Phần 5 (chỉ BLE, khoá = UUID) |
| protocol/WristInitialization.java | Protocol/WristInitialization.swift | ✅ Phần 5 |
| protocol/WireNames.java | Protocol/WireNames.swift (`WireNames.request/parseResponse`) | ✅ Phần 6 (chưa biên dịch) |
| protocol/DeviceTelemetry.java | Protocol/DeviceTelemetry.swift (`DeviceTelemetry`, `.Stats`, `.ProbeOwner`) | ✅ Phần 5 |
| protocol/ActivationState, DeletionState, NameQueryState, ReplacementState .java | Protocol/ActivationState/DeletionState/NameQueryState/ReplacementState.swift (class) | ✅ Phần 6 (chưa biên dịch) |
| store/SecureStore.java | Store/KeychainStore.swift (class `SecureStore`, Keychain) | ✅ Phần 5 |
| store/SafeLog.java | Store/SafeLog.swift | ✅ Phần 5 |
| lifecycle/DeviceRemovalJournal.java | Store/DeviceRemovalGuard.swift | ✅ Phần 5 (rút gọn: chỉ chặn + bộ đếm thế hệ, không có huỷ ghép nối hệ thống) |
| protocol/FileTransfer.java (33KB) | Protocol/FileTransfer.swift | ✅ Phần 6 (chưa biên dịch) |
| protocol/HwtSource.java (12.5KB) | Protocol/HwtSource.swift + Protocol/ZipArchive.swift (bộ đọc ZIP + CRC32 tự viết) | ✅ Phần 6 (chưa biên dịch) |
| protocol/FacePolicy.java, VersionPolicy.java | Protocol/FacePolicy.swift, VersionPolicy.swift | ✅ Phần 6 (chưa biên dịch) |
| transport/WatchfaceManager.java (51KB) | Transport/WatchfaceManager.swift (`WatchfaceManager`, `WatchfaceManagerListener`) | ✅ Phần 7 (chưa biên dịch) |
| AppRuntime.java (29KB) | App/AppRuntime.swift (`AppRuntime.shared`, `Snapshot`, `AppRuntimeObserver`) | ✅ Phần 7 (chưa biên dịch) |
| AppModels.kt | App/Models.swift (`AppUiState`, `FaceItem`, `OperationInfo`, `ReplacementDialogInfo`, protocol `AppActions`…) | ✅ Phần 7 (làm sớm vì AppRuntime cần) |
| store/SavedWatchStore.kt | Store/SavedWatchStore.swift (UserDefaults, khoá = UUID) | ✅ Phần 7 |
| WatchViewModel.kt (85KB) | App/WatchViewModel.swift (ObservableObject, implements `AppActions` + `AppRuntimeObserver`) | ✅ Phần 8 (chưa biên dịch) |
| ui/*.kt (Compose/Miuix) | Views/RootView, DeviceView, FacesView, LogsView, SettingsView (SwiftUI, rút gọn) | ✅ Phần 8 (chưa biên dịch) |
| account/HuaweiId*.kt (WebView đăng nhập Huawei ID) | Views/HuaweiIdWebView.swift (WKWebView nonPersistent + chính sách URL + cookie `uid`) | ✅ Phần 8 (chưa biên dịch) |
| lifecycle/DeviceRemoval*.java, platform/AndroidSystemUnpair.java | — | ❌ Không port nguyên: iOS không cho app huỷ ghép nối hệ thống. Chỉ xoá dữ liệu cục bộ + hướng dẫn người dùng vào Cài đặt > Bluetooth > "Forget This Device". |
| UpdateChecker/UpdateDialog/UpdateReleaseParser/UpdateVersion, ConnectionService.java | — | ❌ Bỏ (tính năng riêng của Android; BLE nền dùng `UIBackgroundModes: bluetooth-central` đã khai báo trong project.yml) |

Thứ tự: Phần 6 ✅ → 7 ✅ → 8 ✅ → **Phần 9 = build GitHub Actions lần đầu, sửa lỗi biên dịch theo log, thử máy thật** ← tiếp theo. Cập nhật bảng này + `README_IOS.md` sau mỗi phần.

## 4. Quy ước code đã dùng (giữ nhất quán)
- Byte luôn là `[UInt8]` (Java `byte[]`, đã xử lý dấu: Java `b & 255` ⇒ `Int(b)`).
- Lỗi giao thức: `throw WMFault("MA_LOI")`; **giữ nguyên chuỗi mã lỗi của Java** (log/UI dựa vào chúng). `WMCore.code(error)` lấy mã.
- Java `long epoch` ⇒ `Int`. Java `Long` có thể null ⇒ `Int64?`.
- JSON: `JSONObject` giữ thứ tự khoá (như LinkedHashMap); chỉ số nguyên, cấm khoá trùng.
- **Cạm bẫy Swift**: `try` không được đứng bên phải toán tử `?:`/`+` không có ngoặc. Dùng `if/else` hoặc đặt một `try` ở đầu biểu thức.
- Giữ nguyên các giới hạn kích thước/ngân sách của bản Java (đây là phần phòng thủ có chủ đích).
- Đa luồng: GattChannel chạy trên `DispatchQueue` tuần tự; callback trả về qua `LinkChannelListener` kèm `epoch` để bỏ qua kết nối cũ.

## 5. Khác biệt iOS cần xử lý (đã biết)
- **Chỉ BLE (GATT)** dùng được: Android có thêm RFCOMM (Bluetooth Classic) – iOS không cho app thường dùng ⇒ bỏ `RfcommChannel`.
- iOS không có địa chỉ MAC; đồng hồ được nhận diện bằng `CBPeripheral.identifier` (UUID). Mọi chỗ Java lưu MAC phải đổi sang UUID (lưu dạng String).
- iOS tự xử lý MTU/CCCD; ghép nối hệ thống xảy ra tự động khi truy cập characteristic mã hoá. Không tự huỷ ghép nối được.
- GATT hằng số: service `FE86`, ghi `FE01`, nhận `FE02` (đã cài trong GattChannel).
- Lưu Secret/khoá vào **Keychain** (không dùng UserDefaults). Ghi `learnedSecret` TRƯỚC khi gửi bước S4 của ISO (xem chú thích đầu IsoAuth.swift).
- Không có `SecureRandom`: dùng `WMRandom.bytes(n)` (SecRandomCopyBytes).
- AES-GCM tự cài (`AESGCMManual`) vì IV 16 byte; thuật toán đã được đối chiếu với thư viện chuẩn bằng mô phỏng Python (khớp).
- Đọc file HWT: HWT là container ZIP chứa `watchface.bin`. Foundation không có API ZIP ⇒ tự viết bộ đọc ZIP tối thiểu (parse central directory; giải nén kiểu deflate bằng `import Compression` với `COMPRESSION_ZLIB`, là raw-deflate). Nhớ giữ giới hạn `WMCore.maxSource/maxMember` và chống ZIP-bomb/path traversal như bản Java.
- Chọn file trong app: `UIDocumentPickerViewController`/`.fileImporter` (cần `startAccessingSecurityScopedResource`).
- Đăng nhập Huawei ID: `WKWebView` (cookie/session quản lý trong `WKWebsiteDataStore`); tham khảo `account/*.kt`.
- Quét thiết bị: bản Java lọc theo cách nào thì đọc `WatchScanner.java`; trên iOS nên thử `scanForPeripherals(withServices: nil)` rồi lọc theo tên/manufacturer data nếu đồng hồ không quảng bá FE86.

## 6. Luồng nghiệp vụ (từ README gốc – xác nhận lại bằng Java khi port)
1. Kết nối BLE → `LinkCapabilities` (link params 01/…, security, services, commands, expand) → xác thực ISO (`IsoAuth`) hoặc Lite (`LiteAuth`) theo `caps.iso()`/`caps.lite()`.
2. Sau khi có khoá phiên: `CryptoSession.seal/open` bọc mọi gói nghiệp vụ (phong bì TLV 7c/7d/7e).
3. Đọc danh sách mặt đồng hồ `0x27/0x02` (`Wire.list`, `Wire.faces`), giữ ID, phiên bản, cờ type thô.
4. Chuẩn bị tải: lấy `watchface.bin` từ HWT, đóng băng + kiểm tra băm.
5. Thay thế: `0x27/0x03` với phiên bản +1 ở trường số cuối (`Wire.operation`); chỉ khi phản hồi thật có `error=0, need=1` mới truyền file; `need=0` thì dừng.
6. Truyền file bằng giao thức `0x28` (FileTransfer): đăng ký file, nhận file ID, thương lượng đơn vị/mã hoá, trả lời digest/chunk/final.
7. Xác minh: kết quả truyền và báo cáo áp dụng được ghi riêng; truy vấn lại danh sách mặt đồng hồ, kiểm tra cùng ID với phiên bản ứng viên. Không coi "100%" là thành công.
- Xoá mặt đồng hồ: `Wire.deletion` (op=2, đúng phiên bản đang cài), xong thì truy vấn lại danh sách.

## 7. Chưa được kiểm chứng (RỦI RO)
- **Chưa có đoạn Swift nào được biên dịch** (môi trường tạo ra không có `swiftc`). Lần build GitHub Actions đầu tiên sẽ lộ lỗi cú pháp/kiểu; sửa theo log.
- GattChannel chưa thử trên đồng hồ thật (đặc biệt: đồng hồ có quảng bá service FE86 không; có cần ghép nối hệ thống trước không).
- Chỉ logic GCM đã được kiểm chứng bằng mô phỏng; các phần mật mã còn lại (HKDF/HMAC/PBKDF2/ISO) port theo Java, chưa có test vector.
- Nên thêm unit test (XCTest) dùng lại các test của Java nếu có (`app/src/test`… trong zip gốc không có thư mục test, chỉ có tác vụ `testDebugUnitTest` trong README).

## 8. Cách làm tiếp
1. Đọc Java của phần kế tiếp (xem bảng mục 3), port từng file, giữ mã lỗi/giới hạn.
2. Đặt file đúng thư mục `WristMirror/<Protocol|Transport|Store|App|Views>/`.
3. Cập nhật bảng trạng thái ở mục 3 và `README_IOS.md`.
4. Đóng zip chỉ chứa file mới/đổi (giải nén chồng lên được), hoặc zip toàn bộ dự án.
5. Giấy phép: giữ Apache-2.0; không chép mã/SDK của Huawei Health (xem `THIRD_PARTY_NOTICES.md` của bản gốc, nên copy sang dự án iOS).

## 9. Ghi chú Phần 5 (dành cho Phần 6/7/8)
- **Khoá thiết bị = UUID của `CBPeripheral`** (chuỗi viết hoa; chuẩn hoá bằng `DeviceRemovalGuard.canonical`). Mọi chỗ Java dùng MAC đều đã đổi.
- `WatchConnection(store:log:deviceModel:)`; truyền `UIDevice.current.model` cho `deviceModel`. Giữ một tham chiếu mạnh tới `WatchConnection` (GattChannel giữ listener yếu). `setListener` giữ yếu.
- Gọi từ UI: `connect(deviceId:account:)`, `submitPin(expectedEpoch:entered:)`, `confirmRebind(expectedEpoch:)`, `respondAgreements(expectedEpoch:accept:)`, `disconnect()`.
- Sau READY: `sendControl(service,command,body)` (gói 0x27, mã hoá) và `sendFile(command,body,encrypt:)` (0x28); gói nghiệp vụ nhận về qua `onPacket` (đã giải mã). `post/execute/delay` chạy trên hàng đợi giao thức; `capabilities` chỉ đọc trên hàng đợi này.
- Giai đoạn `SYSTEM_PAIRING` của bản Java không còn (iOS tự ghép nối khi truy cập characteristic mã hoá).
- `stopForRemoval(id)` (thay `stopForUnpair`) bắt buộc gọi trên hàng đợi giao thức: `connection.post { try? connection.stopForRemoval(id) }`. Quy trình xoá đồng hồ: `removals.beginRemoval` → `stopForRemoval` → `store.clearDevice` → `removals.finishRemoval` (nếu lỗi: `cancelRemoval`).
- Chuỗi mô tả giai đoạn (UI) đã dịch sang tiếng Việt; mã giai đoạn/mã lỗi giữ nguyên tiếng Anh như Java.
- `WatchScanner` lọc theo tên (huawei/honor/watch/华为/荣耀) HOẶC quảng bá service FE86; callback trên main queue.
- Chưa có đoạn Swift nào được biên dịch (xem mục 7). Các điểm dễ lỗi khi build lần đầu: các chuỗi `+` dài của `[UInt8]`, `try` trong biểu thức, `private(set)` trên thuộc tính tính toán ở `WatchConnection`.

## 10. Ghi chú Phần 6 (dành cho Phần 7/8)
- `FacePolicy.isCurrent(face)` (Java `FacePolicy.current`), `eligible`, `canActivate`, `kind` (nhãn tiếng Việt), `defaultSelection`.
- `VersionPolicy.next(id:baseline:listed:)` → phiên bản ứng viên (chỉ +1 trường cuối).
- `WireNames.request(faces:language:)` (rỗng ⇒ bỏ qua gửi), `WireNames.parseResponse(fields)` → `Response{names, orderedNames, ids, malformedNameCount}`.
- Các lớp `*State` là **class** (tham chiếu, đổi được như Java). `Action` là enum `.none/.query/.upload/.activate`. Tham số nhãn: `operation(error:need:echo:)`, `report(type:error:)`, `list(_:generation:ownQuery:serial:)` (Deletion: `querySerial:`), `ReplacementState.list(_:queryGeneration:ownQuery:)`.
- `NameQueryState.next(now:)`/`expire(now:)` dùng mili-giây `Int64`.
- `HwtSource.load(from: URL, privateFiles: URL)`: UI phải gọi `startAccessingSecurityScopedResource()` quanh lời gọi. `privateFiles` nên là Application Support. `freeze(.bin)` → `Snapshot` (chỉ-đọc 0o400); `HwtSource.cleanup(privateFiles:directory:)` xoá thư mục `source-<uuid>`.
- `ZipArchive` chỉ hỗ trợ stored/deflate, không mã hoá, không ZIP64; deflate dùng `Compression` (`COMPRESSION_ZLIB` = raw deflate). Chưa thử trên file HWT thật.
- `FileTransfer(id:installedProtocolVersion:frozen:)`: `metadataBody()` (gửi 0x28/0x02, seal=true) → `onPacket(command:body:transactionsCrypted:)` trả `[Outgoing(command, encrypt, body)]`; bên gọi (WatchfaceManager, Phần 7) gửi qua `WatchConnection.sendFile(command:body:encrypt:)`. Đọc kết quả: `peerResultRaw`, `resultObserved`, `peerComplete`, `completionFailure`. Gọi `close()` khi xong.
- Danh tính file: dùng `systemNumber:systemFileNumber` thay cho `fileKey` của Java; kiểm tra symlink qua `.type == .typeRegular`.
- Rủi ro biên dịch cần soi ở build đầu: `ZipArchive.stream` (con trỏ `compression_stream` trong closure), `HwtSource` (init throwing với nhiều `let`), `FileTransfer.init` (dùng `self` sau khi gán đủ thuộc tính).

## 11. Thêm thông tin vào HWT có sẵn + Studio (mới, CHƯA biên dịch/chưa thử máy thật)
Mã dữ liệu (valueType) đọc từ 2 file HWT thật (Versaled, p0187VietNam), giải mã bằng script Python:
- Dương lịch: tháng 51 (13 mục, mục 0 đệm), chục ngày 70 (4 mục 0..3), đơn vị ngày 71 (10 mục).
- Âm lịch: tháng 92, chục ngày 93 (5 mục), đơn vị ngày 94.
- Thứ: 52, 8 mục (mục 0 đệm lặp "Thứ hai"; 1 = thứ hai ... 7 = chủ nhật).
- Giờ số 24h: chục giờ 59 (3 mục), giờ 60 (10), chục phút 61 (6), phút 62 (10); 63/64 = chục/đơn vị giây (chưa dùng).
- Kim: 150 giờ, 153 phút, 154 giây. Mã 50 (3 mục) có trong Versaled, chưa rõ nghĩa.
- Pin, thời tiết, bước chân, nhịp tim, calo: ĐÃ CÓ mã, đọc từ 3 file Kozmik (Kule, Kristal, Ultimate; ảnh cover đối chiếu từng mục), xem mục 12.
- File HWT thật: `com.huawei.watchface` KHÔNG phải ZIP mà chính là `watchface.bin`; không có hashCode, ability.xml, ảnh xem trước. Thứ tự phần tử: 0 (nền), 3, 2 (ngày), 1 (giờ). Code đã xử lý (nhánh không ZIP).
Code:
- `Store/FaceLunar.swift` (khối ngày/tháng dùng chung âm/dương), `Store/FaceInfo.swift` (thứ, giờ số, tên, gom `infoLayers`/`drawInfoPreview`), `Store/HwtLunarPatch.swift` (chèn vào HWT có sẵn, `HwtLunarPatch.apply`; từ chối nếu file đã có mã trùng), `Views/InfoSettingsView.swift` (UI dùng chung Studio + "Thêm thông tin" trong chi tiết thư viện).
- Phần chèn vào bin đã mô phỏng bằng Python trên 2 file thật (header, bảng ảnh, phần tử mới, ảnh cũ nguyên vẹn). Cả hai file mẫu đã có âm lịch + giờ số nên sẽ bị từ chối nếu bật các mục đó; dùng được "Tên" và "Dương lịch"/"Thứ" khi file chưa có.
- Test: `LunarPatchTests` trong `BuilderTests.swift`. Việc kế tiếp: build GitHub Actions, thử máy thật, thêm pin/thời tiết/bước/nhịp tim khi có file mẫu.

## 12. Số liệu pin / bước chân / nhịp tim / calo / thời tiết (mới, CHƯA biên dịch/chưa thử máy thật)
Nguồn: 3 file `Kozmik*_EN.hwt` (bản mới của HWHD09: có thêm trường 7 = biến thể màu, trường 8 = "widget" trong phần tử 3, nên cấu trúc ngoài khác file cũ).
Lớp (layer) dùng chung một lược đồ ở mọi nơi nên app tái sử dụng trong phần tử "ngày" kiểu cũ (trường 5):
- Lớp loại 3 = SỐ do đồng hồ cập nhật: trường 6 = {1: 10 ảnh chữ số 0..9, 2: ảnh dấu trừ (lặp 2 lần), 3: {x,y}, 4: căn lề (0 trái, 1 giữa, 2 phải), 5: mã loại số liệu, 6: ảnh đơn vị ghép sau số hoặc rỗng, 13: 0}.
  Đã mô phỏng bằng Python: mã hoá lại đúng từng byte cả 25 lớp số trong 3 file (script ở lịch sử phiên làm việc; test `testNumberLayerMatchesRealFile`).
- Mã loại số liệu: 0 bước chân, 1 calo, 2 nhịp tim, 4 nhiệt độ hiện tại, 9 pin %, 18/19 nhịp tim cao/thấp, 20/21 nhiệt độ cao/thấp, 15 giờ đứng, 26 căng thẳng (3 mã cuối chưa dùng).
- Thời tiết: lớp dãy ảnh (loại 2) mã 53, 11 mục: 0 không dữ liệu, 1 nắng, 2 quang, 3 ít mây, 4 nhiều mây, 5 mưa, 6 dông, 7 tuyết, 8 bão cát, 9 mù, 10 sương mù (dùng cho cả biểu tượng và tên tình trạng).
- Chưa dùng: lớp loại 6/7 (thanh/vòng tiến độ), lớp loại 0 (chữ: bình minh/hoàng hôn 121/122, giấc ngủ 142, quãng đường 146), mã tap "code" của widget (trường 8), mã 116 (pha trăng), 117 (mức căng thẳng).
Code: `Store/FaceData.swift` (`DataWidget`, `DataKind`, `WeatherLayout`, `dataLayers`, `drawDataPreview`), `HwtLayer.number` + `HwtDataType` trong `HwtBuilder.swift`, UI trong `InfoSettingsView.swift`.
Rủi ro cần thử máy thật: (1) firmware có chấp nhận lớp số đặt trong phần tử kiểu cũ (trường 5) thay vì widget (trường 8) không; (2) ý nghĩa trường 13 của lớp số (đang để 0 = không AOD); (3) biểu tượng thời tiết dùng SF Symbols nên cần iOS 15+.
Nếu (1) sai: gói các lớp số vào một phần tử số hiệu 3 theo cấu trúc widget như file Kozmik (xem script phân tích trong lịch sử phiên).

## 13. 26 kiểu kim + hiệu ứng mùa (mới, CHƯA biên dịch/chưa thử máy thật)
- Kim: `FaceDesign.HandStyle` nay có 26 case (3 cơ bản + 23 vector). 23 kiểu mới nằm trong `Store/HandShapes.swift` dưới dạng chuỗi lệnh SVG rút gọn (M L Q C Z, O = hình tròn; x theo bề rộng kim, y âm theo tầm kim, y dương theo đuôi), vẽ bằng `HandShapes.draw` (thân tô liền, lỗ khoét bằng blend `.clear` trong transparency layer, mảng tối `shade`, mảng sáng `lume`). Kim giây luôn là thanh mảnh. `handImage` mở rộng ảnh kim gấp ~2.1 lần bề rộng cho kiểu vector. Bản SVG của 23 kiểu: `design/hands_svg/`.
- Hiệu ứng mùa: 7 họa tiết mới trong `DecorPattern` (đào, mai, anh đào, tuyết, lá thu, tia nắng, vòng hoa), vẽ trong `Store/SeasonFX.swift` (`SeasonArt.draw`): chuyển sắc, bóng đổ, gân cánh, nhị hoa. Là lớp quay thật theo kim giờ/phút/giây qua cơ chế `DecorLayer` cũ (xuất thành ảnh PNG trong HWT). Đồng hồ KHÔNG có hạt rơi thật; hạt rơi thật chỉ ở `SeasonFallView` (xem trước trong Studio).
- 6 mẫu mới trong `FacePresets`: peachTet, apricotTet, snowWinter, sunSummer, autumnLeaf, garland.
- Rủi ro: chưa biên dịch; xem trước Studio vẽ lại mỗi lần chỉnh nên hiệu ứng mùa có thể hơi chậm (nếu giật, thu nhỏ `count` trong `SeasonArt.draw` hoặc lưu nhớ tạm ảnh lớp); kích thước PNG lớp mùa lớn hơn họa tiết cũ.

## 14. Phân tích 4 mặt động Kozmik + xem trước động trong Studio (mới, CHƯA biên dịch/chưa thử máy thật)
Phân tích 4 file: KozmikTavuk_EN, KozmikSemazen, Kozmik_Equinox_EN__1_, KozmikCam_EN_v10 (đều HWHD09, `com.huawei.watchface` = bin thô, 4 phần tử 0,3,2,1 như mục 11).
Các kiểu "động" thực sự có trong file:
- **Kim quay theo đồng hồ**: lớp loại 5 (valueType 150 giờ / 153 phút / 154 giây), ảnh kim to bằng cả mặt (466x466) trong Semazen.
- **Dãy ảnh đổi theo số liệu** (lớp loại 2, trường 3 = valueType, KHÔNG phải thời lượng khung hình): ngày 70/71, tháng 51, thứ 52, giờ 59/60, phút 61/62 và **giây 63/64**. Tavuk "gà mổ thóc mỗi giây" = dãy 10 ảnh gắn valueType 64 (chữ số đơn vị giây): mỗi giây đổi một ảnh. Đây là loại chuyển động có thật trên đồng hồ mà `HwtLayer.array` của app đã mã hoá được (chưa dùng mã 63/64).
- **Hoạt ảnh theo thời gian thật**: chỉ thấy ở Semazen trang 0: phần tử trường 9 loại 11, 24 ảnh (223..246), trường 3 = {x,y}, 3 và 4 = 50 và 100 (nghi là chu kỳ ms và tham số lặp), 3 phần tử bắt đầu lệch khung (230, 237). Cam trang 1 có dãy 28 ảnh với số 248 ở trường 3, chưa rõ là valueType hay chu kỳ. CHƯA giải mã chắc chắn, app chưa xuất được loại này.
- Trường 6 của dãy ảnh (0/1) có thể là cờ lặp/AOD, chưa kiểm chứng.
Đã làm (Phần 10): `Views/LivePreview.swift` (`LiveFaceAssets`, `LiveFaceView`, `GlowRing`, `staggerIn`) + sửa `Views/StudioView.swift`: xem trước chạy kim giờ thật (hoặc cố định 10:08:35), kim giây quét mượt, lớp quay chạy thật, vòng sáng, thẻ trượt lên lần lượt, nhấp nhẹ khi áp mẫu. Chỉ là xem trước trong app, không đổi file HWT xuất ra.
Việc kế tiếp: (a) lớp "chuyển động theo giây" xuất ra HWT bằng `.array` valueType 64 (10 ảnh/giây như Tavuk); (b) giải mã phần tử loại 11 của Semazen bằng cách so sánh byte rồi mới thêm vào `HwtLayer`.

## 15. Chuyển động theo giây (Phần 11, mới, CHƯA biên dịch/chưa thử máy thật)
- `Store/SecondFX.swift`: `SecondFX` (none, dotChase, bloom, arc, pulse), `FaceRenderer.drawSecondFX/secondFXFrames` (10 ảnh 466x466 trong suốt).
- `FaceDesign.secondFX`, `secondFXColor`; `FaceBuilder.build` thêm `.array(resources: 10 ảnh, x:0, y:0, valueType: HwtValueType.secondOnes (64), ambient:false)` vào phần tử giờ, dưới kim.
- Xem trước: `LiveFaceAssets.fxFrames` + `LiveFaceView` đổi khung theo chữ số giây. UI: `secondFXCard` trong Studio.
- Rủi ro cần thử máy thật: firmware có nhận dãy ảnh mã 64 đặt trong phần tử giờ không (file Kozmik đặt ở phần tử 1, cùng chỗ nên khả năng cao); ảnh trong suốt toàn mặt tốn bộ nhớ đồng hồ hơn ảnh nhỏ.
- Chưa làm: hoạt ảnh loại 11 của Semazen (Phần 12).

## 16. Hoạt ảnh xoay liên tục, lớp loại 11 (Phần 12, THỬ NGHIỆM, CHƯA biên dịch/chưa thử máy thật)
Giải mã từ KozmikSemazen trang 0 (chỉ file này có): 3 phần tử trường 9 (không phải trường 5), `{1: chỉ số lớp (nối tiếp lớp trường 5), 2: 11, 3: {1: 24 ảnh (lặp), 2: {x,y}, 3: 50, 4: 100, 5: 1, 6..9: 0}, 4: {11: {1:0,2:0}, 12..17: 0}}`. Ảnh 92x92 là dervish quay trọn một vòng trong 24 khung; 3 bản bắt đầu ở khung 0, 7, 14 (lệch pha).
- Trường 3 của nhóm 3 = ms mỗi khung (nghi, khớp 50 ms x 24 = 1,2 s/vòng). Trường 4 = 100 và 5 = 1 chưa rõ nghĩa (nghi 100% độ đục / bật lặp), nhóm 4 toàn 0: app chép đúng giá trị của file thật. Trường 9 của nhóm 3 đang dùng làm cờ AOD (suy từ lớp kim, chưa kiểm chứng).
- Code: `HwtLayer.animation`, nhánh trường 9 trong `HwtBuilder.layoutBytes`, `Store/AnimFX.swift`, `FaceDesign.anim*`, thẻ `animCard` trong Studio, xem trước xoay ở `LiveFaceView`.
- Mặt đồng hồ tự tạo đặt lớp này cuối phần tử nền (vẽ trên nền, dưới kim). Chưa có test; việc cần làm: thêm test so `layoutBytes` với byte thật của Semazen.

## 17. Hoạt ảnh hạt rơi: tuyết / lá / hoa (Phần 13, THỬ NGHIỆM, CHƯA biên dịch/chưa thử máy thật)
- `Store/FallFX.swift` (mới): `AnimKind {spin,snow,leaves,petals}`, `FaceRenderer.fallStrips(design)` → 3 dải cột (cao 466 px, rộng ~185/216/186 px gồm lề 36 px) × 24/32/48 khung ARGB. Mỗi dải là một lớp `.animation` riêng (cùng `intervalMs`, nội dung khác nhau), đặt ở `x = imgX, y = 0`, vẽ trên nền, dưới kim, chỉ ban ngày (không AOD).
- Lặp liền mạch: mọi hạt rơi đúng 466 px mỗi vòng (y = (y0 + 466·t) mod 466), lắc ngang/xoay/lật dùng số chu kỳ NGUYÊN; hạt vẽ hai bản (y và y−466) để qua mép dưới hiện lại ở mép trên. Hạt sinh bằng RNG cố định (SplitMix) nên bản xem trước = bản xuất.
- Hạt tự vẽ (không dùng `SeasonArt`, vì zip này không có file đó): tuyết (chấm mềm / tinh thể 6 nhánh khi bán kính ≥ 4,2 px), lá (5 màu thu, gân + cuống, nửa lá tối), hoa anh đào (4 màu hồng).
- `FaceDesign`: thêm `animKind`, `animFallFrames` (24/32/48), `animDensity`. `buildHwt`: nhánh `animKind.isFall` thêm 3 lớp animation. Xem trước: `LiveFaceAssets.fall` + vẽ trong `LiveFaceView`. UI: thẻ `animCard` có chọn kiểu, mật độ, số khung, chu kỳ.
- Rủi ro: 3 dải × 32 khung ≈ 28 MB ảnh thô trên đồng hồ (hiện cảnh báo trong app); số ảnh = 3 × số khung (tối đa 144, giới hạn 300 của HwtBuilder gồm cả ảnh khác); chưa rõ đồng hồ có chịu được không. Tốc độ rơi cố định = 466 px / (số khung × ms) nên muốn rơi chậm hơn phải tăng số khung hoặc ms (tối đa 120).
- Chưa làm: tái dùng hình lá/tuyết của `SeasonArt` (cần file đó); rơi cho AOD.

## 18. Bản ghép đầy đủ (Phần 13) – LƯU Ý
- Ghép từ WristMirror-iOS-merged (đến mục 12) + phan12-anim + phan13-fall. Các file còn THIẾU trong bản ghép (nằm ở phần giữa, chưa có zip): `HandShapes.swift` (23 kiểu kim vector), `SeasonArt.swift`, `SeasonFallView`, `HandThumbs` và `DecorPattern.isSeasonal/.seasonal/.geometric`.
- `Store/CompatStubs.swift` thay tạm các phần đó để project biên dịch được: kiểu kim ngoài Thanh/Nhọn/Cổ điển vẽ như kim Thanh; hiệu ứng mùa trống. Khi có file thật thì XOÁ `CompatStubs.swift`.
- Chưa biên dịch: nếu build lỗi, gửi log (`out/build.log`) để sửa.

## 19. Sửa lỗi hiệu ứng/hoạt ảnh không chạy liên tục trên đồng hồ (Phần 14, CHƯA biên dịch/chưa thử máy thật)
Nghi nguyên nhân (chưa xác nhận trên máy): (1) ảnh quá nặng: hiệu ứng giây từng là 10 ảnh 466x466 (~8,7 MB), hoạt ảnh xoay cạnh tới 443 px x 24 khung (~18 MB) trong khi file mẫu Semazen chỉ ~0,8 MB; (2) tắt kim giây thì đồng hồ có thể chỉ vẽ lại mỗi phút nên dãy ảnh mã 64 đứng yên.
- `SecondFX.swift`: `secondFXCropped` cắt 10 khung về hộp nhỏ nhất (Hoa nở ~230 px), `secondFXRawMegabytes`, `animSpinRawMegabytes`.
- `FaceDesign.buildHwt`: dãy mã 64 dùng x,y của hộp cắt; nếu `!showSecond` thêm kim giây vô hình 2x2 (valueType giây) để buộc cập nhật mỗi giây.
- `AnimFX.animLayer`: kẹp kích thước ≤ 0,5 mặt; Studio: thanh Kích thước 0,2...0,5 + hiện MB ảnh thô.
- Còn nghi chưa kiểm chứng: trường 4 (=100) và 5 (=1) của lớp loại 11 có thể là số lần lặp/chế độ lặp; nếu vẫn dừng sau một lúc, thử đổi các giá trị này.
- Phần 14b: bản cũ hoạt ảnh mượt nhưng chỉ chạy một lượt rồi nghỉ vài giây ⇒ nghi trường 4/5 của lớp loại 11. Thêm `FaceDesign.animLoopMode` + `HwtFaceSpec.animLoopMode` (A=100/1 chép Semazen, B=100/0, C=0/1, D=0/0) và bộ chọn "Kiểu lặp (thử)" trong thẻ hoạt ảnh; cần thử B/C/D trên đồng hồ và ghi lại kiểu nào lặp liên tục.
- Phần 14c: "Thêm thông tin" làm app báo có âm/dương lịch nhưng đồng hồ không hiện (log: truyền xong, mặt được liệt kê, `visual_application_unverified`). Nghi số hiệu phần tử mới = max+1 (vd. 4) chưa từng thử trên máy. Nay `HwtLunarPatch.mergeIntoElement` nhét lớp mới vào phần tử số 2 có sẵn (chỉ số lớp tiếp theo, `HwtFaceSpec.layerIndexBase`); không được (có hoạt ảnh/không có lớp) thì quay lại thêm phần tử mới. CHƯA biên dịch/thử máy thật. Nghi thêm: ability.xml gốc có thể thiếu bit mã âm lịch — cần file Kozmik_Equinox_EN.hwt gốc để kiểm.
- Phần 14d: ĐÃ XÁC NHẬN trên máy thật: gộp lớp âm/dương lịch vào phần tử số 2 có sẵn thì đồng hồ hiện đúng; phần tử mới số 4 thì không hiện. `mergeIntoElement` là cách mặc định (chưa biên dịch bằng Swift, đã mô phỏng bằng Python trên Kozmik_Equinox_EN). Chỉ số lớp của phần tử file thật bắt đầu từ 1, code lấy max+1 nên khớp.
- Phần 14e: kiểm 4 file mẫu. Equinox/Semazen (lớp ở trường 5, có phần tử số 2) gộp được. Kozmik Cam/Tavuk dùng định dạng bố cục mới (lớp ở trường 7 trong mỗi phần tử, trường 2 của phần tử = 1, có trường 5 cấp cao nhất) => `patchBin` ném `LUNAR_FORMAT_UNSUPPORTED`. Bỏ nhánh thêm phần tử số 4 (đồng hồ không hiện): không gộp được thì ném `LUNAR_NO_SLOT`. Semazen đã có dương lịch (mã 70/71) và thứ, giờ số nên chỉ thêm được âm lịch. CHƯA biên dịch Swift.
- Phần 14f: đã đọc định dạng bố cục MỚI (Kozmik Cam/Tavuk): phần tử có nhiều "kiểu" ở trường 7 (trường 1 = số kiểu, trường 2 = các lớp {1=chỉ số, 2=loại, thân 4/5/6/8 như cũ}, trường 3 = tên ảnh xem trước); Cam có 4 kiểu ở phần tử 0/1/2 và 10 kiểu ở phần tử 3 (ô phụ). Cam/Tavuk đã có dương lịch (51/70/71) + thứ (52) ở phần tử 2 nhưng chưa có âm lịch. `HwtLunarPatch.mergeIntoModes` thêm lớp vào cuối MỖI kiểu của phần tử 2 (tag 0x12), `existingValueTypes` đọc cả trường 7. Mô phỏng bằng Python và tạo 2 file thử (KozmikCam_EN_amlich_test.hwt, KozmikTavuk_EN_amlich_test.hwt, chỉ lớp âm lịch lấy từ ảnh Equinox nên vị trí có thể chồng lên chữ có sẵn). CHƯA thử máy thật, CHƯA biên dịch Swift. Lớp của Cam/Tavuk có cờ AOD=1 ở nhiều lớp ngày: chưa rõ ý nghĩa.

## 16. Biểu tượng SVG riêng, khung nền SVG, font chữ/số, nền AOD gốc (phần 15, CHƯA biên dịch/chưa thử máy thật)
- `Store/FaceSVG.swift`: `MiniSVG` (đọc path M L H V C S Q Z, circle, ellipse, rect; màu theo palette), `PlateStyle` + `FacePlate` (6 khung nền SVG, tạo chuỗi SVG theo kích thước thật), `drawPlatesPreview`/`plateLayers` (khung nền là lớp `.single` đặt TRƯỚC các lớp chữ), `drawWeatherIcon`/`drawDataIcon`.
- `Store/FaceSVGData.swift`: 11 biểu tượng thời tiết + pin, bước chân, tim, calo (viewBox 100x100). `FaceDesign.iconSVG` bật/tắt (tắt = SF Symbols). `FaceDesign.plates[key]` với key: digital, weekday, solar, lunar, weather, battery, steps, heart, calories, name.
- `Store/FaceFonts.swift`: `FaceFont` (6 font), `FaceDesign.textFontIndex`/`numberFontIndex`.
- `FaceDesign.AodBackground.original` = AOD dùng nền ban ngày.
- Pin đổi theo mức: CHƯA làm được; cần mã valueType của dãy ảnh theo mức pin (chưa giải mã, chỉ biết mã số liệu 9 cho lớp số). Cần file HWT thật có biểu tượng pin đổi theo mức để đối chiếu.
