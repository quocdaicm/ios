// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import PhotosUI

/// Trạng thái màn hình "Tạo mặt đồng hồ": giữ thiết kế, vẽ lại ảnh xem trước mỗi khi thiết kế đổi.
final class StudioModel: ObservableObject {
    @Published var design = FaceDesign() {
        didSet { refreshPreview() }
    }
    @Published private(set) var dayPreview: UIImage?
    @Published private(set) var aodPreview: UIImage?
    @Published private(set) var dayAssets: LiveFaceAssets?
    @Published private(set) var aodAssets: LiveFaceAssets?
    @Published private(set) var building = false

    private static let previewPixels = 320

    init() { refreshPreview() }

    private func refreshPreview() {
        let day = LiveFaceAssets.build(design: design, ambient: false, pixels: StudioModel.previewPixels)
        let aod = LiveFaceAssets.build(design: design, ambient: true, pixels: StudioModel.previewPixels)
        dayAssets = day
        aodAssets = aod
        dayPreview = day.base
        aodPreview = aod.base
    }

    func setPhoto(_ image: UIImage?) {
        var d = design
        d.photo = image.map { FaceRenderer.downscale($0, maxSide: 1600) }
        d.photoZoom = 1; d.photoPanX = 0; d.photoPanY = 0
        design = d
    }

    /// Dựng file .hwt ở luồng nền rồi gọi `completion` trên main.
    func export(completion: @escaping (Result<URL, Error>) -> Void) {
        guard !building else { return }
        let snapshot = design
        building = true
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let result: Result<URL, Error>
            do {
                let bytes = try FaceBuilder.build(snapshot)
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("wm-studio-\(UUID().uuidString)", isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(FaceBuilder.fileName(snapshot.name))
                try Data(bytes).write(to: url, options: .atomic)
                result = .success(url)
            } catch {
                result = .failure(error)
            }
            DispatchQueue.main.async {
                self?.building = false
                completion(result)
            }
        }
    }
}

struct StudioView: View {
    @EnvironmentObject var vm: WatchViewModel
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = StudioModel()
    @State private var pickerItem: PhotosPickerItem?
    @State private var errorText: String?
    @State private var showFall = true
    @State private var liveClock = true
    @State private var pulse = false

    private var busy: Bool { vm.ui.operation.active || model.building }

    var body: some View {
        VStack(spacing: 0) {
            // Khung xem trước cố định phía trên; phần bên dưới cuộn.
            previewCard
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 8)
            ScrollView {
            VStack(spacing: 16) {
                presetCard.staggerIn(1)
                nameCard.staggerIn(2)
                backgroundCard.staggerIn(3)
                decorCard.staggerIn(4)
                lunarCard.staggerIn(5)
                marksCard.staggerIn(6)
                handsCard.staggerIn(7)
                secondFXCard.staggerIn(8)
                animCard.staggerIn(8)
                aodCard.staggerIn(8)
                saveButton.staggerIn(8)
            }
            .padding(16)
            }
        }
        .background(AppBackground())
        .navigationTitle("Tạo mặt đồng hồ")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Không tạo được mặt đồng hồ", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button("Đóng", role: .cancel) {}
        } message: {
            Text(errorText ?? "")
        }
    }

    // MARK: Xem trước

    private var previewCard: some View {
        VStack(spacing: 12) {
            HStack(spacing: 16) {
                previewCircle(model.dayAssets, fallback: model.dayPreview,
                              title: showFall && !fallPatterns.isEmpty ? "Ban ngày (hạt rơi chỉ để xem thử)" : "Ban ngày",
                              fall: showFall ? fallPatterns : [], glow: true)
                previewCircle(model.aodAssets, fallback: model.aodPreview, title: "AOD (màn hình tắt)")
            }
            .scaleEffect(pulse ? 0.94 : 1)

            Picker("Giờ xem thử", selection: $liveClock) {
                Text("Giờ thật").tag(true)
                Text("10:08:35").tag(false)
            }
            .pickerStyle(.segmented)
        }
        .frame(maxWidth: .infinity)
        .card()
    }

    /// Nhấp nhẹ bản xem trước khi áp một mẫu mới.
    private func pulsePreview() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        withAnimation(.easeOut(duration: 0.12)) { pulse = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.55)) { pulse = false }
        }
    }

    /// Các hiệu ứng mùa có hạt rơi trong thiết kế hiện tại.
    private var fallPatterns: [DecorPattern] {
        var seen = [DecorPattern]()
        for l in model.design.decor where l.pattern.isSeasonal && !SeasonArt.fallSprites(l.pattern).isEmpty {
            if !seen.contains(l.pattern) { seen.append(l.pattern) }
        }
        return seen
    }

    private func previewCircle(_ assets: LiveFaceAssets?, fallback: UIImage?, title: String,
                               fall: [DecorPattern] = [], glow: Bool = false) -> some View {
        VStack(spacing: 6) {
            ZStack {
                if glow { GlowRing().padding(-5) }
                Circle().fill(Color.black)
                if let assets = assets {
                    LiveFaceView(assets: assets,
                                 fixed: liveClock ? nil : LiveFaceTime(hour: 10, minute: 8, second: 35))
                        .clipShape(Circle())
                } else if let image = fallback {
                    Image(uiImage: image).resizable().scaledToFit().clipShape(Circle())
                }
                if !fall.isEmpty {
                    SeasonFallView(patterns: fall).clipShape(Circle())
                }
            }
            .frame(maxWidth: 130, maxHeight: 130)
            .aspectRatio(1, contentMode: .fit)
            Text(title).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Mẫu có sẵn

    private var presetCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Mẫu có sẵn").font(.headline)
            Text("Chạm để áp dụng một mẫu vector, rồi chỉnh tiếp bên dưới. Tên và tác giả của bạn được giữ nguyên.")
                .font(.footnote).foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(FacePresets.all) { preset in
                        Button {
                            pickerItem = nil
                            pulsePreview()
                            model.design = FacePresets.apply(preset, to: model.design)
                        } label: {
                            VStack(spacing: 4) {
                                Image(uiImage: FacePresetThumbs.image(preset))
                                    .resizable()
                                    .frame(width: 72, height: 72)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                                Text(preset.title).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .card()
    }

    // MARK: Tên

    private var nameCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Tên và tác giả").font(.headline)
            TextField("Tên mặt đồng hồ", text: $model.design.name)
                .textFieldStyle(.roundedBorder)
            TextField("Tác giả (không bắt buộc)", text: $model.design.author)
                .textFieldStyle(.roundedBorder)
        }
        .card()
    }

    // MARK: Nền

    private var backgroundCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Nền").font(.headline)

            PhotosPicker(selection: $pickerItem, matching: .images) {
                Label(model.design.photo == nil ? "Chọn ảnh nền" : "Đổi ảnh nền", systemImage: "photo")
            }
            .buttonStyle(SecondaryButtonStyle())
            .onChange(of: pickerItem) { item in
                guard let item = item else { return }
                _ = item.loadTransferable(type: Data.self) { result in
                    DispatchQueue.main.async {
                        if case .success(let data?) = result, let img = UIImage(data: data) {
                            model.setPhoto(img)
                        } else {
                            errorText = "Không đọc được ảnh đã chọn."
                        }
                    }
                }
            }

            if model.design.photo != nil {
                slider("Phóng to", value: $model.design.photoZoom, range: 1...3)
                slider("Dịch ngang", value: $model.design.photoPanX, range: -1...1)
                slider("Dịch dọc", value: $model.design.photoPanY, range: -1...1)
                slider("Làm tối ảnh", value: $model.design.photoDim, range: 0...0.8)
                Button(role: .destructive) {
                    pickerItem = nil
                    model.setPhoto(nil)
                } label: { Label("Bỏ ảnh nền", systemImage: "xmark.circle") }
                    .buttonStyle(SecondaryButtonStyle(color: Color.red))
            } else {
                ColorPicker("Màu nền", selection: $model.design.backgroundColor, supportsOpacity: false)
                Toggle("Chuyển sắc", isOn: $model.design.useGradient)
                if model.design.useGradient {
                    ColorPicker("Màu nền thứ hai", selection: $model.design.backgroundColor2, supportsOpacity: false)
                }
            }
        }
        .card()
    }

    // MARK: Lớp trang trí

    private var decorCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Lớp trang trí").font(.headline)
            Text("Chọn Giờ, Phút hoặc Giây để lớp quay theo kim tương ứng; Tĩnh là đứng yên.")
                .font(.footnote).foregroundStyle(.secondary)
            if !fallPatterns.isEmpty {
                Toggle("Xem thử hoa/tuyết/lá rơi trên điện thoại", isOn: $showFall)
                Text("Chỉ để xem thử: trên đồng hồ, lớp hoa/tuyết/lá không rơi mà quay theo Giờ, Phút hoặc Giây.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            ForEach($model.design.decor) { $layer in
                decorEditor($layer)
            }
            if model.design.decor.count < FaceRenderer.maxDecor {
                Button {
                    model.design.decor.append(DecorLayer())
                } label: { Label("Thêm lớp trang trí", systemImage: "plus.circle") }
                    .buttonStyle(SecondaryButtonStyle())
            }
        }
        .card()
    }

    private func decorEditor(_ layer: Binding<DecorLayer>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Họa tiết").font(.caption).foregroundStyle(.secondary)
            decorRow(DecorPattern.geometric, layer)
            Text("Hiệu ứng mùa (nhiều màu)").font(.caption).foregroundStyle(.secondary)
            decorRow(DecorPattern.seasonal, layer)
            if !layer.wrappedValue.pattern.isSeasonal {
                ColorPicker("Màu", selection: layer.color, supportsOpacity: false)
            }
            slider("Độ đậm", value: layer.opacity, range: 0.1...1)
            slider("Kích thước", value: layer.scale, range: 0.2...0.95)
            Picker("Chuyển động", selection: layer.spin) {
                ForEach(DecorSpin.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Button(role: .destructive) {
                let id = layer.wrappedValue.id
                model.design.decor.removeAll { $0.id == id }
            } label: { Label("Xóa lớp này", systemImage: "trash") }
                .buttonStyle(SecondaryButtonStyle(color: Color.red))
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.primary.opacity(0.05)))
    }

    private func decorRow(_ patterns: [DecorPattern], _ layer: Binding<DecorLayer>) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(patterns) { p in
                    Button {
                        layer.wrappedValue.pattern = p
                        // Hiệu ứng mùa cần đậm để thấy màu thật
                        if p.isSeasonal && layer.wrappedValue.opacity < 0.8 { layer.wrappedValue.opacity = 0.95 }
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: DecorThumbs.image(p))
                                .resizable()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(layer.wrappedValue.pattern == p ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(p.title).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Âm lịch

    private var lunarCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Thông tin trên mặt đồng hồ").font(.headline)
            Text("Các mục này do đồng hồ tự cập nhật. Xem trước dùng ngày giờ hiện tại và số liệu mẫu.")
                .font(.footnote).foregroundStyle(.secondary)
            InfoSettingsView(design: $model.design)
        }
    }

    // MARK: Vạch giờ

    private var marksCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Vạch giờ").font(.headline)
            Picker("Kiểu", selection: $model.design.marks) {
                ForEach(FaceDesign.Marks.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.marks != .none {
                ColorPicker("Màu vạch giờ", selection: $model.design.marksColor, supportsOpacity: false)
            }
        }
        .card()
    }

    // MARK: Chuyển động theo giây

    private var secondFXCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Chuyển động theo giây").font(.headline)
            Text("Hiệu ứng đổi ảnh mỗi giây trên đồng hồ. Chỉ hiện ban ngày.")
                .font(.footnote).foregroundStyle(.secondary)
            Picker("Kiểu", selection: $model.design.secondFX) {
                ForEach(SecondFX.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.secondFX != .none {
                ColorPicker("Màu hiệu ứng", selection: $model.design.secondFXColor, supportsOpacity: false)
                Text(String(format: "Ảnh thô khoảng %.1f MB trên đồng hồ. Nếu tắt kim giây, app tự thêm một kim giây vô hình để đồng hồ cập nhật mỗi giây.",
                            FaceRenderer.secondFXRawMegabytes(model.design)))
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .card()
    }

    // MARK: Hoạt ảnh xoay liên tục (thử nghiệm)

    private var animCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Hoạt ảnh nền (thử nghiệm)").font(.headline)
            Text("Họa tiết xoay hoặc tuyết/lá/hoa rơi liên tục trên nền. Chưa thử trên đồng hồ thật, nên hãy cài lên một ô mặt đồng hồ dự phòng trước.")
                .font(.footnote).foregroundStyle(.secondary)
            Toggle("Bật hoạt ảnh", isOn: $model.design.animOn)
            if model.design.animOn {
                Picker("Kiểu", selection: Binding(
                    get: { model.design.animKind },
                    set: { k in
                        model.design.animKind = k
                        model.design.animInterval = k.isFall ? 90 : 50
                    })) {
                    ForEach(AnimKind.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
                Picker("Kiểu lặp (thử)", selection: $model.design.animLoopMode) {
                    Text("A").tag(0); Text("B").tag(1); Text("C").tag(2); Text("D").tag(3)
                }
                .pickerStyle(.segmented)
                Text("Nếu hoạt ảnh chỉ chạy một lần rồi nghỉ vài giây, hãy thử lần lượt kiểu B, C, D.")
                    .font(.caption2).foregroundStyle(.secondary)
                if model.design.animKind.isFall {
                    slider("Mật độ hạt", value: $model.design.animDensity, range: 0.1...1)
                    Picker("Số khung", selection: $model.design.animFallFrames) {
                        ForEach(FaceRenderer.fallFrameChoices, id: \.self) { Text("\($0)").tag($0) }
                    }
                    .pickerStyle(.segmented)
                    slider("Chu kỳ mỗi khung: \(Int(model.design.animInterval)) ms (nhỏ = rơi nhanh)",
                           value: $model.design.animInterval,
                           range: Double(AnimFX.minInterval)...Double(AnimFX.maxInterval))
                    Text(String(format: "Ảnh thô khoảng %.0f MB trên đồng hồ. Nhiều khung = mượt hơn nhưng nặng hơn; nếu đồng hồ báo lỗi hoặc giật, hãy giảm số khung hoặc mật độ.",
                                FaceRenderer.fallRawMegabytes(model.design)))
                        .font(.caption2).foregroundStyle(.secondary)
                } else {
                    Picker("Họa tiết", selection: $model.design.animPattern) {
                        ForEach(DecorPattern.allCases) { Text($0.title).tag($0) }
                    }
                    if !model.design.animPattern.isSeasonal {
                        ColorPicker("Màu", selection: $model.design.animColor, supportsOpacity: false)
                    }
                    slider("Kích thước", value: $model.design.animSize, range: 0.2...0.5)
                    Text(String(format: "Ảnh thô khoảng %.1f MB trên đồng hồ. Càng to càng dễ giật hoặc đứng hình; nên để nhỏ.",
                                FaceRenderer.animSpinRawMegabytes(model.design)))
                        .font(.caption2).foregroundStyle(.secondary)
                    slider("Vị trí ngang", value: $model.design.animX, range: 0...1)
                    slider("Vị trí dọc", value: $model.design.animY, range: 0...1)
                    slider("Chu kỳ mỗi khung: \(Int(model.design.animInterval)) ms (nhỏ = quay nhanh)",
                           value: $model.design.animInterval,
                           range: Double(AnimFX.minInterval)...Double(AnimFX.maxInterval))
                    Toggle("Quay ngược chiều", isOn: $model.design.animReverse)
                }
            }
        }
        .card()
    }

    // MARK: Kim

    private var handsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Kim").font(.headline)
            Text("Kiểu kim: \(model.design.handStyle.title)").font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 62), spacing: 10)], spacing: 10) {
                ForEach(FaceDesign.HandStyle.allCases) { st in
                    Button {
                        model.design.handStyle = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: HandThumbs.image(st))
                                .resizable()
                                .frame(width: 58, height: 58)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(model.design.handStyle == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(st.title).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            ColorPicker("Kim giờ", selection: $model.design.hourColor, supportsOpacity: false)
            ColorPicker("Kim phút", selection: $model.design.minuteColor, supportsOpacity: false)
            Toggle("Hiện kim giây", isOn: $model.design.showSecond)
            if model.design.showSecond {
                ColorPicker("Kim giây", selection: $model.design.secondColor, supportsOpacity: false)
            }
            ColorPicker("Núm giữa", selection: $model.design.capColor, supportsOpacity: false)
            slider("Độ dày kim", value: $model.design.handWidth, range: 0.6...1.8)
            Toggle("Viền tối quanh kim", isOn: $model.design.handOutline)
        }
        .card()
    }

    // MARK: AOD

    private var aodCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("AOD (màn hình tắt)").font(.headline)
            Text("Nền đen và ít điểm sáng sẽ tiết kiệm pin hơn.")
                .font(.footnote).foregroundStyle(.secondary)
            Picker("Nền AOD", selection: $model.design.aodBackground) {
                ForEach(FaceDesign.AodBackground.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.aodBackground == .dimmed {
                slider("Độ sáng nền", value: $model.design.aodBrightness, range: 0.05...0.6)
            }
            ColorPicker("Màu kim AOD", selection: $model.design.aodHandColor, supportsOpacity: false)
            Toggle("Hiện vạch giờ", isOn: $model.design.aodShowMarks)
            if model.design.aodShowMarks && model.design.marks != .none {
                ColorPicker("Màu vạch giờ AOD", selection: $model.design.aodMarksColor, supportsOpacity: false)
            }
        }
        .card()
    }

    // MARK: Lưu

    private var saveButton: some View {
        VStack(spacing: 8) {
            Button {
                model.export { result in
                    switch result {
                    case .success(let url):
                        vm.importHwt(url, displayName: url.lastPathComponent)
                        dismiss()
                    case .failure(let error):
                        errorText = "Mã lỗi: \(WMCore.code(error))"
                    }
                }
            } label: {
                if model.building {
                    HStack(spacing: 8) { ProgressView(); Text("Đang tạo file HWT") }
                } else {
                    Label("Tạo và thêm vào thư viện", systemImage: "wand.and.stars")
                }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)
            Text("File được lưu vào Thư viện; từ đó bạn có thể gửi lên đồng hồ như mọi file HWT khác.")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
    }

    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.footnote).foregroundStyle(.secondary)
            Slider(value: value, in: range)
        }
    }
}
