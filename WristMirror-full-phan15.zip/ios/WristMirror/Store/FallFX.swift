// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Kiểu hoạt ảnh nền: xoay một họa tiết, hoặc hạt rơi (tuyết / lá / hoa).
enum AnimKind: String, CaseIterable, Identifiable {
    case spin, snow, leaves, petals
    var id: String { rawValue }
    var title: String {
        switch self {
        case .spin: return "Xoay"
        case .snow: return "Tuyết"
        case .leaves: return "Lá"
        case .petals: return "Hoa"
        }
    }
    var isFall: Bool { self != .spin }
}

/// Một dải ảnh hoạt ảnh cao bằng cả mặt đồng hồ (466 px), đặt tại cột `x`.
struct FallStrip {
    var x: Int
    var width: Int
    var frames: [HwtRaster]
}

private struct FallRNG {
    var s: UInt64
    init(_ seed: UInt64) { s = seed &* 0x9E3779B97F4A7C15 &+ 0x1234567 }
    mutating func next() -> CGFloat {
        s = s &+ 0x9E3779B97F4A7C15
        var z = s
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        z = z ^ (z >> 31)
        return CGFloat(Double(z >> 11) / Double(UInt64(1) << 53))
    }
    mutating func range(_ a: CGFloat, _ b: CGFloat) -> CGFloat { a + (b - a) * next() }
}

private struct FallParticle {
    var x: CGFloat          // tâm ngang (toạ độ trong ảnh dải)
    var y0: CGFloat         // vị trí dọc ở khung 0
    var size: CGFloat       // bán kính (tuyết) hoặc chiều dài (lá/hoa)
    var sway: CGFloat       // biên độ lắc ngang
    var swayCycles: Int     // số chu kỳ lắc trong một vòng lặp (số nguyên => lặp liền mạch)
    var swayPhase: CGFloat
    var rot0: CGFloat
    var rotCycles: Int
    var tumbleCycles: Int   // lật mặt (lá/hoa)
    var tumblePhase: CGFloat
    var color: Int
}

struct FallGeom {
    var imgX: Int
    var imgW: Int
    var cellX0: Int
    var cellX1: Int
}

extension FaceRenderer {
    static let fallStripCount = 3
    /// Lề hai bên mỗi cột để hạt không bị cắt cứng ở mép dải ảnh.
    static let fallMargin = 36
    static let fallFrameChoices = [24, 32, 48]

    static func fallFrameCount(_ d: FaceDesign) -> Int {
        fallFrameChoices.contains(d.animFallFrames) ? d.animFallFrames : 32
    }

    static func fallGeometry(_ i: Int) -> FallGeom {
        let full = Int(size)
        let x0 = i * full / fallStripCount
        let x1 = (i + 1) * full / fallStripCount
        let ix = max(0, x0 - fallMargin)
        let ex = min(full, x1 + fallMargin)
        return FallGeom(imgX: ix, imgW: ex - ix, cellX0: x0, cellX1: x1)
    }

    /// Ước lượng dung lượng ảnh thô (MB) khi đồng hồ giải nén, để hiện cảnh báo trong app.
    static func fallRawMegabytes(_ d: FaceDesign) -> Double {
        var px = 0
        for i in 0..<fallStripCount { px += fallGeometry(i).imgW * Int(size) }
        return Double(px * 4 * fallFrameCount(d)) / 1_048_576
    }

    // MARK: Hạt

    private static func fallParticles(_ d: FaceDesign, strip i: Int) -> [FallParticle] {
        let kind = d.animKind
        let g = fallGeometry(i)
        let seedKind: UInt64
        let base: CGFloat
        switch kind {
        case .snow: seedKind = 11; base = 15
        case .leaves: seedKind = 23; base = 6
        case .petals: seedKind = 37; base = 8
        case .spin: return []
        }
        var rng = FallRNG(UInt64(i + 1) &* 7919 &+ seedKind)
        let dens = CGFloat(min(1, max(0.1, d.animDensity)))
        let n = max(2, Int((base * (0.35 + 1.3 * dens)).rounded()))
        let H = size
        var out = [FallParticle]()
        for j in 0..<n {
            let size: CGFloat
            let sway: CGFloat
            switch kind {
            case .snow: size = rng.range(2.6, 6.4); sway = rng.range(4, 10)
            case .leaves: size = rng.range(15, 26); sway = rng.range(8, 15)
            default: size = rng.range(10, 17); sway = rng.range(7, 13)
            }
            let rotChoices = kind == .snow ? [0, 1] : [-1, 1]
            out.append(FallParticle(
                x: CGFloat(g.cellX0 - g.imgX) + rng.range(0, CGFloat(g.cellX1 - g.cellX0)),
                y0: (CGFloat(j) + rng.range(0.15, 0.85)) * H / CGFloat(n),
                size: size,
                sway: sway,
                swayCycles: rng.next() < 0.5 ? 1 : 2,
                swayPhase: rng.range(0, 2 * .pi),
                rot0: rng.range(0, 2 * .pi),
                rotCycles: rotChoices[Int(rng.next() * CGFloat(rotChoices.count)) % rotChoices.count],
                tumbleCycles: 1 + Int(rng.next() * 3) % 3,
                tumblePhase: rng.range(0, 2 * .pi),
                color: Int(rng.next() * 100)))
        }
        return out
    }

    // MARK: Khung

    private static func fallFrame(_ d: FaceDesign, _ g: FallGeom, _ ps: [FallParticle], _ f: Int, _ n: Int) -> HwtRaster {
        let H = size
        let t = CGFloat(f) / CGFloat(n)
        let kind = d.animKind
        return drawRaster(width: g.imgW, height: Int(H)) { ctx in
            for p in ps {
                let y = (p.y0 + H * t).truncatingRemainder(dividingBy: H)
                let swayAngle = 2 * CGFloat.pi * CGFloat(p.swayCycles) * t + p.swayPhase
                let x = p.x + p.sway * sin(swayAngle)
                let rot: CGFloat
                if kind == .snow {
                    rot = p.rot0 + 2 * CGFloat.pi * CGFloat(p.rotCycles) * t
                } else {
                    rot = p.rot0 + 0.7 * sin(swayAngle + 1.0)
                }
                let wob = 0.40 + 0.60 * abs(cos(2 * CGFloat.pi * CGFloat(p.tumbleCycles) * t + p.tumblePhase))
                // Vẽ hai bản (y và y - H) để hạt đi qua mép dưới hiện lại liền mạch ở mép trên.
                for dy in [CGFloat(0), -H] {
                    ctx.saveGState()
                    ctx.translateBy(x: x, y: y + dy)
                    switch kind {
                    case .snow: drawSnow(ctx, r: p.size, rot: rot)
                    case .leaves:
                        ctx.rotate(by: rot)
                        ctx.scaleBy(x: wob, y: 1)
                        drawLeaf(ctx, len: p.size, color: leafPalette[p.color % leafPalette.count])
                    case .petals:
                        ctx.rotate(by: rot)
                        ctx.scaleBy(x: wob, y: 1)
                        drawPetal(ctx, len: p.size, color: petalPalette[p.color % petalPalette.count])
                    case .spin: break
                    }
                    ctx.restoreGState()
                }
            }
        }
    }

    /// Các dải ảnh (đã vẽ đủ khung) cho hoạt ảnh rơi; rỗng nếu không bật hoặc đang ở kiểu xoay.
    static func fallStrips(_ d: FaceDesign) -> [FallStrip] {
        guard d.animOn, d.animKind.isFall else { return [] }
        let n = fallFrameCount(d)
        var out = [FallStrip]()
        for i in 0..<fallStripCount {
            let g = fallGeometry(i)
            let ps = fallParticles(d, strip: i)
            let frames = (0..<n).map { fallFrame(d, g, ps, $0, n) }
            out.append(FallStrip(x: g.imgX, width: g.imgW, frames: frames))
        }
        return out
    }

    // MARK: Hình hạt (gốc toạ độ tại tâm hạt, y hướng xuống)

    private static let leafPalette: [UIColor] = [
        UIColor(red: 0.93, green: 0.45, blue: 0.10, alpha: 1),
        UIColor(red: 0.85, green: 0.22, blue: 0.12, alpha: 1),
        UIColor(red: 0.96, green: 0.70, blue: 0.15, alpha: 1),
        UIColor(red: 0.62, green: 0.32, blue: 0.12, alpha: 1),
        UIColor(red: 0.72, green: 0.58, blue: 0.14, alpha: 1)
    ]
    private static let petalPalette: [UIColor] = [
        UIColor(red: 1.00, green: 0.80, blue: 0.86, alpha: 1),
        UIColor(red: 1.00, green: 0.70, blue: 0.80, alpha: 1),
        UIColor(red: 0.98, green: 0.88, blue: 0.92, alpha: 1),
        UIColor(red: 1.00, green: 0.62, blue: 0.74, alpha: 1)
    ]

    private static func drawSnow(_ ctx: CGContext, r: CGFloat, rot: CGFloat) {
        let cs = CGColorSpaceCreateDeviceRGB()
        let glow = [UIColor(white: 1, alpha: 0.5).cgColor, UIColor(white: 1, alpha: 0).cgColor] as CFArray
        if let gr = CGGradient(colorsSpace: cs, colors: glow, locations: [0, 1]) {
            ctx.drawRadialGradient(gr, startCenter: .zero, startRadius: 0, endCenter: .zero, endRadius: r * 2.2, options: [])
        }
        if r >= 4.2 {
            let R = r * 1.9
            ctx.setStrokeColor(UIColor(white: 1, alpha: 0.96).cgColor)
            ctx.setLineWidth(max(1.3, r * 0.3))
            ctx.setLineCap(.round)
            for k in 0..<6 {
                ctx.saveGState()
                ctx.rotate(by: rot + CGFloat(k) * CGFloat.pi / 3)
                ctx.move(to: .zero)
                ctx.addLine(to: CGPoint(x: 0, y: -R))
                ctx.move(to: CGPoint(x: 0, y: -R * 0.6))
                ctx.addLine(to: CGPoint(x: -R * 0.26, y: -R * 0.84))
                ctx.move(to: CGPoint(x: 0, y: -R * 0.6))
                ctx.addLine(to: CGPoint(x: R * 0.26, y: -R * 0.84))
                ctx.strokePath()
                ctx.restoreGState()
            }
        } else {
            ctx.setFillColor(UIColor(white: 1, alpha: 0.97).cgColor)
            ctx.fillEllipse(in: CGRect(x: -r * 0.62, y: -r * 0.62, width: r * 1.24, height: r * 1.24))
        }
    }

    private static func drawLeaf(_ ctx: CGContext, len L: CGFloat, color: UIColor) {
        let w = L * 0.46
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 0, y: -L / 2))
        path.addQuadCurve(to: CGPoint(x: 0, y: L / 2), control: CGPoint(x: w * 1.2, y: -L * 0.08))
        path.addQuadCurve(to: CGPoint(x: 0, y: -L / 2), control: CGPoint(x: -w * 1.2, y: -L * 0.08))
        ctx.addPath(path)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()
        // Nửa lá tối hơn cho có khối.
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        ctx.setFillColor(UIColor(white: 0, alpha: 0.16).cgColor)
        ctx.fill(CGRect(x: -w * 2, y: -L, width: w * 2, height: 2 * L))
        ctx.restoreGState()
        // Gân lá và cuống.
        ctx.setStrokeColor(UIColor(white: 0, alpha: 0.38).cgColor)
        ctx.setLineCap(.round)
        ctx.setLineWidth(max(0.9, L * 0.045))
        ctx.move(to: CGPoint(x: 0, y: -L / 2))
        ctx.addLine(to: CGPoint(x: 0, y: L / 2 + L * 0.16))
        ctx.strokePath()
        ctx.setLineWidth(max(0.7, L * 0.03))
        for k in 1...3 {
            let y = -L * 0.28 + CGFloat(k) * L * 0.17
            ctx.move(to: CGPoint(x: 0, y: y))
            ctx.addLine(to: CGPoint(x: -w * 0.55, y: y - L * 0.12))
            ctx.move(to: CGPoint(x: 0, y: y))
            ctx.addLine(to: CGPoint(x: w * 0.55, y: y - L * 0.12))
        }
        ctx.strokePath()
    }

    private static func drawPetal(_ ctx: CGContext, len L: CGFloat, color: UIColor) {
        let w = L * 0.5
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 0, y: L / 2))
        path.addCurve(to: CGPoint(x: -w * 0.55, y: -L / 2),
                      control1: CGPoint(x: -w * 1.15, y: L * 0.2), control2: CGPoint(x: -w * 1.0, y: -L * 0.45))
        path.addQuadCurve(to: CGPoint(x: 0, y: -L * 0.34), control: CGPoint(x: -w * 0.2, y: -L * 0.55))
        path.addQuadCurve(to: CGPoint(x: w * 0.55, y: -L / 2), control: CGPoint(x: w * 0.2, y: -L * 0.55))
        path.addCurve(to: CGPoint(x: 0, y: L / 2),
                      control1: CGPoint(x: w * 1.0, y: -L * 0.45), control2: CGPoint(x: w * 1.15, y: L * 0.2))
        path.closeSubpath()
        ctx.addPath(path)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()
        ctx.setStrokeColor(UIColor(red: 0.85, green: 0.35, blue: 0.5, alpha: 0.35).cgColor)
        ctx.setLineWidth(max(0.8, L * 0.05))
        ctx.setLineCap(.round)
        ctx.move(to: CGPoint(x: 0, y: L / 2))
        ctx.addLine(to: CGPoint(x: 0, y: -L * 0.1))
        ctx.strokePath()
    }
}
