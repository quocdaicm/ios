import math, os, sys, json
OUT=sys.argv[1]; W="#FFFFFF"
def n(v):
    s=("%.1f"%v).rstrip("0").rstrip("."); return "0" if s in("-0","") else s
G={ # glyph 10x16, stroke paths
'0':"M5,0C9,0 10,4 10,8C10,12 9,16 5,16C1,16 0,12 0,8C0,4 1,0 5,0Z",
'1':"M2,3.5L6,0V16",
'2':"M0.5,4C0.5,-1.5 9.5,-1.5 9.5,4.5C9.5,8 3,11 0.5,16H10",
'3':"M1,1.5C5,-1.5 9.5,1 8.5,5C8,7.5 5,8 4,8C6,8 10,9 9.5,12C9,17 3,17.5 0.5,14.5",
'4':"M8,16V0L0,11H10",
'5':"M9,0H2L1,7.5C5,5.5 10,7 9.5,11.5C9,16.5 3,17 0.5,14",
'6':"M8.5,1.5C5,-1 1,3 0.5,9C0,16 9,17 9.5,11.5C10,7 4,6 0.5,10",
'7':"M0.5,0H9.5L3.5,16",
'8':"M5,8C0,7 0.5,0 5,0C9.5,0 10,7 5,8C0,9 -0.5,16 5,16C10.5,16 10,9 5,8Z",
'9':"M1.5,14.5C5,17 9,13 9.5,7C10,0 1,-1 0.5,4.5C0,9 6,10 9.5,6"}
# 7 đoạn: a b c d e f g
SEG={'a':"M1,0H9",'b':"M10,1V7",'c':"M10,9V15",'d':"M1,16H9",'e':"M0,9V15",'f':"M0,1V7",'g':"M1,8H9"}
DIG={'0':"abcdef",'1':"bc",'2':"abged",'3':"abgcd",'4':"fgbc",'5':"afgcd",'6':"afgedc",'7':"abc",'8':"abcdefg",'9':"abcdfg"}
ROM={'I':(2,["M1,0V16"]),'V':(11,["M0.5,0L5.5,16L10.5,0"]),'X':(11,["M0.5,0L10.5,16","M10.5,0L0.5,16"])}
RN=["","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"]
def glyph(ch,style):
    if style=='seg': return 10,[SEG[s] for s in DIG[ch]]
    return 10,[G[ch]]
def label(k,style):
    """trả về (rộng, [path], cao) trong hệ glyph 16 cao, gốc ở trái-trên"""
    if style=='roman':
        x=0;ps=[]
        for c in RN[k]:
            w,pp=ROM[c]; ps+= [f'<g transform="translate({n(x)} 0)"><path d="{p}"/></g>' for p in pp]; x+=w+3.5
        return x-3.5,ps
    x=0;ps=[]
    for c in str(k):
        w,pp=glyph(c,style); ps+= [f'<g transform="translate({n(x)} 0)"><path d="{p}"/></g>' for p in pp]; x+=w+3.5
    return x-3.5,ps
STY={ # id,tên,kiểu glyph,độ cao,nét,hướng tâm,vòng,chỉ4
 'manh':("Ả Rập mảnh",'d',34,1.6,0,0,0),
 'dam':("Ả Rập đậm",'d',36,3.2,0,0,0),
 'vuong':("Bảy đoạn",'seg',32,2.4,0,0,0),
 'la-ma':("La Mã",'roman',30,2.2,0,0,0),
 'la-ma-xoay':("La Mã hướng tâm",'roman',26,2.0,1,0,0),
 'huong-tam':("Ả Rập hướng tâm",'d',32,2.2,1,0,0),
 'vong':("Số trong vòng",'d',24,2.0,0,1,0),
 'bon-so':("Bốn số chính",'d',46,4.0,0,0,1),
}
def item(k,style,H,sw,rad,ring,r0,cx,cy,ang):
    w,ps=label(k,style); s=H/16
    rot=ang if rad else 0
    if rad and 90<ang<270: rot=ang+180
    tr=f'translate({n(cx)} {n(cy)})'+(f' rotate({n(rot)})' if rot else '')+f' scale({n(s)}) translate({n(-w/2)} -8)'
    return f'<g fill="none" stroke="{W}" stroke-width="{n(sw/s)}" stroke-linecap="round" stroke-linejoin="round" transform="{tr}">'+"".join(ps)+"</g>"
def dial(style,only=None):
    name,gs,H,sw,rad,ring,four=STY[style]
    out=[]
    r=178 if not ring else 190
    for k in range(1,13):
        if four and k%3: continue
        a=k*30; cx=256+r*math.sin(math.radians(a)); cy=256-r*math.cos(math.radians(a))
        if ring:
            out.append(f'<circle cx="{n(cx)}" cy="{n(cy)}" r="{n(H*0.95)}" fill="none" stroke="{W}" stroke-width="2" opacity=".6"/>')
        out.append(item(k,gs,H,sw,rad,ring,0,cx,cy,a))
    return out
def single(style,k):
    name,gs,H,sw,rad,ring,four=STY[style]
    e=[]
    w,ps=label(k,gs); sc=min(H*2.2/16,100/max(w,1))
    if ring: e.append(f'<circle cx="64" cy="64" r="{n(H*0.95*2.2)}" fill="none" stroke="{W}" stroke-width="4" opacity=".6"/>')
    e.append(f'<g fill="none" stroke="{W}" stroke-width="{n(sw*2.2/sc)}" stroke-linecap="round" stroke-linejoin="round" transform="translate(64 64) scale({n(sc)}) translate({n(-w/2)} -8)">'+"".join(ps)+"</g>")
    return e
os.makedirs(OUT,exist_ok=True); meta=[]
for st,(name,*_) in STY.items():
    d=os.path.join(OUT,st); os.makedirs(os.path.join(d,"so"),exist_ok=True)
    body="\n".join(dial(st))
    open(os.path.join(d,"mat-so.svg"),"w",encoding="utf-8").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">\n<title>{name}</title>\n<!-- số giờ quanh mặt số, tâm (256,256), màu #FFFFFF -->\n{body}\n</svg>\n')
    for k in range(1,13):
        if STY[st][6] and k%3: continue
        open(os.path.join(d,"so",f"{k:02d}.svg"),"w",encoding="utf-8").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">\n<title>{name} {k}</title>\n'+"\n".join(single(st,k))+"\n</svg>\n")
    meta.append({"id":st,"title":name})
# tổng hợp
cols,cell=4,300; rows=math.ceil(len(STY)/cols); Wd,Hd=cols*cell,rows*(cell+26)+10
s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Wd} {Hd}" width="{Wd}" height="{Hd}" font-family="sans-serif"><rect width="{Wd}" height="{Hd}" fill="#0b0b0b"/>']
for i,st in enumerate(STY):
    x,y=(i%cols)*cell,(i//cols)*(cell+26)+6; sc=(cell-12)/512
    s.append(f'<circle cx="{x+cell/2}" cy="{y+cell/2}" r="{cell/2-6}" fill="#161616" stroke="#262626"/><g transform="translate({x+6} {y+6}) scale({n(sc)})">'+"\n".join(dial(st))+'</g>')
    s.append(f'<text x="{x+cell/2}" y="{y+cell+16}" text-anchor="middle" fill="#E8C77A" font-size="14">{STY[st][0]}</text>')
open(os.path.join(OUT,"_tong-hop.svg"),"w",encoding="utf-8").write("\n".join(s)+"</svg>\n")
json.dump({"canvas":512,"pivot":[256,256],"styles":meta},open(os.path.join(OUT,"so-gio.json"),"w",encoding="utf-8"),ensure_ascii=False,indent=2)
print(len(STY))
