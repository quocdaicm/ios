#!/usr/bin/env python3
"""Vật thể xoay quanh mặt số. Canvas 512, tâm (256,256), vật thể nằm ở đỉnh (bán kính ~205), xoay quanh tâm."""
import math, os, sys, json

OUT = sys.argv[1]
GOLD, PALE, RED, CYAN, WHITE, PINK, LEAF = "#E8C77A", "#DCE6FF", "#E5383B", "#6FD3FF", "#FFFFFF", "#FF8FB1", "#7BD88F"
CX, CY, ORB = 256, 256, 205
TOP = CY - ORB  # y của vật thể


def n(v):
    s = ("%.1f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def poly(p, fill, extra=""):
    return f'<polygon points="{" ".join(f"{n(x)},{n(y)}" for x, y in p)}" fill="{fill}" {extra}/>'


def star(cx, cy, ro, ri, k=5, rot=-90):
    return [(cx + (ro if i % 2 == 0 else ri) * math.cos(math.radians(rot) + i * math.pi / k),
             cy + (ro if i % 2 == 0 else ri) * math.sin(math.radians(rot) + i * math.pi / k)) for i in range(2 * k)]


def trail(deg, col, w=5, op=.55):
    """Vệt sáng phía sau (ngược chiều kim đồng hồ) dọc quỹ đạo, mờ dần."""
    a0 = math.radians(-90 - deg)
    x0, y0 = CX + ORB * math.cos(a0), CY + ORB * math.sin(a0)
    gid = "t" + str(abs(hash((deg, col))) % 9999)
    return (f'<defs><linearGradient id="{gid}" gradientUnits="userSpaceOnUse" x1="{n(x0)}" y1="{n(y0)}" x2="{CX}" y2="{TOP}">'
            f'<stop offset="0" stop-color="{col}" stop-opacity="0"/><stop offset="1" stop-color="{col}" stop-opacity="{op}"/></linearGradient></defs>'
            f'<path d="M{n(x0)},{n(y0)}A{ORB},{ORB} 0 0,1 {CX},{TOP}" fill="none" stroke="url(#{gid})" stroke-width="{w}" stroke-linecap="round"/>')


def mat_troi():
    out = [trail(40, "#FFC94A", 4, .35)]
    for i in range(12):
        a = math.radians(i * 30)
        r1, r2 = 24, 36 if i % 2 == 0 else 31
        out.append(f'<line x1="{n(CX + r1 * math.sin(a))}" y1="{n(TOP - r1 * math.cos(a))}" x2="{n(CX + r2 * math.sin(a))}" y2="{n(TOP - r2 * math.cos(a))}" stroke="#FFC94A" stroke-width="4" stroke-linecap="round"/>')
    out.append(f'<circle cx="{CX}" cy="{TOP}" r="19" fill="#FFB52E"/><circle cx="{CX}" cy="{TOP}" r="12" fill="#FFE08A"/>')
    return out


def mat_trang():
    return [trail(50, PALE, 4, .3),
            f'<mask id="cr"><rect x="{CX - 40}" y="{TOP - 40}" width="80" height="80" fill="#fff"/><circle cx="{CX + 12}" cy="{TOP - 6}" r="22" fill="#000"/></mask>',
            f'<circle cx="{CX}" cy="{TOP}" r="26" fill="{PALE}" mask="url(#cr)"/>',
            f'<circle cx="{CX + 24}" cy="{TOP - 20}" r="2.2" fill="{PALE}"/><circle cx="{CX + 30}" cy="{TOP + 6}" r="1.6" fill="{PALE}"/>']


def sao_bang():
    return [trail(80, CYAN, 7, .7), trail(80, WHITE, 2, .8),
            f'<circle cx="{CX}" cy="{TOP}" r="11" fill="{WHITE}"/><circle cx="{CX}" cy="{TOP}" r="17" fill="{CYAN}" opacity=".35"/>']


def sao_vang():
    return [trail(35, GOLD, 3, .35),
            poly(star(CX, TOP + 2, 26, 10.5), "#FFD84A", f'stroke="#B8860B" stroke-width="2" stroke-linejoin="round"')]


def may_bay():
    # bay theo chiều kim đồng hồ: ở đỉnh quỹ đạo mũi hướng sang phải (+x)
    g = (f'<g transform="translate({CX} {TOP})"><path d="M30,0L12,-5L-2,-30L-9,-30L-3,-5L-18,-5L-22,-14L-27,-14L-24,0L-27,14L-22,14L-18,5L-3,5L-9,30L-2,30L12,5Z" fill="{WHITE}"/>'
         f'<circle cx="26" cy="0" r="1.8" fill="#9aa0a6"/></g>')
    return [trail(55, WHITE, 2.5, .4), g]


def thuyen_buom():
    g = (f'<g transform="translate({CX} {TOP})">'
         f'<path d="M-30,10H30L22,24H-22Z" fill="#8a5a2b"/>'
         f'<path d="M0,-34V10" stroke="#5b3a1a" stroke-width="3"/>'
         f'<path d="M3,-30Q26,-10 26,6H3Z" fill="#E9B44C"/><path d="M-3,-22Q-20,-6 -20,6H-3Z" fill="#D9892B"/></g>')
    return [g]


def ca_chep():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M-30,0C-40,-12 -42,-14 -50,-14C-46,-6 -46,6 -50,14C-42,14 -40,12 -30,0Z" fill="#FF7A2F"/>'
         f'<ellipse cx="0" cy="0" rx="32" ry="13" fill="#FF5A1F"/>'
         f'<path d="M-6,-12C0,-26 12,-24 16,-12Z" fill="#FF7A2F"/><path d="M-4,12C2,24 12,22 14,12Z" fill="#FF7A2F"/>'
         f'<path d="M-10,-9Q0,0 -10,9M0,-11Q10,0 0,11M10,-8Q18,0 10,8" fill="none" stroke="#FFD2A8" stroke-width="1.6" opacity=".7"/>'
         f'<circle cx="22" cy="-3" r="3" fill="#fff"/><circle cx="23" cy="-3" r="1.4" fill="#111"/></g>')
    return [trail(45, "#FF7A2F", 3, .35), g]


def chim_lac():
    g = (f'<g transform="translate({CX} {TOP})" fill="{GOLD}">'
         f'<path d="M34,-2L18,-6L-6,-34C-4,-18 -4,-10 -2,-4L-30,-18C-18,-8 -12,-2 -6,2L-24,18C-8,12 4,8 10,6L22,4Z"/>'
         f'<circle cx="30" cy="-4" r="2" fill="#161616"/></g>')
    return [trail(50, GOLD, 3, .35), g]


def buom():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M0,0C-8,-30 -34,-34 -34,-14C-34,-2 -14,4 0,0Z" fill="#B58CFF"/>'
         f'<path d="M0,0C8,-30 34,-34 34,-14C34,-2 14,4 0,0Z" fill="#B58CFF"/>'
         f'<path d="M0,0C-6,22 -26,28 -26,14C-26,6 -12,0 0,0Z" fill="#8F63E8"/><path d="M0,0C6,22 26,28 26,14C26,6 12,0 0,0Z" fill="#8F63E8"/>'
         f'<rect x="-2" y="-14" width="4" height="28" rx="2" fill="#2b1f4a"/>'
         f'<circle cx="-18" cy="-12" r="5" fill="#fff" opacity=".7"/><circle cx="18" cy="-12" r="5" fill="#fff" opacity=".7"/></g>')
    return [g]


def hoa_sen():
    petals = ""
    for a, s in ((-60, .8), (60, .8), (-30, .95), (30, .95), (0, 1.1)):
        petals += (f'<path transform="rotate({a} 0 14) scale({s})" d="M0,-26C14,-14 14,2 0,14C-14,2 -14,-14 0,-26Z" '
                   f'fill="{PINK}" stroke="#E85C8D" stroke-width="1.4"/>')
    g = (f'<g transform="translate({CX} {TOP})">{petals}<ellipse cx="0" cy="16" rx="26" ry="5" fill="{LEAF}" opacity=".9"/>'
         f'<circle cx="0" cy="8" r="4" fill="#FFD84A"/></g>')
    return [g]


def giot_suong():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M0,-30C6,-16 18,-8 18,6A18,18 0 0,1 -18,6C-18,-8 -6,-16 0,-30Z" fill="{CYAN}" opacity=".9"/>'
         f'<path d="M-9,4Q-9,12 -2,14" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".8"/></g>')
    return [trail(40, CYAN, 3, .3), g]


def ngoc():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M-24,-10L-12,-26H12L24,-10L0,26Z" fill="#6FE0FF"/>'
         f'<path d="M-24,-10H24M-12,-26L-6,-10L0,26L6,-10L12,-26M-6,-10L0,-26L6,-10" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" opacity=".85"/>'
         f'<path d="M-12,-26L-6,-10L-24,-10Z" fill="#B8F1FF"/></g>')
    return [g]


def mui_nhon():
    return [trail(30, RED, 3, .5),
            f'<path d="M{CX},{TOP + 22}L{CX + 18},{TOP - 14}H{CX - 18}Z" fill="{RED}" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>']


def tia_chop():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M6,-32L-16,4H-2L-8,32L18,-8H3Z" fill="#FFE14A" stroke="#C99700" stroke-width="2" stroke-linejoin="round"/></g>')
    return [trail(30, "#FFE14A", 3, .35), g]


def trai_tim():
    g = (f'<g transform="translate({CX} {TOP})"><path d="M0,24C-34,0 -30,-26 -14,-26C-6,-26 0,-20 0,-14C0,-20 6,-26 14,-26C30,-26 34,0 0,24Z" fill="#FF4D6D"/>'
         f'<path d="M-18,-16Q-22,-12 -20,-6" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".7"/></g>')
    return [g]


def cung_sang():
    r = ORB
    a0, a1 = math.radians(-90 - 30), math.radians(-90 + 30)
    x0, y0, x1, y1 = CX + r * math.cos(a0), CY + r * math.sin(a0), CX + r * math.cos(a1), CY + r * math.sin(a1)
    return [f'<path d="M{n(x0)},{n(y0)}A{r},{r} 0 0,1 {n(x1)},{n(y1)}" fill="none" stroke="{GOLD}" stroke-width="12" stroke-linecap="round" opacity=".25"/>',
            f'<path d="M{n(x0)},{n(y0)}A{r},{r} 0 0,1 {n(x1)},{n(y1)}" fill="none" stroke="{GOLD}" stroke-width="5" stroke-linecap="round"/>']


def dom_dom():
    out = [trail(60, "#B6FF3B", 3, .3)]
    out.append(f'<circle cx="{CX}" cy="{TOP}" r="13" fill="#B6FF3B" opacity=".25"/><circle cx="{CX}" cy="{TOP}" r="7" fill="#E9FF9A"/>')
    return out


ITEMS = [
    ("mat-troi", "Mặt trời", mat_troi),
    ("mat-trang", "Mặt trăng", mat_trang),
    ("sao-bang", "Sao băng", sao_bang),
    ("sao-vang", "Sao vàng", sao_vang),
    ("may-bay", "Máy bay", may_bay),
    ("thuyen-buom", "Thuyền buồm", thuyen_buom),
    ("ca-chep", "Cá chép", ca_chep),
    ("chim-lac", "Chim Lạc", chim_lac),
    ("buom", "Bươm bướm", buom),
    ("hoa-sen", "Hoa sen", hoa_sen),
    ("giot-suong", "Giọt sương", giot_suong),
    ("ngoc", "Viên ngọc", ngoc),
    ("mui-nhon", "Mũi chỉ", mui_nhon),
    ("tia-chop", "Tia chớp", tia_chop),
    ("trai-tim", "Trái tim", trai_tim),
    ("cung-sang", "Cung sáng", cung_sang),
    ("dom-dom", "Đom đóm", dom_dom),
]


def main():
    os.makedirs(OUT, exist_ok=True)
    meta = []
    for slug, title, fn in ITEMS:
        body = "\n".join(fn())
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">\n'
               f'<title>{title}</title>\n<!-- vật thể ở đỉnh quỹ đạo, tâm xoay (256,256); dùng làm lớp xoay theo kim giờ/phút/giây -->\n{body}\n</svg>\n')
        with open(os.path.join(OUT, slug + ".svg"), "w", encoding="utf-8") as fh:
            fh.write(svg)
        meta.append({"id": slug, "title": title, "file": slug + ".svg"})
    # tổng hợp
    cols, cell = 6, 200
    rows = math.ceil(len(ITEMS) / cols)
    W_, H_ = cols * cell, rows * (cell + 24) + 10
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W_} {H_}" width="{W_}" height="{H_}" font-family="sans-serif">',
         f'<rect width="{W_}" height="{H_}" fill="#0b0b0b"/>']
    for i, (slug, title, fn) in enumerate(ITEMS):
        x, y = (i % cols) * cell, (i // cols) * (cell + 24) + 6
        sc = (cell - 12) / 512
        s.append(f'<circle cx="{x + cell / 2}" cy="{y + cell / 2}" r="{cell / 2 - 8}" fill="#161616" stroke="#262626"/>')
        s.append(f'<g transform="translate({x + 6} {y + 6}) scale({n(sc)})">' + "\n".join(fn()) + "</g>")
        s.append(f'<text x="{x + cell / 2}" y="{y + cell + 14}" text-anchor="middle" fill="{GOLD}" font-size="13">{title}</text>')
    s.append("</svg>\n")
    with open(os.path.join(OUT, "_tong-hop.svg"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(s))
    with open(os.path.join(OUT, "dong.json"), "w", encoding="utf-8") as fh:
        json.dump({"canvas": 512, "pivot": [256, 256], "orbitRadius": ORB, "spin": ["gio", "phut", "giay"], "items": meta},
                  fh, ensure_ascii=False, indent=2)
    print(len(ITEMS), "vật thể")


main()
