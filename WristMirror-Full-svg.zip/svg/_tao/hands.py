#!/usr/bin/env python3
"""Sinh SVG kim đồng hồ. Quy ước: canvas 512x512, tâm xoay (256,256), đầu kim hướng lên."""
import math, os, json, sys

OUT = sys.argv[1]
MAIN = "#FFFFFF"
RED = "#FF4D59"
DARK = "#000000"


def n(v):
    s = ("%.1f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def pts(p):
    return "M" + " L".join(f"{n(x)},{n(y)}" for x, y in p) + "Z"


def circ(cx, cy, r):
    return f"M{n(cx - r)},{n(cy)}a{n(r)},{n(r)} 0 1,0 {n(2 * r)},0a{n(r)},{n(r)} 0 1,0 {n(-2 * r)},0Z"


def rr(x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    return (f"M{n(x + r)},{n(y)}H{n(x + w - r)}a{n(r)},{n(r)} 0 0,1 {n(r)},{n(r)}V{n(y + h - r)}"
            f"a{n(r)},{n(r)} 0 0,1 {n(-r)},{n(r)}H{n(x + r)}a{n(r)},{n(r)} 0 0,1 {n(-r)},{n(-r)}"
            f"V{n(y + r)}a{n(r)},{n(r)} 0 0,1 {n(r)},{n(-r)}Z")


def star(cx, cy, ro, ri, k=5):
    p = []
    for i in range(k * 2):
        r = ro if i % 2 == 0 else ri
        a = -math.pi / 2 + i * math.pi / k
        p.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts(p)


def P(d, col, eo=False, op=None):
    a = f'<path d="{d}" fill="{col}"'
    if eo:
        a += ' fill-rule="evenodd"'
    if op is not None:
        a += f' opacity="{op}"'
    return a + "/>"


def L(x1, y1, x2, y2, w, col=DARK, op=0.35):
    return (f'<line x1="{n(x1)}" y1="{n(y1)}" x2="{n(x2)}" y2="{n(y2)}" stroke="{col}" '
            f'stroke-width="{n(w)}" stroke-linecap="round" opacity="{op}"/>')


def S(d, col, w, fill="none"):
    return f'<path d="{d}" fill="{fill}" stroke="{col}" stroke-width="{n(w)}" stroke-linejoin="round" stroke-linecap="round"/>'


def shaft(w, y0, y1, col):
    return P(rr(-w / 2, y0, w, y1 - y0, w / 2), col)


# ---------------------------------------------------------------- kiểu kim
# mỗi hàm: (R, T, W, c) -> list[str]; toạ độ cục bộ, gốc ở tâm xoay, y âm = hướng lên

def thanh(R, T, W, c):
    w = W * 0.62
    return [shaft(w, -R, T, c)]


def nhon(R, T, W, c):
    return [P(pts([(0, -R), (W / 2, -R * .3), (W * .36, T), (-W * .36, T), (-W / 2, -R * .3)]), c),
            L(0, -R * .9, 0, T * .8, max(1.2, W * .07))]


def dauphine(R, T, W, c):
    return [P(pts([(0, -R), (W / 2, T), (-W / 2, T)]), c),
            P(pts([(0, -R), (W / 2, T), (0, T)]), DARK, op=0.28)]


def kiem(R, T, W, c):
    bw = W * .3
    yg = -W * .9
    gw = max(3, W * .22)
    grip = max(3, W * .2)
    out = [P(pts([(0, -R), (bw, -R + W * 1.1), (bw, yg), (-bw, yg), (-bw, -R + W * 1.1)]), c),
           P(rr(-W * .75, yg, W * 1.5, gw, gw / 2), c),
           P(rr(-grip / 2, yg, grip, T - yg, grip / 2), c),
           P(circ(0, T - max(3.5, W * .22), max(3.5, W * .3)), c),
           L(0, -R + W * 1.6, 0, yg - 3, max(1.2, W * .07))]
    return out


def la_tre(R, T, W, c):
    d = f"M0,{n(T)}C{n(W * .95)},{n(T * .2)} {n(W * .8)},{n(-R * .7)} 0,{n(-R)}C{n(-W * .8)},{n(-R * .7)} {n(-W * .95)},{n(T * .2)} 0,{n(T)}Z"
    return [P(d, c), L(0, -R * .88, 0, T * .7, max(1.2, W * .07))]


def la_sen(R, T, W, c):
    cy = -R + W * 1.15
    rx, ry = W * .8, W * 1.15
    e = f"M{n(-rx)},{n(cy)}a{n(rx)},{n(ry)} 0 1,0 {n(2 * rx)},0a{n(rx)},{n(ry)} 0 1,0 {n(-2 * rx)},0Z"
    out = [shaft(max(3, W * .22), cy, T, c), P(e, c)]
    for ang in (-35, 0, 35):
        a = math.radians(ang)
        out.append(L(0, cy + ry * .7, math.sin(a) * rx * .8, cy + ry * .7 - math.cos(a) * ry * 1.25, max(1, W * .06)))
    return out


def canh_sen(R, T, W, c):
    d = (f"M0,{n(-R)}C{n(W * .55)},{n(-R + W * .9)} {n(W * .85)},{n(-R + W * 2)} 0,{n(-R + W * 2.9)}"
         f"C{n(-W * .85)},{n(-R + W * 2)} {n(-W * .55)},{n(-R + W * .9)} 0,{n(-R)}Z")
    return [shaft(max(3, W * .24), -R + W * 2.5, T, c), P(d, c),
            L(0, -R + W * .5, 0, -R + W * 2.4, max(1, W * .06)),
            L(0, -R + W * 2.2, W * .32, -R + W * 1.2, max(1, W * .05)),
            L(0, -R + W * 2.2, -W * .32, -R + W * 1.2, max(1, W * .05))]


def mui_ten(R, T, W, c):
    out = [shaft(max(3, W * .2), -R + W * 1.3, T, c),
           P(pts([(0, -R), (W * .75, -R + W * 1.7), (0, -R + W * 1.25), (-W * .75, -R + W * 1.7)]), c)]
    for s in (1, -1):
        out.append(P(pts([(0, T * .1), (s * W * .5, T * .1 + W * .5), (s * W * .5, T + W * .3), (0, T - W * .3)]), c))
    return out


def breguet(R, T, W, c):
    hw = max(1.6, W * .12)
    cy = -(R - W * 1.4)
    r = W * .5
    sw = max(2.4, W * .13)
    return [P(pts([(0, -R), (hw, -R + W * 2.6), (hw, T), (-hw, T), (-hw, -R + W * 2.6)]), c),
            S(circ(0, cy, r), c, sw)]


def nha_tho(R, T, W, c):
    outer = pts([(0, -R), (W / 2, -R * .45), (W * .3, T), (-W * .3, T), (-W / 2, -R * .45)])
    inner = pts([(0, -R * .82), (W * .24, -R * .45), (W * .12, -W * .4), (-W * .12, -W * .4), (-W * .24, -R * .45)])
    return [P(outer + inner, c, eo=True)]


def khung_rong(R, T, W, c):
    sw = max(2, W * .1)
    out = [S(pts([(0, -R), (W * .5, -R * .4), (0, T), (-W * .5, -R * .4)]), c, sw),
           L(0, -R + W * .8, 0, -W * .3, max(1.2, sw * .6), col=c, op=1)]
    return out


def alpha(R, T, W, c):
    outer = pts([(0, -R), (W * .5, -R + W * 1.7), (W * .5, T), (-W * .5, T), (-W * .5, -R + W * 1.7)])
    slot = pts([(0, -R + W * 2.6), (W * .2, -R + W * 3.3), (W * .2, -W * .2), (-W * .2, -W * .2), (-W * .2, -R + W * 3.3)])
    return [P(outer + slot, c, eo=True)]


def da_quang(R, T, W, c):
    w = W * .72
    sw = W * .32
    return [P(rr(-w / 2, -R, w, R + T, 3) + rr(-sw / 2, -R + W * .7, sw, R - W * 1.5, 2), c, eo=True)]


def hoa_tuyet(R, T, W, c):
    outer = pts([(0, -R), (W * .65, -R + W * 1.1), (0, -R + W * 2.2), (-W * .65, -R + W * 1.1)])
    inner = pts([(0, -R + W * .55), (W * .3, -R + W * 1.1), (0, -R + W * 1.65), (-W * .3, -R + W * 1.1)])
    return [shaft(max(3, W * .22), -R + W * 2.0, T, c), P(outer + inner, c, eo=True)]


def keo_mut(R, T, W, c, solid=False):
    r = W * .62
    cy = -R + r
    d = circ(0, cy, r) if solid else circ(0, cy, r) + circ(0, cy, r * .5)
    return [shaft(max(3, W * .2), cy, T, c), P(d, c, eo=True)]


def long_vu(R, T, W, c):
    d = (f"M0,{n(T)}C{n(W * .95)},{n(T * .0)} {n(W * .85)},{n(-R * .62)} 0,{n(-R)}"
         f"C{n(-W * .7)},{n(-R * .62)} {n(-W * .8)},{n(-R * .05)} 0,{n(T)}Z")
    out = [P(d, c), L(0, -R * .95, 0, T * .9, max(1.3, W * .08), op=.5)]
    for i in range(1, 7):
        y = -R * (.12 + .125 * i)
        k = (1 - abs(y) / R * .9)
        out.append(L(0, y, W * .6 * k, y - W * .5, max(1, W * .05)))
        out.append(L(0, y, -W * .55 * k, y - W * .5, max(1, W * .05)))
    return out


def tia_set(R, T, W, c):
    p = [(W * .15, -R), (W * .62, -R * .62), (W * .2, -R * .55), (W * .55, -R * .1), (-W * .05, T),
         (-W * .2, -R * .02), (W * .02, -R * .06), (-W * .38, -R * .55), (-W * .1, -R * .6), (-W * .5, -R * .62 + W * .2)]
    return [P(pts(p), c)]


def but_chi(R, T, W, c):
    w = W * .72
    top = -R + W * 1.5
    return [P(pts([(0, -R), (w / 2, top), (-w / 2, top)]), c),
            P(pts([(0, -R), (w * .17, -R + W * .45), (-w * .17, -R + W * .45)]), DARK, op=.55),
            P(rr(-w / 2, top, w, T - W * .55 - top, 0), c),
            L(0, top, 0, T - W * .55, max(1.2, W * .08), op=.22),
            P(rr(-w / 2, T - W * .55, w, W * .55, 2), DARK, op=.3)]


def mui_giao(R, T, W, c):
    yc = -R * .5
    d = (f"M0,{n(-R)}C{n(W * .62)},{n(-R * .85)} {n(W * .6)},{n(-R * .62)} {n(W * .2)},{n(yc)}"
         f"L{n(-W * .2)},{n(yc)}C{n(-W * .6)},{n(-R * .62)} {n(-W * .62)},{n(-R * .85)} 0,{n(-R)}Z")
    return [shaft(max(3, W * .2), yc, T, c), P(d, c),
            P(rr(-W * .3, yc - 1, W * .6, max(3, W * .26), 1.5), c),
            L(0, -R + W * .8, 0, yc - W * .3, max(1.2, W * .06))]


def sao_vang(R, T, W, c):
    ro = W * .95
    cy = -R + ro
    return [shaft(max(3, W * .2), cy, T, c), P(star(0, cy + ro * .06, ro, ro * .4), c)]


def trong_dong(R, T, W, c):
    r = W * .85
    cy = -R + r
    d = circ(0, cy, r) + circ(0, cy, r * .78) + circ(0, cy, r * .7) + star(0, cy, r * .5, r * .2)
    return [shaft(max(3, W * .2), cy, T, c), P(d, c, eo=True)]


def giot_nuoc(R, T, W, c):
    r = W * .85
    cy = -R + W * 1.9
    d = (f"M0,{n(-R)}C{n(W * .2)},{n(-R + W * .5)} {n(r)},{n(-R + W * 1.0)} {n(r)},{n(cy)}"
         f"A{n(r)},{n(r)} 0 0,1 {n(-r)},{n(cy)}C{n(-r)},{n(-R + W * 1.0)} {n(-W * .2)},{n(-R + W * .5)} 0,{n(-R)}Z")
    return [shaft(max(3, W * .2), cy, T, c), P(d, c),
            P(f"M{n(-r * .55)},{n(cy + 1)}a{n(r * .2)},{n(r * .35)} 0 1,0 {n(r * .4)},0Z", DARK, op=.0)]


def chuoi_hat(R, T, W, c):
    out = [shaft(max(2.4, W * .12), -R, T, c)]
    y = -R
    i = 0
    k = 9
    while True:
        r = W * (.2 + .34 * min(1, i / k))
        y += r if i == 0 else 0
        if y + r > T + 2:
            break
        out.append(f'<circle cx="0" cy="{n(y)}" r="{n(r)}" fill="{c}"/>')
        y += r + W * (.2 + .34 * min(1, (i + 1) / k)) + 1.5
        i += 1
        if i > 40:
            break
    return out


def non_la(R, T, W, c):
    top = -R + W * 1.2
    d = f"M0,{n(-R)}L{n(W)},{n(top)}Q0,{n(top + W * .38)} {n(-W)},{n(top)}Z"
    out = [shaft(max(3, W * .2), top, T, c), P(d, c)]
    for f_ in (.4, .65, .85):
        y = -R + W * 1.2 * f_
        h = W * f_
        out.append(f'<path d="M{n(-h)},{n(y)}Q0,{n(y + W * .3)} {n(h)},{n(y)}" fill="none" stroke="{DARK}" stroke-width="{n(max(1, W * .05))}" opacity=".3"/>')
    return out


def kim_cuong(R, T, W, c):
    out = []
    y = -R
    i = 0
    while True:
        t = min(1, i / 5)
        hw = W * (.22 + .3 * t)
        h = hw * 1.7
        if y + 2 * h > T + 3:
            break
        out.append(P(pts([(0, y), (hw, y + h), (0, y + 2 * h), (-hw, y + h)]), c))
        y += 2 * h
        i += 1
        if i > 30:
            break
    out.append(L(0, -R, 0, T, 0.5, col=c, op=1))
    return out


def ten_lua(R, T, W, c):
    body = (f"M0,{n(-R)}C{n(W * .55)},{n(-R * .8)} {n(W * .5)},{n(-R * .55)} {n(W * .5)},{n(-R * .3)}L{n(W * .5)},{n(T * .2)}"
            f"L{n(-W * .5)},{n(T * .2)}L{n(-W * .5)},{n(-R * .3)}C{n(-W * .5)},{n(-R * .55)} {n(-W * .55)},{n(-R * .8)} 0,{n(-R)}Z")
    win = circ(0, -R * .6, max(2.5, W * .2))
    out = [P(body + win, c, eo=True)]
    for s in (1, -1):
        out.append(P(pts([(s * W * .5, -R * .12), (s * W * 1.05, T), (s * W * .5, T * .25)]), c))
    out.append(P(pts([(W * .3, T * .2), (0, T), (-W * .3, T * .2)]), c))
    return out


STYLES = [
    ("thanh", "Thanh mảnh", thanh),
    ("nhon", "Nhọn", nhon),
    ("dauphine", "Dauphine", dauphine),
    ("kiem", "Kiếm", kiem),
    ("la-tre", "Lá tre", la_tre),
    ("la-sen", "Lá sen", la_sen),
    ("canh-sen", "Cánh sen", canh_sen),
    ("mui-ten", "Mũi tên", mui_ten),
    ("breguet", "Breguet", breguet),
    ("nha-tho", "Nhà thờ", nha_tho),
    ("khung-rong", "Khung rỗng", khung_rong),
    ("alpha", "Alpha", alpha),
    ("da-quang", "Thanh dạ quang", da_quang),
    ("hoa-tuyet", "Bông tuyết", hoa_tuyet),
    ("keo-mut", "Kẹo mút", keo_mut),
    ("long-vu", "Lông vũ", long_vu),
    ("tia-set", "Tia sét", tia_set),
    ("but-chi", "Bút chì", but_chi),
    ("mui-giao", "Mũi giáo", mui_giao),
    ("sao-vang", "Sao vàng", sao_vang),
    ("trong-dong", "Trống đồng", trong_dong),
    ("giot-nuoc", "Giọt nước", giot_nuoc),
    ("chuoi-hat", "Chuỗi hạt", chuoi_hat),
    ("non-la", "Nón lá", non_la),
    ("kim-cuong", "Chuỗi kim cương", kim_cuong),
    ("ten-lua", "Tên lửa", ten_lua),
]

# kích thước trong hệ 512 (= 466 của app × 512/466)
KINDS = {
    "gio": dict(R=137, T=26, W=26, col=MAIN, name="Kim giờ"),
    "phut": dict(R=203, T=30, W=21, col=MAIN, name="Kim phút"),
    "giay": dict(R=226, T=46, W=8, col=RED, name="Kim giây"),
}


def body(slug, kind):
    fn = dict((s, f) for s, _, f in STYLES)[slug]
    k = KINDS[kind]
    if slug == "keo-mut" and kind == "giay":
        els = keo_mut(k["R"], k["T"], k["W"], k["col"], solid=True)
    else:
        els = fn(k["R"], k["T"], k["W"], k["col"])
    if kind == "giay":
        els.append(f'<circle cx="0" cy="{n(k["T"] * .6)}" r="7" fill="{k["col"]}"/>')
    return els


def hand_svg(slug, title, kind):
    k = KINDS[kind]
    els = "\n".join(body(slug, kind))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">\n'
            f'<title>{title} – {k["name"].lower()}</title>\n'
            f'<!-- tâm xoay (256,256), đầu kim hướng lên; reach={k["R"]} tail={k["T"]} (hệ 512; nhân 466/512 cho mặt app) -->\n'
            f'<g transform="translate(256 256)">\n{els}\n</g>\n</svg>\n')


def main():
    os.makedirs(OUT, exist_ok=True)
    manifest = []
    for slug, title, _ in STYLES:
        d = os.path.join(OUT, slug)
        os.makedirs(d, exist_ok=True)
        for kind in KINDS:
            with open(os.path.join(d, kind + ".svg"), "w", encoding="utf-8") as fh:
                fh.write(hand_svg(slug, title, kind))
        manifest.append({"id": slug, "title": title,
                         "files": {k: f"{slug}/{k}.svg" for k in KINDS}})
    # tổng hợp: lưới đồng hồ mini
    cols = 5
    cell = 300
    rows = math.ceil(len(STYLES) / cols)
    W_, H_ = cols * cell, rows * (cell + 30) + 20
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W_} {H_}" width="{W_}" height="{H_}" font-family="sans-serif">',
         f'<rect width="{W_}" height="{H_}" fill="#0b0b0b"/>']
    ang = {"gio": (10 + 8 / 60) * 30, "phut": (8 + 35 / 60) * 6, "giay": 35 * 6}
    for i, (slug, title, _) in enumerate(STYLES):
        cx = (i % cols) * cell + cell / 2
        cy = (i // cols) * (cell + 30) + cell / 2 + 10
        sc = (cell / 2 - 14) / 256
        s.append(f'<circle cx="{n(cx)}" cy="{n(cy)}" r="{n(cell / 2 - 10)}" fill="#161616" stroke="#2a2a2a"/>')
        for kind in ("gio", "phut", "giay"):
            s.append(f'<g transform="translate({n(cx)} {n(cy)}) rotate({n(ang[kind])}) scale({n(sc)})">')
            s.extend(body(slug, kind))
            s.append("</g>")
        s.append(f'<text x="{n(cx)}" y="{n(cy + cell / 2 + 8)}" text-anchor="middle" fill="#E8C77A" font-size="15">{title}</text>')
    s.append("</svg>\n")
    with open(os.path.join(OUT, "_tong-hop.svg"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(s))
    with open(os.path.join(OUT, "kim.json"), "w", encoding="utf-8") as fh:
        json.dump({"canvas": 512, "pivot": [256, 256], "tipDirection": "up",
                   "reach": {k: v["R"] for k, v in KINDS.items()},
                   "tail": {k: v["T"] for k, v in KINDS.items()},
                   "defaultColor": {k: v["col"] for k, v in KINDS.items()},
                   "styles": manifest}, fh, ensure_ascii=False, indent=2)
    print(len(STYLES), "kiểu")


main()
