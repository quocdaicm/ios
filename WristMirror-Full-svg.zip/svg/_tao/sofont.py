import os, sys, math, json
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
OUT=sys.argv[1]
GF="/usr/share/fonts/truetype/google-fonts/"
# id, tên, file, chế độ (fill/outline/shadow/gold), cao số (hệ 512), tracking, nghiêng thêm, roman?
STY=[
 ("cardo","Cardo cổ điển",GF+"ofl/cardo/Cardo-Regular.ttf","fill",42,.02,0,0),
 ("cardo-nghieng","Cardo nghiêng",GF+"ofl/cardo/Cardo-Italic.ttf","fill",42,.02,0,0),
 ("crimson-nghieng","Crimson nghiêng đậm",GF+"ofl/crimsontext/CrimsonText-BoldItalic.ttf","fill",44,.02,0,0),
 ("free-serif","FreeSerif đậm","/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf","fill",42,.03,0,0),
 ("dunhill","Dunhill nghệ thuật","/usr/share/texmf/fonts/opentype/public/lm/lmromandunh10-oblique.otf","fill",42,.03,0,0),
 ("inter-manh","Tối giản mảnh","/usr/share/fonts/opentype/inter/InterDisplay-Thin.otf","fill",40,.05,0,0),
 ("anton","Cao hẹp Anton",GF+"ofl/anton/Anton-Regular.ttf","fill",46,.03,0,0),
 ("archivo","Dày Archivo",GF+"ofl/archivoblack/ArchivoBlack-Regular.ttf","fill",38,.02,0,0),
 ("vien-rong","Viền rỗng Cardo đậm",GF+"ofl/cardo/Cardo-Bold.ttf","outline",44,.04,0,0),
 ("bong-doi","Bóng đôi Crimson",GF+"ofl/crimsontext/CrimsonText-SemiBold.ttf","shadow",44,.03,0,0),
 ("la-ma-cardo","La Mã Cardo",GF+"ofl/cardo/Cardo-Bold.ttf","fill",36,.08,0,1),
 ("la-ma-vien","La Mã viền rỗng",GF+"ofl/cardo/Cardo-Bold.ttf","outline",36,.08,0,1),
]
RN=["","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"]
def n(v):
    s=("%.1f"%v).rstrip("0").rstrip("."); return "0" if s in("-0","") else s
_cache={}
def font(p):
    if p not in _cache:
        f=TTFont(p); _cache[p]=(f,f.getGlyphSet(),f.getBestCmap(),f["head"].unitsPerEm)
    return _cache[p]
def layout(path,text,H,track):
    f,gs,cmap,upm=font(path)
    ref='0' if text.isdigit() else 'I'
    bp=BoundsPen(gs); gs[cmap[ord(ref)]].draw(bp); b=bp.bounds
    sc=H/(b[3]-b[1]); base=b[1]
    x=0; parts=[]; bb=BoundsPen(gs)
    for ch in text:
        g=gs[cmap[ord(ch)]]
        m=(sc,0,0,-sc,x,base*sc)
        sp=SVGPathPen(gs, ntos=lambda v:("%.2f"%v).rstrip("0").rstrip("."))
        g.draw(TransformPen(sp,m)); g.draw(TransformPen(bb,m))
        parts.append(sp.getCommands())
        x+=g.width*sc+track*H
    return bb.bounds,"".join(parts)
def item(path,text,H,track,mode,cx,cy,col="#FFFFFF"):
    bd,d=layout(path,text,H,track)
    tr=f'translate({n(cx-(bd[0]+bd[2])/2)} {n(cy-(bd[1]+bd[3])/2)})'
    g=f'<g transform="{tr}">'
    if mode=="shadow":
        g+=f'<path d="{d}" fill="{col}" opacity=".28" transform="translate(2.2 2.6)"/>'
    if mode=="outline":
        g+=f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.6" stroke-linejoin="round"/>'
    else:
        g+=f'<path d="{d}" fill="{col}"/>'
    return g+"</g>"
def dial(sty):
    _,name,p,mode,H,track,_,rom=sty; out=[]
    r=186
    for k in range(1,13):
        a=math.radians(k*30)
        txt=RN[k] if rom else str(k)
        out.append(item(p,txt,H*(0.85 if rom and len(txt)>2 else 1),track,mode,256+r*math.sin(a),256-r*math.cos(a)))
    return out
def single(sty,k):
    _,name,p,mode,H,track,_,rom=sty
    txt=RN[k] if rom else str(k)
    bd,_d=layout(p,txt,H,track); s=min(2.4,104/max(bd[2]-bd[0],1))
    return [f'<g transform="translate(64 64) scale({n(s)})">'+item(p,txt,H,track,mode,0,0)+"</g>"]
os.makedirs(OUT,exist_ok=True); meta=[]
for sty in STY:
    sid,name=sty[0],sty[1]; d=os.path.join(OUT,sid); os.makedirs(os.path.join(d,"so"),exist_ok=True)
    open(os.path.join(d,"mat-so.svg"),"w",encoding="utf-8").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">\n<title>{name}</title>\n<!-- số giờ dạng đường vẽ (không cần font), tâm (256,256), màu #FFFFFF -->\n'+"\n".join(dial(sty))+"\n</svg>\n")
    for k in range(1,13):
        open(os.path.join(d,"so",f"{k:02d}.svg"),"w",encoding="utf-8").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">\n<title>{name} {k}</title>\n'+"\n".join(single(sty,k))+"\n</svg>\n")
    meta.append({"id":sid,"title":name})
cols,cell=4,300; rows=math.ceil(len(STY)/cols); Wd,Hd=cols*cell,rows*(cell+26)+10
s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Wd} {Hd}" width="{Wd}" height="{Hd}" font-family="sans-serif"><rect width="{Wd}" height="{Hd}" fill="#0b0b0b"/>']
for i,sty in enumerate(STY):
    x,y=(i%cols)*cell,(i//cols)*(cell+26)+6; sc=(cell-12)/512
    s.append(f'<circle cx="{x+cell/2}" cy="{y+cell/2}" r="{cell/2-6}" fill="#161616" stroke="#262626"/><g transform="translate({x+6} {y+6}) scale({n(sc)})">'+"\n".join(dial(sty))+'</g>')
    s.append(f'<text x="{x+cell/2}" y="{y+cell+16}" text-anchor="middle" fill="#E8C77A" font-size="14">{sty[1]}</text>')
open(os.path.join(OUT,"_tong-hop.svg"),"w",encoding="utf-8").write("\n".join(s)+"</svg>\n")
json.dump({"canvas":512,"pivot":[256,256],"styles":meta,"note":"Đường vẽ được chuyển từ font OFL/GPL-font-exception; xem README"},open(os.path.join(OUT,"so-gio.json"),"w",encoding="utf-8"),ensure_ascii=False,indent=2)
print(len(STY))
