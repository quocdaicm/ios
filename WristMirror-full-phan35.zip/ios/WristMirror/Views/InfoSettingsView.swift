// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Cài đặt các mục thông tin: dương lịch, âm lịch, thứ, giờ số, pin, bước chân, nhịp tim, calo, thời tiết, tên. Dùng chung cho Studio và "Thêm thông tin vào HWT".
struct InfoSettingsView: View {
    @Binding var design: FaceDesign

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Toggle(tr("Tự sắp xếp, không cho chữ chồng nhau hoặc đè lên số giờ"), isOn: $design.autoLayout)
                Toggle(tr("Viền chữ mờ phía sau cho dễ đọc"), isOn: $design.textOutline)
                Toggle(tr("Biểu tượng SVG riêng (tắt = biểu tượng iOS)"), isOn: $design.iconSVG)
                Picker(tr("Font chữ"), selection: $design.textFontIndex) {
                    ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
                }
                .pickerStyle(.menu)
                Picker(tr("Font số"), selection: $design.numberFontIndex) {
                    ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
                }
                .pickerStyle(.menu)
            }
            .card()
            ElementStyleView(design: $design)
            dataStyleCard
            block(tr("Dương lịch"), isOn: $design.showSolar) { dateContent(lunar: false) }
            block(tr("Âm lịch"), isOn: $design.showLunar) { dateContent(lunar: true) }
            block(tr("Thứ trong tuần"), isOn: $design.showWeekday) {
                ColorPicker(tr("Màu chữ"), selection: $design.weekdayColor, supportsOpacity: false)
                pos(size: $design.weekdaySize, x: $design.weekdayX, y: $design.weekdayY)
                plateControls("weekday")
            }
            block(tr("Giờ số (HH:MM)"), isOn: $design.showDigital) {
                styleOverride(custom: $design.digitalCustom, style: $design.digitalStyle, own: $design.digitalOwnColors) {
                    digitalStyleGrid
                }
                if !(design.digitalStyleEff.hasOwnPalette && design.digitalOwnEff) {
                    ColorPicker(tr("Màu chữ"), selection: $design.digitalColor, supportsOpacity: false)
                }
                pos(size: $design.digitalSize, x: $design.digitalX, y: $design.digitalY)
                plateControls("digital")
            }
            dataBlock("Pin", $design.battery, key: "battery", unitTitle: tr("Hiện %"))
            dataBlock(tr("Bước chân"), $design.steps, key: "steps", unitTitle: tr("Hiện chữ \"bước\""))
            dataBlock(tr("Nhịp tim"), $design.heart, key: "heart", unitTitle: tr("Hiện chữ \"bpm\""))
            dataBlock("Calo", $design.calories, key: "calories", unitTitle: tr("Hiện chữ \"kcal\""))
            block(tr("Thời tiết"), isOn: $design.weather.show) {
                if showsTextColor(design.weather) {
                    ColorPicker(tr("Màu chữ"), selection: $design.weather.color, supportsOpacity: false)
                }
                dataItemStyle($design.weather)
                pos(size: $design.weather.size, x: $design.weather.x, y: $design.weather.y, xTitle: tr("Vị trí ngang (mép trái khối)"))
                Toggle(tr("Hiện biểu tượng thời tiết"), isOn: $design.weatherIcon)
                if design.weatherIcon {
                    Toggle(tr("Biểu tượng một màu (theo màu chữ)"), isOn: $design.weatherIconMono)
                }
                Toggle(tr("Hiện tên tình trạng (nắng, mưa…)"), isOn: $design.weatherText)
                Toggle(tr("Hiện nhiệt độ cao / thấp"), isOn: $design.weatherRange)
                plateControls("weather")
            }
            block(tr("Tên của bạn"), isOn: $design.showName) {
                TextField(tr("Nhập tên hiển thị"), text: $design.nameText)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: design.nameText) { v in
                        let c = FaceRenderer.cleanName(v)
                        if c != v && v.count > FaceRenderer.maxNameChars { design.nameText = c }
                    }
                Picker(tr("Kiểu chữ"), selection: $design.nameStyle) {
                    ForEach(0..<FaceRenderer.nameStyleTitles.count, id: \.self) { Text(tr(FaceRenderer.nameStyleTitles[$0])).tag($0) }
                }
                .pickerStyle(.segmented)
                ColorPicker(tr("Màu chữ"), selection: $design.nameColor, supportsOpacity: false)
                pos(size: $design.nameSize, x: $design.nameX, y: $design.nameY)
                plateControls("name")
            }
        }
    }

    private func bind<T>(_ kp: WritableKeyPath<FaceDesign, T>) -> Binding<T> {
        Binding(get: { design[keyPath: kp] }, set: { design[keyPath: kp] = $0 })
    }

    /// Nội dung một khối ngày/tháng: dạng hiển thị ("D lịch 26/11", "D lịch 26-11", "Â lịch 26/11", "Â lịch 26-11"),
    /// lưới kiểu số vector, màu, vị trí, nhãn chữ (Việt/Anh) và khung nền.
    @ViewBuilder
    private func dateContent(lunar: Bool) -> some View {
        let styleKP: WritableKeyPath<FaceDesign, DigitalStyle> = lunar ? \.lunarStyle : \.solarStyle
        let ownKP: WritableKeyPath<FaceDesign, Bool> = lunar ? \.lunarOwnColors : \.solarOwnColors
        let colorKP: WritableKeyPath<FaceDesign, Color> = lunar ? \.lunarColor : \.solarColor
        let sizeKP: WritableKeyPath<FaceDesign, Double> = lunar ? \.lunarSize : \.solarSize
        let xKP: WritableKeyPath<FaceDesign, Double> = lunar ? \.lunarX : \.solarX
        let yKP: WritableKeyPath<FaceDesign, Double> = lunar ? \.lunarY : \.solarY
        let labelKP: WritableKeyPath<FaceDesign, Bool> = lunar ? \.lunarLabel : \.solarLabel
        let customKP: WritableKeyPath<FaceDesign, Bool> = lunar ? \.lunarCustom : \.solarCustom
        let style = lunar ? design.lunarStyleEff : design.solarStyleEff
        let ownEff = lunar ? design.lunarOwnEff : design.solarOwnEff
        dateFormatPicker(lunar: lunar)
        styleOverride(custom: bind(customKP), style: bind(styleKP), own: bind(ownKP)) {
            dateStyleGrid(lunar: lunar)
        }
        if !(style.hasOwnPalette && ownEff) {
            ColorPicker(tr("Màu chữ"), selection: bind(colorKP), supportsOpacity: false)
        }
        pos(size: bind(sizeKP), x: bind(xKP), y: bind(yKP))
        Toggle(tr("Hiện nhãn chữ"), isOn: bind(labelKP))
        if design[keyPath: labelKP] {
            dateLangPicker(lunar: lunar)
            if style != .classic {
                let fontKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarLabelFont : \.solarLabelFont
                Picker(tr("Kiểu chữ nhãn"), selection: bind(fontKP)) {
                    ForEach(0..<DateLabelShapes.fontTitles.count, id: \.self) { Text(tr(DateLabelShapes.fontTitles[$0])).tag($0) }
                }
                .pickerStyle(.menu)
            }
        }
        plateControls(lunar ? "lunar" : "solar")
    }

    /// Chọn dạng hiển thị: nhãn + 26/11 hoặc nhãn + 26-11.
    private func dateFormatPicker(lunar: Bool) -> some View {
        let sepKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarSep : \.solarSep
        let langKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarLabelLang : \.solarLabelLang
        let label = FaceRenderer.dateLabelString(lunar: lunar, lang: design[keyPath: langKP])
        return VStack(alignment: .leading, spacing: 4) {
            Text(tr("Dạng hiển thị")).font(.footnote).foregroundStyle(.secondary)
            Picker(tr("Dạng hiển thị"), selection: bind(sepKP)) {
                ForEach(0..<2, id: \.self) { i in
                    Text("\(label) 26\(FaceRenderer.dateSepString(i))11").tag(i)
                }
            }
            .pickerStyle(.segmented)
        }
    }

    /// Chọn ngôn ngữ chữ nhãn: theo app / Tiếng Việt ("D lịch", "Â lịch") / English ("Solar", "Lunar").
    private func dateLangPicker(lunar: Bool) -> some View {
        let langKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarLabelLang : \.solarLabelLang
        return VStack(alignment: .leading, spacing: 4) {
            Text(tr("Chữ nhãn")).font(.footnote).foregroundStyle(.secondary)
            Picker(tr("Chữ nhãn"), selection: bind(langKP)) {
                Text(tr("Theo app")).tag(0)
                Text(tr("Tiếng Việt")).tag(1)
                Text("English").tag(2)
            }
            .pickerStyle(.segmented)
        }
    }

    /// Lưới chọn kiểu số ngày/tháng (hình thu nhỏ "nhãn + 26/11").
    private func dateStyleGrid(lunar: Bool) -> some View {
        let styleKP: WritableKeyPath<FaceDesign, DigitalStyle> = lunar ? \.lunarStyle : \.solarStyle
        let sepKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarSep : \.solarSep
        let langKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarLabelLang : \.solarLabelLang
        let current = design[keyPath: styleKP]
        let sep = design[keyPath: sepKP]
        let lang = design[keyPath: langKP]
        let fontKP: WritableKeyPath<FaceDesign, Int> = lunar ? \.lunarLabelFont : \.solarLabelFont
        let fi = design[keyPath: fontKP]
        return VStack(alignment: .leading, spacing: 10) {
            Text(trf("Kiểu số: %@", tr(current.title))).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 104), spacing: 10)], spacing: 12) {
                ForEach(DigitalStyle.allCases) { st in
                    Button {
                        design[keyPath: styleKP] = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: DateThumbs.image(st, lunar: lunar, sep: sep, lang: lang, font: fi))
                                .resizable()
                                .aspectRatio(DateThumbs.size.width / DateThumbs.size.height, contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(current == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(st.title)).font(.caption2).foregroundStyle(.secondary)
                                .lineLimit(2).minimumScaleFactor(0.75).multilineTextAlignment(.center)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    /// Lưới chọn kiểu số giờ số (hình thu nhỏ "13:00").
    private var digitalStyleGrid: some View {
        styleGrid(bind(\.digitalStyle), thumb: { DigitalThumbs.image($0) }, aspect: 240.0 / 84.0)
    }

    /// Lưới chọn kiểu số dùng chung (hình thu nhỏ do `thumb` vẽ).
    private func styleGrid(_ sel: Binding<DigitalStyle>, thumb: @escaping (DigitalStyle) -> UIImage, aspect: CGFloat) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(trf("Kiểu số: %@", tr(sel.wrappedValue.title))).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 104), spacing: 10)], spacing: 12) {
                ForEach(DigitalStyle.allCases) { st in
                    Button {
                        sel.wrappedValue = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: thumb(st))
                                .resizable()
                                .aspectRatio(aspect, contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(sel.wrappedValue == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(st.title)).font(.caption2).foregroundStyle(.secondary)
                                .lineLimit(2).minimumScaleFactor(0.75).multilineTextAlignment(.center)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    /// Kiểu số chung cho tất cả số liệu (pin, bước chân, nhịp tim, calo, thời tiết).
    private var dataStyleCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Kiểu số chung cho tất cả")).font(.headline)
            Text(tr("Áp dụng cho giờ số, dương lịch, âm lịch, pin, bước chân, nhịp tim, calo và thời tiết. Mỗi mục có thể chọn kiểu riêng bên dưới."))
                .font(.footnote).foregroundStyle(.secondary)
            styleGrid(bind(\.dataStyle), thumb: { DataThumbs.image($0) }, aspect: DataThumbs.size.width / DataThumbs.size.height)
            if design.dataStyle.hasOwnPalette {
                Toggle(tr("Dùng màu gốc của kiểu số"), isOn: $design.dataOwnColors)
            }
        }
        .card()
    }

    /// Màu chữ của mục chỉ có tác dụng khi số không dùng màu gốc của kiểu vector.
    private func showsTextColor(_ w: DataWidget) -> Bool {
        let st = w.customStyle ? w.style : design.dataStyle
        let own = w.customStyle ? w.ownColors : design.dataOwnColors
        return !(st.hasOwnPalette && own)
    }

    /// Tuỳ chọn kiểu số riêng của một mục số liệu (tắt = theo kiểu chung).
    @ViewBuilder
    private func dataItemStyle(_ w: Binding<DataWidget>) -> some View {
        styleOverride(custom: w.customStyle, style: w.style, own: w.ownColors) {
            styleGrid(w.style, thumb: { DataThumbs.image($0) }, aspect: DataThumbs.size.width / DataThumbs.size.height)
        }
    }

    /// Công tắc "Kiểu số riêng": bật thì hiện lưới kiểu (`grid`) và công tắc màu gốc, tắt thì ghi chú đang theo kiểu chung.
    @ViewBuilder
    private func styleOverride<G: View>(custom: Binding<Bool>, style: Binding<DigitalStyle>, own: Binding<Bool>,
                                        @ViewBuilder grid: () -> G) -> some View {
        Toggle(tr("Kiểu số riêng cho mục này"), isOn: custom)
        if custom.wrappedValue {
            grid()
            if style.wrappedValue.hasOwnPalette {
                Toggle(tr("Dùng màu gốc của kiểu số"), isOn: own)
            }
        } else {
            Text(trf("Đang dùng kiểu chung: %@", tr(design.dataStyle.title))).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func block<C: View>(_ title: String, isOn: Binding<Bool>, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: isOn) { Text(tr(title)).font(.headline) }
            if isOn.wrappedValue { content() }
        }
        .card()
    }

    /// Mục số liệu do đồng hồ cập nhật (pin, bước chân, nhịp tim, calo).
    private func dataBlock(_ title: String, _ w: Binding<DataWidget>, key: String, unitTitle: String) -> some View {
        block(title, isOn: w.show) {
            if showsTextColor(w.wrappedValue) {
                ColorPicker(tr("Màu chữ"), selection: w.color, supportsOpacity: false)
            }
            dataItemStyle(w)
            pos(size: w.size, x: w.x, y: w.y, xTitle: tr("Vị trí ngang (mép trái số)"))
            Toggle(tr(unitTitle), isOn: w.unit)
            Toggle(tr("Hiện biểu tượng"), isOn: w.icon)
            if w.icon.wrappedValue {
                Toggle(tr("Biểu tượng một màu (theo màu chữ)"), isOn: w.iconMono)
            }
            plateControls(key)
        }
    }

    /// Khung nền SVG phía sau một mục (viên thuốc, lục giác, viền đôi…).
    private func plateControls(_ key: String) -> some View {
        let b = Binding<PlateStyle>(get: { design.plates[key] ?? PlateStyle() }, set: { design.plates[key] = $0 })
        return VStack(alignment: .leading, spacing: 8) {
            Picker(tr("Khung nền SVG"), selection: b.shape) {
                ForEach(0..<FacePlate.titles.count, id: \.self) { Text(tr(FacePlate.titles[$0])).tag($0) }
            }
            .pickerStyle(.menu)
            if b.wrappedValue.shape > 0 {
                ColorPicker(tr("Màu nền khung"), selection: b.fill, supportsOpacity: false)
                ColorPicker(tr("Màu viền khung"), selection: b.line, supportsOpacity: false)
                labeled(tr("Độ đậm nền khung")) { Slider(value: b.opacity, in: 0.1...1) }
                Toggle(tr("Viền khung"), isOn: b.outline)
            }
        }
    }

    private func pos(size: Binding<Double>, x: Binding<Double>, y: Binding<Double>, xTitle: String = tr("Vị trí ngang")) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            labeled(tr("Cỡ chữ")) { Slider(value: size, in: 0.6...1.8) }
            labeled(xTitle) { Slider(value: x, in: 0.1...0.9) }
            labeled(tr("Vị trí dọc")) { Slider(value: y, in: 0.1...0.9) }
        }
    }

    private func labeled<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(tr(title)).font(.footnote).foregroundStyle(.secondary)
            content()
        }
    }
}
