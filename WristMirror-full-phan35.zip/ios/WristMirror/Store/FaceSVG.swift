// Tính năng mới của bản iOS (không có trong WristMirror gốc).
import SwiftUI
import UIKit

// MARK: - Bộ vẽ SVG nhỏ (path, circle, ellipse, rect) + khung nền SVG cho từng mục thông tin

/// Đọc và vẽ một đoạn SVG đơn giản. Hỗ trợ: path (M L H V C S Q Z, viết hoa/thường), circle, ellipse, rect (rx),
/// thuộc tính fill, stroke, stroke-width, opacity. Màu: #rgb, #rrggbb, "none" hoặc tên trong `palette`
/// (ví dụ accent, currentColor). Vẽ vào ngữ cảnh UIKit hiện tại (gốc trên-trái).
enum MiniSVG {
    private static let elementRegex = try! NSRegularExpression(pattern: #"<(path|circle|ellipse|rect)\b([^>]*?)/?>"#)
    private static let attrRegex = try! NSRegularExpression(pattern: #"([A-Za-z-]+)="([^"]*)""#)
    private static let tokenRegex = try! NSRegularExpression(pattern: #"[MmLlHhVvCcSsQqZz]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?"#)

    static func draw(_ svg: String, box: CGSize, in rect: CGRect, palette: [String: UIColor]) {
        guard let ctx = UIGraphicsGetCurrentContext(), box.width > 0, box.height > 0, rect.width > 0, rect.height > 0 else { return }
        let s = min(rect.width / box.width, rect.height / box.height)
        let ox = rect.midX - box.width * s / 2
        let oy = rect.midY - box.height * s / 2
        let ns = svg as NSString
        let whole = NSRange(location: 0, length: ns.length)
        for m in elementRegex.matches(in: svg, range: whole) {
            let tag = ns.substring(with: m.range(at: 1))
            let attrString = ns.substring(with: m.range(at: 2)) as NSString
            var a = [String: String]()
            for am in attrRegex.matches(in: attrString as String, range: NSRange(location: 0, length: attrString.length)) {
                a[attrString.substring(with: am.range(at: 1))] = attrString.substring(with: am.range(at: 2))
            }
            guard let path = makePath(tag, a) else { continue }
            let opacity = CGFloat(Double(a["opacity"] ?? "1") ?? 1)
            let fill = color(a["fill"] ?? "currentColor", palette)
            let stroke = color(a["stroke"] ?? "none", palette)
            let sw = CGFloat(Double(a["stroke-width"] ?? "1") ?? 1)
            ctx.saveGState()
            ctx.translateBy(x: ox, y: oy)
            ctx.scaleBy(x: s, y: s)
            if let f = fill {
                ctx.setFillColor(f.withAlphaComponent(f.cgColor.alpha * opacity).cgColor)
                ctx.addPath(path)
                ctx.fillPath()
            }
            if let st = stroke {
                ctx.setStrokeColor(st.withAlphaComponent(st.cgColor.alpha * opacity).cgColor)
                ctx.setLineWidth(sw)
                ctx.setLineCap(.round)
                ctx.setLineJoin(.round)
                ctx.addPath(path)
                ctx.strokePath()
            }
            ctx.restoreGState()
        }
    }

    private static func num(_ a: [String: String], _ k: String) -> CGFloat { CGFloat(Double(a[k] ?? "0") ?? 0) }

    private static func makePath(_ tag: String, _ a: [String: String]) -> CGPath? {
        switch tag {
        case "path":
            return parsePath(a["d"] ?? "")
        case "circle":
            let r = num(a, "r")
            return CGPath(ellipseIn: CGRect(x: num(a, "cx") - r, y: num(a, "cy") - r, width: r * 2, height: r * 2), transform: nil)
        case "ellipse":
            let rx = num(a, "rx"), ry = num(a, "ry")
            return CGPath(ellipseIn: CGRect(x: num(a, "cx") - rx, y: num(a, "cy") - ry, width: rx * 2, height: ry * 2), transform: nil)
        case "rect":
            let r = CGRect(x: num(a, "x"), y: num(a, "y"), width: num(a, "width"), height: num(a, "height"))
            let rx = min(num(a, "rx"), r.width / 2, r.height / 2)
            return CGPath(roundedRect: r, cornerWidth: rx, cornerHeight: rx, transform: nil)
        default:
            return nil
        }
    }

    private static func color(_ value: String, _ palette: [String: UIColor]) -> UIColor? {
        if value == "none" { return nil }
        if let c = palette[value] { return c }
        guard value.hasPrefix("#") else { return nil }
        var h = String(value.dropFirst())
        if h.count == 3 { h = h.map { "\($0)\($0)" }.joined() }
        guard h.count == 6, let v = Int(h, radix: 16) else { return nil }
        return UIColor(red: CGFloat((v >> 16) & 255) / 255, green: CGFloat((v >> 8) & 255) / 255, blue: CGFloat(v & 255) / 255, alpha: 1)
    }

    static func parsePath(_ d: String) -> CGPath {
        let ns = d as NSString
        let tokens = tokenRegex.matches(in: d, range: NSRange(location: 0, length: ns.length)).map { ns.substring(with: $0.range) }
        let path = CGMutablePath()
        var i = 0
        var cmd: Character = "M"
        var cur = CGPoint.zero, start = CGPoint.zero
        var lastCtrl: CGPoint?
        func isCmd(_ t: String) -> Bool { t.count == 1 && t.first!.isLetter }
        func next() -> CGFloat {
            guard i < tokens.count, !isCmd(tokens[i]) else { return 0 }
            defer { i += 1 }
            return CGFloat(Double(tokens[i]) ?? 0)
        }
        while i < tokens.count {
            if isCmd(tokens[i]) { cmd = tokens[i].first!; i += 1 }
            let rel = cmd.isLowercase
            switch cmd {
            case "Z", "z":
                path.closeSubpath()
                cur = start
                lastCtrl = nil
                if i < tokens.count, !isCmd(tokens[i]) { i += 1 }
            case "M", "m":
                let x = next(), y = next()
                cur = rel ? CGPoint(x: cur.x + x, y: cur.y + y) : CGPoint(x: x, y: y)
                start = cur
                path.move(to: cur)
                cmd = rel ? "l" : "L"
                lastCtrl = nil
            case "L", "l":
                let x = next(), y = next()
                cur = rel ? CGPoint(x: cur.x + x, y: cur.y + y) : CGPoint(x: x, y: y)
                path.addLine(to: cur)
                lastCtrl = nil
            case "H", "h":
                let x = next()
                cur = CGPoint(x: rel ? cur.x + x : x, y: cur.y)
                path.addLine(to: cur)
                lastCtrl = nil
            case "V", "v":
                let y = next()
                cur = CGPoint(x: cur.x, y: rel ? cur.y + y : y)
                path.addLine(to: cur)
                lastCtrl = nil
            case "C", "c":
                let o = rel ? cur : .zero
                let c1 = CGPoint(x: o.x + next(), y: o.y + next())
                let c2 = CGPoint(x: o.x + next(), y: o.y + next())
                let e = CGPoint(x: o.x + next(), y: o.y + next())
                path.addCurve(to: e, control1: c1, control2: c2)
                cur = e
                lastCtrl = c2
            case "S", "s":
                let o = rel ? cur : .zero
                let c1 = lastCtrl.map { CGPoint(x: 2 * cur.x - $0.x, y: 2 * cur.y - $0.y) } ?? cur
                let c2 = CGPoint(x: o.x + next(), y: o.y + next())
                let e = CGPoint(x: o.x + next(), y: o.y + next())
                path.addCurve(to: e, control1: c1, control2: c2)
                cur = e
                lastCtrl = c2
            case "Q", "q":
                let o = rel ? cur : .zero
                let c = CGPoint(x: o.x + next(), y: o.y + next())
                let e = CGPoint(x: o.x + next(), y: o.y + next())
                path.addQuadCurve(to: e, control: c)
                cur = e
                lastCtrl = nil
            default:
                i += 1
            }
        }
        return path
    }
}

// MARK: - Khung nền SVG

/// Kiểu khung nền phía sau một mục thông tin (tuỳ chọn riêng cho từng mục).
struct PlateStyle {
    /// 0 = không có khung; 1... xem `FacePlate.titles`.
    var shape = 0
    var fill = Color.black
    var line = Color(red: 0.92, green: 0.76, blue: 0.40)
    /// Độ đậm của màu nền (0.1 ... 1).
    var opacity = 0.55
    var outline = true
}

enum FacePlate {
    static let titles = ["Không", "Viên thuốc", "Chữ nhật bo", "Lục giác dẹt", "Bát giác", "Viền đôi", "Khung góc"]

    private static func f(_ v: Double) -> String { String(format: "%.1f", v) }

    /// SVG của khung kích thước w × h (px), viewBox trùng kích thước thật nên góc bo không bị méo.
    static func svg(shape: Int, w: Double, h: Double, outline: Bool) -> String {
        let i = 1.5
        let iw = w - 2 * i, ih = h - 2 * i
        let stroke = outline ? #"stroke="line" stroke-width="2.5""# : #"stroke="none""#
        switch shape {
        case 1:
            return #"<rect x="\#(f(i))" y="\#(f(i))" width="\#(f(iw))" height="\#(f(ih))" rx="\#(f(ih / 2))" fill="fill" \#(stroke)/>"#
        case 2:
            return #"<rect x="\#(f(i))" y="\#(f(i))" width="\#(f(iw))" height="\#(f(ih))" rx="\#(f(min(h * 0.26, 16)))" fill="fill" \#(stroke)/>"#
        case 3:
            let c = min(h * 0.5, w * 0.22)
            let d = "M\(f(i + c)) \(f(i)) L\(f(w - i - c)) \(f(i)) L\(f(w - i)) \(f(h / 2)) L\(f(w - i - c)) \(f(h - i)) L\(f(i + c)) \(f(h - i)) L\(f(i)) \(f(h / 2)) Z"
            return #"<path d="\#(d)" fill="fill" \#(stroke)/>"#
        case 4:
            let c = min(h * 0.3, w * 0.2)
            let d = "M\(f(i + c)) \(f(i)) L\(f(w - i - c)) \(f(i)) L\(f(w - i)) \(f(i + c)) L\(f(w - i)) \(f(h - i - c)) L\(f(w - i - c)) \(f(h - i)) L\(f(i + c)) \(f(h - i)) L\(f(i)) \(f(h - i - c)) L\(f(i)) \(f(i + c)) Z"
            return #"<path d="\#(d)" fill="fill" \#(stroke)/>"#
        case 5:
            var s = #"<rect x="\#(f(i))" y="\#(f(i))" width="\#(f(iw))" height="\#(f(ih))" rx="\#(f(ih / 2))" fill="fill" \#(stroke)/>"#
            if outline, ih > 14, iw > 14 {
                s += #"<rect x="\#(f(i + 4))" y="\#(f(i + 4))" width="\#(f(iw - 8))" height="\#(f(ih - 8))" rx="\#(f((ih - 8) / 2))" fill="none" stroke="line" stroke-width="1.5" opacity="0.6"/>"#
            }
            return s
        case 6:
            let l = min(w, h) * 0.32
            var s = #"<rect x="\#(f(i))" y="\#(f(i))" width="\#(f(iw))" height="\#(f(ih))" rx="6" fill="fill" stroke="none"/>"#
            if outline {
                let d = "M\(f(i)) \(f(i + l)) L\(f(i)) \(f(i)) L\(f(i + l)) \(f(i)) "
                    + "M\(f(w - i - l)) \(f(i)) L\(f(w - i)) \(f(i)) L\(f(w - i)) \(f(i + l)) "
                    + "M\(f(w - i)) \(f(h - i - l)) L\(f(w - i)) \(f(h - i)) L\(f(w - i - l)) \(f(h - i)) "
                    + "M\(f(i + l)) \(f(h - i)) L\(f(i)) \(f(h - i)) L\(f(i)) \(f(h - i - l))"
                s += #"<path d="\#(d)" fill="none" stroke="line" stroke-width="3"/>"#
            }
            return s
        default:
            return ""
        }
    }
}

extension FaceRenderer {
    private static let plateItems: [(key: String, item: InfoItem)] = [
        ("digital", .digital), ("weekday", .weekday), ("solar", .solar), ("lunar", .lunar), ("weather", .weather),
        ("battery", .data(.battery)), ("steps", .data(.steps)), ("heart", .data(.heart)), ("calories", .data(.calories)),
        ("name", .name)
    ]

    /// Ô chứa khung nền của một mục: vùng của mục nới ra một chút, gọn trong mặt đồng hồ.
    private static func plateRect(_ it: InfoItem, _ d: FaceDesign) -> CGRect {
        let r = itemRect(it, d)
        guard r.width > 0, r.height > 0 else { return .zero }
        let padX = max(8, r.height * 0.4), padY: CGFloat = 3
        let box = CGRect(x: 0, y: 0, width: size, height: size)
        let p = r.insetBy(dx: -padX, dy: -padY).intersection(box)
        return CGRect(x: floor(p.minX), y: floor(p.minY), width: ceil(p.width), height: ceil(p.height))
    }

    private static func platePalette(_ s: PlateStyle) -> [String: UIColor] {
        ["fill": UIColor(s.fill).withAlphaComponent(CGFloat(min(1, max(0.1, s.opacity)))), "line": UIColor(s.line)]
    }

    private static func drawPlate(_ s: PlateStyle, in rect: CGRect) {
        let svg = FacePlate.svg(shape: s.shape, w: Double(rect.width), h: Double(rect.height), outline: s.outline)
        MiniSVG.draw(svg, box: rect.size, in: rect, palette: platePalette(s))
    }

    /// Vẽ khung nền của các mục đang bật (xem trước), vẽ trước chữ.
    static func drawPlatesPreview(_ ctx: CGContext, design d: FaceDesign) {
        UIGraphicsPushContext(ctx)
        for (key, item) in plateItems {
            guard let s = d.plates[key], s.shape > 0, isShown(item, d) else { continue }
            let r = plateRect(item, d)
            guard r.width > 4, r.height > 4 else { continue }
            drawPlate(s, in: r)
        }
        UIGraphicsPopContext()
    }

    /// Lớp ảnh tĩnh của khung nền (đặt trước các lớp chữ).
    static func plateLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        var layers = [HwtLayer]()
        for (key, item) in plateItems {
            guard let s = d.plates[key], s.shape > 0, isShown(item, d) else { continue }
            let r = plateRect(item, d)
            guard r.width > 4, r.height > 4 else { continue }
            let w = Int(r.width), h = Int(r.height)
            let id = add(drawRaster(width: w, height: h) { _ in
                drawPlate(s, in: CGRect(x: 0, y: 0, width: w, height: h))
            })
            layers.append(.single(resource: id, x: Int(r.minX), y: Int(r.minY), ambient: false))
        }
        return layers
    }

    // MARK: Biểu tượng SVG riêng

    private static func weatherPalette(mono: UIColor?) -> [String: UIColor] {
        if let m = mono {
            return ["sun": m, "cloud": m, "rain": m, "snow": m, "sand": m, "gray": m, "accent": m, "currentColor": m]
        }
        let yellow = UIColor(red: 1.0, green: 0.80, blue: 0.20, alpha: 1)
        let cyan = UIColor(red: 0.35, green: 0.78, blue: 1.0, alpha: 1)
        return ["sun": yellow, "cloud": UIColor(white: 0.95, alpha: 1), "rain": cyan, "snow": cyan,
                "sand": UIColor(red: 0.80, green: 0.62, blue: 0.38, alpha: 1), "gray": UIColor(white: 0.72, alpha: 1),
                "accent": yellow, "currentColor": .white]
    }

    /// Biểu tượng thời tiết: SVG riêng hoặc SF Symbols; `mono` = một màu theo màu chữ.
    static func drawWeatherIcon(_ index: Int, in rect: CGRect, textColor: UIColor, mono: Bool, svg: Bool) {
        if svg, index >= 0, index < FaceSVGData.weather.count {
            MiniSVG.draw(FaceSVGData.weather[index], box: CGSize(width: 100, height: 100), in: rect,
                         palette: weatherPalette(mono: mono ? textColor : nil))
        } else {
            drawWeatherSymbol(index, in: rect, mono: mono ? textColor : nil)
        }
    }

    /// Biểu tượng của pin / bước chân / nhịp tim / calo.
    static func drawDataIcon(_ kind: DataKind, in rect: CGRect, textColor: UIColor, mono: Bool, svg: Bool) {
        let ic = kind.iconSymbol
        let accent = mono ? textColor : ic.color
        if svg {
            let src: String
            switch kind {
            case .battery: src = FaceSVGData.battery
            case .steps: src = FaceSVGData.steps
            case .heart: src = FaceSVGData.heart
            case .calories: src = FaceSVGData.calories
            }
            MiniSVG.draw(src, box: CGSize(width: 100, height: 100), in: rect,
                         palette: ["accent": accent, "currentColor": mono ? textColor : .white])
        } else {
            drawSymbol(ic.name, colors: [accent, accent], in: rect)
        }
    }
}
