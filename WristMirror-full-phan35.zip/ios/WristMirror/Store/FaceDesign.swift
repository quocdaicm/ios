// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

// MARK: - Thiết kế mặt đồng hồ (dữ liệu người dùng chỉnh)

/// Mặt đồng hồ kim (analog) cho màn hình HWHD09 (466×466): nền, vạch giờ, 3 kim, và chế độ AOD (màn hình tắt).
struct FaceDesign {
    enum Marks: String, CaseIterable, Identifiable {
        case none, ticks, dots, numerals
        var id: String { rawValue }
        var title: String {
            switch self {
            case .none: return "Không"
            case .ticks: return "Vạch"
            case .dots: return "Chấm"
            case .numerals: return "Số"
            }
        }
    }

    /// 43 kiểu kim: 3 kiểu cơ bản (thanh, nhọn, cổ điển) + 40 kiểu vẽ vector theo ảnh thiết kế (HandShapes.swift).
    /// Tên case (rawValue) phải trùng khoá trong `HandShapes.table`.
    enum HandStyle: String, CaseIterable, Identifiable {
        case bar, pointed, classic
        case dauphine, dauphineSilver, dauphineRose, sword, swordGold, leaf, leafGold, cathedral, skeleton
        case baton, batonGold, arrow, arrowGold, feather, featherGold, trident, tridentGold, diamond, diamondGold
        case blueSteel, blueGold, roseGold, ruby, sapphire
        case luminous, luminousGreen, luminousBlue, luminousAqua, luminousPurple, luminousOrange
        case sport, racing, royal, baroque, luxury, elegant, chronograph, minimalist, geometric, future
        var id: String { rawValue }
        var title: String {
            switch self {
            case .bar: return "Thanh"
            case .pointed: return "Nhọn"
            case .classic: return "Cổ điển"
            default: return HandShapes.title(rawValue)
            }
        }
        /// Kiểu vẽ vector có bảng màu riêng (kim loại, đá quý, dạ quang...).
        var isVector: Bool { HandShapes.table[rawValue] != nil }
    }

    enum AodBackground: String, CaseIterable, Identifiable {
        case black, dimmed, original, custom
        var id: String { rawValue }
        var title: String {
            switch self {
            case .black: return "Nền đen"
            case .dimmed: return "Nền mờ"
            case .original: return "Nền gốc"
            case .custom: return "Nền riêng"
            }
        }
    }

    var name = "Mặt đồng hồ của tôi"
    var author = ""

    // Nền
    var backgroundColor = Color(red: 0.03, green: 0.05, blue: 0.13)
    var useGradient = true
    var backgroundColor2 = Color(red: 0.10, green: 0.26, blue: 0.58)
    var photo: UIImage?
    var photoZoom = 1.0
    var photoPanX = 0.0
    var photoPanY = 0.0
    var photoDim = 0.2
    /// Nền SVG có sẵn (id trong `FaceBackdrops.day`, rỗng = không); chỉ dùng khi không có ảnh nền.
    var backdrop = ""

    // Lớp trang trí (họa tiết vector, có thể quay theo kim)
    var decor: [DecorLayer] = []

    // Âm lịch (ngày/tháng âm do đồng hồ cập nhật)
    var showLunar = false
    var lunarColor = Color.white
    var lunarSize = 1.0
    /// Vị trí dọc của khối âm lịch (tỉ lệ 0.1 ... 0.9 chiều cao mặt đồng hồ).
    var lunarY = 0.57
    var lunarLabel = true
    var lunarX = 0.76
    /// Kiểu số ngày/tháng âm (`.classic` = số thường theo font số), dùng màu gốc của kiểu, dấu ngăn (0 = "/", 1 = "-")
    /// và ngôn ngữ chữ nhãn (0 = theo app, 1 = Tiếng Việt "Â lịch", 2 = English "Lunar").
    var lunarStyle: DigitalStyle = .classic
    var lunarOwnColors = true
    /// Bật = dùng kiểu số riêng ở trên; tắt = theo kiểu số chung (`dataStyle`).
    var lunarCustom = false
    var lunarSep = 0
    var lunarLabelLang = 0
    /// Kiểu chữ nhãn vector (0 đậm, 1 tròn, 2 có chân, 3 nghiêng, 4 đơn cách, 5 mảnh).
    var lunarLabelFont = 0

    // Dương lịch (ngày/tháng dương do đồng hồ cập nhật)
    var showSolar = false
    var solarColor = Color.white
    var solarSize = 1.0
    var solarX = 0.76
    var solarY = 0.44
    var solarLabel = true
    /// Như âm lịch: kiểu số, màu gốc, dấu ngăn, ngôn ngữ nhãn ("D lịch" / "Solar").
    var solarStyle: DigitalStyle = .classic
    var solarOwnColors = true
    var solarCustom = false
    var solarSep = 0
    var solarLabelLang = 0
    var solarLabelFont = 0

    // Thứ trong tuần
    var showWeekday = false
    var weekdayColor = Color.white
    var weekdaySize = 1.0
    var weekdayX = 0.25
    var weekdayY = 0.52

    // Giờ số (HH:MM)
    var showDigital = false
    var digitalColor = Color.white
    var digitalSize = 1.0
    var digitalX = 0.5
    var digitalY = 0.36
    /// Kiểu số giờ số (`.classic` = số thường theo font số) và có dùng màu gốc của kiểu (kim loại, LED, neon...) hay không.
    var digitalStyle: DigitalStyle = .classic
    var digitalOwnColors = true
    var digitalCustom = false

    // Tên hiển thị (chữ tĩnh do người dùng nhập)
    var showName = false
    var nameText = ""
    var nameColor = Color.white
    var nameSize = 1.0
    var nameX = 0.5
    var nameY = 0.76
    var nameStyle = 0

    // Font chữ (thứ, tên, nhãn, đơn vị) và font số (ngày, giờ số, số liệu, nhiệt độ, số trên vạch giờ). Chỉ số của FaceFont.
    var textFontIndex = 0
    var numberFontIndex = 0
    /// Font riêng từng mục (khoá: digital, weekday, solar, lunar, name, battery, steps, heart, calories, weather; giá trị = chỉ số FaceFont). Không có khoá = dùng font chung.
    var elementFonts: [String: Int] = [:]
    /// Hành động khi chạm từng mục (giá trị = TapAction.rawValue, 0 = không). Không có khoá = hành động tự nhiên của mục (xem FaceTap.swift).
    var taps: [String: Int] = [:]
    /// Bật/tắt toàn bộ vùng chạm ghi vào HWT.
    var tapsOn = true
    /// Vùng chạm ở mép mặt đồng hồ (khoá: top, left, bottom, right; giá trị = TapAction.rawValue). Không có khoá = không có vùng.
    var edgeTaps: [String: Int] = [:]

    // Số liệu do đồng hồ cập nhật (xem FaceData.swift). x = mép trái của số.
    /// Kiểu số CHUNG cho mọi thứ có số: giờ số, dương lịch, âm lịch, pin, bước chân, nhịp tim, calo, thời tiết. Từng mục có thể chọn
    /// kiểu riêng (`digitalCustom` / `solarCustom` / `lunarCustom` / `DataWidget.customStyle`). `.classic` = số thường theo font.
    /// `dataOwnColors` = dùng màu gốc của kiểu chung.
    var dataStyle: DigitalStyle = .classic
    var dataOwnColors = true
    var battery = DataWidget(x: 0.42, y: 0.14)
    var steps = DataWidget(x: 0.52, y: 0.84)
    var heart = DataWidget(x: 0.62, y: 0.84)
    var calories = DataWidget(x: 0.38, y: 0.87)
    var weather = DataWidget(x: 0.33, y: 0.68)
    var weatherText = false
    var weatherIcon = true
    var weatherIconMono = false
    /// Biểu tượng vẽ bằng SVG riêng (tắt = SF Symbols của iOS).
    var iconSVG = true
    /// Khung nền SVG theo từng mục (khoá: digital, weekday, solar, lunar, weather, battery, steps, heart, calories, name).
    var plates: [String: PlateStyle] = [:]
    var weatherRange = false
    /// Tự dời/thu nhỏ các mục thông tin để không chồng nhau hoặc đè lên số giờ.
    var autoLayout = false
    /// Viền tối mờ quanh chữ cho dễ đọc trên nền hoa văn.
    var textOutline = true

    // Vạch giờ
    var marks: Marks = .ticks
    var marksColor = Color.white
    /// Kiểu số giờ (khi vạch giờ = Số) và có dùng màu gốc của kiểu (vàng, bạc, dạ quang...) hay không.
    var numeralStyle: NumeralStyle = .classic
    var numeralOwnColors = true

    // Kim
    var handStyle: HandStyle = .classic
    var hourColor = Color.white
    var minuteColor = Color.white
    var secondColor = Color(red: 1.0, green: 0.30, blue: 0.35)
    var capColor = Color(red: 1.0, green: 0.30, blue: 0.35)
    var showSecond = true
    var handWidth = 1.0
    var handOutline = true
    /// Dùng màu gốc của kiểu kim vector (vàng, bạc, xanh...); tắt thì tô theo màu kim giờ/phút đã chọn.
    var handOwnColors = true

    // Chuyển động theo giây (10 ảnh đổi mỗi giây, xuất ra HWT)
    var secondFX: SecondFX = .none
    var secondFXColor = Color(red: 0.10, green: 0.80, blue: 0.92)

    // Hoạt ảnh xoay liên tục (thử nghiệm, xuất ra HWT)
    var animOn = false
    var animPattern: DecorPattern = .mandala
    var animColor = Color.white
    /// Đường kính so với mặt (0.2 ... 0.95), tâm tại (animX, animY) tính theo tỉ lệ mặt.
    var animSize = 0.35
    var animX = 0.5
    var animY = 0.5
    /// Mili-giây mỗi khung (24 khung = một vòng).
    var animInterval = 50.0
    var animReverse = false
    /// Chế độ lặp thử nghiệm (xem HwtFaceSpec.animLoopMode).
    var animLoopMode = 0
    /// Kiểu hoạt ảnh: xoay họa tiết hoặc hạt rơi (tuyết/lá/hoa) – xem FallFX.swift.
    var animKind: AnimKind = .spin
    /// Số khung của hoạt ảnh rơi (24/32/48): nhiều = mượt nhưng nặng hơn.
    var animFallFrames = 32
    /// Mật độ hạt rơi (0.1 ... 1).
    var animDensity = 0.6

    // AOD
    var aodBackground: AodBackground = .black
    var aodBrightness = 0.25
    var aodShowMarks = true
    var aodHandColor = Color(white: 0.85)
    var aodMarksColor = Color(white: 0.5)
    // AOD "Nền riêng": ảnh hoặc màu/chuyển sắc riêng, tách khỏi nền ban ngày
    var aodPhoto: UIImage?
    var aodPhotoZoom = 1.0
    var aodPhotoPanX = 0.0
    var aodPhotoPanY = 0.0
    var aodPhotoDim = 0.55
    /// Nền SVG nét mảnh của AOD "Nền riêng" (id trong `FaceBackdrops.aod`, rỗng = không).
    var aodBackdrop = ""
    var aodColor = Color(red: 0.0, green: 0.0, blue: 0.0)
    var aodColor2 = Color(red: 0.04, green: 0.09, blue: 0.19)
    var aodUseGradient = true
    /// Vẽ lớp trang trí tĩnh (không quay) lên nền riêng.
    var aodShowDecor = true
    /// Hiện giờ số, thứ, ngày, số liệu, tên... trên AOD (dùng lại ảnh của mặt ban ngày).
    var aodShowInfo = false
}

// MARK: - Vẽ

enum FaceRenderer {
    static let size: CGFloat = 466
    static let center: CGFloat = 233

    enum HandKind {
        case hour, minute, second
        var valueType: Int {
            switch self {
            case .hour: return HwtValueType.hour
            case .minute: return HwtValueType.minute
            case .second: return HwtValueType.second
            }
        }
    }

    struct HandGeometry {
        var reach: CGFloat
        var tail: CGFloat
        var width: CGFloat
    }

    static func geometry(_ kind: HandKind, ambient: Bool, design: FaceDesign) -> HandGeometry {
        let k = CGFloat(min(1.8, max(0.6, design.handWidth)))
        switch kind {
        case .hour:
            return ambient ? HandGeometry(reach: 118, tail: 20, width: 20 * k) : HandGeometry(reach: 125, tail: 24, width: 24 * k)
        case .minute:
            return ambient ? HandGeometry(reach: 178, tail: 22, width: 16 * k) : HandGeometry(reach: 185, tail: 28, width: 20 * k)
        case .second:
            return HandGeometry(reach: 205, tail: 42, width: 7 * k)
        }
    }

    // MARK: Nền

    static func photoRect(_ img: UIImage, zoom: Double, panX: Double, panY: Double) -> CGRect {
        let iw = max(1, img.size.width), ih = max(1, img.size.height)
        let base = max(size / iw, size / ih)
        let s = base * CGFloat(max(1.0, zoom))
        let w = iw * s, h = ih * s
        let px = CGFloat(max(-1, min(1, panX))), py = CGFloat(max(-1, min(1, panY)))
        return CGRect(x: (size - w) / 2 + px * (w - size) / 2, y: (size - h) / 2 + py * (h - size) / 2, width: w, height: h)
    }

    private static func drawBase(_ ctx: CGContext, _ d: FaceDesign) {
        drawFill(ctx, photo: d.photo, zoom: d.photoZoom, panX: d.photoPanX, panY: d.photoPanY, dim: d.photoDim,
                 gradient: d.useGradient, c1: d.backgroundColor, c2: d.backgroundColor2)
        if d.photo == nil, !d.backdrop.isEmpty { drawBackdrop(ctx, id: d.backdrop) }
    }

    /// Nền riêng của AOD (ảnh hoặc màu/chuyển sắc riêng).
    private static func drawAodBase(_ ctx: CGContext, _ d: FaceDesign) {
        drawFill(ctx, photo: d.aodPhoto, zoom: d.aodPhotoZoom, panX: d.aodPhotoPanX, panY: d.aodPhotoPanY, dim: d.aodPhotoDim,
                 gradient: d.aodUseGradient, c1: d.aodColor, c2: d.aodColor2)
        if d.aodPhoto == nil, !d.aodBackdrop.isEmpty { drawBackdrop(ctx, id: d.aodBackdrop) }
    }

    private static func drawFill(_ ctx: CGContext, photo: UIImage?, zoom: Double, panX: Double, panY: Double, dim: Double,
                                 gradient: Bool, c1: Color, c2: Color) {
        let full = CGRect(x: 0, y: 0, width: size, height: size)
        if let photo = photo {
            ctx.setFillColor(UIColor.black.cgColor)
            ctx.fill(full)
            UIGraphicsPushContext(ctx)
            photo.draw(in: photoRect(photo, zoom: zoom, panX: panX, panY: panY))
            UIGraphicsPopContext()
            if dim > 0 {
                ctx.setFillColor(UIColor.black.withAlphaComponent(CGFloat(min(0.9, dim))).cgColor)
                ctx.fill(full)
            }
        } else if gradient {
            let colors = [UIColor(c1).cgColor, UIColor(c2).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: nil) {
                ctx.drawLinearGradient(g, start: CGPoint(x: 0, y: 0), end: CGPoint(x: size, y: size), options: [])
            } else {
                ctx.setFillColor(UIColor(c1).cgColor); ctx.fill(full)
            }
        } else {
            ctx.setFillColor(UIColor(c1).cgColor)
            ctx.fill(full)
        }
    }

    static func drawBackground(_ ctx: CGContext, design d: FaceDesign, ambient: Bool) {
        let full = CGRect(x: 0, y: 0, width: size, height: size)
        if ambient {
            if d.aodBackground == .black {
                ctx.setFillColor(UIColor.black.cgColor)
                ctx.fill(full)
            } else if d.aodBackground == .custom {
                drawAodBase(ctx, d)
                if d.aodShowDecor { drawStaticDecor(ctx, d) }
            } else if d.aodBackground == .original {
                // Giữ nguyên nền ban ngày (ảnh/màu/chuyển sắc và lớp trang trí tĩnh).
                drawBase(ctx, d)
                drawStaticDecor(ctx, d)
            } else {
                drawBase(ctx, d)
                ctx.setFillColor(UIColor.black.withAlphaComponent(CGFloat(1.0 - min(0.6, max(0.05, d.aodBrightness)))).cgColor)
                ctx.fill(full)
            }
            if d.aodShowMarks {
                drawMarks(ctx, style: d.marks, color: UIColor(d.aodMarksColor), numberFont: FaceFont.from(d.numberFontIndex),
                          numeral: d.numeralStyle, own: false)
            }
        } else {
            drawBase(ctx, d)
            drawStaticDecor(ctx, d)
            drawMarks(ctx, style: d.marks, color: UIColor(d.marksColor), numberFont: FaceFont.from(d.numberFontIndex),
                      numeral: d.numeralStyle, own: d.numeralOwnColors)
        }
    }

    static func drawMarks(_ ctx: CGContext, style: FaceDesign.Marks, color: UIColor, numberFont: FaceFont = .system,
                          numeral: NumeralStyle = .classic, own: Bool = true) {
        guard style != .none else { return }
        ctx.saveGState()
        ctx.translateBy(x: center, y: center)
        ctx.setFillColor(color.cgColor)
        ctx.setStrokeColor(color.cgColor)
        ctx.setLineCap(.round)
        switch style {
        case .none:
            break
        case .ticks:
            for i in 0..<60 {
                let major = i % 5 == 0
                ctx.saveGState()
                ctx.rotate(by: CGFloat(i) * CGFloat.pi / 30)
                ctx.setLineWidth(major ? 6 : 2.5)
                let outer = center - 10
                let inner = outer - (major ? 26 : 10)
                ctx.move(to: CGPoint(x: 0, y: -outer))
                ctx.addLine(to: CGPoint(x: 0, y: -inner))
                ctx.strokePath()
                ctx.restoreGState()
            }
        case .dots:
            for i in 0..<60 {
                let a = CGFloat(i) * CGFloat.pi / 30
                let major = i % 5 == 0
                let r: CGFloat = major ? 205 : 218
                let rad: CGFloat = major ? 7 : 2.5
                ctx.fillEllipse(in: CGRect(x: sin(a) * r - rad, y: -cos(a) * r - rad, width: rad * 2, height: rad * 2))
            }
        case .numerals:
            var tickColor = color
            if numeral != .classic, let def = numeral.def {
                NumeralShapes.draw(ctx, def: def, color: color, own: own, numberFont: numberFont)
                if own, let p = def.pal { tickColor = p.mid }
            } else {
                let font = numberFont.text(44, .semibold)
                for n in 1...12 {
                    let a = CGFloat(n) * CGFloat.pi / 6
                    let r: CGFloat = 180
                    let s = NSAttributedString(string: "\(n)", attributes: [.font: font, .foregroundColor: color])
                    let sz = s.size()
                    UIGraphicsPushContext(ctx)
                    s.draw(at: CGPoint(x: sin(a) * r - sz.width / 2, y: -cos(a) * r - sz.height / 2))
                    UIGraphicsPopContext()
                }
            }
            ctx.setStrokeColor(tickColor.cgColor)
            for i in 0..<60 {
                ctx.saveGState()
                ctx.rotate(by: CGFloat(i) * CGFloat.pi / 30)
                ctx.setLineWidth(i % 5 == 0 ? 3 : 1.5)
                ctx.move(to: CGPoint(x: 0, y: -(center - 8)))
                ctx.addLine(to: CGPoint(x: 0, y: -(center - 8 - 8)))
                ctx.strokePath()
                ctx.restoreGState()
            }
        }
        ctx.restoreGState()
    }

    // MARK: Kim

    /// Vẽ một kim trong toạ độ cục bộ: trục xoay ở gốc (0,0), đầu kim hướng lên (0, -reach).
    static func drawHand(_ ctx: CGContext, kind: HandKind, geo: HandGeometry, style: FaceDesign.HandStyle,
                         color: UIColor, outline: Bool, own: Bool = true) {
        // Kim giây luôn là thanh mảnh có đối trọng; kim giờ/phút dùng kiểu người dùng chọn.
        if kind != .second, let def = HandShapes.table[style.rawValue] {
            HandShapes.draw(ctx, def: def, kind: kind, geo: geo, color: color, outline: outline, own: own)
            return
        }
        drawBasicHand(ctx, kind: kind, geo: geo, style: style, color: color, outline: outline)
    }

    /// Ba kiểu kim cơ bản (thanh, nhọn, cổ điển) và kim giây.
    private static func drawBasicHand(_ ctx: CGContext, kind: HandKind, geo: HandGeometry, style: FaceDesign.HandStyle,
                                      color: UIColor, outline: Bool) {
        let w = geo.width
        let path = CGMutablePath()
        let effective: FaceDesign.HandStyle = kind == .second ? .bar : style
        switch effective {
        case .bar:
            path.addRoundedRect(in: CGRect(x: -w / 2, y: -geo.reach, width: w, height: geo.reach + geo.tail),
                                cornerWidth: w / 2, cornerHeight: w / 2)
        case .pointed:
            path.move(to: CGPoint(x: 0, y: -geo.reach))
            path.addLine(to: CGPoint(x: w / 2, y: 0))
            path.addLine(to: CGPoint(x: w * 0.3, y: geo.tail))
            path.addLine(to: CGPoint(x: -w * 0.3, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: 0))
            path.closeSubpath()
        case .classic:
            let shoulder = -geo.reach + w * 1.3
            path.move(to: CGPoint(x: 0, y: -geo.reach))
            path.addLine(to: CGPoint(x: w / 2, y: shoulder))
            path.addLine(to: CGPoint(x: w / 2, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: geo.tail))
            path.addLine(to: CGPoint(x: -w / 2, y: shoulder))
            path.closeSubpath()
        default:
            path.addRoundedRect(in: CGRect(x: -w / 2, y: -geo.reach, width: w, height: geo.reach + geo.tail),
                                cornerWidth: w / 2, cornerHeight: w / 2)
        }

        ctx.saveGState()
        ctx.setLineJoin(.round)
        if outline {
            ctx.addPath(path)
            ctx.setStrokeColor(UIColor.black.withAlphaComponent(0.55).cgColor)
            ctx.setLineWidth(2.5)
            ctx.strokePath()
        }
        ctx.addPath(path)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()

        if effective == .classic {
            // Rãnh tối ở giữa thân kim
            let groove = CGMutablePath()
            let gw = max(2, w * 0.3)
            groove.addRoundedRect(in: CGRect(x: -gw / 2, y: -geo.reach + w * 1.9, width: gw, height: geo.reach - w * 1.9 + geo.tail * 0.6),
                                  cornerWidth: gw / 2, cornerHeight: gw / 2)
            ctx.addPath(groove)
            ctx.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
            ctx.fillPath()
        }
        if kind == .second {
            // Đối trọng ở đuôi kim giây
            let rad = max(3.5, w * 0.9)
            ctx.setFillColor(color.cgColor)
            ctx.fillEllipse(in: CGRect(x: -rad, y: geo.tail * 0.55 - rad, width: rad * 2, height: rad * 2))
        }
        ctx.restoreGState()
    }

    struct HandImage {
        let raster: HwtRaster
        let pivotX: Int
        let pivotY: Int
    }

    /// Ảnh của một kim (nền trong suốt) kèm vị trí trục xoay trong ảnh.
    static func handImage(_ kind: HandKind, ambient: Bool, design d: FaceDesign) -> HandImage {
        let geo = geometry(kind, ambient: ambient, design: d)
        let pad = 8
        // Kiểu kim vector có phần phình rộng tới ~2 lần bề rộng thân (mũi giáo, hoa lis...) nên ảnh phải rộng hơn.
        let wide = kind != .second && HandShapes.table[d.handStyle.rawValue] != nil
        var w = Int(ceil(wide ? geo.width * 2.1 : geo.width)) + pad * 2
        if kind == .second { w = max(w, Int(ceil(max(3.5, geo.width * 0.9) * 2)) + pad * 2) }
        if w % 2 != 0 { w += 1 }
        let pivotY = Int(ceil(geo.reach)) + pad
        let h = pivotY + Int(ceil(geo.tail)) + pad + 2
        let color: UIColor
        switch kind {
        case .hour: color = UIColor(ambient ? d.aodHandColor : d.hourColor)
        case .minute: color = UIColor(ambient ? d.aodHandColor : d.minuteColor)
        case .second: color = UIColor(d.secondColor)
        }
        let outline = d.handOutline && !ambient
        let raster = drawRaster(width: w, height: h) { ctx in
            ctx.translateBy(x: CGFloat(w) / 2, y: CGFloat(pivotY))
            drawHand(ctx, kind: kind, geo: geo, style: d.handStyle, color: color, outline: outline, own: !ambient && d.handOwnColors)
        }
        return HandImage(raster: raster, pivotX: w / 2, pivotY: pivotY)
    }

    static func capImage(design d: FaceDesign) -> HwtRaster {
        let dia = 24
        return drawRaster(width: dia, height: dia) { ctx in
            let c = CGFloat(dia) / 2
            ctx.setFillColor(UIColor.black.withAlphaComponent(0.5).cgColor)
            ctx.fillEllipse(in: CGRect(x: 0.5, y: 0.5, width: CGFloat(dia) - 1, height: CGFloat(dia) - 1))
            ctx.setFillColor(UIColor(d.capColor).cgColor)
            ctx.fillEllipse(in: CGRect(x: c - 9.5, y: c - 9.5, width: 19, height: 19))
        }
    }

    // MARK: Ghép cả mặt (xem trước)

    static func drawComposite(_ ctx: CGContext, design d: FaceDesign, ambient: Bool,
                              hour: Int = 10, minute: Int = 8, second: Int = 35,
                              scale: CGFloat = 1, circle: Bool = false) {
        ctx.saveGState()
        ctx.scaleBy(x: scale, y: scale)
        if circle {
            ctx.addEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            ctx.clip()
        }
        drawBackground(ctx, design: d, ambient: ambient)
        if !ambient || d.aodShowInfo { drawInfoPreview(ctx, design: d) }

        func hand(_ kind: HandKind, angle: CGFloat) {
            let geo = geometry(kind, ambient: ambient, design: d)
            let color: UIColor
            switch kind {
            case .hour: color = UIColor(ambient ? d.aodHandColor : d.hourColor)
            case .minute: color = UIColor(ambient ? d.aodHandColor : d.minuteColor)
            case .second: color = UIColor(d.secondColor)
            }
            ctx.saveGState()
            ctx.translateBy(x: center, y: center)
            ctx.rotate(by: angle)
            drawHand(ctx, kind: kind, geo: geo, style: d.handStyle, color: color, outline: d.handOutline && !ambient,
                     own: !ambient && d.handOwnColors)
            ctx.restoreGState()
        }
        let hAngle = (CGFloat(hour % 12) + CGFloat(minute) / 60) * CGFloat.pi / 6
        let mAngle = (CGFloat(minute) + CGFloat(second) / 60) * CGFloat.pi / 30
        let sAngle = CGFloat(second) * CGFloat.pi / 30
        if !ambient {
            for l in d.decor where l.spin != .none {
                let a: CGFloat
                switch l.spin {
                case .hour: a = hAngle
                case .minute: a = mAngle
                default: a = sAngle
                }
                ctx.saveGState()
                ctx.translateBy(x: center, y: center)
                ctx.rotate(by: a)
                drawDecorLayer(ctx, l)
                ctx.restoreGState()
            }
        }
        hand(.hour, angle: hAngle)
        hand(.minute, angle: mAngle)
        if !ambient {
            if d.showSecond { hand(.second, angle: sAngle) }
            ctx.saveGState()
            ctx.translateBy(x: center - 12, y: center - 12)
            let cap = capImage(design: d)
            if let cg = cgImage(cap) {
                // cgImage có gốc trên-trái; ctx đã lật (y xuống) nên lật ngược lại khi vẽ
                ctx.translateBy(x: 0, y: 24)
                ctx.scaleBy(x: 1, y: -1)
                ctx.draw(cg, in: CGRect(x: 0, y: 0, width: 24, height: 24))
            }
            ctx.restoreGState()
        }
        ctx.restoreGState()
    }

    /// Ảnh xem trước dạng UIImage (nền đen ngoài vòng tròn khi `circle`).
    static func image(design d: FaceDesign, ambient: Bool, pixels: Int, circle: Bool) -> UIImage {
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let r = UIGraphicsImageRenderer(size: CGSize(width: pixels, height: pixels), format: fmt)
        return r.image { c in
            UIColor.black.setFill()
            c.fill(CGRect(x: 0, y: 0, width: pixels, height: pixels))
            drawComposite(c.cgContext, design: d, ambient: ambient, scale: CGFloat(pixels) / size, circle: circle)
        }
    }

    // MARK: Điểm ảnh <-> ảnh

    /// Vẽ vào bộ đệm RGBA (gốc trên-trái) rồi đổi sang ARGB không nhân trước alpha.
    static func drawRaster(width: Int, height: Int, _ draw: (CGContext) -> Void) -> HwtRaster {
        var buf = [UInt8](repeating: 0, count: width * height * 4)
        buf.withUnsafeMutableBytes { raw in
            guard let ctx = CGContext(data: raw.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
            ctx.translateBy(x: 0, y: CGFloat(height))
            ctx.scaleBy(x: 1, y: -1)
            ctx.setAllowsAntialiasing(true)
            ctx.interpolationQuality = .high
            UIGraphicsPushContext(ctx)
            draw(ctx)
            UIGraphicsPopContext()
        }
        var px = [UInt32](repeating: 0, count: width * height)
        for i in 0..<(width * height) {
            let o = i * 4
            let a = UInt32(buf[o + 3])
            if a == 0 { continue }
            var r = UInt32(buf[o]), g = UInt32(buf[o + 1]), b = UInt32(buf[o + 2])
            if a < 255 {
                r = min(255, (r * 255 + a / 2) / a)
                g = min(255, (g * 255 + a / 2) / a)
                b = min(255, (b * 255 + a / 2) / a)
            }
            px[i] = (a << 24) | (r << 16) | (g << 8) | b
        }
        return HwtRaster(width: width, height: height, argb: px)
    }

    static func cgImage(_ r: HwtRaster) -> CGImage? {
        var bytes = [UInt8](repeating: 0, count: r.width * r.height * 4)
        for (i, p) in r.argb.enumerated() {
            bytes[i * 4] = UInt8((p >> 16) & 0xff)
            bytes[i * 4 + 1] = UInt8((p >> 8) & 0xff)
            bytes[i * 4 + 2] = UInt8(p & 0xff)
            bytes[i * 4 + 3] = UInt8((p >> 24) & 0xff)
        }
        guard let provider = CGDataProvider(data: Data(bytes) as CFData) else { return nil }
        return CGImage(width: r.width, height: r.height, bitsPerComponent: 8, bitsPerPixel: 32,
                       bytesPerRow: r.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    static func pngData(_ r: HwtRaster) -> [UInt8]? {
        guard let cg = cgImage(r) else { return nil }
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(out, UTType.png.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dest, cg, nil)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return [UInt8](out as Data)
    }

    /// Thu nhỏ ảnh quá lớn (giới hạn bộ nhớ); trả nguyên ảnh nếu đã đủ nhỏ.
    static func downscale(_ img: UIImage, maxSide: CGFloat) -> UIImage {
        let longest = max(img.size.width, img.size.height)
        guard longest > maxSide, longest > 0 else { return img }
        let k = maxSide / longest
        let newSize = CGSize(width: (img.size.width * k).rounded(), height: (img.size.height * k).rounded())
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { _ in
            img.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}

// MARK: - Dựng file HWT từ thiết kế

enum FaceBuilder {
    static func cleanTitle(_ s: String) -> String {
        let t = HwtLibrary.cleanName(s)
        return t.isEmpty ? "Mặt đồng hồ" : t
    }

    static func fileName(_ name: String) -> String {
        let base = cleanTitle(name).unicodeScalars.map { sc -> String in
            if CharacterSet.alphanumerics.contains(sc) && sc.isASCII { return String(sc) }
            return "_"
        }.joined()
        let trimmed = base.split(separator: "_").joined(separator: "_")
        return (trimmed.isEmpty ? "face" : String(trimmed.prefix(40))) + ".hwt"
    }

    /// Dựng toàn bộ file `.hwt` (byte). Chạy được ở luồng nền.
    /// File HWT chỉ chứa tối đa `HwtBuilder.maxImages` ảnh. Khi bật nhiều mục (nhịp tim, thời tiết có biểu tượng,
    /// tên tình trạng, cao/thấp...) cùng hoạt ảnh rơi (3 dải x số khung) thì dễ vượt giới hạn => thay vì báo lỗi
    /// `BUILD_IMAGE_COUNT`, tự giảm số khung hoạt ảnh rơi (48 -> 32 -> 24) rồi dựng lại.
    static func build(_ design: FaceDesign, date: Date = Date()) throws -> [UInt8] {
        var d = design
        while true {
            do {
                return try buildOnce(d, date: date)
            } catch let e as WMFault where e.code == "BUILD_IMAGE_COUNT" {
                guard d.animOn, d.animKind.isFall else { throw e }
                let current = FaceRenderer.fallFrameCount(d)
                guard let lower = FaceRenderer.fallFrameChoices.sorted().last(where: { $0 < current }) else { throw e }
                d.animFallFrames = lower
            }
        }
    }

    private static func buildOnce(_ design: FaceDesign, date: Date = Date()) throws -> [UInt8] {
        let c = Int(FaceRenderer.center)
        var images = [HwtRaster]()
        func add(_ r: HwtRaster) -> Int { images.append(r); return images.count }

        // A100_001: ảnh thu nhỏ (vòng tròn, trong suốt ở góc)
        _ = add(FaceRenderer.drawRaster(width: 250, height: 250) { ctx in
            FaceRenderer.drawComposite(ctx, design: design, ambient: false, scale: 250 / FaceRenderer.size, circle: true)
        })
        let side = Int(FaceRenderer.size)
        let bgDay = add(FaceRenderer.drawRaster(width: side, height: side) { FaceRenderer.drawBackground($0, design: design, ambient: false) })
        let bgAod = add(FaceRenderer.drawRaster(width: side, height: side) { FaceRenderer.drawBackground($0, design: design, ambient: true) })

        func handLayer(_ kind: FaceRenderer.HandKind, ambient: Bool) -> HwtLayer {
            let h = FaceRenderer.handImage(kind, ambient: ambient, design: design)
            let id = add(h.raster)
            let rect = HwtRect(x: c - h.pivotY, y: c - h.pivotY, w: h.pivotY * 2, h: h.pivotY * 2)
            return .hand(resource: id, rect: rect, pivotX: h.pivotX, pivotY: h.pivotY, valueType: kind.valueType, ambient: ambient)
        }

        var lunar: [HwtLayer] = FaceRenderer.infoActive(design) ? FaceRenderer.infoLayers(design, add: add) : []
        // AOD có thông tin: thêm bản sao các lớp (cùng ảnh, cờ ambient = 1) nên không tốn thêm ảnh.
        if design.aodShowInfo { lunar += lunar.map { $0.ambientCopy } }

        var time = [HwtLayer]()
        for l in design.decor.prefix(FaceRenderer.maxDecor) where l.spin != .none {
            guard let vt = l.spin.valueType else { continue }
            let side = FaceRenderer.decorSide(l)
            let id = add(FaceRenderer.drawRaster(width: side, height: side) { ctx in
                ctx.translateBy(x: CGFloat(side) / 2, y: CGFloat(side) / 2)
                FaceRenderer.drawDecorLayer(ctx, l)
            })
            let rect = HwtRect(x: c - side / 2, y: c - side / 2, w: side, h: side)
            time.append(.hand(resource: id, rect: rect, pivotX: side / 2, pivotY: side / 2, valueType: vt, ambient: false))
        }
        if design.secondFX != .none {
            let fx = FaceRenderer.secondFXCropped(design)
            let fxIDs = fx.frames.map { add($0) }
            time.append(.array(resources: fxIDs, x: fx.x, y: fx.y, valueType: HwtValueType.secondOnes, ambient: false))
            // Không có kim giây thì đồng hồ có thể chỉ vẽ lại mỗi phút => hiệu ứng giây đứng yên.
            // Thêm một kim giây vô hình (2x2, trong suốt) để buộc đồng hồ cập nhật mỗi giây.
            if !design.showSecond {
                let tiny = add(HwtRaster(width: 2, height: 2, fill: 0))
                time.append(.hand(resource: tiny, rect: HwtRect(x: c - 1, y: c - 1, w: 2, h: 2), pivotX: 1, pivotY: 1,
                                  valueType: FaceRenderer.HandKind.second.valueType, ambient: false))
            }
        }
        time.append(handLayer(.hour, ambient: false))
        time.append(handLayer(.minute, ambient: false))
        if design.showSecond { time.append(handLayer(.second, ambient: false)) }
        let cap = add(FaceRenderer.capImage(design: design))
        time.append(.single(resource: cap, x: c - 12, y: c - 12, ambient: false))
        time.append(handLayer(.hour, ambient: true))
        time.append(handLayer(.minute, ambient: true))

        let title = cleanTitle(design.name)
        let author = HwtLibrary.cleanName(design.author)
        var background: [HwtLayer] = [.single(resource: bgDay, x: 0, y: 0, ambient: false),
                                      .single(resource: bgAod, x: 0, y: 0, ambient: true)]
        // File thật vẽ theo thứ tự: nền (0), ngày (2), giờ (1) nên âm lịch nằm dưới kim.
        if design.animOn {
            let ms = min(AnimFX.maxInterval, max(AnimFX.minInterval, Int(design.animInterval.rounded())))
            if design.animKind.isFall {
                // Hạt rơi: 3 dải cột cao bằng mặt đồng hồ, mỗi dải một lớp hoạt ảnh (cùng chu kỳ, nội dung khác nhau).
                for strip in FaceRenderer.fallStrips(design) {
                    let ids = strip.frames.map { add($0) }
                    background.append(.animation(resources: ids, x: strip.x, y: 0, intervalMs: ms, ambient: false))
                }
            } else {
                let p = FaceRenderer.animPlacement(design)
                let animIDs = FaceRenderer.animFrames(design).map { add($0) }
                background.append(.animation(resources: animIDs, x: p.x, y: p.y, intervalMs: ms, ambient: false))
            }
        }
        let elements: [[HwtLayer]] = lunar.isEmpty ? [background, time] : [background, lunar, time]
        let ids: [Int]? = lunar.isEmpty ? nil : [0, 2, 1]
        let spec = HwtFaceSpec(title: title, titleCN: title, author: author.isEmpty ? "WristMirror" : author,
                               version: "1.0.0",
                               elements: elements,
                               images: images,
                               elementIDs: ids,
                               animLoopMode: design.animLoopMode,
                               tapZones: FaceRenderer.tapZones(design))

        // Kiểm tra sớm số ảnh (trước khi mã hoá PNG tốn thời gian).
        guard images.count <= HwtBuilder.maxImages else { throw WMFault("BUILD_IMAGE_COUNT") }

        var pngs = [[UInt8]]()
        for img in images {
            guard let p = FaceRenderer.pngData(img) else { throw WMFault("BUILD_PNG") }
            pngs.append(p)
        }

        func jpeg(_ ambient: Bool, _ px: Int) throws -> [UInt8] {
            let img = FaceRenderer.image(design: design, ambient: ambient, pixels: px, circle: true)
            guard let d = img.jpegData(compressionQuality: 0.9) else { throw WMFault("BUILD_JPEG") }
            return [UInt8](d)
        }
        let previews = HwtBuilder.Previews(cover: try jpeg(false, 480), aod: try jpeg(true, 960), icon: try jpeg(false, 390))
        return try HwtBuilder.build(spec: spec, pngs: pngs, previews: previews, date: date)
    }
}
