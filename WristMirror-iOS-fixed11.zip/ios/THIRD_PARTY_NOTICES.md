# Giấy phép và ghi công / Third-party notices (WristMirror iOS)

## 0. Tác giả bản iOS
**Quốc Đại** (GitHub: quocdaicm) – bản port Swift/SwiftUI/CoreBluetooth và các sửa đổi.
Web: https://quocdai.site – TikTok: https://www.tiktok.com/@quocdai69f1

## 1. Mã nguồn gốc được sử dụng
**WristMirror (腕镜)** – Copyright 2026 Escosis – https://github.com/Escosis/WristMirror – **Apache License 2.0**.
Bản iOS này là tác phẩm phái sinh: logic giao thức (khung gói, TLV, mật mã/xác thực ISO và Lite, truyền file 0x28,
quy trình thay/xoá/kích hoạt mặt đồng hồ, chính sách phiên bản, đọc file HWT) và cấu trúc giao diện được **port từ
Kotlin/Java sang Swift/SwiftUI/CoreBluetooth**, kèm các thay đổi dành riêng cho iOS (xem `HANDOFF.md`).
Toàn văn giấy phép: `LICENSE`. Thông báo bản quyền: `NOTICE`.
Mỗi file Swift mang chú thích nêu rõ nguồn gốc và việc đã sửa đổi (Apache-2.0 §4b).

## 2. Thay đổi so với bản gốc (Apache-2.0 §4b)
- Viết lại toàn bộ bằng Swift 5 / SwiftUI / CoreBluetooth; chỉ dùng BLE (GATT FE86/FE01/FE02), bỏ RFCOMM.
- Khoá thiết bị là UUID của `CBPeripheral` (iOS không có MAC); lưu bí mật bằng Keychain.
- Tự cài AES-GCM (IV 16 byte), bộ đọc ZIP/CRC32 tối thiểu, bộ ghi/giới hạn kích thước ghi theo ATT MTU.
- Thêm (không có ở bản gốc): khôi phục trạng thái CoreBluetooth, tự nối lại, tác vụ nền và thông báo cục bộ,
  tuỳ chọn ANCS, màn giới thiệu, AppIcon.
- Bỏ các tính năng riêng của Android: dịch vụ nền, kiểm tra cập nhật, huỷ ghép nối hệ thống.

## 3. Tài liệu tham khảo giao thức (không chép mã)
Theo ghi chú của dự án gốc, luồng giao tiếp Bluetooth và thao tác mặt đồng hồ được tham khảo từ quy trình của
Huawei Health (Huawei Sport Health), 腕连手表助手 và Gadgetbridge, rồi **triển khai độc lập**. Bản iOS này
**không chứa** mã, thư viện (SDK), tài nguyên hay APK/IPA của các ứng dụng đó. Việc quan sát tên hàm/chuỗi trong
bản Huawei Health chỉ để đối chiếu cách kết nối khi phát triển; không có mã nào được sao chép vào dự án.

## 4. Công cụ build (không phân phối cùng app)
- [XcodeGen](https://github.com/yonaskolb/XcodeGen) – MIT License – sinh file `.xcodeproj` từ `project.yml`.
- GitHub Actions, Xcode và các framework hệ thống của Apple (CoreBluetooth, SwiftUI, Security, UserNotifications...)
  dùng theo điều khoản của GitHub/Apple; không có thư viện bên thứ ba nào được nhúng vào app.

## 5. Hình ảnh
- AppIcon do Quốc Đại tạo mới cho bản này (không lấy từ nguồn khác), phát hành cùng giấy phép Apache-2.0 của dự án.

## 6. Nhãn hiệu / miễn trừ
Huawei, HarmonyOS, Huawei Health và các tên liên quan là nhãn hiệu của chủ sở hữu. Dự án này độc lập, không liên kết
hay được xác nhận bởi Huawei, và được cung cấp "NGUYÊN TRẠNG" (xem LICENSE). Hãy tự chịu rủi ro khi dùng với thiết bị của bạn.

Các thông báo của bản Android gốc (Miuix, AndroidX, Kotlin, Gradle, JUnit...) được lưu nguyên tại
`docs/UPSTREAM_THIRD_PARTY_NOTICES_ANDROID.md`; các thành phần đó **không** có trong bản iOS.
