// Copyright 2026 Quốc Đại (quocdaicm, https://quocdai.site). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import SwiftUI

/// Hệ thống giao diện "Huawei watch face": màu, nền vector, logo, thẻ kính mờ, nút, huy hiệu.
/// Mọi hình (nền, logo, vòng mặt số) được vẽ bằng vector (Canvas/Shape) nên sắc nét ở mọi độ phân giải;
/// bản SVG gốc nằm trong thư mục design/ (khớp hình học với code).
enum Theme {
    static let accent = Color(red: 0.14, green: 0.34, blue: 0.94)    // #2456F0
    static let accent2 = Color(red: 0.48, green: 0.30, blue: 1.0)    // #7A4DFF
    static let cyan = Color(red: 0.10, green: 0.80, blue: 0.92)      // #1ACCEB
    static let navy = Color(red: 0.043, green: 0.086, blue: 0.314)   // #0B1650
    static let cardRadius: CGFloat = 22

    /// Gradient dùng cho nút/huy hiệu.
    static var gradient: LinearGradient {
        LinearGradient(colors: [Color(red: 0.10, green: 0.45, blue: 0.97), accent2],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    /// Gradient thẻ nổi bật (chữ trắng đọc rõ).
    static var heroGradient: LinearGradient {
        LinearGradient(colors: [Color(red: 0.04, green: 0.22, blue: 0.74),
                                Color(red: 0.16, green: 0.34, blue: 0.96),
                                Color(red: 0.45, green: 0.30, blue: 0.98)],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    /// Gradient nền logo/icon.
    static var logoGradient: LinearGradient {
        LinearGradient(colors: [Color(red: 0.043, green: 0.106, blue: 0.40),
                                Color(red: 0.14, green: 0.34, blue: 0.94),
                                Color(red: 0.09, green: 0.71, blue: 0.91)],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

// MARK: - Mặt số vector (vòng tròn + vạch phút)

/// Vòng mặt số trang trí: 3 vòng đồng tâm + 60 vạch (12 vạch lớn).
struct DialArt: View {
    var color: Color = .white
    var ringOpacity: Double = 0.10
    var tickOpacity: Double = 0.22

    var body: some View {
        Canvas { ctx, size in
            let c = CGPoint(x: size.width / 2, y: size.height / 2)
            let r = min(size.width, size.height) / 2
            for f in [1.0, 0.74, 0.5] {
                let rr = r * CGFloat(f)
                let ring = Path(ellipseIn: CGRect(x: c.x - rr, y: c.y - rr, width: rr * 2, height: rr * 2))
                ctx.stroke(ring, with: .color(color.opacity(ringOpacity)), lineWidth: 1)
            }
            for i in 0..<60 {
                let major = i % 5 == 0
                let a = Double(i) / 60.0 * 2.0 * Double.pi
                let r1 = r * 0.92
                let r2 = r * (major ? 0.82 : 0.87)
                var p = Path()
                p.move(to: CGPoint(x: c.x + CGFloat(sin(a)) * r1, y: c.y - CGFloat(cos(a)) * r1))
                p.addLine(to: CGPoint(x: c.x + CGFloat(sin(a)) * r2, y: c.y - CGFloat(cos(a)) * r2))
                ctx.stroke(p, with: .color(color.opacity(major ? tickOpacity : tickOpacity * 0.5)),
                           style: StrokeStyle(lineWidth: major ? 2 : 1, lineCap: .round))
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Nền toàn app

/// Nền vector: gradient sâu + quầng sáng cyan/tím + hai mặt số đồng hồ mờ. Tự đổi theo sáng/tối.
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme

    private var dark: Bool { scheme == .dark }

    private var baseColors: [Color] {
        if dark {
            return [Color(red: 0.020, green: 0.043, blue: 0.133),
                    Color(red: 0.039, green: 0.102, blue: 0.271),
                    Color(red: 0.078, green: 0.059, blue: 0.220)]
        }
        return [Color(red: 0.953, green: 0.973, blue: 1.0),
                Color(red: 0.894, green: 0.933, blue: 1.0),
                Color(red: 0.933, green: 0.914, blue: 1.0)]
    }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ZStack {
                LinearGradient(colors: baseColors, startPoint: .top, endPoint: .bottom)

                RadialGradient(colors: [Theme.cyan.opacity(dark ? 0.32 : 0.28), Theme.cyan.opacity(0)],
                               center: UnitPoint(x: 0.95, y: 0.095), startRadius: 0, endRadius: max(w, 1) * 0.78)
                RadialGradient(colors: [Theme.accent2.opacity(dark ? 0.30 : 0.18), Theme.accent2.opacity(0)],
                               center: UnitPoint(x: 0.05, y: 0.85), startRadius: 0, endRadius: max(w, 1) * 0.85)

                DialArt(color: dark ? Color.white : Theme.accent,
                        ringOpacity: dark ? 0.07 : 0.10,
                        tickOpacity: dark ? 0.16 : 0.18)
                    .frame(width: w * 1.34, height: w * 1.34)
                    .position(x: w * 1.03, y: h * 0.095)
                DialArt(color: dark ? Color.white : Theme.accent,
                        ringOpacity: dark ? 0.055 : 0.08,
                        tickOpacity: dark ? 0.13 : 0.14)
                    .frame(width: w * 0.87, height: w * 0.87)
                    .position(x: w * -0.05, y: h * 0.90)
            }
            .frame(width: w, height: h)
        }
        .ignoresSafeArea()
    }
}

// MARK: - Logo vector

/// Hình đồng hồ (dây + vỏ + mặt số + kim 10:10 + vòng hoạt động). Hình học khớp design/logo-mark.svg (hệ 100×100).
struct WatchMark: View {
    var body: some View {
        Canvas { ctx, sz in
            let u = min(sz.width, sz.height) / 100
            let ox = (sz.width - 100 * u) / 2
            let oy = (sz.height - 100 * u) / 2
            func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: ox + x * u, y: oy + y * u) }
            func box(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) -> CGRect {
                CGRect(x: ox + x * u, y: oy + y * u, width: w * u, height: h * u)
            }

            // Dây đeo trên/dưới.
            let strap = GraphicsContext.Shading.linearGradient(
                Gradient(colors: [Color.white.opacity(0.95), Color.white.opacity(0.55)]),
                startPoint: pt(50, 0), endPoint: pt(50, 100))
            ctx.fill(Path(roundedRect: box(34, 1, 32, 26), cornerRadius: 9 * u), with: strap)
            ctx.fill(Path(roundedRect: box(34, 73, 32, 26), cornerRadius: 9 * u), with: strap)

            // Núm xoay.
            ctx.fill(Path(roundedRect: box(83.5, 42, 6, 16), cornerRadius: 3 * u), with: .color(Color.white.opacity(0.9)))

            // Viền vỏ + mặt số.
            let bezel = GraphicsContext.Shading.linearGradient(
                Gradient(colors: [Color.white, Color(red: 0.72, green: 0.80, blue: 1.0)]),
                startPoint: pt(16, 16), endPoint: pt(84, 84))
            ctx.fill(Path(ellipseIn: box(16, 16, 68, 68)), with: bezel)

            let dialPath = Path(ellipseIn: box(20.5, 20.5, 59, 59))
            let dial = GraphicsContext.Shading.linearGradient(
                Gradient(colors: [Theme.navy, Color(red: 0.106, green: 0.227, blue: 0.659)]),
                startPoint: pt(20, 20), endPoint: pt(80, 80))
            ctx.fill(dialPath, with: dial)

            // 12 vạch giờ (4 vạch lớn màu cyan).
            for i in 0..<12 {
                let a = Double(i) * Double.pi / 6.0
                let major = i % 3 == 0
                let r1: CGFloat = 26
                let r2: CGFloat = major ? 21.5 : 23.5
                var p = Path()
                p.move(to: pt(50 + CGFloat(sin(a)) * r1, 50 - CGFloat(cos(a)) * r1))
                p.addLine(to: pt(50 + CGFloat(sin(a)) * r2, 50 - CGFloat(cos(a)) * r2))
                ctx.stroke(p, with: .color(major ? Theme.cyan : Color.white.opacity(0.6)),
                           style: StrokeStyle(lineWidth: (major ? 2.2 : 1.4) * u, lineCap: .round))
            }

            // Vòng hoạt động (từ 12h quay thuận 240°).
            var arc = Path()
            var first = true
            var deg = -90.0
            while deg <= 150.0 {
                let a = deg * Double.pi / 180.0
                let p = pt(50 + CGFloat(cos(a)) * 19, 50 + CGFloat(sin(a)) * 19)
                if first { arc.move(to: p); first = false } else { arc.addLine(to: p) }
                deg += 3.0
            }
            let arcShade = GraphicsContext.Shading.linearGradient(
                Gradient(colors: [Theme.cyan, Color(red: 0.50, green: 0.66, blue: 1.0)]),
                startPoint: pt(30, 30), endPoint: pt(70, 70))
            ctx.stroke(arc, with: arcShade, style: StrokeStyle(lineWidth: 3 * u, lineCap: .round, lineJoin: .round))

            // Vệt phản chiếu kính.
            ctx.drawLayer { layer in
                layer.clip(to: dialPath)
                var glint = Path()
                glint.move(to: pt(20, 38))
                glint.addLine(to: pt(62, 20))
                glint.addLine(to: pt(80, 20))
                glint.addLine(to: pt(20, 56))
                glint.closeSubpath()
                layer.fill(glint, with: .color(Color.white.opacity(0.10)))
            }

            // Kim giờ/phút (10:10) + trục.
            let ma = 60.0 * Double.pi / 180.0
            let ha = 300.0 * Double.pi / 180.0
            var minute = Path()
            minute.move(to: pt(50, 50))
            minute.addLine(to: pt(50 + CGFloat(sin(ma)) * 16, 50 - CGFloat(cos(ma)) * 16))
            ctx.stroke(minute, with: .color(Color.white), style: StrokeStyle(lineWidth: 3 * u, lineCap: .round))
            var hour = Path()
            hour.move(to: pt(50, 50))
            hour.addLine(to: pt(50 + CGFloat(sin(ha)) * 11, 50 - CGFloat(cos(ha)) * 11))
            ctx.stroke(hour, with: .color(Color.white), style: StrokeStyle(lineWidth: 3.6 * u, lineCap: .round))
            ctx.fill(Path(ellipseIn: box(47, 47, 6, 6)), with: .color(Theme.cyan))
            ctx.fill(Path(ellipseIn: box(48.8, 48.8, 2.4, 2.4)), with: .color(Theme.navy))
        }
    }
}

/// Logo đầy đủ dạng biểu tượng app (nền gradient bo góc + đồng hồ).
struct BrandLogo: View {
    var size: CGFloat = 96

    var body: some View {
        ZStack {
            Theme.logoGradient
            RadialGradient(colors: [Theme.accent2.opacity(0.65), Theme.accent2.opacity(0)],
                           center: UnitPoint(x: 0.84, y: 0.15), startRadius: 0, endRadius: size * 0.5)
            DialArt(color: .white, ringOpacity: 0.10, tickOpacity: 0.22)
                .frame(width: size * 0.92, height: size * 0.92)
            WatchMark()
                .padding(size * 0.17)
                .shadow(color: Theme.navy.opacity(0.45), radius: size * 0.03, x: 0, y: size * 0.014)
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.225, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
                .strokeBorder(Color.white.opacity(0.25), lineWidth: max(0.5, size * 0.006))
        )
        .shadow(color: Theme.accent.opacity(0.35), radius: size * 0.12, x: 0, y: size * 0.06)
    }
}

/// Huy hiệu đồng hồ nhỏ trên thẻ gradient (chữ trắng).
struct WatchGlyph: View {
    var size: CGFloat = 56
    var body: some View {
        WatchMark()
            .padding(size * 0.12)
            .frame(width: size, height: size)
            .background(Color.white.opacity(0.16), in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.3), lineWidth: 0.8)
            )
    }
}

// MARK: - Thẻ kính mờ

/// Nền thẻ kính mờ (material + viền sáng + bóng mềm).
struct GlassBackground: View {
    var radius: CGFloat = Theme.cardRadius
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        let dark = scheme == .dark
        return shape
            .fill(dark ? Color.white.opacity(0.06) : Color.white.opacity(0.70))
            .background(.ultraThinMaterial, in: shape)
            .overlay(
                shape.strokeBorder(
                    LinearGradient(colors: [Color.white.opacity(dark ? 0.30 : 0.95),
                                            Color.white.opacity(dark ? 0.04 : 0.25)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(dark ? 0.35 : 0.08), radius: 14, x: 0, y: 6)
    }
}

/// Nền dòng trong List/Form (kính mờ, hợp với nền vector).
struct RowBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        (scheme == .dark ? Color.white.opacity(0.07) : Color.white.opacity(0.72))
    }
}

struct CardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(GlassBackground())
    }
}

extension View {
    func card() -> some View { modifier(CardModifier()) }
    /// Dùng cho Section trong List/Form để dòng có nền kính mờ.
    func glassRows() -> some View { listRowBackground(RowBackground()) }
}

/// Thẻ nổi bật nền gradient (chữ trắng) có mặt số mờ và quầng sáng.
struct HeroCard<Content: View>: View {
    private let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 28, style: .continuous)
        return VStack(alignment: .leading, spacing: 12) { content }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                ZStack {
                    Theme.heroGradient
                    DialArt(color: .white, ringOpacity: 0.20, tickOpacity: 0.42)
                        .frame(width: 230, height: 230)
                        .offset(x: 120, y: -50)
                    RadialGradient(colors: [Theme.cyan.opacity(0.55), Theme.cyan.opacity(0)],
                                   center: .center, startRadius: 0, endRadius: 120)
                        .frame(width: 240, height: 240)
                        .offset(x: -130, y: 95)
                }
            )
            .clipShape(shape)
            .overlay(
                shape.strokeBorder(
                    LinearGradient(colors: [Color.white.opacity(0.55), Color.white.opacity(0.05)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    lineWidth: 1)
            )
            .shadow(color: Theme.accent.opacity(0.40), radius: 18, x: 0, y: 10)
    }
}

// MARK: - Nút

struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    init() {}
    func makeBody(configuration: Configuration) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
        return configuration.label
            .font(.subheadline.weight(.semibold))
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .foregroundStyle(Color.white)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(
                ZStack {
                    Theme.gradient
                    LinearGradient(colors: [Color.white.opacity(0.30), Color.white.opacity(0)],
                                   startPoint: .top, endPoint: .center)
                }
                .clipShape(shape)
            )
            .overlay(shape.strokeBorder(Color.white.opacity(0.35), lineWidth: 0.8))
            .shadow(color: Theme.accent.opacity(isEnabled ? 0.38 : 0), radius: 10, x: 0, y: 5)
            .opacity(isEnabled ? (configuration.isPressed ? 0.85 : 1.0) : 0.4)
            .scaleEffect(configuration.isPressed ? 0.98 : 1.0)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    var color: Color
    init(color: Color = Theme.accent) { self.color = color }
    func makeBody(configuration: Configuration) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
        return configuration.label
            .font(.subheadline.weight(.semibold))
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .foregroundStyle(color)
            .frame(maxWidth: .infinity, minHeight: 48)
            .background(color.opacity(0.10), in: shape)
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(color.opacity(0.35), lineWidth: 1))
            .opacity(isEnabled ? (configuration.isPressed ? 0.7 : 1.0) : 0.4)
            .scaleEffect(configuration.isPressed ? 0.98 : 1.0)
    }
}

// MARK: - Thành phần nhỏ

/// Ô biểu tượng gradient (SF Symbol trắng).
struct IconBadge: View {
    let systemName: String
    var size: CGFloat = 34
    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: size * 0.46, weight: .semibold))
            .foregroundStyle(Color.white)
            .frame(width: size, height: size)
            .background(Theme.gradient, in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
    }
}

/// Huy hiệu trạng thái trên nền gradient.
struct StatusPill: View {
    let text: String
    let color: Color
    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 8, height: 8)
                .shadow(color: color.opacity(0.8), radius: 3)
            Text(text).font(.footnote.weight(.semibold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Color.white.opacity(0.20), in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.25), lineWidth: 0.8))
        .foregroundStyle(Color.white)
    }
}

/// Vòng phần trăm pin (trên nền gradient).
struct BatteryRing: View {
    let percent: Int
    var body: some View {
        let value = CGFloat(max(0, min(100, percent))) / 100.0
        ZStack {
            Circle().stroke(Color.white.opacity(0.25), lineWidth: 7)
            Circle()
                .trim(from: 0, to: value)
                .stroke(Color.white, style: StrokeStyle(lineWidth: 7, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: Theme.cyan.opacity(0.8), radius: 4)
            Text("\(percent)%").font(.caption.bold()).foregroundStyle(Color.white)
        }
        .frame(width: 58, height: 58)
    }
}

/// Dòng "nhãn – giá trị" dùng trong thẻ.
struct InfoRow: View {
    let label: String
    let value: String
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label).font(.footnote).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).font(.footnote).multilineTextAlignment(.trailing)
        }
    }
}

/// Đầu trang thương hiệu (logo + tên app + mô tả ngắn).
struct BrandHeader: View {
    var logoSize: CGFloat = 84
    var subtitle: String = "Cài mặt đồng hồ HWT cho đồng hồ Huawei"
    var body: some View {
        VStack(spacing: 8) {
            BrandLogo(size: logoSize)
            Text("Huawei watch face").font(.title3.weight(.bold))
            Text(subtitle)
                .font(.footnote).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
    }
}
