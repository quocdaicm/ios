// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Tương đương LogsScreen.kt (được mở từ Cài đặt).
struct LogsView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        ScrollView {
            Text(vm.ui.logs.isEmpty ? "Chưa có nhật ký." : vm.ui.logs.joined(separator: "\n"))
                .font(.system(.caption2, design: .monospaced))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .textSelection(.enabled)
        }
        .background(AppBackground())
        .navigationTitle("Nhật ký")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                ShareLink(item: vm.logsText())
                Button(role: .destructive) { vm.clearLogs() } label: { Image(systemName: "trash") }
            }
        }
    }
}
