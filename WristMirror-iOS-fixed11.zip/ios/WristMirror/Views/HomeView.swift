// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Tab "Trang chủ" – tương đương HomeScreen.kt: trạng thái kết nối + thông tin thiết bị, chạm để sao chép.
struct HomeView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var copiedKey = ""

    private var title: String {
        if vm.ui.connected || vm.ui.connecting {
            return vm.ui.watchName.isEmpty ? "Thiết bị chưa rõ tên" : vm.ui.watchName
        }
        guard let a = vm.ui.selectedDeviceAddress, !a.isEmpty else { return "Chưa có thiết bị trong lịch sử" }
        let name = vm.ui.savedDevices.first { $0.address == a }?.name
            ?? vm.ui.devices.first { $0.address == a }?.name
        return (name?.isEmpty == false ? name : nil) ?? "Thiết bị chưa rõ tên"
    }

    private var statusText: String {
        vm.ui.connected ? "Đã kết nối" : (vm.ui.connecting ? "Đang kết nối" : "Chưa kết nối")
    }

    private var statusColor: Color {
        vm.ui.connected ? .green : (vm.ui.connecting ? .orange : .gray)
    }

    private func known(_ s: String?) -> String? {
        guard let s = s?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty, s != "Không rõ" else { return nil }
        return s
    }

    private var rows: [(String, String?, String)] {
        let selected = vm.ui.selectedDeviceAddress
        let saved = vm.ui.savedDevices.first { $0.address == selected }
        let model = known(vm.ui.deviceModel) ?? known(saved?.model)
        let serial = known(vm.ui.serialNumber) ?? known(saved?.serialNumber)
        let address = known(vm.ui.deviceAddress) ?? selected
        var resolution: String? = nil
        if let w = vm.ui.width, let h = vm.ui.height { resolution = "\(w) × \(h)" }
        let live = vm.ui.connected
        return [
            ("Mã model", model, "cpu"),
            ("Mã thiết bị (UUID Bluetooth)", address, "dot.radiowaves.left.and.right"),
            ("Số sê-ri", serial, "barcode"),
            ("Phiên bản firmware", live ? known(vm.ui.firmware) : nil, "shippingbox"),
            ("Độ phân giải mặt đồng hồ", live ? resolution : nil, "viewfinder"),
            ("Pin", live ? vm.ui.batteryPercent.map { "\($0)%" } : nil, "battery.75"),
            ("Bộ nhớ trống", live ? vm.ui.freeMemoryBytes.map { Self.memory($0) } : nil, "internaldrive"),
        ]
    }

    static func memory(_ bytes: Int64) -> String {
        let mb = Double(bytes) / 1_048_576.0
        return mb >= 1024 ? String(format: "%.2f GB", mb / 1024.0) : String(format: "%.0f MB", mb)
    }

    private func copy(_ key: String, _ value: String) {
        // Hết hạn sau 60 giây, giống cờ IS_SENSITIVE của Android.
        UIPasteboard.general.setItems([["public.utf8-plain-text": value]],
                                      options: [.expirationDate: Date().addingTimeInterval(60)])
        copiedKey = key
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { if copiedKey == key { copiedKey = "" } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HeroCard {
                        HStack(alignment: .center, spacing: 14) {
                            WatchGlyph(size: 64)
                            VStack(alignment: .leading, spacing: 6) {
                                Text(title).font(.title3.bold()).foregroundStyle(Color.white).lineLimit(2)
                                StatusPill(text: statusText, color: statusColor)
                            }
                            Spacer(minLength: 8)
                            if vm.ui.connected, let b = vm.ui.batteryPercent {
                                BatteryRing(percent: b)
                            }
                        }
                        if vm.ui.connecting || vm.ui.connected {
                            Text(vm.ui.detail).font(.footnote).foregroundStyle(Color.white.opacity(0.85))
                        }
                    }

                    VStack(alignment: .leading, spacing: 0) {
                        Text("Thông tin thiết bị").font(.headline).padding(.bottom, 6)
                        ForEach(Array(rows.enumerated()), id: \.offset) { index, row in
                            VStack(spacing: 0) {
                                if index > 0 { Divider().opacity(0.6) }
                                Button {
                                    if let v = row.1 { copy(row.0, v) }
                                } label: {
                                    HStack(alignment: .center, spacing: 12) {
                                        IconBadge(systemName: row.2, size: 30)
                                        Text(row.0).foregroundStyle(.primary)
                                        Spacer(minLength: 12)
                                        Text(copiedKey == row.0 ? "Đã sao chép" : (row.1 ?? "Chưa rõ"))
                                            .foregroundStyle(copiedKey == row.0 ? Theme.accent : Color.secondary)
                                            .multilineTextAlignment(.trailing)
                                    }
                                    .font(.subheadline)
                                    .padding(.vertical, 9)
                                }
                                .buttonStyle(.plain)
                                .disabled(row.1 == nil)
                            }
                        }
                        Text("Chạm vào một dòng để sao chép (tự xoá sau 60 giây).")
                            .font(.caption).foregroundStyle(.secondary).padding(.top, 8)
                    }
                    .card()

                    VStack(spacing: 2) {
                        Text("Huawei watch face · v\(vm.ui.appVersion)").font(.caption).foregroundStyle(.secondary)
                        Link("Làm bởi Quốc Đại · quocdai.site", destination: URL(string: "https://quocdai.site")!)
                            .font(.caption.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
                }
                .padding(16)
            }
            .background(AppBackground())
            .navigationTitle("Trang chủ")
        }
    }
}
