// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Lỗi có cấu trúc do đồng hồ (đối tác) báo về, tách khỏi lỗi JSON hay lỗi mật mã.
struct IsoPeerError: Error, CustomStringConvertible {
    let errorCode: Int64
    var description: String { "ISO_PEER_ERROR" }
}

/// Một lần xác thực HiChain ISO độc lập (port từ IsoAuth.java).
///
/// - Operation 1 (ghép đôi): lấy Secret lâu dài. Phải lưu `learnedSecret()` TRƯỚC khi gửi S4.
/// - Operation 2 (kết nối lại): dùng Secret đã lưu, kết thúc trả về khoá nghiệp vụ ứng viên.
/// Thể hiện chỉ dùng một lần; lỗi xác minh đối tác thì dừng hẳn (fail-closed).
final class IsoAuth {
    static let groupId = "7B0BC0CBCE474F6C238D9661C63400B797B166EA7849B3A370FC73A9A236E989"
    static let maxJsonBytes = WMCore.maxAuth
    static let maxServerSaltBytes = 64
    static let maxPeerIdBytes = 128
    static let isoNonceBytes = 12
    static let challengeBytes = 16

    private static let exchangeAAD = Array("hichain_iso_exchange".utf8)
    private static let resultAAD = Array("hichain_iso_result".utf8)
    private static let sessionInfo = Array("hichain_iso_session_key".utf8)
    private static let returnInfo = Array("hichain_return_key".utf8)
    private static let successResult: [UInt8] = [0, 0, 0, 0]

    private enum Stage { case new, peerSalt, peerMac, peerSecret, completion, finished, failed, closed }

    private let lock = NSRecursiveLock()
    let operation: Int
    let requestId: Int64

    private var random: ((Int) -> [UInt8])?
    private var stage: Stage = .new
    private var completed = false
    private var selfId: [UInt8]?
    private var base: [UInt8]?
    private var clientSalt: [UInt8]?
    private var serverSalt: [UInt8]?
    private var peerId: [UInt8]?
    private var psk: [UInt8]?
    private var isoKey: [UInt8]?
    private var challenge: [UInt8]?
    private var exchangeNonce: [UInt8]?
    private var storedSecret: [UInt8]?
    private var issuedJson: [UInt8]?

    /// self32: 32 byte ASCII = hex thường của 16 byte ngẫu nhiên (do bên gọi lưu theo từng đồng hồ).
    /// pairing=true: dùng PIN thô (không rỗng); pairing=false: dùng Secret đã lưu (16/24/32 byte).
    init(pairing: Bool, self32: [UInt8], pinRawOrSavedSecret: [UInt8], requestId: Int64,
         random: @escaping (Int) -> [UInt8] = { WMRandom.bytes($0) }) throws {
        guard self32.count == 32 else { throw WMFault("ISO_SELF_ID_LENGTH_INVALID") }
        for v in self32 where !((v >= 48 && v <= 57) || (v >= 97 && v <= 102)) {
            throw WMFault("ISO_SELF_ID_FORMAT_INVALID")
        }
        let derived: [UInt8]
        if pairing {
            guard pinRawOrSavedSecret.count >= 1, pinRawOrSavedSecret.count <= HuaweiCrypto.maxPinBytes else {
                throw WMFault("ISO_PIN_LENGTH_INVALID")
            }
            derived = try HuaweiCrypto.pinBase(pinRawOrSavedSecret)
        } else {
            try HuaweiCrypto.validateKeyLength(pinRawOrSavedSecret)
            derived = pinRawOrSavedSecret
        }
        self.operation = pairing ? 1 : 2
        self.requestId = requestId
        self.random = random
        self.selfId = self32
        self.base = derived
    }

    // MARK: API công khai

    func startRequest() throws -> JSONObject {
        lock.lock(); defer { lock.unlock() }
        try require(.new)
        do {
            let salt = try fresh(16)
            let seed = try fresh(32)
            let b = try need(base), sid = try need(selfId)
            let key = try HuaweiCrypto.hmac(b, seed)
            var payload = IsoAuth.versionPayload()
            try payload.put("isoSalt", .string(WMCore.hex(salt)))
            try payload.put("peerAuthId", .string(WMCore.hex(sid)))
            try payload.put("operationCode", .int(Int64(operation)))
            try payload.put("seed", .string(WMCore.hex(seed)))
            try payload.put("peerUserType", .int(0))
            if operation == 2 {
                try payload.put("pkgName", .string("com.huawei.devicegroupmanage"))
                try payload.put("serviceType", .string(IsoAuth.groupId))
                try payload.put("keyLength", .int(32))
            }
            let next = try issue(payload, 1)
            clientSalt = salt
            psk = key
            base = nil
            stage = .peerSalt
            return next
        } catch {
            abort()
            throw error
        }
    }

    func handlePeer(_ peer: JSONObject) throws -> JSONObject {
        lock.lock(); defer { lock.unlock() }
        try requirePeerProof()
        do {
            let root = try IsoAuth.snapshotJson(peer)
            try IsoAuth.checkPeerError(root)
            let payload = try MiniJson.object(root, "payload")
            try IsoAuth.checkPeerError(payload)
            try validateEchoes(root, payload)
            try checkProofShape(payload)
            if stage == .peerSalt { return try peerSalt(payload) }
            if stage == .peerMac { return try peerMac(payload) }
            return try peerSecret(payload)
        } catch {
            abort()
            throw error
        }
    }

    func handlePeer(jsonUtf8: [UInt8]) throws -> JSONObject {
        lock.lock(); defer { lock.unlock() }
        try requirePeerProof()
        do {
            guard jsonUtf8.count >= 1, jsonUtf8.count <= IsoAuth.maxJsonBytes else {
                throw WMFault("ISO_JSON_BYTES_INVALID")
            }
            return try handlePeer(try MiniJson.parseObject(jsonUtf8))
        } catch {
            abort()
            throw error
        }
    }

    /// Thân TLV của service 01 / command 28: tag1 = JSON, tag2 = opcode (1 byte), tag3 = requestId (8 byte BE).
    func requestTlv(_ request: JSONObject) throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        guard let issued = issuedJson, active() else { throw WMFault("ISO_REQUEST_STATE_INVALID") }
        let json = try IsoAuth.encodeJson(IsoAuth.snapshotJson(request))
        if !HuaweiCrypto.constantTimeEquals(json, issued) { throw WMFault("ISO_REQUEST_MODIFIED_OR_STALE") }
        var body: [UInt8] = [1]
        body += try WMCore.length(json.count)
        body += json
        body += [2, 1, UInt8(operation), 3, 8]
        let rid = UInt64(bitPattern: requestId)
        for shift in stride(from: 56, through: 0, by: -8) {
            body.append(UInt8((rid >> UInt64(shift)) & 0xff))
        }
        return body
    }

    /// 0 = mới; 1/2/3 = chờ bằng chứng tương ứng; 4 = chỉ chờ hoàn tất; -1 = trạng thái cuối.
    func expectedStage() -> Int {
        lock.lock(); defer { lock.unlock() }
        switch stage {
        case .new: return 0
        case .peerSalt: return 1
        case .peerMac: return 2
        case .peerSecret: return 3
        case .completion: return 4
        default: return -1
        }
    }

    func awaitingCompletion() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return stage == .completion
    }

    func finished() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return completed
    }

    /// Secret học được ở S3 (chỉ khi ghép đôi). PHẢI lưu trước khi gửi S4.
    func learnedSecret() -> [UInt8]? {
        lock.lock(); defer { lock.unlock() }
        return storedSecret
    }

    /// Chấp nhận hoàn tất (chỉ ở giai đoạn chờ hoàn tất). Operation 2 trả về khoá ứng viên; operation 1 trả nil.
    func acceptCompletion(_ peer: JSONObject? = nil) throws -> [UInt8]? {
        lock.lock(); defer { lock.unlock() }
        try require(.completion)
        do {
            if let peer = peer {
                let root = try IsoAuth.snapshotJson(peer)
                try IsoAuth.checkPeerError(root)
                var payload = JSONObject()
                if root.has("payload") { payload = try MiniJson.object(root, "payload") }
                try IsoAuth.checkPeerError(payload)
                try validateEchoes(root, payload)
                if payload.has("isoSalt") || payload.has("returnCodeMac") || payload.has("encAuthToken") {
                    throw WMFault("ISO_COMPLETION_PROOF_UNEXPECTED")
                }
            }
            var candidate: [UInt8]? = nil
            if operation == 1 {
                if storedSecret == nil { throw WMFault("ISO_SECRET_NOT_AVAILABLE") }
            } else {
                candidate = try derive(try need(isoKey), IsoAuth.returnInfo)
            }
            completed = true
            stage = .finished
            clearTransient()
            return candidate
        } catch {
            abort()
            throw error
        }
    }

    func acceptCompletionJson(_ peerJsonUtf8: [UInt8]) throws -> [UInt8]? {
        lock.lock(); defer { lock.unlock() }
        try require(.completion)
        do {
            guard peerJsonUtf8.count >= 1, peerJsonUtf8.count <= IsoAuth.maxJsonBytes else {
                throw WMFault("ISO_JSON_BYTES_INVALID")
            }
            return try acceptCompletion(try MiniJson.parseObject(peerJsonUtf8))
        } catch {
            abort()
            throw error
        }
    }

    func close() {
        lock.lock(); defer { lock.unlock() }
        clearTransient()
        storedSecret = nil
        stage = .closed
    }

    // MARK: Các bước

    private func peerSalt(_ payload: JSONObject) throws -> JSONObject {
        let salt = try IsoAuth.boundedHex(payload, "isoSalt", 1, IsoAuth.maxServerSaltBytes)
        let identity = try IsoAuth.boundedHex(payload, "peerAuthId", 1, IsoAuth.maxPeerIdBytes)
        let token = try IsoAuth.boundedHex(payload, "token", 32, 32)
        let key = try need(psk), cs = try need(clientSalt), sid = try need(selfId)
        let expected = try IsoAuth.hmacJoined(key, [salt, cs, sid, identity])
        if !HuaweiCrypto.constantTimeEquals(token, expected) { throw WMFault("ISO_S1_TOKEN_MISMATCH") }
        let replyToken = try IsoAuth.hmacJoined(key, [cs, salt, identity, sid])
        var nextPayload = IsoAuth.versionPayload()
        try nextPayload.put("peerAuthId", .string(WMCore.hex(sid)))
        try nextPayload.put("token", .string(WMCore.hex(replyToken)))
        let next = try issue(nextPayload, 2)
        serverSalt = salt
        peerId = identity
        stage = .peerMac
        return next
    }

    private func peerMac(_ payload: JSONObject) throws -> JSONObject {
        let mac = try IsoAuth.boundedHex(payload, "returnCodeMac", 32, 32)
        let k = try need(psk)
        let expected = try HuaweiCrypto.hmac(k, IsoAuth.successResult)
        if !HuaweiCrypto.constantTimeEquals(mac, expected) { throw WMFault("ISO_S2_MAC_MISMATCH") }
        let key = try derive(k, IsoAuth.sessionInfo)
        let nonce = try fresh(IsoAuth.isoNonceBytes)
        var nextPayload = IsoAuth.versionPayload()
        try nextPayload.put("nonce", .string(WMCore.hex(nonce)))
        var nextChallenge: [UInt8]? = nil
        if operation == 1 {
            let ch = try fresh(IsoAuth.challengeBytes)
            nextChallenge = ch
            let enc = try HuaweiCrypto.aesGcmEncrypt(key, nonce, ch, IsoAuth.exchangeAAD)
            try nextPayload.put("encData", .string(WMCore.hex(enc)))
        } else {
            let enc = try HuaweiCrypto.aesGcmEncrypt(key, nonce, IsoAuth.successResult, IsoAuth.resultAAD)
            try nextPayload.put("encResult", .string(WMCore.hex(enc)))
            try nextPayload.put("operationCode", .int(Int64(operation)))
        }
        let next = try issue(nextPayload, 3)
        isoKey = key
        if operation == 1 {
            challenge = nextChallenge
            exchangeNonce = nonce
            stage = .peerSecret
        } else {
            stage = .completion
        }
        psk = nil
        peerId = nil
        return next
    }

    private func peerSecret(_ payload: JSONObject) throws -> JSONObject {
        let nonce = try IsoAuth.boundedHex(payload, "nonce", IsoAuth.isoNonceBytes, IsoAuth.isoNonceBytes)
        let encrypted = try IsoAuth.boundedHex(payload, "encAuthToken", 32, 48)
        let key = try need(isoKey), ch = try need(challenge)
        let secret = try HuaweiCrypto.aesGcmDecrypt(key, nonce, encrypted, ch)
        if !HuaweiCrypto.isAesKeyLength(secret.count) { throw WMFault("ISO_SECRET_LENGTH_NOT_SUPPORTED") }
        // Cố ý lưu trước khi tạo kết quả: không bỏ Secret đã xác thực chỉ vì bước S4 hỏng.
        storedSecret = secret
        challenge = nil
        let resultNonce = try fresh(IsoAuth.isoNonceBytes)
        if HuaweiCrypto.constantTimeEquals(resultNonce, exchangeNonce) ||
            HuaweiCrypto.constantTimeEquals(resultNonce, nonce) {
            throw WMFault("ISO_LOCAL_NONCE_REUSE")
        }
        let result = try HuaweiCrypto.aesGcmEncrypt(key, resultNonce, IsoAuth.successResult, IsoAuth.resultAAD)
        var nextPayload = IsoAuth.versionPayload()
        try nextPayload.put("nonce", .string(WMCore.hex(resultNonce)))
        try nextPayload.put("encResult", .string(WMCore.hex(result)))
        try nextPayload.put("operationCode", .int(Int64(operation)))
        let next = try issue(nextPayload, 4)
        exchangeNonce = nil
        stage = .completion
        return next
    }

    // MARK: Dựng yêu cầu

    private func issue(_ payload: JSONObject, _ step: Int) throws -> JSONObject {
        var root = JSONObject([
            ("authForm", .int(0)),
            ("payload", .object(payload)),
            ("groupAndModuleVersion", .string("2.0.1")),
            ("message", .int(Int64(step | (operation == 2 ? 0x10 : 0)))),
        ])
        if operation == 1 {
            let identity = try WMCore.utf8(try need(selfId))
            try root.put("requestId", .string(String(requestId)))
            try root.put("groupId", .string(IsoAuth.groupId))
            try root.put("groupName", .string("health_group_name"))
            try root.put("groupOp", .int(2))
            try root.put("groupType", .int(256))
            try root.put("peerDeviceId", .string(identity))
            try root.put("connDeviceId", .string(identity))
            try root.put("appId", .string("com.huawei.health"))
            try root.put("ownerName", .string(""))
        } else if step == 1 || step == 2 {
            try root.put("isDeviceLevel", .bool(false))
        }
        issuedJson = try IsoAuth.encodeJson(root)
        return root
    }

    private static func versionPayload() -> JSONObject {
        JSONObject([("version", .object(JSONObject([
            ("minVersion", .string("1.0.0")),
            ("currentVersion", .string("2.0.16")),
        ])))])
    }

    // MARK: Kiểm tra

    private func validateEchoes(_ root: JSONObject, _ payload: JSONObject) throws {
        try validateEchoScope(root)
        try validateEchoScope(payload)
    }

    private func validateEchoScope(_ scope: JSONObject) throws {
        if scope.has("operationCode") {
            let code = try IsoAuth.number(scope, "operationCode")
            if code < Int64(Int32.min) || code > 0xffffffff { throw WMFault("ISO_OPERATION_METADATA_INVALID") }
            // Chỉ op1/op2 tường minh mới liên hệ được với thao tác này.
            if (code == 1 || code == 2) && code != Int64(operation) { throw WMFault("ISO_OPERATION_MISMATCH") }
        }
        if let v = scope["requestId"] {
            switch v {
            case .int(let n):
                if n != requestId { throw WMFault("ISO_REQUEST_ID_MISMATCH") }
            case .string(let t):
                if t.range(of: "^-?[0-9]+$", options: .regularExpression) != nil && String(requestId) != t {
                    throw WMFault("ISO_REQUEST_ID_MISMATCH")
                }
            default:
                throw WMFault("ISO_REQUEST_ID_METADATA_INVALID")
            }
        }
        if scope.has("message") {
            let m = try IsoAuth.number(scope, "message")
            // message chỉ là metadata không diễn giải; không dùng để chọn giai đoạn/chứng minh.
            if m < Int64(Int32.min) || m > 0xffffffff { throw WMFault("ISO_MESSAGE_METADATA_INVALID") }
        }
    }

    private static func number(_ scope: JSONObject, _ field: String) throws -> Int64 {
        guard let v = try MiniJson.optionalNumber(scope, field) else { throw WMFault("ISO_ECHO_NUMBER_INVALID") }
        return v
    }

    private static func checkPeerError(_ scope: JSONObject) throws {
        if !scope.has("errorCode") { return }
        let code = try number(scope, "errorCode")
        if code < Int64(Int32.min) || code > 0xffffffff { throw WMFault("ISO_PEER_ERROR_CODE_INVALID") }
        if code != 0 { throw IsoPeerError(errorCode: code) }
    }

    private func checkProofShape(_ payload: JSONObject) throws {
        let salt = payload.has("isoSalt"), mac = payload.has("returnCodeMac"), secret = payload.has("encAuthToken")
        let count = (salt ? 1 : 0) + (mac ? 1 : 0) + (secret ? 1 : 0)
        if count != 1 { throw WMFault("ISO_PROOF_MISSING_OR_AMBIGUOUS") }
        if (stage == .peerSalt && !salt) || (stage == .peerMac && !mac) || (stage == .peerSecret && !secret) {
            throw WMFault("ISO_PROOF_OUT_OF_ORDER")
        }
    }

    // MARK: Tiện ích

    private func need(_ v: [UInt8]?) throws -> [UInt8] {
        guard let v = v else { throw WMFault("ISO_KEY_STATE_INVALID") }
        return v
    }

    private func derive(_ key: [UInt8], _ info: [UInt8]) throws -> [UInt8] {
        let salts = try IsoAuth.joined([try need(clientSalt), try need(serverSalt)])
        return try HuaweiCrypto.hkdf32(key, salts, info)
    }

    private static func hmacJoined(_ key: [UInt8], _ pieces: [[UInt8]]) throws -> [UInt8] {
        try HuaweiCrypto.hmac(key, try joined(pieces))
    }

    private static func joined(_ pieces: [[UInt8]]) throws -> [UInt8] {
        var out = [UInt8]()
        for p in pieces {
            if p.count > maxJsonBytes - out.count { throw WMFault("ISO_KEY_STATE_INVALID") }
            out += p
        }
        return out
    }

    private func fresh(_ n: Int) throws -> [UInt8] {
        guard let r = random else { throw WMFault("ISO_RANDOM_FAILED") }
        let b = r(n)
        if b.count != n { throw WMFault("ISO_RANDOM_FAILED") }
        return b
    }

    private static func boundedHex(_ payload: JSONObject, _ field: String, _ min: Int, _ max: Int) throws -> [UInt8] {
        let text = try MiniJson.string(payload, field)
        if text.utf8.count < min * 2 || text.utf8.count > max * 2 { throw WMFault("ISO_HEX_LENGTH_INVALID_" + field) }
        return try MiniJson.hex(payload, field, min: min, max: max)
    }

    private static func encodeJson(_ json: JSONObject) throws -> [UInt8] {
        let bytes = Array(try MiniJson.encode(json).utf8)
        if bytes.count > maxJsonBytes { throw WMFault("ISO_JSON_SIZE_LIMIT") }
        return bytes
    }

    /// JSONObject là kiểu giá trị nên không cần sao chép sâu; chỉ kiểm tra ngân sách kích thước.
    private static func snapshotJson(_ input: JSONObject) throws -> JSONObject {
        _ = try encodeJson(input)
        return input
    }

    private func require(_ expected: Stage) throws {
        if stage != expected { throw WMFault("ISO_STATE_UNEXPECTED") }
    }

    private func requirePeerProof() throws {
        if stage != .peerSalt && stage != .peerMac && stage != .peerSecret { throw WMFault("ISO_STATE_UNEXPECTED") }
    }

    private func active() -> Bool {
        stage == .peerSalt || stage == .peerMac || stage == .peerSecret || stage == .completion
    }

    private func abort() {
        clearTransient()
        stage = .failed
    }

    private func clearTransient() {
        selfId = nil; base = nil; clientSalt = nil; serverSalt = nil; peerId = nil
        psk = nil; isoKey = nil; challenge = nil; exchangeNonce = nil; issuedJson = nil
        random = nil
    }
}
