// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Máy trạng thái quan sát việc xoá (port từ DeletionState.java). Không bao giờ xin file hay bật mặt khác.
/// op=2 của 27/03 và reportType=3 của 27/05 là hai trường khác nhau.
final class DeletionState {
    enum Phase: String { case waitDevice = "WAIT_DEVICE", waitList = "WAIT_LIST", deleted = "DELETED", failed = "FAILED", cancelled = "CANCELLED", timedOut = "TIMED_OUT" }
    enum Action { case none, query }

    let id: String
    let version: String
    let wasCurrent: Bool
    private(set) var phase: Phase = .waitDevice
    private(set) var reason = "WAITING_DELETE_RESPONSE_OR_REPORT"
    private(set) var operationError: Int64?, need: Int64?, operationEcho: Int64?, reportError: Int64?, firstError: Int64?
    private(set) var reportType: Int?
    private(set) var operationObserved = false, deleteReportObserved = false, idAbsent = false, versionAbsent = false
    private(set) var signalGeneration = 0, listObservations = 0, consecutiveAbsences = 0, currentCount = 0
    private(set) var newCurrentId: String?
    private var lastObservedQuery: Int64 = -1

    init(id: String, version: String, current: Bool = false) throws {
        try WMCore.resource(id, version)
        self.id = id
        self.version = version
        self.wasCurrent = current
    }

    func matches(_ id: String, _ version: String) -> Bool { self.id == id && self.version == version }

    var terminal: Bool { phase == .deleted || phase == .failed || phase == .cancelled || phase == .timedOut }

    func operation(error: Int64?, need transferNeed: Int64?, echo: Int64?) -> Action {
        // Echo = 1 là thao tác khác, không bao giờ coi là phản hồi xoá.
        if let e = echo, e != 2 { return .none }
        operationError = error
        need = transferNeed
        operationEcho = echo
        if let e = error, e != 0 { fail("DELETE_OPERATION_ERROR", e); return .none }
        if terminal { return .none }
        // Thiếu 7F không được coi là 0 rõ ràng.
        if error == nil { fail("DELETE_OPERATION_ERROR_MISSING", nil); return .none }
        if let n = transferNeed, n != 0 { fail("DELETE_UNEXPECTED_FILE_REQUEST_NO_TRANSFER", nil); return .none }
        if operationObserved { return .none }
        operationObserved = true
        signalGeneration += 1
        consecutiveAbsences = 0
        phase = .waitList
        reason = echo == nil ? "DELETE_RESPONSE_NO_ECHO_WAIT_NEW_LIST" : "DELETE_RESPONSE_WAIT_NEW_LIST"
        return .query
    }

    func report(type: Int?, error: Int64?) -> Action {
        reportType = type
        reportError = error
        // Report 2 = truyền file xong, 1 = đổi mặt hiện tại; chỉ 3 liên quan đến xoá.
        guard type == 3 else { return .none }
        if let e = error, e != 100000, e != 0 { fail("DELETE_REPORT_ERROR", e); return .none }
        if terminal { return .none }
        // 7F tường minh bằng 0 không chứng minh report thành công.
        if let e = error, e == 0 { reason = "DELETE_REPORT_ZERO_WAIT_OPERATION_OR_NORMAL_REPORT"; return .none }
        if deleteReportObserved { return .none }
        deleteReportObserved = true
        signalGeneration += 1
        consecutiveAbsences = 0
        phase = .waitList
        reason = "DELETE_REPORT_THREE_WAIT_NEW_LIST"
        return .query
    }

    private static func observedText(_ text: String) -> Bool {
        if text.isEmpty { return false }
        let bytes = Array(text.utf8)
        guard bytes.count <= 32, let back = try? WMCore.utf8(bytes) else { return false }
        return back == text
    }

    private static func inRange(_ v: Int64) -> Bool { v >= 0 && v <= 0xffffffff }

    private static func observedFace(_ face: TlvView.Face) -> Bool {
        guard observedText(face.id), observedText(face.version), let t = face.type, inRange(t) else { return false }
        if let e = face.expandType { return inRange(e) }
        return true
    }

    func list(_ faces: [TlvView.Face]?, generation: Int, ownQuery: Bool, querySerial: Int64) {
        listObservations += 1
        if terminal || phase != .waitList || !ownQuery || signalGeneration == 0 || generation != signalGeneration
            || querySerial <= 0 || querySerial <= lastObservedQuery { return }
        lastObservedQuery = querySerial
        guard let faces = faces else { fail("DELETE_LIST_MISSING", nil); return }
        if faces.count > TlvView.maxFields { fail("DELETE_LIST_LIMIT", nil); return }
        idAbsent = true
        versionAbsent = true
        currentCount = 0
        newCurrentId = nil
        var validCurrent = true
        for face in faces {
            if !DeletionState.observedFace(face) { fail("DELETE_LIST_INVALID", nil); return }
            if id == face.id {
                idAbsent = false
                if version == face.version { versionAbsent = false }
            }
            if FacePolicy.isCurrent(face) {
                currentCount += 1
                newCurrentId = face.id
                if !face.validResource { validCurrent = false }
            }
        }
        if !idAbsent {
            consecutiveAbsences = 0
            reason = versionAbsent ? "DELETE_VERSION_ABSENT_BUT_ID_STILL_PRESENT" : "DELETE_TARGET_STILL_LISTED"
            return
        }
        if wasCurrent && (currentCount != 1 || !validCurrent) {
            consecutiveAbsences = 0
            reason = "DELETE_TARGET_ABSENT_WAIT_UNIQUE_VALID_CURRENT_MARKER"
            return
        }
        consecutiveAbsences += 1
        if consecutiveAbsences >= 2 {
            phase = .deleted
            reason = "DELETE_TARGET_ID_ABSENT_IN_TWO_NEW_LISTS_VISUAL_CHECK_REQUIRED"
        } else {
            reason = "DELETE_TARGET_ABSENT_WAIT_SECOND_INDEPENDENT_QUERY"
        }
    }

    /// Danh sách thiếu ID của mặt khác ⇒ không tính là lần vắng mặt hợp lệ (Java ghi trực tiếp hai trường này).
    func markNonTargetListIncomplete() {
        consecutiveAbsences = 0
        reason = "DELETE_NON_TARGET_LIST_INCOMPLETE"
    }

    func fail(_ why: String, _ error: Int64?) {
        if firstError == nil, let e = error { firstError = e }
        if !terminal || phase == .deleted {
            phase = .failed
            reason = why
        }
    }

    func cancel() {
        if !terminal { phase = .cancelled; reason = "DELETE_CANCELLED_QUEUED_COMMAND_NOT_RETRACTABLE" }
    }

    func timeout() {
        if !terminal { phase = .timedOut; reason = "DELETE_TIMEOUT_NOT_A_REMOVAL_VERDICT" }
    }

    func summary() -> String {
        func s(_ v: Int64?) -> String { v.map(String.init) ?? "nil" }
        return "phase=\(phase.rawValue) reason=\(reason) id=\(id) version=\(version)"
            + " operation_error=\(s(operationError)) need=\(s(need)) operation_echo=\(s(operationEcho))"
            + " delete_report=\(reportType.map(String.init) ?? "nil") report_error=\(s(reportError))"
            + " operation_observed=\(operationObserved) report_three_observed=\(deleteReportObserved)"
            + " signal_generation=\(signalGeneration) list_observations=\(listObservations)"
            + " independent_absences=\(consecutiveAbsences) id_absent=\(idAbsent) version_absent=\(versionAbsent)"
            + " was_current=\(wasCurrent) new_current_count=\(currentCount) new_current_id=\(newCurrentId ?? "nil")"
            + " first_error=\(s(firstError))"
    }
}
