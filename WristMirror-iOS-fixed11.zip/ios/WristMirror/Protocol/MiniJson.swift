// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Giá trị JSON nhỏ, có giới hạn, dùng cho thông điệp HiChain (chỉ số nguyên, cấm khoá trùng).
enum JSONValue {
    case null
    case bool(Bool)
    case int(Int64)
    case string(String)
    case object(JSONObject)
    case array([JSONValue])
}

/// Object giữ nguyên thứ tự chèn khoá (như LinkedHashMap).
struct JSONObject {
    private(set) var keys: [String] = []
    private var dict: [String: JSONValue] = [:]

    init() {}
    init(_ pairs: [(String, JSONValue)]) {
        for (k, v) in pairs { precondition(dict[k] == nil, "Duplicate JSON key"); keys.append(k); dict[k] = v }
    }
    subscript(key: String) -> JSONValue? { dict[key] }
    func has(_ key: String) -> Bool { dict[key] != nil }
    mutating func put(_ key: String, _ value: JSONValue) throws {
        if dict[key] != nil { throw WMFault("AUTH_JSON_DUPLICATE_OR_KEY") }
        keys.append(key); dict[key] = value
    }
}

enum MiniJson {
    static let maxBytes = 65536
    static let maxDepth = 8
    static let maxNodes = 2048

    // MARK: Truy cập có kiểm tra
    static func object(_ m: JSONObject, _ key: String) throws -> JSONObject {
        if case .object(let o)? = m[key] { return o }
        throw WMFault("AUTH_JSON_OBJECT_REQUIRED_" + key)
    }
    static func string(_ m: JSONObject, _ key: String) throws -> String {
        if case .string(let s)? = m[key] { return s }
        throw WMFault("AUTH_JSON_STRING_REQUIRED_" + key)
    }
    static func optionalString(_ m: JSONObject, _ key: String) -> String? {
        if case .string(let s)? = m[key] { return s }
        return nil
    }
    static func optionalNumber(_ m: JSONObject, _ key: String) throws -> Int64? {
        guard let v = m[key] else { return nil }
        switch v {
        case .null: return nil
        case .int(let n): return n
        default: throw WMFault("AUTH_JSON_NUMBER_REQUIRED_" + key)
        }
    }
    static func hex(_ m: JSONObject, _ key: String, min: Int, max: Int) throws -> [UInt8] {
        let b = try WMCore.unhex(string(m, key))
        if b.count < min || b.count > max { throw WMFault("AUTH_JSON_HEX_LENGTH_" + key) }
        return b
    }

    // MARK: Phân tích
    static func parseObject(_ utf8: [UInt8]) throws -> JSONObject {
        try parseObject(WMCore.utf8(utf8))
    }

    static func parseObject(_ text: String) throws -> JSONObject {
        if text.utf8.count > maxBytes { throw WMFault("AUTH_JSON_SIZE") }
        let p = Parser(text)
        let o = try p.value(0)
        p.space()
        guard p.i == p.s.count, case .object(let m) = o else { throw WMFault("AUTH_JSON_ROOT") }
        return m
    }

    // MARK: Mã hoá
    static func encode(_ value: JSONObject) throws -> String {
        var out = ""
        var nodes = 0
        try write(&out, .object(value), 0, &nodes)
        if out.utf8.count > maxBytes { throw WMFault("AUTH_JSON_SIZE") }
        return out
    }

    private static func write(_ b: inout String, _ o: JSONValue, _ depth: Int, _ nodes: inout Int) throws {
        nodes += 1
        if depth > maxDepth || nodes > maxNodes { throw WMFault("AUTH_JSON_BUDGET") }
        switch o {
        case .null: b += "null"
        case .string(let s): quote(&b, s)
        case .bool(let v): b += v ? "true" : "false"
        case .int(let n): b += String(n)
        case .object(let m):
            b += "{"
            var first = true
            for k in m.keys {
                if !first { b += "," }
                first = false
                quote(&b, k)
                b += ":"
                try write(&b, m[k]!, depth + 1, &nodes)
            }
            b += "}"
        case .array(let a):
            b += "["
            var first = true
            for v in a {
                if !first { b += "," }
                first = false
                try write(&b, v, depth + 1, &nodes)
            }
            b += "]"
        }
    }

    private static func quote(_ b: inout String, _ s: String) {
        b += "\""
        for c in s.unicodeScalars {
            switch c {
            case "\"": b += "\\\""
            case "\\": b += "\\\\"
            case "\u{08}": b += "\\b"
            case "\u{0C}": b += "\\f"
            case "\n": b += "\\n"
            case "\r": b += "\\r"
            case "\t": b += "\\t"
            default:
                if c.value < 32 {
                    let h = String(c.value, radix: 16)
                    b += "\\u" + String(repeating: "0", count: 4 - h.count) + h
                } else {
                    b.unicodeScalars.append(c)
                }
            }
        }
        b += "\""
    }

    // MARK: Bộ phân tích
    fileprivate final class Parser {
        let s: [Unicode.Scalar]
        var i = 0
        var nodes = 0
        init(_ text: String) { s = Array(text.unicodeScalars) }

        func bad() -> WMFault { WMFault("AUTH_JSON_INVALID") }
        func digit(_ c: Unicode.Scalar) -> Bool { c.value >= 48 && c.value <= 57 }

        func space() {
            while i < s.count && (s[i] == " " || s[i] == "\n" || s[i] == "\r" || s[i] == "\t") { i += 1 }
        }

        func eat(_ c: Unicode.Scalar) -> Bool {
            if i < s.count && s[i] == c { i += 1; return true }
            return false
        }

        func starts(_ word: String) -> Bool {
            let u = Array(word.unicodeScalars)
            return i + u.count <= s.count && Array(s[i..<(i + u.count)]) == u
        }

        func value(_ depth: Int) throws -> JSONValue {
            space()
            nodes += 1
            if depth > MiniJson.maxDepth || nodes > MiniJson.maxNodes || i >= s.count {
                throw WMFault("AUTH_JSON_BUDGET_OR_TRUNCATED")
            }
            let c = s[i]
            if c == "{" {
                i += 1
                var m = JSONObject()
                space()
                if eat("}") { return .object(m) }
                while true {
                    space()
                    if i >= s.count || s[i] != "\"" { throw bad() }
                    let k = try str()
                    space()
                    if !eat(":") || m.has(k) { throw WMFault("AUTH_JSON_DUPLICATE_OR_KEY") }
                    try m.put(k, try value(depth + 1))
                    space()
                    if eat("}") { return .object(m) }
                    if !eat(",") { throw bad() }
                }
            }
            if c == "[" {
                i += 1
                var a: [JSONValue] = []
                space()
                if eat("]") { return .array(a) }
                while true {
                    a.append(try value(depth + 1))
                    space()
                    if eat("]") { return .array(a) }
                    if !eat(",") { throw bad() }
                }
            }
            if c == "\"" { return .string(try str()) }
            if starts("true") { i += 4; return .bool(true) }
            if starts("false") { i += 5; return .bool(false) }
            if starts("null") { i += 4; return .null }
            let start = i
            if c == "-" { i += 1 }
            if i >= s.count || !digit(s[i]) { throw bad() }
            if s[i] == "0" { i += 1 } else { while i < s.count && digit(s[i]) { i += 1 } }
            if i < s.count && (s[i] == "." || s[i] == "e" || s[i] == "E") { throw WMFault("AUTH_JSON_NON_INTEGER") }
            var t = ""
            for k in start..<i { t.unicodeScalars.append(s[k]) }
            guard let n = Int64(t) else { throw bad() }
            return .int(n)
        }

        func hexVal(_ c: Unicode.Scalar) -> UInt16? {
            switch c.value {
            case 48...57: return UInt16(c.value - 48)
            case 97...102: return UInt16(c.value - 87)
            case 65...70: return UInt16(c.value - 55)
            default: return nil
            }
        }

        func decodeStrict(_ units: [UInt16]) -> String? {
            var it = units.makeIterator()
            var dec = UTF16()
            var out = String.UnicodeScalarView()
            while true {
                switch dec.decode(&it) {
                case .scalarValue(let v): out.append(v)
                case .emptyInput: return String(out)
                case .error: return nil
                }
            }
        }

        func str() throws -> String {
            if !eat("\"") { throw bad() }
            var units: [UInt16] = []
            var closed = false
            while i < s.count {
                let c = s[i]; i += 1
                if c == "\"" { closed = true; break }
                if c.value < 32 { throw bad() }
                if c == "\\" {
                    if i >= s.count { throw bad() }
                    let e = s[i]; i += 1
                    switch e {
                    case "\"", "\\", "/": units.append(UInt16(e.value))
                    case "b": units.append(8)
                    case "f": units.append(12)
                    case "n": units.append(10)
                    case "r": units.append(13)
                    case "t": units.append(9)
                    case "u":
                        if i + 4 > s.count { throw bad() }
                        var v: UInt16 = 0
                        for p in 0..<4 {
                            guard let d = hexVal(s[i + p]) else { throw bad() }
                            v = (v << 4) | d
                        }
                        units.append(v)
                        i += 4
                    default: throw bad()
                    }
                } else {
                    units.append(contentsOf: Array(String(c).utf16))
                }
                if units.count > MiniJson.maxBytes { throw WMFault("AUTH_JSON_STRING_SIZE") }
            }
            guard closed, let out = decodeStrict(units) else { throw bad() }
            return out
        }
    }
}
