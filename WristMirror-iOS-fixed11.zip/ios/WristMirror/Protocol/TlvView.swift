// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Giải mã TLV Huawei chỉ-đọc, có giới hạn (port từ TlvView.java).
enum TlvView {
    static let maxBytes = 65536
    static let maxFields = 512
    static let maxDepth = 4

    struct Part {
        let tag: Int
        let value: [UInt8]
        func number() -> Int64? { try? WMCore.number(value) }
        func resourceText() -> String? {
            value.count <= 32 ? (try? WMCore.utf8(value)) : nil
        }
    }

    static func decode(_ bytes: [UInt8]?) throws -> [Part] {
        guard let bytes = bytes, bytes.count <= maxBytes else { throw WMFault("TLV_VIEW_BYTES_LIMIT") }
        var out: [Part] = []
        var p = 0
        while p < bytes.count {
            if out.count >= maxFields { throw WMFault("TLV_VIEW_FIELDS_LIMIT") }
            let tag = Int(bytes[p]); p += 1
            var groups = 0
            var length = 0
            var ended = false
            while p < bytes.count {
                let b = Int(bytes[p]); p += 1
                groups += 1
                if groups > 5 || length > (Int(Int32.max) >> 7) { throw WMFault("TLV_VIEW_LENGTH_OVERFLOW") }
                length = (length << 7) | (b & 127)
                if length > maxBytes { throw WMFault("TLV_VIEW_BYTES_LIMIT") }
                if (b & 128) == 0 { ended = true; break }
            }
            if !ended { throw WMFault("TLV_VIEW_TRUNCATED_LENGTH") }
            if length > bytes.count - p { throw WMFault("TLV_VIEW_TRUNCATED_VALUE") }
            out.append(Part(tag: tag, value: Array(bytes[p..<(p + length)])))
            p += length
        }
        return out
    }

    static func first(_ fields: [Part], _ tag: Int) -> Part? {
        fields.first { $0.tag == tag }
    }

    static func tags(_ fields: [Part]) -> String {
        var s = ""
        var count = 0
        for p in fields {
            count += 1
            if count > 64 { s += ",..."; break }
            if !s.isEmpty { s += "," }
            s += String(p.tag, radix: 16) + ":" + String(p.value.count)
        }
        return s
    }

    struct Face {
        let id: String
        let version: String
        let type: Int64?
        let expandType: Int64?
        var validResource: Bool { (try? WMCore.resource(id, version)) != nil }
        var description: String {
            "\(WMCore.clean(id))_\(WMCore.clean(version))  type(raw)=\(type.map(String.init) ?? "nil") expand(raw)=\(expandType.map(String.init) ?? "nil")"
        }
    }

    /// Cấu trúc danh sách quan sát được: root 0x81 → các mục 0x82 → ID(03), version(04), type(05), tuỳ chọn 07.
    static func faces(root81: [UInt8]) throws -> [Face] {
        var out: [Face] = []
        for entry in try decode(root81) where entry.tag == 0x82 {
            let data = try decode(entry.value)
            let id = first(data, 3), version = first(data, 4), type = first(data, 5), expand = first(data, 7)
            guard let id = id, let version = version else { throw WMFault("TLV_VIEW_FACE_ID_VERSION_MISSING") }
            guard let i = id.resourceText(), let v = version.resourceText() else {
                throw WMFault("TLV_VIEW_FACE_TEXT_INVALID")
            }
            out.append(Face(id: i, version: v, type: type?.number(), expandType: expand?.number()))
        }
        return out
    }
}
