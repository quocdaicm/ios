// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Bố cục gói khởi tạo sau xác thực (port từ WristInitialization.java).
/// Việc dựng gói KHÔNG có nghĩa là người dùng đã đồng ý các điều khoản.
enum WristInitialization {
    static let optionalWaitMs: Int64 = 1500
    static let agreementVersion = "20230508-20230508-0-0"
    static let agreementMessage =
        "Bước này sẽ khai báo với đồng hồ rằng bạn chấp nhận ba điều khoản: tuyên bố dịch vụ cập nhật phần mềm, quản lý thông tin thiết bị, và thỏa thuận người dùng.\n\n"
        + "Trường phiên bản điều khoản là \(agreementVersion). Ứng dụng này không có toàn văn điều khoản và sẽ không tự đồng ý thay bạn. "
        + "Chỉ chọn gửi khi bạn đã đọc và đồng ý ở kênh chính thức; nếu không hãy chọn bỏ qua. "
        + "Bỏ qua sẽ không gửi 01/30 và không xoá ghép nối hay khoá."

    static func emptyTags(_ tags: [Int]) throws -> [UInt8] {
        var out: [UInt8] = []
        for t in tags { out += try WMCore.tlv(t, []) }
        return out
    }

    /// 16 trường rỗng (đã gồm phiên bản phần mềm 07); phản hồi sản phẩm chỉ là thông tin phụ.
    static func productRequest() throws -> [UInt8] {
        try emptyTags([1, 2, 7, 9, 10, 17, 18, 22, 26, 29, 30, 31, 32, 33, 34, 35])
    }

    static func productFirmware(_ fields: [TlvView.Part]) throws -> String? {
        try DeviceInfo.firmware(fields)
    }

    /// Giây UTC dạng big-endian 32 bit, rồi giờ (có dấu qua bit 128) và phút lẻ.
    static func timeRequest(utcMillis: Int64, offsetMillis: Int) throws -> [UInt8] {
        if offsetMillis < -86_400_000 || offsetMillis > 86_400_000 { throw WMFault("TIME_ZONE_RANGE") }
        let seconds = offsetMillis / 1000
        let hours = seconds < 0 ? -seconds / 3600 + 128 : seconds / 3600
        let minutes = seconds / 60 % 60
        let utc = UInt32(truncatingIfNeeded: utcMillis / 1000)
        let be: [UInt8] = [UInt8(truncatingIfNeeded: utc >> 24), UInt8(truncatingIfNeeded: utc >> 16),
                           UInt8(truncatingIfNeeded: utc >> 8), UInt8(truncatingIfNeeded: utc)]
        let zone: [UInt8] = [UInt8(truncatingIfNeeded: hours), UInt8(truncatingIfNeeded: minutes)]
        return try WMCore.tlv(1, be) + WMCore.tlv(2, zone)
    }

    static func settingsRequest() throws -> [UInt8] { try emptyTags([1, 2, 3, 4, 5, 6]) }

    /// Nhánh khai báo khả năng ngược; bảng lệnh gốc không có 3F nên luồng thường bỏ qua.
    static func reverseRequest() throws -> [UInt8] { try WMCore.tlv(1, [0xfd, 0xf7, 0x73, 0x7a]) }

    /// Bên gọi phải có sự đồng ý rõ ràng gắn với kết nối hiện tại trước khi dựng gói này.
    static func agreementsRequest(millis: Int64) throws -> [UInt8] {
        var rows: [UInt8] = []
        for name in ["software_update_service_statement", "device_information_management", "user_license_agreement"] {
            var row: [UInt8] = []
            row += try WMCore.tlv(3, Array(name.utf8))
            row += try WMCore.tlv(4, [1])
            row += try WMCore.tlv(5, Array(agreementVersion.utf8))
            row += try WMCore.tlv(6, Array(String(millis).utf8))
            rows += try WMCore.tlv(0x82, row)
        }
        return try WMCore.tlv(0x81, rows)
    }

    private static func isControl(_ s: Unicode.Scalar) -> Bool {
        s.value < 0x20 || (s.value >= 0x7f && s.value <= 0x9f)
    }

    static func boundedDeviceName(_ name: String?) throws -> String {
        let trimmed = (name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let s = trimmed.isEmpty ? "HUAWEI Watch" : trimmed
        if s.utf8.count > 128 { throw WMFault("DEVICE_NAME_SIZE") }
        for u in s.unicodeScalars where isControl(u) { throw WMFault("DEVICE_NAME_CONTROL") }
        return s
    }

    private static func optionalText(_ fields: [TlvView.Part], _ tag: Int) throws -> String? {
        guard let f = try Wire.unique(fields, tag), !f.value.isEmpty else { return nil }
        if f.value.count > 129 { throw WMFault("PRODUCT_NAME_SIZE") }
        var end = f.value.count
        if f.value[end - 1] == 0 { end -= 1 }
        let text = try WMCore.utf8(Array(f.value[0..<end]))
        if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return nil }
        return try boundedDeviceName(text)
    }

    /// Ưu tiên tên thiết bị 11 không rỗng, rồi model 0A; không ghi số seri hay tài khoản.
    static func productName(_ fields: [TlvView.Part], fallback: String) throws -> String {
        if let n = try optionalText(fields, 0x11) { return n }
        if let n = try optionalText(fields, 0x0a) { return n }
        return try boundedDeviceName(fallback)
    }

    static func setupRequest(deviceName: String) throws -> [UInt8] {
        var out: [UInt8] = []
        out += try WMCore.tlv(1, [1])
        out += try WMCore.tlv(2, Array(boundedDeviceName(deviceName).utf8))
        out += try WMCore.tlv(3, [0])
        return out
    }

    static func connectedRequest() throws -> [UInt8] { try WMCore.tlv(1, [1]) }
}
