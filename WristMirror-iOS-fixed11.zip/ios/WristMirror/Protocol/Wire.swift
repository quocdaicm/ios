// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Thân gói TLV gốc của Huawei Health: dựng yêu cầu, tách trường, đọc danh sách mặt đồng hồ.
enum Wire {
    static let maxNativePacketBytes = TlvView.maxBytes + 2
    private static let maxTextBytes = 32
    private static let maxTotalFaceFields = 4096

    /// Thân 0x27/0x03 (thay/cài): id, version, op=1.
    static func operation(id: String, version: String) throws -> [UInt8] {
        try WMCore.resource(id, version)
        return try WMCore.tlv(1, Array(id.utf8)) + WMCore.tlv(2, Array(version.utf8)) + WMCore.tlv(3, [1])
    }

    /// Xoá: dùng đúng phiên bản đã cài, op=2, không tải file.
    static func deletion(id: String, version: String) throws -> [UInt8] {
        try WMCore.resource(id, version)
        return try WMCore.tlv(1, Array(id.utf8)) + WMCore.tlv(2, Array(version.utf8)) + WMCore.tlv(3, [2])
    }

    /// Thân 0x27/0x01.
    static func params() throws -> [UInt8] {
        var out: [UInt8] = []
        for tag in [1, 2, 3, 4, 5, 0x14, 0x15] { out += try WMCore.tlv(tag, []) }
        return out
    }

    /// Thân 0x27/0x02; giữ đúng serverMode (kể cả 2).
    static func list(serverMode: Int) throws -> [UInt8] {
        if serverMode < 1 || serverMode > 3 { throw WMFault("LIST_SERVER_MODE_INVALID") }
        return try WMCore.tlv(1, []) + WMCore.tlv(6, [UInt8(serverMode)])
    }

    /// Gói gốc phải bắt đầu đúng bằng 2 byte service + command.
    static func fields(nativePacket: [UInt8]?, service: Int, command: Int) throws -> [TlvView.Part] {
        if service < 0 || service > 255 || command < 0 || command > 255 {
            throw WMFault("WIRE_SERVICE_COMMAND_INVALID")
        }
        guard let p = nativePacket, p.count >= 2 else { throw WMFault("WIRE_PACKET_TRUNCATED") }
        if p.count > maxNativePacketBytes { throw WMFault("WIRE_PACKET_BYTES_LIMIT") }
        if Int(p[0]) != service || Int(p[1]) != command { throw WMFault("WIRE_PACKET_HEADER_MISMATCH") }
        return try TlvView.decode(Array(p[2...]))
    }

    /// Thiếu trường → nil; trùng tag → báo lỗi.
    static func unique(_ fields: [TlvView.Part], _ tag: Int) throws -> TlvView.Part? {
        if tag < 0 || tag > 255 { throw WMFault("WIRE_TAG_INVALID") }
        try validateParts(fields)
        var found: TlvView.Part? = nil
        for f in fields where f.tag == tag {
            if found != nil { throw WMFault("WIRE_DUPLICATE_TAG") }
            found = f
        }
        return found
    }

    static func text(_ fields: [TlvView.Part], _ tag: Int) throws -> String? {
        guard let f = try unique(fields, tag) else { return nil }
        if f.value.isEmpty || f.value.count > maxTextBytes { throw WMFault("WIRE_TEXT_LENGTH_INVALID") }
        return try WMCore.utf8(f.value)
    }

    static func number(_ fields: [TlvView.Part], _ tag: Int) throws -> Int64? {
        guard let f = try unique(fields, tag) else { return nil }
        return try WMCore.number(f.value)
    }

    /// root 0x81 → các mục 0x82 → 03/04/05 (+07). Thiếu root ≠ danh sách rỗng.
    static func faces(_ fields: [TlvView.Part]) throws -> [TlvView.Face] {
        guard let root = try unique(fields, 0x81) else { throw WMFault("WIRE_FACE_LIST_ROOT_MISSING") }
        let budget = Budget()
        try budget.initial(fields)
        let entries = try budget.decode(root.value)
        var out: [TlvView.Face] = []
        for entry in entries where entry.tag == 0x82 {
            let data = try budget.decode(entry.value)
            let id = try text(data, 3)
            let ver = try text(data, 4)
            let type = try number(data, 5)
            let expand = try number(data, 7)
            guard let i = id, let v = ver, let t = type else { throw WMFault("WIRE_FACE_REQUIRED_FIELD_MISSING") }
            out.append(TlvView.Face(id: i, version: v, type: t, expandType: expand))
        }
        return out
    }

    private static func validateParts(_ fields: [TlvView.Part]) throws {
        if fields.count > TlvView.maxFields { throw WMFault("WIRE_FIELDS_LIMIT") }
        var bytes = 0
        for f in fields {
            if f.tag < 0 || f.tag > 255 { throw WMFault("WIRE_FIELD_INVALID") }
            bytes += f.value.count
            if bytes > TlvView.maxBytes { throw WMFault("WIRE_FIELDS_BYTES_LIMIT") }
        }
    }

    private final class Budget {
        var nodesLeft = Wire.maxTotalFaceFields
        var bytesLeft = TlvView.maxBytes * TlvView.maxDepth
        func initial(_ fields: [TlvView.Part]) throws {
            try takeNodes(fields.count)
            for f in fields { try takeBytes(f.value.count) }
        }
        func decode(_ bytes: [UInt8]) throws -> [TlvView.Part] {
            if bytes.count > TlvView.maxBytes { throw WMFault("TLV_VIEW_BYTES_LIMIT") }
            try takeBytes(bytes.count)
            let d = try TlvView.decode(bytes)
            try takeNodes(d.count)
            return d
        }
        func takeNodes(_ n: Int) throws {
            if n > nodesLeft { throw WMFault("WIRE_TOTAL_FIELDS_LIMIT") }
            nodesLeft -= n
        }
        func takeBytes(_ n: Int) throws {
            if n > bytesLeft { throw WMFault("WIRE_TOTAL_BYTES_LIMIT") }
            bytesLeft -= n
        }
    }
}
