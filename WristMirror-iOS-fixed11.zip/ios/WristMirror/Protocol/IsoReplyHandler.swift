// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Định tuyến gói trả lời 01/28, tách khỏi nội dung JSON và bằng chứng mật mã.
/// Bên gọi phải gắn với đúng kết nối hiện tại và lưu learnedSecret trước khi gửi bước kế tiếp.
enum IsoReplyHandler {
    enum Kind { case nextRequest, controlCompletion, peerRejected }

    struct Result {
        let kind: Kind
        let next: JSONObject?
        let candidate: [UInt8]?
        let peerCode: Int64?
    }

    static func apply(_ auth: IsoAuth?, _ fields: [TlvView.Part]) throws -> Result {
        guard let auth = auth else { throw WMFault("ISO_CONTEXT_MISSING") }
        // Đọc hết các trường ngữ nghĩa trước để tag trùng lặp không giả làm lỗi hay ACK.
        let json = try Wire.unique(fields, 1)
        let completion = try Wire.unique(fields, 4)
        let headerError = try Wire.number(fields, 0x7f)
        if let he = headerError, he != 0, he != 100000 {
            return Result(kind: .peerRejected, next: nil, candidate: nil, peerCode: he)
        }
        if let c = completion, c.value.count != 1 { throw WMFault("ISO_COMPLETION_MARKER_LENGTH") }
        if let c = completion, c.value[0] != 0 {
            if !auth.awaitingCompletion() { throw WMFault("ISO_COMPLETION_OUT_OF_STAGE") }
            // tag4 khác 0 = hoàn tất; tag1 lúc này không phải JSON, chỉ là metadata điều khiển.
            if let j = json, j.value.count > WMCore.maxAuth + 1 { throw WMFault("ISO_CONTROL_PAYLOAD_SIZE") }
            let candidate = try auth.acceptCompletion()
            return Result(kind: .controlCompletion, next: nil, candidate: candidate, peerCode: nil)
        }
        guard let j = json, !j.value.isEmpty else { throw WMFault("ISO_JSON_MISSING") }
        let peer = try AuthReplyJson.parseObject(j.value)
        return Result(kind: .nextRequest, next: try auth.handlePeer(peer), candidate: nil, peerCode: nil)
    }

    /// Chỉ mô tả cấu trúc/trạng thái, không lộ tài khoản, PIN, nonce, token hay nội dung JSON.
    static func describe(_ auth: IsoAuth?, _ fields: [TlvView.Part]) -> String {
        do {
            let json = try Wire.unique(fields, 1)
            let completion = try Wire.unique(fields, 4)
            let error = try Wire.number(fields, 0x7f)
            let marker: String
            if let c = completion { marker = c.value.count == 1 ? String(c.value[0]) : "invalid_length" } else { marker = "absent" }
            return "operation=\(auth?.operation ?? -1) expected_stage=\(auth?.expectedStage() ?? -1) completion_marker=\(marker) header_error=\(error.map(String.init) ?? "absent") " + AuthReplyJson.describe(json?.value)
        } catch {
            return "reply_metadata_invalid=true code=\(WMCore.code(error))"
        }
    }
}
