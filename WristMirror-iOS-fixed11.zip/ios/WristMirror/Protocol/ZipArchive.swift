// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import Compression

/// CRC-32 (IEEE) dùng cho kiểm tra thành viên ZIP.
struct CRC32 {
    private static let table: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }
    private(set) var value: UInt32 = 0xFFFFFFFF
    mutating func update(_ bytes: [UInt8], count: Int? = nil) {
        let n = count ?? bytes.count
        var c = value
        var i = 0
        while i < n {
            c = CRC32.table[Int((c ^ UInt32(bytes[i])) & 0xff)] ^ (c >> 8)
            i += 1
        }
        value = c
    }
    var checksum: UInt32 { value ^ 0xFFFFFFFF }
}

/// Bộ đọc ZIP tối thiểu, có giới hạn (thay `java.util.zip.ZipFile`).
/// Hỗ trợ: stored (0) và deflate (8), không mã hoá, không ZIP64. Chỉ đọc theo tên cố định, không bao giờ ghi theo đường dẫn trong ZIP.
final class ZipArchive {
    struct Entry {
        let name: String
        let method: UInt16
        let crc: UInt32
        let compressedSize: Int64
        let size: Int64
        let localOffset: Int64
        var isDirectory: Bool { name.hasSuffix("/") }
    }

    static let maxEntries = 12000
    private static let maxCentralDirectory: Int64 = 16 * 1024 * 1024

    let entries: [String: Entry]
    private let handle: FileHandle
    private let fileSize: Int64

    init(url: URL) throws {
        guard let h = try? FileHandle(forReadingFrom: url) else { throw WMFault("FILE_OPEN_FAILED") }
        handle = h
        let end: UInt64
        do { end = try h.seekToEnd() } catch { try? h.close(); throw WMFault("ZIP_INVALID") }
        fileSize = Int64(end)
        do {
            entries = try ZipArchive.readEntries(handle: h, fileSize: fileSize)
        } catch {
            try? h.close()
            throw error
        }
    }

    deinit { try? handle.close() }

    private static func u16(_ b: [UInt8], _ o: Int) -> Int { Int(b[o]) | Int(b[o + 1]) << 8 }
    private static func u32(_ b: [UInt8], _ o: Int) -> Int64 {
        Int64(b[o]) | Int64(b[o + 1]) << 8 | Int64(b[o + 2]) << 16 | Int64(b[o + 3]) << 24
    }

    private static func read(_ h: FileHandle, at offset: Int64, count: Int) throws -> [UInt8] {
        if count == 0 { return [] }
        do {
            try h.seek(toOffset: UInt64(offset))
            guard let d = try h.read(upToCount: count), d.count == count else { throw WMFault("ZIP_TRUNCATED") }
            return [UInt8](d)
        } catch let f as WMFault { throw f } catch { throw WMFault("ZIP_TRUNCATED") }
    }

    private static func readEntries(handle h: FileHandle, fileSize: Int64) throws -> [String: Entry] {
        if fileSize < 22 { throw WMFault("ZIP_INVALID") }
        let tailLen = Int(min(fileSize, 65557))
        let tail = try read(h, at: fileSize - Int64(tailLen), count: tailLen)
        var eocd = -1
        var i = tail.count - 22
        while i >= 0 {
            if tail[i] == 0x50 && tail[i + 1] == 0x4b && tail[i + 2] == 0x05 && tail[i + 3] == 0x06 { eocd = i; break }
            i -= 1
        }
        if eocd < 0 { throw WMFault("ZIP_INVALID") }
        let total = u16(tail, eocd + 10), cdSize = u32(tail, eocd + 12), cdOffset = u32(tail, eocd + 16)
        if total == 0xFFFF || cdSize == 0xFFFFFFFF || cdOffset == 0xFFFFFFFF { throw WMFault("ZIP64_UNSUPPORTED") }
        if total > maxEntries { throw WMFault("ZIP_ENTRY_LIMIT") }
        if cdSize > maxCentralDirectory || cdOffset + cdSize > fileSize { throw WMFault("ZIP_INVALID") }
        let cd = try read(h, at: cdOffset, count: Int(cdSize))
        var map: [String: Entry] = [:]
        var p = 0
        var count = 0
        while p < cd.count {
            if p + 46 > cd.count || u32(cd, p) != 0x02014b50 { throw WMFault("ZIP_INVALID") }
            count += 1
            if count > maxEntries { throw WMFault("ZIP_ENTRY_LIMIT") }
            let flags = u16(cd, p + 8), method = u16(cd, p + 10)
            let crc = u32(cd, p + 16), csize = u32(cd, p + 20), size = u32(cd, p + 24)
            let nameLen = u16(cd, p + 28), extraLen = u16(cd, p + 30), commentLen = u16(cd, p + 32)
            let offset = u32(cd, p + 42)
            if p + 46 + nameLen + extraLen + commentLen > cd.count { throw WMFault("ZIP_INVALID") }
            if (flags & 1) != 0 { throw WMFault("ZIP_ENCRYPTED") }
            if csize == 0xFFFFFFFF || size == 0xFFFFFFFF || offset == 0xFFFFFFFF { throw WMFault("ZIP64_UNSUPPORTED") }
            let nameBytes = Array(cd[(p + 46)..<(p + 46 + nameLen)])
            let name = String(bytes: nameBytes, encoding: .utf8) ?? String(bytes: nameBytes, encoding: .isoLatin1) ?? ""
            let e = Entry(name: name, method: UInt16(method), crc: UInt32(crc), compressedSize: csize, size: size, localOffset: offset)
            if map[name] != nil { throw WMFault("ZIP_DUPLICATE_ENTRY") }
            map[name] = e
            p += 46 + nameLen + extraLen + commentLen
        }
        return map
    }

    /// Vị trí dữ liệu thật của thành viên (sau local header).
    private func dataStart(_ e: Entry) throws -> Int64 {
        let header = try ZipArchive.read(handle, at: e.localOffset, count: 30)
        if ZipArchive.u32(header, 0) != 0x04034b50 { throw WMFault("ZIP_INVALID") }
        let start = e.localOffset + 30 + Int64(ZipArchive.u16(header, 26)) + Int64(ZipArchive.u16(header, 28))
        if start + e.compressedSize > fileSize { throw WMFault("ZIP_TRUNCATED") }
        return start
    }

    /// Giải nén có giới hạn: gọi `sink` với từng khối; trả (số byte, CRC). Ném nếu vượt `maxBytes` hoặc dữ liệu hỏng.
    func stream(_ e: Entry, maxBytes: Int64, sink: ([UInt8]) throws -> Void) throws -> (size: Int64, crc: UInt32) {
        if e.method != 0 && e.method != 8 { throw WMFault("ZIP_METHOD_UNSUPPORTED") }
        let start = try dataStart(e)
        try handle.seek(toOffset: UInt64(start))
        var crc = CRC32()
        var total: Int64 = 0
        func emit(_ chunk: [UInt8]) throws {
            if chunk.isEmpty { return }
            total += Int64(chunk.count)
            if total > maxBytes || total > e.size { throw WMFault("RESOURCE_SIZE_LIMIT") }
            crc.update(chunk)
            try sink(chunk)
        }
        var remaining = e.compressedSize
        if e.method == 0 {
            if e.compressedSize != e.size { throw WMFault("ZIP_INVALID") }
            while remaining > 0 {
                let want = Int(min(65536, remaining))
                guard let d = try? handle.read(upToCount: want), d.count == want else { throw WMFault("ZIP_TRUNCATED") }
                remaining -= Int64(want)
                try emit([UInt8](d))
            }
            return (total, crc.checksum)
        }
        // Deflate thô qua Compression (COMPRESSION_ZLIB = raw deflate).
        let dummy = UnsafeMutablePointer<UInt8>.allocate(capacity: 1)
        defer { dummy.deallocate() }
        var cs = compression_stream(dst_ptr: dummy, dst_size: 0, src_ptr: UnsafePointer(dummy), src_size: 0, state: nil)
        guard compression_stream_init(&cs, COMPRESSION_STREAM_DECODE, COMPRESSION_ZLIB) == COMPRESSION_STATUS_OK else {
            throw WMFault("ZIP_INFLATE_INIT_FAILED")
        }
        defer { compression_stream_destroy(&cs) }
        var out = [UInt8](repeating: 0, count: 65536)
        var ended = false
        while !ended {
            let want = Int(min(65536, remaining))
            var input: [UInt8] = []
            if want > 0 {
                guard let d = try? handle.read(upToCount: want), d.count == want else { throw WMFault("ZIP_TRUNCATED") }
                input = [UInt8](d)
                remaining -= Int64(want)
            }
            let isFinal = remaining == 0
            var failure: WMFault? = nil
            input.withUnsafeBufferPointer { ib in
                cs.src_ptr = ib.baseAddress ?? UnsafePointer(dummy)
                cs.src_size = ib.count
                var status = COMPRESSION_STATUS_OK
                repeat {
                    let cap = out.count
                    out.withUnsafeMutableBufferPointer { ob in
                        cs.dst_ptr = ob.baseAddress!
                        cs.dst_size = cap
                        status = compression_stream_process(&cs, isFinal ? Int32(COMPRESSION_STREAM_FINALIZE.rawValue) : 0)
                    }
                    let produced = cap - cs.dst_size
                    if status == COMPRESSION_STATUS_ERROR { failure = WMFault("ZIP_INFLATE_FAILED"); return }
                    if produced > 0 {
                        do { try emit(Array(out[0..<produced])) } catch let f as WMFault { failure = f; return } catch { failure = WMFault("ZIP_INFLATE_FAILED"); return }
                    }
                    if status == COMPRESSION_STATUS_END { ended = true; return }
                } while status == COMPRESSION_STATUS_OK && (cs.src_size > 0 || cs.dst_size == 0)
            }
            if let f = failure { throw f }
            if isFinal && !ended { throw WMFault("ZIP_INFLATE_TRUNCATED") }
        }
        return (total, crc.checksum)
    }

    /// Đọc cả thành viên vào bộ nhớ (giới hạn `max`), kiểm tra kích thước và CRC.
    func read(_ e: Entry, max: Int) throws -> [UInt8] {
        var data: [UInt8] = []
        let r = try stream(e, maxBytes: Int64(max)) { data += $0 }
        if r.size != e.size || r.crc != e.crc { throw WMFault("ZIP_CRC") }
        return data
    }

    /// Trích ra file; ghi nguyên byte; kiểm tra kích thước + CRC.
    func extract(_ e: Entry, to url: URL, maxBytes: Int64) throws {
        FileManager.default.createFile(atPath: url.path, contents: nil)
        guard let out = try? FileHandle(forWritingTo: url) else { throw WMFault("FILE_OPEN_FAILED") }
        defer { try? out.close() }
        let r = try stream(e, maxBytes: maxBytes) { chunk in
            do { try out.write(contentsOf: chunk) } catch { throw WMFault("FILE_WRITE_FAILED") }
        }
        if r.size != e.size || r.crc != e.crc { throw WMFault("RESOURCE_CRC") }
    }
}
