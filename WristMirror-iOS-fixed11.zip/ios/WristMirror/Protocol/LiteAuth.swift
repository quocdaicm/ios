// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Đường xác thực Mode2 "Lite" (authMode == 2). Chế độ chưa biết không bao giờ được coi là đã xác thực.
final class LiteAuth {
    private var activeKey: [UInt8]
    private var bondCipherKey: [UInt8]
    private var expected: [UInt8]
    private var clientNonce: [UInt8]
    private let caps: LinkCapabilities

    init(caps: LinkCapabilities, pin: [UInt8]?, saved: [UInt8]?,
         random: (Int) -> [UInt8] = { WMRandom.bytes($0) }) throws {
        guard caps.authMode == 2, let serverNonce = caps.serverNonce, serverNonce.count == 16 else {
            throw WMFault("LITE_AUTH_MODE_OR_NONCE_UNSUPPORTED")
        }
        self.caps = caps
        let cn = random(16)
        clientNonce = cn
        let nonces = serverNonce + cn
        let key = saved ?? random(16)
        activeKey = key
        if key.count != 16 && caps.authVersion == 2 { throw WMFault("LITE_AUTH_SAVED_KEY_LENGTH") }
        if caps.authVersion == 2 {
            bondCipherKey = key
            expected = try HuaweiCrypto.hmac(key + [1, 16], nonces)
        } else {
            guard let pin = pin, !pin.isEmpty else { throw WMFault("PIN_REQUIRED") }
            let p = try HuaweiCrypto.pinBase(pin)
            let magic = HuaweiCrypto.pinMagic(caps.authVersion)
            let root = (0..<16).map { p[$0] ^ magic[$0] }
            let a = try LiteAuth.derive(caps, root + [1, 0], nonces)
            let b = try LiteAuth.derive(caps, root + [1, 16], nonces)
            bondCipherKey = Array(a[0..<16])
            expected = try HuaweiCrypto.hmac(b, nonces)
        }
    }

    private static func derive(_ caps: LinkCapabilities, _ root: [UInt8], _ nonces: [UInt8]) throws -> [UInt8] {
        if caps.authAlgorithm != 1 { return try HuaweiCrypto.hmac(root, nonces) }
        let password = WMCore.hex(root).uppercased()
        let salt = Array(WMCore.hex(nonces).uppercased().utf8)
        return try AESPrimitives.pbkdf2(password: password, salt: salt, iterations: 1000, outLength: 32)
    }

    func requestBody(pin: [UInt8]?) throws -> [UInt8] {
        guard let serverNonce = caps.serverNonce else { throw WMFault("LITE_AUTH_MODE_OR_NONCE_UNSUPPORTED") }
        let n = serverNonce + clientNonce
        let challenge: [UInt8]
        if caps.authVersion == 2 {
            challenge = try HuaweiCrypto.hmac(activeKey + [1, 0], n)
        } else {
            guard let pin = pin else { throw WMFault("PIN_REQUIRED") }
            let p = try HuaweiCrypto.pinBase(pin)
            let magic = HuaweiCrypto.pinMagic(caps.authVersion)
            let root = (0..<16).map { p[$0] ^ magic[$0] }
            let d = try LiteAuth.derive(caps, root + [1, 0], n)
            challenge = try HuaweiCrypto.hmac(d, n)
        }
        let ver = [UInt8((caps.authVersion >> 8) & 0xff), UInt8(caps.authVersion & 0xff)]
        return try WMCore.tlv(1, challenge) + WMCore.tlv(2, ver + clientNonce)
            + WMCore.tlv(3, [UInt8(caps.authAlgorithm & 0xff)])
    }

    func validate(_ body: [UInt8]) throws {
        let f = try Wire.unique(TlvView.decode(body), 1)
        guard let v = f, HuaweiCrypto.constantTimeEquals(expected, v.value) else {
            throw WMFault("LITE_AUTH_TOKEN_MISMATCH")
        }
    }

    func savedActiveKey() -> [UInt8] { activeKey }
    func cipherKey() -> [UInt8] { bondCipherKey }

    func close() {
        activeKey = [UInt8](repeating: 0, count: activeKey.count)
        bondCipherKey = [UInt8](repeating: 0, count: bondCipherKey.count)
        expected = [UInt8](repeating: 0, count: expected.count)
        clientNonce = [UInt8](repeating: 0, count: clientNonce.count)
    }
}
