// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Chọn phiên bản ứng viên cục bộ (port từ VersionPolicy.java). Không gửi dữ liệu, không cấp quyền tải.
enum VersionPolicy {
    private static let maxVersionLength = 10

    /// Chỉ cộng 1 vào trường thập phân CUỐI của `baseline`; giữ nguyên số 0 đứng đầu, không nhớ sang tiền tố.
    static func next(id: String, baseline: String, listed: [TlvView.Face]?) throws -> String {
        try WMCore.resource(id, baseline)
        let candidate = incrementTail(baseline)
        if candidate.count > maxVersionLength { throw WMFault("VERSION_INCREMENT_OVERFLOW") }
        try WMCore.resource(id, candidate)

        guard let listed = listed else { throw WMFault("VERSION_LIST_REQUIRED") }
        if listed.count > TlvView.maxFields { throw WMFault("VERSION_LIST_LIMIT") }
        var baselineMatches = 0
        for face in listed {
            if face.id != id { continue }
            if face.version == candidate { throw WMFault("VERSION_CANDIDATE_ALREADY_LISTED") }
            if face.version == baseline { baselineMatches += 1 }
        }
        if baselineMatches == 0 { throw WMFault("VERSION_BASELINE_NOT_LISTED") }
        if baselineMatches != 1 { throw WMFault("VERSION_BASELINE_AMBIGUOUS") }
        return candidate
    }

    private static func incrementTail(_ version: String) -> String {
        var chars = Array(version.utf8)
        var start = 0
        if let dot = chars.lastIndex(of: UInt8(ascii: ".")) { start = dot + 1 }
        var i = chars.count - 1
        while i >= start {
            if chars[i] < UInt8(ascii: "9") {
                chars[i] += 1
                return String(decoding: chars, as: UTF8.self)
            }
            chars[i] = UInt8(ascii: "0")
            i -= 1
        }
        chars.insert(UInt8(ascii: "1"), at: start)
        return String(decoding: chars, as: UTF8.self)
    }
}
