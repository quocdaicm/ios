// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Bóc phong bì byte của HiChain, tách khỏi bộ phân tích JSON nghiêm ngặt.
/// Chỉ chấp nhận một NUL kiểu C ở cuối; không BOM, không NUL bên trong.
enum AuthReplyJson {
    private static func ws(_ c: UInt8) -> Bool { c == 0x20 || c == 0x09 || c == 0x0a || c == 0x0d }

    static func normalize(_ input: [UInt8]?) throws -> [UInt8] {
        guard let input = input, !input.isEmpty, input.count <= WMCore.maxAuth + 1 else {
            throw WMFault("ISO_JSON_BYTES_INVALID")
        }
        var start = 0
        var end = input.count
        // GT 6 Pro (HarmonyOS 6.x) gửi JSON hợp lệ kèm byte thừa sau '}' cuối (HuaSideload đã xác nhận bằng log thật).
        // Nếu gốc là object, cắt mọi thứ sau '}' cuối cùng; bản gốc chỉ chấp nhận đúng một NUL ở cuối.
        // An toàn vì HiChain vẫn xác thực bằng MAC/khoá ở các bước sau, không dựa vào hình dạng JSON.
        var firstIdx = 0
        while firstIdx < end && ws(input[firstIdx]) { firstIdx += 1 }
        if firstIdx < end && input[firstIdx] == UInt8(ascii: "{"), let brace = input.lastIndex(of: 0x7D), brace + 1 < end {
            end = brace + 1
        } else if end > start && input[end - 1] == 0 { end -= 1 }
        for i in start..<end where input[i] == 0 { throw WMFault("ISO_JSON_EMBEDDED_OR_MULTIPLE_NUL") }
        while start < end && ws(input[start]) { start += 1 }
        while end > start && ws(input[end - 1]) { end -= 1 }
        if start == end { throw WMFault("ISO_JSON_EMPTY_AFTER_ENVELOPE") }
        if end - start > WMCore.maxAuth { throw WMFault("ISO_JSON_SIZE_LIMIT") }
        return Array(input[start..<end])
    }

    static func parseObject(_ input: [UInt8]?) throws -> JSONObject {
        try MiniJson.parseObject(normalize(input))
    }

    static func startsObject(_ input: [UInt8]?) throws -> Bool {
        let n = try normalize(input)
        return !n.isEmpty && n[0] == UInt8(ascii: "{")
    }

    /// Chỉ mô tả metadata, không lộ nội dung (PIN/token/tài khoản).
    static func describe(_ input: [UInt8]?) -> String {
        guard let input = input else { return "json_present=false" }
        var start = (input.count >= 3 && input[0] == 0xef && input[1] == 0xbb && input[2] == 0xbf) ? 3 : 0
        let bom = start == 3
        var leading = 0
        while start < input.count && ws(input[start]) { start += 1; leading += 1 }
        var shape = "EMPTY"
        if start < input.count {
            let c = input[start]
            switch c {
            case UInt8(ascii: "{"): shape = "OBJECT"
            case UInt8(ascii: "["): shape = "ARRAY"
            case UInt8(ascii: "\""): shape = "STRING"
            case UInt8(ascii: "-"), UInt8(ascii: "0")...UInt8(ascii: "9"): shape = "NUMBER"
            case UInt8(ascii: "t"), UInt8(ascii: "f"): shape = "BOOLEAN"
            case UInt8(ascii: "n"): shape = "NULL"
            default: shape = "OTHER"
            }
        }
        var trailingNul = 0
        var i = input.count - 1
        while i >= 0 && input[i] == 0 { trailingNul += 1; i -= 1 }
        var tail = input.count - trailingNul
        var trailingSpace = 0
        while tail > 0 && ws(input[tail - 1]) { tail -= 1; trailingSpace += 1 }
        return "json_present=true bytes=\(input.count) root_shape=\(shape) utf8_bom=\(bom) leading_ws=\(leading) trailing_ws=\(trailingSpace) terminal_nuls=\(trailingNul)"
    }
}
