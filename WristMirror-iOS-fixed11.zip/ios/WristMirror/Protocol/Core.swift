// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import CryptoKit

/// Tiện ích byte dùng chung (port từ Core.java). Không chứa khoá ký hay mã của hãng.
enum WMCore {
    static let maxSource: Int64 = 160 * 1024 * 1024
    static let maxMember: Int64 = 128 * 1024 * 1024
    static let maxAuth = 32768
    static let maxChunk = 4 * 1024 * 1024

    static func code(_ e: Error) -> String {
        (e as? WMFault)?.code ?? String(describing: type(of: e))
    }

    static func digest(_ b: [UInt8]) -> [UInt8] {
        [UInt8](SHA256.hash(data: Data(b)))
    }

    static func digest(file url: URL) throws -> [UInt8] {
        guard let h = try? FileHandle(forReadingFrom: url) else { throw WMFault("FILE_OPEN_FAILED") }
        defer { try? h.close() }
        var sha = SHA256()
        while true {
            guard let d = try? h.read(upToCount: 65536), !d.isEmpty else { break }
            sha.update(data: d)
        }
        return [UInt8](sha.finalize())
    }

    static func hex(_ b: [UInt8]) -> String {
        let alphabet = Array("0123456789abcdef")
        var out = ""
        out.reserveCapacity(b.count * 2)
        for x in b { out.append(alphabet[Int(x >> 4)]); out.append(alphabet[Int(x & 15)]) }
        return out
    }

    static func unhex(_ s: String?) throws -> [UInt8] {
        guard let s = s, s.utf8.count % 2 == 0 else { throw WMFault("HEX_INVALID") }
        let u = Array(s.utf8)
        var out: [UInt8] = []
        out.reserveCapacity(u.count / 2)
        func v(_ c: UInt8) -> UInt8? {
            switch c {
            case 48...57: return c - 48
            case 97...102: return c - 87
            case 65...70: return c - 55
            default: return nil
            }
        }
        var i = 0
        while i < u.count {
            guard let a = v(u[i]), let b = v(u[i + 1]) else { throw WMFault("HEX_INVALID") }
            out.append(a << 4 | b)
            i += 2
        }
        return out
    }

    /// UTF-8 nghiêm ngặt: byte hỏng thì báo lỗi, không thay thế.
    static func utf8(_ b: [UInt8]) throws -> String {
        guard let s = String(bytes: b, encoding: .utf8) else { throw WMFault("INVALID_UTF8") }
        return s
    }

    private static func matches(_ s: String, _ pattern: String) -> Bool {
        s.range(of: "^(?:" + pattern + ")$", options: .regularExpression) != nil
    }

    static func resource(_ id: String?, _ version: String?) throws {
        guard let id = id, matches(id, "[0-9]{1,11}") else { throw WMFault("RESOURCE_ID_REQUIRED") }
        guard let v = version, v.count <= 10, matches(v, "[0-9]+(?:\\.[0-9]+){1,3}") else {
            throw WMFault("RESOURCE_VERSION_INVALID")
        }
    }

    static func number(_ b: [UInt8]?) throws -> Int64 {
        guard let b = b, b.count >= 1, b.count <= 4 else { throw WMFault("NUMERIC_TLV_LENGTH") }
        var n: Int64 = 0
        for x in b { n = (n << 8) | Int64(x) }
        return n
    }

    /// Số nguyên biến độ dài 7 bit, nhóm cao đứng trước (KHÔNG phải LEB128 của protobuf).
    static func length(_ value: Int) throws -> [UInt8] {
        if value < 0 { throw WMFault("NEGATIVE_LENGTH") }
        var groups = 1
        var x = value
        while true { x >>= 7; if x == 0 { break }; groups += 1 }
        var b = [UInt8](repeating: 0, count: groups)
        var n = value
        var i = groups - 1
        while i >= 0 {
            b[i] = UInt8(n & 127)
            if i < groups - 1 { b[i] |= 128 }
            n >>= 7
            i -= 1
        }
        return b
    }

    static func tlv(_ tag: Int, _ value: [UInt8]) throws -> [UInt8] {
        [UInt8(tag & 0xff)] + (try length(value.count)) + value
    }

    static func clean(_ s: String?) -> String {
        guard let s = s else { return "unknown" }
        return s.replacingOccurrences(of: "\r", with: " ").replacingOccurrences(of: "\n", with: " ")
    }

    static func firmware(_ s: String?) -> String {
        if let s = s, s.count <= 80, matches(s, "[0-9][0-9A-Za-z.() _-]*") { return s }
        return "unknown"
    }

    static func chunkValid(offset: Int, count: Int, total: Int, unit: Int) -> Bool {
        offset >= 0 && count > 0 && count <= maxChunk && offset <= total && count <= total - offset
            && unit > 0 && unit <= maxChunk && (count + unit - 1) / unit <= 256
    }
}
