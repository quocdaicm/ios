// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Trường sản phẩm / pin / dung lượng nhạc đã được kiểm chứng (port từ DeviceTelemetry.java).
/// Không đoán RAM, dung lượng toàn cục hay khả năng theo model.
enum DeviceTelemetry {
    static let configService = 0x01
    static let productCommand = 0x07
    static let serialTag = 0x09
    static let batteryCommand = 0x08
    static let batteryTag = 0x01
    static let musicService = 0x25
    static let musicStorageCommand = 0x04
    static let musicFreeTag = 0x02
    static let mib: Int64 = 1024 * 1024
    /// Giới hạn phòng thủ khi hiển thị, không khẳng định giao thức quy định độ dài số seri.
    static let maxSerialBytes = 128

    /// Mỗi lần chỉ mang các trường thực sự quan sát được; nil KHÔNG phải giá trị xoá hay thành công.
    struct Stats {
        let serialNumber: String?
        let batteryPercent: Int?
        let freeMemoryBytes: Int64?
        var hasObservedFields: Bool { serialNumber != nil || batteryPercent != nil || freeMemoryBytes != nil }
    }

    static func matches(_ service: Int, _ command: Int) -> Bool {
        (service == configService && (command == productCommand || command == batteryCommand))
            || (service == musicService && command == musicStorageCommand)
    }

    static func musicStorageRequest() throws -> [UInt8] {
        var out: [UInt8] = []
        for t in [1, 2, 3] { out += try WMCore.tlv(t, []) }
        return out
    }

    static func parse(_ service: Int, _ command: Int, plain: [UInt8]) throws -> Stats {
        if !matches(service, command) { throw WMFault("DEVICE_STATS_HEADER_MISMATCH") }
        return try parse(service, command, try TlvView.decode(plain))
    }

    static func parse(_ service: Int, _ command: Int, _ fields: [TlvView.Part]) throws -> Stats {
        if service == configService && command == productCommand {
            return Stats(serialNumber: try serialNumber(fields), batteryPercent: nil, freeMemoryBytes: nil)
        }
        if service == configService && command == batteryCommand {
            return Stats(serialNumber: nil, batteryPercent: try batteryPercent(fields), freeMemoryBytes: nil)
        }
        if service == musicService && command == musicStorageCommand {
            return Stats(serialNumber: nil, batteryPercent: nil, freeMemoryBytes: try musicFreeMemoryBytes(fields))
        }
        throw WMFault("DEVICE_STATS_HEADER_MISMATCH")
    }

    private static func isControl(_ s: Unicode.Scalar) -> Bool {
        s.value < 0x20 || (s.value >= 0x7f && s.value <= 0x9f)
    }

    /// UTF-8 số seri (tag 09): chỉ bỏ một NUL cuối và khoảng trắng hai đầu.
    static func serialNumber(_ fields: [TlvView.Part]) throws -> String? {
        try checkHeader(fields)
        guard let field = try Wire.unique(fields, serialTag), !field.value.isEmpty else { return nil }
        if field.value.count > maxSerialBytes + 1 { throw WMFault("PRODUCT_SERIAL_SIZE") }
        var end = field.value.count
        if field.value[end - 1] == 0 { end -= 1 }
        if end > maxSerialBytes { throw WMFault("PRODUCT_SERIAL_SIZE") }
        if end == 0 { return nil }
        let text = try WMCore.utf8(Array(field.value[0..<end]))
        for u in text.unicodeScalars where isControl(u) { throw WMFault("PRODUCT_SERIAL_CONTROL") }
        let serial = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return serial.isEmpty ? nil : serial
    }

    /// Cùng kiểm tra có giới hạn cho số seri đã giải mã / lưu cục bộ; giá trị giữ chỗ không tính là seri.
    static func serialText(_ text: String?) throws -> String? {
        guard let text = text else { return nil }
        if text.utf8.count > maxSerialBytes { throw WMFault("PRODUCT_SERIAL_SIZE") }
        for u in text.unicodeScalars where isControl(u) { throw WMFault("PRODUCT_SERIAL_CONTROL") }
        let serial = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = serial.lowercased()
        if serial.isEmpty || lower == "unknown" || serial == "未知" || serial == "未知序列号"
            || lower == "null" || lower == "n/a" { return nil }
        return serial
    }

    /// Pin: byte đầu của trường 01 không rỗng, phạm vi 0...100.
    static func batteryPercent(_ fields: [TlvView.Part]) throws -> Int? {
        try checkHeader(fields)
        guard let field = try Wire.unique(fields, batteryTag), !field.value.isEmpty else { return nil }
        let percent = Int(field.value[0])
        if percent > 100 { throw WMFault("BATTERY_PERCENT_RANGE") }
        return percent
    }

    /// 25/04 trường 02 là dung lượng nhạc còn trống theo cách app gốc quy đổi hiển thị
    /// (raw<=0: không rõ; raw<=2^20: coi như MB; lớn hơn: floor(raw/2^20) MB), KHÔNG phải số byte chính xác.
    static func musicFreeMemoryBytes(_ fields: [TlvView.Part]) throws -> Int64? {
        try checkHeader(fields)
        guard let field = try Wire.unique(fields, musicFreeTag), !field.value.isEmpty else { return nil }
        let raw = try WMCore.number(field.value)
        if raw > Int64(Int32.max) { throw WMFault("MUSIC_STORAGE_RANGE") }
        if raw == 0 { return nil }
        let displayMb = raw <= mib ? raw : max(1, raw / mib)
        return displayMb * mib
    }

    private static func checkHeader(_ fields: [TlvView.Part]) throws {
        if let e = try Wire.number(fields, 0x7f), e != 0, e != 100000 { throw WMFault("DEVICE_STATS_REJECTED") }
    }

    /// Quyền sở hữu yêu cầu chỉ-đọc trong bộ nhớ cho đúng một lô kết nối. Không giữ READY/xác thực.
    final class ProbeOwner {
        let epoch: Int
        private var initializationClaimed = false, readyClaimed = false
        private var productPending = false, batteryPending = false, storagePending = false
        private var observed = Stats(serialNumber: nil, batteryPercent: nil, freeMemoryBytes: nil)
        private var delivered = Stats(serialNumber: nil, batteryPercent: nil, freeMemoryBytes: nil)

        init(epoch: Int) { self.epoch = epoch }

        func markInitializationRequests(_ current: Int) -> Bool {
            if current != epoch || initializationClaimed { return false }
            initializationClaimed = true
            productPending = true
            batteryPending = true
            return true
        }

        func batteryQueryClaimed(_ current: Int) -> Bool { current == epoch && initializationClaimed }

        func markReadyStorageRequest(_ current: Int, sessionVerified: Bool, ready: Bool, supported: Bool) -> Bool {
            if current != epoch || !sessionVerified || !ready || readyClaimed { return false }
            readyClaimed = true
            storagePending = supported
            return supported
        }

        func pending(_ current: Int, _ service: Int, _ command: Int) -> Bool {
            if current != epoch { return false }
            if service == DeviceTelemetry.configService && command == DeviceTelemetry.productCommand { return productPending }
            if service == DeviceTelemetry.configService && command == DeviceTelemetry.batteryCommand { return batteryPending }
            return service == DeviceTelemetry.musicService && command == DeviceTelemetry.musicStorageCommand && storagePending
        }

        func complete(_ current: Int, _ service: Int, _ command: Int) -> Bool {
            if !pending(current, service, command) { return false }
            if service == DeviceTelemetry.configService && command == DeviceTelemetry.productCommand { productPending = false }
            else if service == DeviceTelemetry.configService && command == DeviceTelemetry.batteryCommand { batteryPending = false }
            else { storagePending = false }
            return true
        }

        func observe(_ current: Int, _ update: Stats?) {
            guard current == epoch, let u = update else { return }
            observed = Stats(serialNumber: u.serialNumber ?? observed.serialNumber,
                             batteryPercent: u.batteryPercent ?? observed.batteryPercent,
                             freeMemoryBytes: u.freeMemoryBytes ?? observed.freeMemoryBytes)
        }

        /// Chỉ trả phần thay đổi so với lần đã giao; đánh dấu đã giao trước khi callback.
        func publication(_ current: Int, sessionVerified: Bool, ready: Bool) -> Stats? {
            if current != epoch || !sessionVerified || !ready { return nil }
            let delta = Stats(
                serialNumber: observed.serialNumber == delivered.serialNumber ? nil : observed.serialNumber,
                batteryPercent: observed.batteryPercent == delivered.batteryPercent ? nil : observed.batteryPercent,
                freeMemoryBytes: observed.freeMemoryBytes == delivered.freeMemoryBytes ? nil : observed.freeMemoryBytes)
            if !delta.hasObservedFields { return nil }
            delivered = observed
            return delta
        }
    }
}
