// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Xử lý thân TLV 27/06 (truy vấn tên mặt đồng hồ) – port từ WireNames.java.
/// Lệnh này không có version/nonce; chủ sở hữu phải tự gắn với thiết bị/yêu cầu/danh sách.
enum WireNames {
    static let languageOther = 1, languageChinese = 2
    static let maxNameBytes = 256, maxNameCharacters = 128
    static let maxRequestIds = (TlvView.maxFields - 2) / 2
    private static let maxIdTextBytes = 32

    /// Kết quả bất biến. `ids` gồm cả ID hợp lệ có tên rỗng/thiếu.
    struct Response {
        let names: [String: String]
        let orderedNames: [(String, String)]
        let ids: Set<String>
        /// Số tên hiển thị bị hỏng UTF-8 (không chứa nội dung tên).
        let malformedNameCount: Int
    }

    private static func validId(_ id: String?) -> Bool {
        (try? WMCore.resource(id, "0.0")) != nil
    }

    /// Chỉ tạo thân: 01/len1/language + 82/{83/{04/id}...}. Không có ID hợp lệ ⇒ mảng rỗng (bỏ qua gửi).
    static func request(faces: [TlvView.Face]?, language: Int) throws -> [UInt8] {
        if language != languageOther && language != languageChinese { throw WMFault("NAMES_LANGUAGE_INVALID") }
        guard let faces = faces, !faces.isEmpty else { return [] }
        if faces.count > TlvView.maxFields { throw WMFault("NAMES_REQUEST_FIELDS_LIMIT") }
        var ids: [String] = []
        var seen = Set<String>()
        for face in faces where validId(face.id) {
            if seen.insert(face.id).inserted {
                ids.append(face.id)
                if ids.count > maxRequestIds { throw WMFault("NAMES_REQUEST_IDS_LIMIT") }
            }
        }
        if ids.isEmpty { return [] }
        var entries: [UInt8] = []
        for id in ids {
            let item = try WMCore.tlv(4, Array(id.utf8))
            entries += try WMCore.tlv(0x83, item)
        }
        let out = try WMCore.tlv(1, [UInt8(language)]) + WMCore.tlv(0x82, entries)
        if out.count > TlvView.maxBytes { throw WMFault("NAMES_REQUEST_BYTES_LIMIT") }
        return out
    }

    static func parse(_ fields: [TlvView.Part]) throws -> [String: String] {
        try parseResponse(fields).names
    }

    /// Phân tích các trường 27/06 (đã kiểm tra header). Chỉ chấp nhận container (bit7 của tag) ở gốc và mục, không đệ quy.
    static func parseResponse(_ fields: [TlvView.Part]) throws -> Response {
        let budget = Budget()
        try budget.initial(fields)
        if let error = try unique(fields, 0x7f) {
            let code = try WMCore.number(error.value)
            if code != 0 && code != 100000 { throw WMFault("NAMES_DEVICE_ERROR_\(code)") }
        }
        var ordered: [(String, String)] = []
        var map: [String: String] = [:]
        var seenIds = Set<String>()
        var container = false
        var malformedNames = 0
        for root in fields {
            if (root.tag & 0x80) == 0 { continue }
            container = true
            for entry in try budget.decode(root.value) {
                if (entry.tag & 0x80) == 0 { continue }
                let data = try budget.decode(entry.value)
                let idField = try unique(data, 4), nameField = try unique(data, 5)
                var id: String? = nil
                var name: String? = nil
                if let f = idField, !f.value.isEmpty {
                    if f.value.count > maxIdTextBytes { throw WMFault("NAMES_ID_BYTES_LIMIT") }
                    id = try WMCore.utf8(f.value)
                }
                if let f = nameField {
                    if f.value.count > maxNameBytes { throw WMFault("NAMES_NAME_BYTES_LIMIT") }
                    do {
                        name = try WMCore.utf8(f.value)
                    } catch let e as WMFault {
                        if e.code != "INVALID_UTF8" { throw e }
                        malformedNames += 1
                    }
                    if let n = name, n.unicodeScalars.count > maxNameCharacters {
                        throw WMFault("NAMES_NAME_CHARACTER_LIMIT")
                    }
                }
                guard let validatedId = id, validId(validatedId) else { continue }
                if !seenIds.insert(validatedId).inserted { throw WMFault("NAMES_DUPLICATE_ID") }
                guard let n = name, hasVisibleText(n) else { continue }
                ordered.append((validatedId, n))
                map[validatedId] = n
            }
        }
        if !container { throw WMFault("NAMES_RESPONSE_CONTAINER_MISSING") }
        return Response(names: map, orderedNames: ordered, ids: seenIds, malformedNameCount: malformedNames)
    }

    private static func hasVisibleText(_ name: String) -> Bool {
        for scalar in name.unicodeScalars {
            let p = scalar.properties
            if !p.isWhitespace && p.generalCategory != .spaceSeparator && p.generalCategory != .control { return true }
        }
        return false
    }

    private static func unique(_ fields: [TlvView.Part], _ tag: Int) throws -> TlvView.Part? {
        var found: TlvView.Part? = nil
        for p in fields where p.tag == tag {
            if found != nil { throw WMFault("NAMES_DUPLICATE_TAG") }
            found = p
        }
        return found
    }

    private final class Budget {
        var nodes = TlvView.maxFields
        var bytes = TlvView.maxBytes * TlvView.maxDepth
        func takeNodes(_ n: Int) throws {
            if n > nodes { throw WMFault("NAMES_TOTAL_FIELDS_LIMIT") }
            nodes -= n
        }
        func takeBytes(_ n: Int) throws {
            if n > bytes { throw WMFault("NAMES_TOTAL_BYTES_LIMIT") }
            bytes -= n
        }
        func initial(_ fields: [TlvView.Part]) throws {
            if fields.count > TlvView.maxFields { throw WMFault("NAMES_FIELDS_LIMIT") }
            try takeNodes(fields.count)
            var encoded = 0
            for p in fields {
                if p.tag < 0 || p.tag > 255 { throw WMFault("NAMES_FIELD_INVALID") }
                let lengthBytes = try WMCore.length(p.value.count)
                encoded += 1 + lengthBytes.count + p.value.count
                if encoded > TlvView.maxBytes { throw WMFault("NAMES_FIELDS_BYTES_LIMIT") }
                try takeBytes(p.value.count)
            }
        }
        func decode(_ value: [UInt8]) throws -> [TlvView.Part] {
            try takeBytes(value.count)
            let f = try TlvView.decode(value)
            try takeNodes(f.count)
            return f
        }
    }
}
