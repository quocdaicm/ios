// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import CoreBluetooth

/// Quét BLE do người dùng chủ động bật, có giới hạn thời gian (port từ WatchScanner.java).
/// iOS không có Bluetooth Classic cho app thường và không lộ MAC: mỗi thiết bị được nhận diện bằng
/// `CBPeripheral.identifier` (UUID). Không thay đổi quan hệ ghép nối của hệ thống.
/// Mọi callback chạy trên main queue.
final class WatchScanner: NSObject, CBCentralManagerDelegate {
    struct Item {
        /// UUID của CBPeripheral (viết hoa) — dùng làm khoá thiết bị ở toàn bộ app.
        let id: String
        let name: String
        let rssi: Int?
        /// Đang kết nối với hệ thống / quảng bá service FE86.
        let advertisesHuaweiService: Bool
    }

    private static let serviceUUID = CBUUID(string: "FE86")
    private static let scanSeconds = 12.0
    private static let keywords = ["huawei", "honor", "watch", "华为", "荣耀"]

    private var central: CBCentralManager?
    private var onItems: (([Item]) -> Void)?
    private var onStopped: ((String) -> Void)?
    private var order: [String] = []
    private var items: [String: Item] = [:]
    private var active = false
    private var scanning = false
    private var serial = 0

    /// Bắt đầu quét. `onStopped` nhận lý do: "Quét xong", "BLUETOOTH_PERMISSION_REQUIRED",
    /// "BLUETOOTH_DISABLED", "BLUETOOTH_UNSUPPORTED"...
    func start(onItems: @escaping ([Item]) -> Void, onStopped: @escaping (String) -> Void) {
        stop()
        self.onItems = onItems
        self.onStopped = onStopped
        active = true
        serial += 1
        order.removeAll()
        items.removeAll()
        if let c = central {
            handleState(c)
        } else {
            central = CBCentralManager(delegate: self, queue: .main) // sẽ gọi centralManagerDidUpdateState
        }
    }

    func stop() {
        active = false
        serial += 1
        if scanning { central?.stopScan(); scanning = false }
    }

    private func finish(_ reason: String) {
        let cb = onStopped
        stop()
        cb?(reason)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if active && !scanning { handleState(central) }
    }

    private func handleState(_ c: CBCentralManager) {
        switch c.state {
        case .poweredOn: beginScan(c)
        case .unauthorized: finish("BLUETOOTH_PERMISSION_REQUIRED")
        case .poweredOff: finish("BLUETOOTH_DISABLED")
        case .unsupported: finish("BLUETOOTH_UNSUPPORTED")
        default: break // .unknown / .resetting: đợi cập nhật tiếp theo
        }
    }

    private func beginScan(_ c: CBCentralManager) {
        let token = serial
        // Thiết bị đã kết nối với hệ thống và có service FE86 (tương đương danh sách "đã ghép nối" của Android).
        // Đồng hồ đang nối Huawei Health có thể không quảng bá; hỏi cả các service chuẩn như HuaSideload (đã chạy được với GT 6 Pro).
        let known = [WatchScanner.serviceUUID, CBUUID(string: "180A"), CBUUID(string: "180F"), CBUUID(string: "1812"), CBUUID(string: "1805")]
        for p in c.retrieveConnectedPeripherals(withServices: known) {
            add(p, advertisedName: nil, rssi: nil, viaService: true)
        }
        scanning = true
        // Không lọc service ở mức hệ thống vì không chắc đồng hồ có quảng bá FE86; lọc theo tên/service ở add().
        c.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        DispatchQueue.main.asyncAfter(deadline: .now() + WatchScanner.scanSeconds) { [weak self] in
            guard let self = self, self.active, self.serial == token else { return }
            self.finish("Quét xong")
        }
    }

    private func add(_ p: CBPeripheral, advertisedName: String?, rssi: Int?, viaService: Bool) {
        guard active else { return }
        let raw = advertisedName ?? p.name
        let name = raw?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let low = name.lowercased()
        let nameMatches = WatchScanner.keywords.contains { low.contains($0) }
        if !nameMatches && !viaService { return }
        let shown = name.isEmpty ? "Thiết bị chưa đặt tên" : String(name.prefix(80))
        let id = p.identifier.uuidString
        let item = Item(id: id, name: shown, rssi: rssi, advertisesHuaweiService: viaService)
        if items[id] == nil { order.append(id) }
        items[id] = item
        onItems?(order.compactMap { items[$0] })
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let services = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        let r = RSSI.intValue == 127 ? nil : RSSI.intValue // 127 = không có giá trị
        add(peripheral, advertisedName: name, rssi: r, viaService: services.contains(WatchScanner.serviceUUID))
    }
}
