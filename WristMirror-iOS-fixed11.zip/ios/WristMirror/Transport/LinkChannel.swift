// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Bên nhận sự kiện từ kênh liên kết. `epoch` dùng để bỏ qua callback của kết nối cũ.
protocol LinkChannelListener: AnyObject {
    func linkDidOpen(epoch: Int, name: String)
    func linkDidReceive(epoch: Int, bytes: [UInt8])
    func linkDidFail(epoch: Int, error: String)
}

/// Một kết nối thuộc về app này. Không đụng tới kết nối của app khác.
protocol LinkChannel: AnyObject {
    func connect()
    func send(frames: [[UInt8]], peerMtu: Int, intervalMs: Int) throws
    func close()
}
