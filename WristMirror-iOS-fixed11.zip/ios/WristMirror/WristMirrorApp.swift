// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
// ============================================================================
// Xem HANDOFF.md ở thư mục gốc để biết trạng thái port và các điểm cần soi khi build lần đầu.
// ============================================================================
import SwiftUI

@main
struct WristMirrorApp: App {
    @StateObject private var vm = WatchViewModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(vm)
                .tint(Theme.accent)
                .preferredColorScheme(scheme(vm.ui.theme))
        }
    }

    private func scheme(_ m: ThemeMode) -> ColorScheme? {
        switch m {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
