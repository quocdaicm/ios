// Unit test cho Phần 60: số/chữ neon, ống neon, khung neon và Tết, nền tranh mới.
import XCTest
import SwiftUI
@testable import WristMirror

final class NeonStylesTests: XCTestCase {
    /// Kiểu "ống neon" phải vẽ ra điểm ảnh (viền sáng + ruột tối) và có lề rộng cho quầng sáng.
    func testTubeStylesDrawPixels() throws {
        for st in DigitalStyle.allCases where st.def?.paint == .tube {
            let def = try XCTUnwrap(st.def)
            XCTAssertTrue(def.paint.glows, st.rawValue)
            let cl = DigitalShapes.cells(def, scale: 1.0)
            XCTAssertEqual(cl.pad, 7, st.rawValue)
            let r = FaceRenderer.drawRaster(width: cl.digitW, height: cl.lineH) { ctx in
                DigitalShapes.draw(ctx, def: def, char: "8", in: CGRect(x: 0, y: 0, width: cl.digitW, height: cl.lineH),
                                   pad: CGFloat(cl.pad), color: .white, own: true)
            }
            XCTAssertGreaterThan(r.argb.filter { ($0 >> 24) != 0 }.count, 20, st.rawValue)
        }
    }

    func testNewPlateShapesProduceSVG() {
        for shape in 17..<FacePlate.titles.count {
            for outline in [true, false] {
                let svg = FacePlate.svg(shape: shape, w: 140, h: 44, outline: outline)
                XCTAssertFalse(svg.isEmpty, "khung \(shape) outline=\(outline)")
            }
        }
        XCTAssertTrue(FacePlate.svg(shape: 17, w: 140, h: 44, outline: true).contains("#FFFFFF"), "neon có lõi trắng")
        XCTAssertEqual(FacePlate.svg(shape: 99, w: 140, h: 44, outline: true), "")
    }

    func testNewBackdropsResolveAndAreNotEmpty() {
        for id in ["artNeonTree", "artReindeer", "artDragonRed", "artDragonJade", "artDragonTeal", "artDragonSilver", "artTetNeon"] {
            let b = FaceBackdrops.day.first { $0.id == id }
            XCTAssertNotNil(b, id)
            XCTAssertGreaterThan(b?.svg.count ?? 0, 500, id)
        }
        let ids = FaceBackdrops.day.map { $0.id }
        XCTAssertEqual(Set(ids).count, ids.count, "id nền không trùng")
    }

    func testTextFXNeonAndTetSpecsExist() {
        let titles = FaceTextFX.titles
        for t in ["Neon Hồng", "Ống Neon Xanh", "Neon Cầu Vồng", "Noel Đèn Màu", "Tết Đỏ Vàng", "Tết Thư Pháp", "Tết Hoa Đào"] {
            XCTAssertTrue(titles.contains(t), t)
        }
    }

    func testNewPresetsBuild() {
        for id in ["noelTube", "noelRudolf", "dragonCarved", "dragonJade", "dragonTeal", "dragonSilver", "tetNeonLantern",
                   "tetLedMai", "tetDaoNeon", "tetHanGold", "neonPinkCity", "neonLimeTube", "neonRainbow", "neonWhiteMinimal"] {
            let p = FacePresets.all.first { $0.id == id }
            XCTAssertNotNil(p, id)
            let d = p?.make()
            XCTAssertNotNil(d)
            if let shape = d?.plates["digital"]?.shape { XCTAssertTrue(shape < FacePlate.titles.count, id) }
        }
    }
}
