// Unit test cho bộ kiểu số giờ vector.
import XCTest
import SwiftUI
@testable import WristMirror

final class NumeralShapesTests: XCTestCase {
    func testEveryStyleHasDefinitionAndTitle() {
        for st in NumeralStyle.allCases where st != .classic {
            XCTAssertNotNil(NumeralShapes.table[st.rawValue], st.rawValue)
            XCTAssertNotNil(NumeralShapes.titles[st.rawValue], st.rawValue)
        }
        XCTAssertEqual(NumeralShapes.table.count, 47)
        XCTAssertEqual(NumeralStyle.allCases.count, 48)
    }

    func testTextPathHasGeometry() {
        let p = NumeralShapes.textPath("12", font: UIFont.systemFont(ofSize: 44, weight: .bold))
        XCTAssertFalse(p.boundingBox.isEmpty)
        XCTAssertEqual(p.boundingBox.midX, 0, accuracy: 0.5)
    }

    func testCodecRoundTrip() throws {
        var d = FaceDesign()
        d.marks = .numerals
        d.numeralStyle = .romanGold
        d.numeralOwnColors = false
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.numeralStyle, .romanGold)
        XCTAssertFalse(back.numeralOwnColors)
    }
}
