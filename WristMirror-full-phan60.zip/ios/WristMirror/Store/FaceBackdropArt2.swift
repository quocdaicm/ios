// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

// MARK: - Phần 60: nền tranh neon, tuần lộc, rồng chữ S và lồng đèn Tết
//
// Cùng cơ chế với `FaceBackdropArt.swift`: khung 466x466, chỉ dùng path (M L C Q Z), circle, ellipse, rect của `MiniSVG`.
// Nét neon được dựng bằng 4 lớp nét chồng nhau (quầng mờ, quầng đậm, thân màu, lõi trắng) vì `MiniSVG` không có bộ lọc làm mờ.

extension FaceBackdrops {
    static let dayArt2: [FaceBackdrop] = [
        FaceBackdrop(id: "artNeonTree", title: "Cây thông ống neon", top: 0x000000, bottom: 0x050A1C, svg: artNeonTree()),
        FaceBackdrop(id: "artReindeer", title: "Tuần lộc Rudolf", top: 0xCDEBDD, bottom: 0x8FCFB8, svg: artReindeer()),
        FaceBackdrop(id: "artDragonRed", title: "Rồng khắc đỏ", top: 0x4A0508, bottom: 0x9E1B1B,
                     svg: dragonS(seed: 601, glow: "#FF6B4A", body: ["#6B4A12", "#E8B040", "#FFE9A0"], accent: "#FFD24A", cloud: "#F2C879", flip: false)),
        FaceBackdrop(id: "artDragonJade", title: "Rồng thanh long", top: 0x02240F, bottom: 0x0C4A22,
                     svg: dragonS(seed: 611, glow: "#3DFF9A", body: ["#0B4A1C", "#1FA050", "#9CF0B0"], accent: "#F2C879", cloud: "#7DFFB0", flip: true)),
        FaceBackdrop(id: "artDragonTeal", title: "Rồng ngọc lam", top: 0x0C4A3C, bottom: 0x1C7A66,
                     svg: dragonS(seed: 621, glow: "#7FFFE0", body: ["#0B3A5A", "#2AA0C8", "#A8F0FF"], accent: "#E8B040", cloud: "#BFFFF0", flip: false)),
        FaceBackdrop(id: "artDragonSilver", title: "Rồng bạc", top: 0x3A0A14, bottom: 0x7A1E2C,
                     svg: dragonS(seed: 631, glow: "#FF9A8A", body: ["#4A515C", "#BAC1CC", "#FFFFFF"], accent: "#F2C879", cloud: "#FFD9B0", flip: true)),
        FaceBackdrop(id: "artTetNeon", title: "Tết neon lồng đèn", top: 0x1A0206, bottom: 0x4A0A12, svg: artTetNeon())
    ]

    // MARK: Nét neon

    private static func neonLine(_ s: inout SVGBuilder, _ d: String, _ color: String, _ w: Double = 3) {
        s.path(d, stroke: color, sw: w * 3.2, op: 0.12)
        s.path(d, stroke: color, sw: w * 2.0, op: 0.28)
        s.path(d, stroke: color, sw: w, op: 1)
        s.path(d, stroke: "#FFFFFF", sw: max(0.8, w * 0.36), op: 0.85)
    }

    private static func neonRing(_ s: inout SVGBuilder, _ cx: Double, _ cy: Double, _ r: Double, _ color: String, _ w: Double = 3) {
        s.ring(cx, cy, r, color, w * 3.2, 0.12)
        s.ring(cx, cy, r, color, w * 2.0, 0.28)
        s.ring(cx, cy, r, color, w, 1)
        s.ring(cx, cy, r, "#FFFFFF", max(0.8, w * 0.36), 0.85)
    }

    private static func star5(_ cx: Double, _ cy: Double, _ r: Double) -> String {
        var pts = [String]()
        for k in 0..<10 {
            let a = Double(k) * Double.pi / 5.0 - Double.pi / 2.0
            let rr = k % 2 == 0 ? r : r * 0.45
            pts.append(String(format: "%.1f %.1f", cx + cos(a) * rr, cy + sin(a) * rr))
        }
        return "M " + pts.joined(separator: " L ") + " Z"
    }

    // MARK: Cây thông ống neon (Lighted Christmas)

    private static func artNeonTree() -> String {
        var s = SVGBuilder(seed: 701)
        s.stars(40, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 1.6, op: 0.5)
        s.glow(233, 190, 190, "#39FF88", steps: 7, peak: 0.16)
        // Ba tầng tán cây
        let tiers = [
            "M 233 74 L 190 152 L 276 152 Z",
            "M 233 124 L 168 224 L 298 224 Z",
            "M 233 194 L 138 306 L 328 306 Z"
        ]
        for t in tiers { neonLine(&s, t, "#39FF88", 2.8) }
        neonLine(&s, "M 223 306 L 223 334 L 243 334 L 243 306", "#FF9A2D", 2.6)
        // Dây đèn
        neonLine(&s, "M 192 150 Q 233 176 274 150", "#FF2DAE", 2)
        neonLine(&s, "M 172 222 Q 233 256 294 222", "#FFD400", 2)
        neonLine(&s, "M 142 304 Q 233 346 324 304", "#2DD4FF", 2)
        // Ngôi sao trên đỉnh
        neonLine(&s, star5(233, 56, 20), "#FFD400", 2.4)
        // Bóng đèn màu chạy dọc hai cạnh tán cây
        let cols = ["#FF2D6F", "#FFD400", "#2DD4FF", "#B36BFF", "#FF7A1A", "#39FF88"]
        let edges: [((Double, Double), (Double, Double))] = [
            ((233, 74), (190, 152)), ((233, 74), (276, 152)),
            ((233, 124), (168, 224)), ((233, 124), (298, 224)),
            ((233, 194), (138, 306)), ((233, 194), (328, 306))
        ]
        var k = 0
        for e in edges {
            for j in 1...4 {
                let t = Double(j) / 5.0
                let x = e.0.0 + (e.1.0 - e.0.0) * t
                let y = e.0.1 + (e.1.1 - e.0.1) * t
                let c = cols[k % cols.count]
                s.glow(x, y, 11, c, steps: 3, peak: 0.5)
                s.circle(x, y, 4.2, c)
                s.circle(x - 1.2, y - 1.2, 1.4, "#FFFFFF", 0.9)
                k += 1
            }
        }
        // Quả cầu treo hai bên
        let hang: [(Double, Double, Double, String)] = [(84, 120, 16, "#FF2DAE"), (112, 168, 11, "#2DD4FF"), (386, 112, 15, "#FFD400"), (360, 162, 11, "#B36BFF")]
        for h in hang {
            neonLine(&s, "M \(h.0) 40 L \(h.0) \(h.1 - h.2)", "#FFFFFF", 1.2)
            neonRing(&s, h.0, h.1, h.2, h.3, 2.2)
        }
        // Hộp quà neon ở chân cây
        neonLine(&s, "M 96 410 L 96 372 L 150 372 L 150 410 Z M 123 372 L 123 410 M 96 390 L 150 390", "#FF2D6F", 2)
        neonLine(&s, "M 316 410 L 316 380 L 366 380 L 366 410 Z M 341 380 L 341 410", "#2DD4FF", 2)
        return s.out
    }

    // MARK: Tuần lộc Rudolf (Santa and Rudolf)

    private static func artReindeer() -> String {
        var s = SVGBuilder(seed: 711)
        s.glow(233, 250, 230, "#FFFFFF", steps: 6, peak: 0.35)
        // Hạt tuyết và confetti
        s.stars(46, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 3.2, op: 0.8)
        let conf = ["#FF6B6B", "#FFD84A", "#4DB6AC", "#7E9CFF"]
        for i in 0..<18 {
            let x = 20 + s.rnd() * 426, y = 20 + s.rnd() * 426
            s.circle(x, y, 2.2 + s.rnd() * 2.4, conf[i % conf.count], 0.7)
        }
        func side(_ mx: Bool) {
            func X(_ v: Double) -> Double { mx ? 466 - v : v }
            // Gạc
            s.path("M \(X(196)) 156 C \(X(172)) 118 \(X(160)) 84 \(X(172)) 48", stroke: "#7A4A24", sw: 10)
            s.path("M \(X(178)) 100 C \(X(152)) 98 \(X(138)) 84 \(X(130)) 64", stroke: "#7A4A24", sw: 7)
            s.path("M \(X(172)) 74 C \(X(192)) 68 \(X(198)) 54 \(X(198)) 38", stroke: "#7A4A24", sw: 6)
            s.path("M \(X(190)) 132 C \(X(166)) 134 \(X(150)) 124 \(X(142)) 108", stroke: "#7A4A24", sw: 6)
            // Tai
            s.path("M \(X(170)) 200 C \(X(124)) 196 \(X(92)) 178 \(X(84)) 150 C \(X(128)) 150 \(X(160)) 168 \(X(178)) 190 Z", fill: "#A0642F")
            s.path("M \(X(164)) 194 C \(X(130)) 188 \(X(108)) 174 \(X(102)) 160 C \(X(132)) 162 \(X(154)) 174 \(X(170)) 188 Z", fill: "#F2B6A0", op: 0.9)
        }
        side(false); side(true)
        // Đầu và mõm
        s.ellipse(233, 252, 82, 92, fill: "#B5753F")
        s.ellipse(233, 232, 60, 54, fill: "#C98A50", op: 0.8)
        s.ellipse(233, 316, 54, 44, fill: "#EBC9A0")
        // Mắt, má
        s.circle(198, 238, 11, "#2B1A14"); s.circle(268, 238, 11, "#2B1A14")
        s.circle(201, 234, 3.6, "#FFFFFF"); s.circle(271, 234, 3.6, "#FFFFFF")
        s.circle(166, 282, 18, "#FF8FA3", 0.55); s.circle(300, 282, 18, "#FF8FA3", 0.55)
        // Mũi đỏ phát sáng
        s.glow(233, 302, 64, "#FF4D4D", steps: 6, peak: 0.45)
        s.circle(233, 302, 23, "#E32A2A")
        s.circle(226, 294, 7, "#FF9A90", 0.9)
        s.path("M 233 326 L 233 342 M 233 342 Q 218 354 206 346 M 233 342 Q 248 354 260 346", stroke: "#7A4A24", sw: 3)
        // Khăn len sọc
        s.path("M 138 374 Q 233 408 328 374 L 334 414 Q 233 448 132 414 Z", fill: "#1F8A4C")
        for i in 0..<6 {
            let x = 156 + Double(i) * 30
            s.path("M \(x) 384 L \(x + 8) 428", stroke: "#FF4D4D", sw: 6, op: 0.95)
        }
        s.circle(318, 420, 9, "#FFD84A"); s.circle(318, 420, 3.4, "#B8860B")
        return s.out
    }

    // MARK: Rồng uốn chữ S

    private static func dragonS(seed: UInt32, glow: String, body: [String], accent: String, cloud: String, flip: Bool) -> String {
        var s = SVGBuilder(seed: seed)
        func X(_ v: Double) -> Double { flip ? 466 - v : v }
        s.glow(233, 236, 232, glow, steps: 8, peak: 0.34)
        // Mây xoắn
        let clouds: [(Double, Double, Double)] = [(70, 380, 1.0), (390, 90, 0.9), (60, 120, 0.7), (400, 360, 0.8), (236, 440, 0.7)]
        for c in clouds {
            let cx = X(c.0), cy = c.1, k = c.2
            s.path("M \(cx - 40 * k) \(cy) C \(cx - 40 * k) \(cy - 22 * k) \(cx - 8 * k) \(cy - 26 * k) \(cx - 4 * k) \(cy - 8 * k) C \(cx) \(cy - 34 * k) \(cx + 40 * k) \(cy - 30 * k) \(cx + 38 * k) \(cy - 4 * k) C \(cx + 54 * k) \(cy - 8 * k) \(cx + 60 * k) \(cy + 12 * k) \(cx + 44 * k) \(cy + 16 * k) L \(cx - 40 * k) \(cy + 16 * k)",
                   stroke: cloud, sw: 2.2, op: 0.4)
            s.path("M \(cx - 22 * k) \(cy + 4 * k) C \(cx - 12 * k) \(cy - 10 * k) \(cx + 4 * k) \(cy - 8 * k) \(cx + 8 * k) \(cy + 4 * k)", stroke: cloud, sw: 1.6, op: 0.3)
        }
        // Thân: hai đoạn Bézier ghép thành chữ S
        let p0 = (X(150), 112.0), c1 = (X(380), 56.0), c2 = (X(408), 232.0), p1 = (X(233), 242.0)
        let c3 = (X(64), 252.0), c4 = (X(86), 402.0), p2 = (X(310), 410.0)
        func cub(_ a: (Double, Double), _ b: (Double, Double), _ c: (Double, Double), _ d: (Double, Double), _ t: Double) -> (Double, Double) {
            let u = 1 - t
            let x = u * u * u * a.0 + 3 * u * u * t * b.0 + 3 * u * t * t * c.0 + t * t * t * d.0
            let y = u * u * u * a.1 + 3 * u * u * t * b.1 + 3 * u * t * t * c.1 + t * t * t * d.1
            return (x, y)
        }
        let n = 96
        var pts = [(Double, Double)]()
        for i in 0...n {
            let t = Double(i) / Double(n)
            pts.append(t < 0.5 ? cub(p0, c1, c2, p1, t * 2) : cub(p1, c3, c4, p2, (t - 0.5) * 2))
        }
        func rad(_ i: Int) -> Double { let t = Double(i) / Double(n); return 6 + 22 * pow(1 - t, 0.8) }
        // Vẽ từ đuôi lên đầu để đầu nằm trên cùng
        for i in stride(from: n, through: 0, by: -1) { s.circle(pts[i].0, pts[i].1, rad(i) + 2.2, body[0]) }
        for i in stride(from: n, through: 0, by: -1) { s.circle(pts[i].0, pts[i].1, rad(i), body[1]) }
        for i in stride(from: n, through: 0, by: -1) {
            s.circle(pts[i].0 - rad(i) * 0.16, pts[i].1 - rad(i) * 0.22, rad(i) * 0.5, body[2], 0.38)
        }
        // Vảy và vây lưng
        for i in stride(from: 3, to: n, by: 3) {
            let (x, y) = pts[i]
            let r = rad(i)
            s.ring(x, y, r * 0.56, body[0], 1.2, 0.45)
            let a = pts[max(0, i - 1)], b = pts[min(n, i + 1)]
            var tx = b.0 - a.0, ty = b.1 - a.1
            let len = max(0.001, (tx * tx + ty * ty).squareRoot())
            tx /= len; ty /= len
            let nx = -ty, ny = tx
            if i % 6 == 0 {
                s.path("M \(x + nx * r - tx * 5) \(y + ny * r - ty * 5) L \(x + nx * (r + 12) + tx * 2) \(y + ny * (r + 12) + ty * 2) L \(x + nx * r + tx * 6) \(y + ny * r + ty * 6) Z",
                       fill: accent, op: 0.95)
            }
        }
        // Đầu rồng
        let a = pts[0], b = pts[8]
        var dx = a.0 - b.0, dy = a.1 - b.1
        let dl = max(0.001, (dx * dx + dy * dy).squareRoot())
        dx /= dl; dy /= dl
        let px = -dy, py = dx
        let hx = a.0 + dx * 10, hy = a.1 + dy * 10
        s.circle(hx, hy, 33, body[0]); s.circle(hx, hy, 30, body[1])
        s.circle(hx + dx * 30, hy + dy * 30, 24, body[0]); s.circle(hx + dx * 30, hy + dy * 30, 21.5, body[1])
        s.circle(hx + dx * 26 + px * 14, hy + dy * 26 + py * 14, 14, body[0]); s.circle(hx + dx * 26 + px * 14, hy + dy * 26 + py * 14, 12, body[2], 0.85)
        s.circle(hx - dx * 4 - px * 6, hy - dy * 4 - py * 6, 14, body[2], 0.35)
        // Mắt
        s.circle(hx + dx * 6 - px * 13, hy + dy * 6 - py * 13, 6.5, "#FFFFFF")
        s.circle(hx + dx * 7 - px * 13, hy + dy * 7 - py * 13, 3.6, "#C41E1E")
        s.circle(hx + dx * 8 - px * 13, hy + dy * 8 - py * 13, 1.5, "#000000")
        // Lỗ mũi
        s.circle(hx + dx * 46 - px * 7, hy + dy * 46 - py * 7, 2.4, body[0])
        // Sừng
        for sgn in [-1.0, 1.0] {
            let bx = hx - dx * 8 + px * 16 * sgn, by = hy - dy * 8 + py * 16 * sgn
            s.path("M \(bx) \(by) C \(bx - dx * 24 + px * 16 * sgn) \(by - dy * 24 + py * 16 * sgn) \(bx - dx * 46 + px * 8 * sgn) \(by - dy * 46 + py * 8 * sgn) \(bx - dx * 62 + px * 22 * sgn) \(by - dy * 62 + py * 22 * sgn)",
                   stroke: accent, sw: 6)
        }
        // Râu
        for sgn in [-1.0, 1.0] {
            let sx = hx + dx * 44 + px * 8 * sgn, sy = hy + dy * 44 + py * 8 * sgn
            s.path("M \(sx) \(sy) C \(sx + dx * 30 + px * 40 * sgn) \(sy + dy * 30 + py * 40 * sgn) \(sx + dx * 10 + px * 76 * sgn) \(sy + dy * 10 + py * 76 * sgn) \(sx - dx * 20 + px * 96 * sgn) \(sy - dy * 20 + py * 96 * sgn)",
                   stroke: accent, sw: 2.4, op: 0.9)
        }
        // Ngọc trước miệng rồng
        let gx = hx + dx * 84, gy = hy + dy * 84
        s.glow(gx, gy, 34, accent, steps: 5, peak: 0.5)
        s.circle(gx, gy, 11, accent)
        s.circle(gx - 3, gy - 3, 4, "#FFFFFF", 0.85)
        // Hạt sáng và sao
        s.stars(26, x0: 0, y0: 0, x1: 466, y1: 466, color: accent, maxR: 2, op: 0.5)
        return s.out
    }

    // MARK: Tết neon lồng đèn

    private static func artTetNeon() -> String {
        var s = SVGBuilder(seed: 721)
        s.glow(233, 240, 220, "#FF3B2F", steps: 7, peak: 0.22)
        s.stars(36, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFE9B8", maxR: 1.8, op: 0.55)
        // Lồng đèn hai bên
        let lanterns: [(Double, Double, Double)] = [(86, 124, 1.0), (380, 118, 0.9), (52, 292, 0.6), (414, 300, 0.62)]
        for l in lanterns {
            let cx = l.0, cy = l.1, k = l.2
            neonLine(&s, "M \(cx) \(cy - 60 * k) L \(cx) \(cy - 40 * k)", "#FFC857", 1.6)
            neonRing(&s, cx, cy, 36 * k, "#FF3B2F", 2.6)
            neonLine(&s, "M \(cx - 12 * k) \(cy - 34 * k) Q \(cx - 30 * k) \(cy) \(cx - 12 * k) \(cy + 34 * k) M \(cx + 12 * k) \(cy - 34 * k) Q \(cx + 30 * k) \(cy) \(cx + 12 * k) \(cy + 34 * k)", "#FF3B2F", 1.8)
            neonLine(&s, "M \(cx - 16 * k) \(cy - 38 * k) L \(cx + 16 * k) \(cy - 38 * k) M \(cx - 16 * k) \(cy + 38 * k) L \(cx + 16 * k) \(cy + 38 * k)", "#FFC857", 2.2)
            neonLine(&s, "M \(cx) \(cy + 38 * k) L \(cx) \(cy + 70 * k)", "#FFC857", 1.8)
            s.circle(cx, cy + 74 * k, 4 * k, "#FFC857")
        }
        // Hoa mai neon
        let mai: [(Double, Double, Double)] = [(160, 66, 20), (320, 58, 17), (232, 36, 13), (116, 398, 20), (350, 410, 22), (236, 432, 14)]
        for m in mai {
            for k in 0..<5 {
                let a = Double(k) * 2.0 * Double.pi / 5.0 - Double.pi / 2.0
                neonRing(&s, m.0 + cos(a) * m.2 * 0.62, m.1 + sin(a) * m.2 * 0.62, m.2 * 0.5, "#FFD400", 1.6)
            }
            s.circle(m.0, m.1, m.2 * 0.22, "#FF9A2D")
        }
        // Cành mai uốn
        neonLine(&s, "M 40 432 C 120 400 180 440 236 432 C 290 424 330 440 430 400", "#FF9A2D", 2)
        // Chữ Phúc cách điệu: hình thoi lồng nhau ở giữa trên
        neonLine(&s, "M 233 92 L 262 122 L 233 152 L 204 122 Z", "#FFC857", 2)
        s.sparkle(233, 122, 12, "#FFFFFF", 0.9)
        return s.out
    }
}
