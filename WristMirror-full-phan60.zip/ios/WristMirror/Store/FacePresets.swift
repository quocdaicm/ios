// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Mẫu thiết kế có sẵn

/// Mẫu mặt đồng hồ vẽ sẵn bằng vector: chạm một lần để áp dụng, rồi chỉnh tiếp từng phần.
struct FacePreset: Identifiable {
    let id: String
    let title: String
    let make: () -> FaceDesign
}

private extension Color {
    /// 0xRRGGBB
    init(wm hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255)
    }
}

enum FacePresets {
    /// Áp mẫu lên thiết kế hiện tại nhưng giữ nguyên tên và tác giả người dùng đã nhập (bỏ ảnh nền vì mẫu là vector).
    static func apply(_ preset: FacePreset, to current: FaceDesign) -> FaceDesign {
        var d = preset.make()
        d.name = current.name
        d.author = current.author
        return d
    }

    private static func base(_ bg1: UInt32, _ bg2: UInt32?) -> FaceDesign {
        var d = FaceDesign()
        d.backgroundColor = Color(wm: bg1)
        if let b = bg2 { d.useGradient = true; d.backgroundColor2 = Color(wm: b) } else { d.useGradient = false }
        d.decor = []
        d.showLunar = false
        return d
    }

    /// Nền SVG ban ngày có sẵn + màu nền chuyển sắc đúng như Studio gán khi chọn nền đó.
    private static func dayBackdrop(_ d: inout FaceDesign, _ id: String) {
        guard let b = FaceBackdrops.day.first(where: { $0.id == id }) else { return }
        d.backdrop = id
        d.useGradient = true
        d.backgroundColor = b.topColor
        d.backgroundColor2 = b.bottomColor
    }

    /// AOD "Nền riêng" dùng nền SVG nét mảnh (màu nền theo nền đó), hiện giờ số/thông tin, kim và vạch giờ màu `hand`/`marks`.
    private static func aodBackdrop(_ d: inout FaceDesign, _ id: String, hand: UInt32, marks: UInt32) {
        guard let b = FaceBackdrops.aod.first(where: { $0.id == id }) else { return }
        d.aodBackground = .custom
        d.aodBackdrop = id
        d.aodUseGradient = true
        d.aodColor = b.topColor
        d.aodColor2 = b.bottomColor
        d.aodShowDecor = true
        d.aodShowMarks = true
        d.aodShowInfo = true
        d.aodHandColor = Color(wm: hand)
        d.aodMarksColor = Color(wm: marks)
    }

    /// Hạt rơi nền (tuyết/lá/hoa/pháo hoa): số khung, ms mỗi khung, mật độ, kiểu lặp.
    private static func fall(_ d: inout FaceDesign, _ kind: AnimKind, frames: Int = 24, ms: Double = 52, density: Double, loop: Int = 2) {
        d.animOn = true
        d.animKind = kind
        d.animFallFrames = frames
        d.animInterval = ms
        d.animDensity = density
        d.animLoopMode = loop
    }

    /// Bố cục thông tin chuẩn (cùng vị trí đã đo trên đồng hồ thật như mặt Mặc định): giờ số có khung, thứ, dương/âm lịch,
    /// pin, nhịp tim, thời tiết; `style` là kiểu số chung cho tất cả.
    private static func standardInfo(_ d: inout FaceDesign, text: UInt32, accent: UInt32, style: DigitalStyle, weekdayFX: Int = 16, plate: Bool = true) {
        d.autoLayout = false
        d.showDigital = true; d.digitalColor = Color(wm: accent); d.digitalSize = 1.0; d.digitalX = 0.496; d.digitalY = 0.209
        d.showWeekday = true; d.weekdayColor = Color(wm: text); d.weekdaySize = 0.82; d.weekdayX = 0.213; d.weekdayY = 0.5
        d.weekdayFX = weekdayFX
        d.showSolar = true; d.solarColor = Color(wm: text); d.solarX = 0.779; d.solarY = 0.385; d.solarLabel = true
        d.showLunar = true; d.lunarColor = Color(wm: text); d.lunarX = 0.771; d.lunarY = 0.556; d.lunarLabel = true
        d.battery.show = true; d.battery.color = Color(wm: accent); d.battery.size = 1.05
        d.battery.x = 0.1182; d.battery.y = 0.406; d.battery.icon = true
        d.heart.show = true; d.heart.color = Color(wm: text); d.heart.size = 0.9
        d.heart.x = 0.5216; d.heart.y = 0.7003; d.heart.icon = true
        d.weather.show = true; d.weather.color = Color(wm: text); d.weather.size = 0.9
        d.weather.x = 0.2233; d.weather.y = 0.737
        d.weatherIcon = true; d.weatherText = true; d.weatherRange = false
        d.dataStyle = style
        d.dataOwnColors = true
        if plate {
            d.plates["digital"] = PlateStyle(shape: 4, fill: .black, line: Color(wm: accent), opacity: 1.0, outline: true)
        }
        if d.marks == .numerals { compactForNumerals(&d) }
    }

    /// Mặt có số giờ lớn (Cơ khí, Vàng đen...): thu nhỏ chữ và dời các mục vào trong vòng tròn bán kính ~148
    /// (phía trong vòng số) để không đè lên số 9, 3, 11, 1, 8, 4... Toạ độ tính từ tâm 233 trên khung 466.
    private static func compactForNumerals(_ d: inout FaceDesign) { ringLayout(&d, spread: 1.0, grow: 1.0) }

    /// Bố cục 3 hàng (giờ số ở trên; pin/thứ trái, dương/âm lịch phải; thời tiết trái, nhịp tim phải).
    /// `spread` nhân khoảng cách từ tâm, `grow` nhân cỡ chữ (1.0 = bản gọn cho mặt có số; ~1.2 cho mặt chỉ có vạch).
    private static func ringLayout(_ d: inout FaceDesign, spread k: Double, grow g: Double) {
        func u(_ off: Double) -> Double { (233 + off * k) / 466 }
        d.autoLayout = true // lưới an toàn: nếu còn chồng nhẹ thì tự dời/thu nhỏ
        d.digitalSize = 0.75 * g; d.digitalX = 0.496; d.digitalY = u(-98)
        d.weekdaySize = 0.62 * g; d.weekdayX = u(-80); d.weekdayY = u(-2)
        d.solarSize = 0.75 * g; d.solarX = u(78); d.solarY = u(-48)
        d.lunarSize = 0.75 * g; d.lunarX = u(78); d.lunarY = u(4)
        d.battery.size = 0.8 * g; d.battery.x = u(-116); d.battery.y = u(-50)
        d.heart.size = 0.72 * g; d.heart.x = u(20); d.heart.y = u(58)
        d.weather.size = 0.7 * g; d.weather.x = u(-108); d.weather.y = u(58)
    }

    /// Hai cột: giờ số ở trên giữa, cột trái = thứ / dương lịch / âm lịch, cột phải = pin / nhịp tim / thời tiết.
    private static func columnsLayout(_ d: inout FaceDesign) {
        func u(_ off: Double) -> Double { (233 + off) / 466 }
        d.autoLayout = true
        d.digitalSize = 0.85; d.digitalX = 0.5; d.digitalY = u(-122)
        d.weekdaySize = 0.68; d.weekdayX = u(-110); d.weekdayY = u(-62)
        d.solarSize = 0.75; d.solarX = u(-110); d.solarY = u(-8)
        d.lunarSize = 0.75; d.lunarX = u(-110); d.lunarY = u(54)
        d.battery.size = 0.8; d.battery.x = u(62); d.battery.y = u(-62)
        d.heart.size = 0.75; d.heart.x = u(62); d.heart.y = u(-4)
        d.weather.size = 0.72; d.weather.x = u(62); d.weather.y = u(60)
    }

    /// Giờ số to ở dưới (kiểu Wild Journey / Moon Pavilion): hàng trên là thứ + dương lịch, giữa là pin/âm lịch,
    /// thời tiết và nhịp tim ở hai bên phía trên giờ số.
    private static func bigBottomLayout(_ d: inout FaceDesign) {
        func u(_ off: Double) -> Double { (233 + off) / 466 }
        d.autoLayout = true
        d.digitalSize = 1.1; d.digitalX = 0.5; d.digitalY = u(100)
        d.weekdaySize = 0.7; d.weekdayX = u(-80); d.weekdayY = u(-100)
        d.solarSize = 0.8; d.solarX = u(85); d.solarY = u(-100)
        d.lunarSize = 0.8; d.lunarX = u(100); d.lunarY = u(-42)
        d.battery.size = 0.85; d.battery.x = u(-150); d.battery.y = u(-42)
        d.weather.size = 0.8; d.weather.x = u(-150); d.weather.y = u(22)
        d.heart.size = 0.8; d.heart.x = u(62); d.heart.y = u(28)
    }

    /// Kim vector dùng màu gốc của kiểu, không viền tối, giây có màu riêng.
    private static func vectorHands(_ d: inout FaceDesign, _ style: FaceDesign.HandStyle, second: UInt32, cap: UInt32, width: Double = 0.9) {
        d.handStyle = style
        d.handOwnColors = true
        d.handOutline = false
        d.handWidth = width
        d.secondColor = Color(wm: second)
        d.capColor = Color(wm: cap)
        d.showSecond = true
    }

    static let all: [FacePreset] = [
        FacePreset(id: "default", title: "Mặc định") { FaceDesign.themeDefault },
        FacePreset(id: "lotus", title: "Hoa sen vàng") {
            var d = FacePresets.base(0x2A0A10, 0x6B1D22)
            d.marks = .ticks; d.marksColor = Color(wm: 0xF2C879)
            d.handStyle = .classic
            d.hourColor = Color(wm: 0xF6DDA4); d.minuteColor = Color(wm: 0xF6DDA4)
            d.secondColor = Color(wm: 0xFF6B4A); d.capColor = Color(wm: 0xF2C879)
            d.decor = [DecorLayer(pattern: .lotus, color: Color(wm: 0xF2C879), opacity: 0.55, scale: 0.85, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xF6DDA4); d.lunarY = 0.70
            d.aodHandColor = Color(wm: 0xF2C879); d.aodMarksColor = Color(wm: 0x8A6A3B)
            return d
        },
        FacePreset(id: "bronze", title: "Trống đồng") {
            var d = FacePresets.base(0x120C05, 0x3A2A10)
            d.marks = .dots; d.marksColor = Color(wm: 0xD9A441)
            d.handStyle = .pointed
            d.hourColor = Color(wm: 0xF1D48A); d.minuteColor = Color(wm: 0xF1D48A)
            d.secondColor = Color(wm: 0xE0572F); d.capColor = Color(wm: 0xD9A441)
            d.decor = [DecorLayer(pattern: .bronzeDrum, color: Color(wm: 0xD9A441), opacity: 0.6, scale: 0.9, spin: .minute)]
            d.aodHandColor = Color(wm: 0xD9A441); d.aodMarksColor = Color(wm: 0x7A5A22)
            return d
        },
        FacePreset(id: "star", title: "Sao vàng") {
            var d = FacePresets.base(0xB5121B, 0x6E0A10)
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD84A)
            d.handStyle = .pointed
            d.hourColor = Color(wm: 0xFFE98A); d.minuteColor = Color(wm: 0xFFE98A)
            d.secondColor = Color.white; d.capColor = Color(wm: 0xFFD84A)
            d.decor = [DecorLayer(pattern: .star, color: Color(wm: 0xFFD84A), opacity: 0.5, scale: 0.62, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xFFE98A); d.lunarY = 0.72
            d.aodHandColor = Color(wm: 0xFFD84A); d.aodMarksColor = Color(wm: 0x8A6A1A)
            return d
        },
        FacePreset(id: "midnight", title: "Đêm xanh") {
            var d = FacePresets.base(0x050B1F, 0x123A7A)
            d.marks = .dots; d.marksColor = Color(wm: 0x7CC4FF)
            d.handStyle = .pointed
            d.hourColor = Color.white; d.minuteColor = Color(wm: 0xBFE1FF)
            d.secondColor = Color(wm: 0x4DA3FF); d.capColor = Color(wm: 0x4DA3FF)
            d.decor = [DecorLayer(pattern: .mandala, color: Color(wm: 0x4DA3FF), opacity: 0.35, scale: 0.85, spin: .hour)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xBFE1FF)
            return d
        },
        FacePreset(id: "ocean", title: "Biển xanh") {
            var d = FacePresets.base(0x021C2E, 0x0B6E8A)
            d.marks = .ticks; d.marksColor = Color.white
            d.handStyle = .bar
            d.hourColor = Color.white; d.minuteColor = Color.white
            d.secondColor = Color(wm: 0xFFB020); d.capColor = Color(wm: 0xFFB020)
            d.decor = [DecorLayer(pattern: .dotRings, color: Color.white, opacity: 0.3, scale: 0.9, spin: .minute)]
            d.lunarColor = Color.white
            return d
        },
        FacePreset(id: "forest", title: "Rừng sâu") {
            var d = FacePresets.base(0x04140B, 0x0F3D24)
            d.marks = .numerals; d.marksColor = Color(wm: 0xF2EBD0)
            d.handStyle = .classic
            d.hourColor = Color(wm: 0xF2EBD0); d.minuteColor = Color(wm: 0xF2EBD0)
            d.secondColor = Color(wm: 0xE8A33D); d.capColor = Color(wm: 0xE8A33D)
            d.decor = [DecorLayer(pattern: .sunburst, color: Color(wm: 0x7BD88F), opacity: 0.25, scale: 0.9, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0xF2EBD0); d.lunarY = 0.70
            return d
        },
        FacePreset(id: "neon", title: "Neon") {
            var d = FacePresets.base(0x05000F, 0x2A0050)
            d.marks = .ticks; d.marksColor = Color(wm: 0xFF3DCB)
            d.handStyle = .bar
            d.hourColor = Color(wm: 0x3DF5FF); d.minuteColor = Color(wm: 0x3DF5FF)
            d.secondColor = Color(wm: 0xFF3DCB); d.capColor = Color(wm: 0xFF3DCB)
            d.decor = [DecorLayer(pattern: .gear, color: Color(wm: 0xFF3DCB), opacity: 0.3, scale: 0.8, spin: .second)]
            d.lunarColor = Color(wm: 0x3DF5FF)
            return d
        },
        FacePreset(id: "paper", title: "Giấy cổ") {
            var d = FacePresets.base(0xF1E6CC, nil)
            d.marks = .numerals; d.marksColor = Color(wm: 0x2B2118)
            d.handStyle = .classic; d.handOutline = false
            d.hourColor = Color(wm: 0x2B2118); d.minuteColor = Color(wm: 0x2B2118)
            d.secondColor = Color(wm: 0xB3261E); d.capColor = Color(wm: 0xB3261E)
            d.decor = [DecorLayer(pattern: .ring, color: Color(wm: 0x8A6A3B), opacity: 0.5, scale: 0.9, spin: .none)]
            d.showLunar = true; d.lunarColor = Color(wm: 0x2B2118); d.lunarY = 0.70
            d.aodHandColor = Color(wm: 0xE9DDBF); d.aodMarksColor = Color(wm: 0x8A6A3B)
            return d
        },
        FacePreset(id: "minimal", title: "Tối giản") {
            var d = FacePresets.base(0x000000, nil)
            d.marks = .ticks; d.marksColor = Color.white
            d.handStyle = .bar
            d.hourColor = Color.white; d.minuteColor = Color.white
            d.secondColor = Color(wm: 0xFF4D5A); d.capColor = Color(wm: 0xFF4D5A)
            return d
        },
        // ---- Mẫu có hiệu ứng (tham khảo các mặt đồng hồ thịnh hành: Motion, Aurora, Galaxy, Cyberpunk, LED hoài cổ...) ----
        FacePreset(id: "aurora", title: "Cực quang") {
            var d = FacePresets.base(0x020B1A, 0x0B3B3A)
            FacePresets.dayBackdrop(&d, "aurora")
            d.marks = .dots; d.marksColor = Color(wm: 0x7DF9C8)
            FacePresets.vectorHands(&d, .luminousAqua, second: 0xFF6B9A, cap: 0x7DF9C8)
            FacePresets.standardInfo(&d, text: 0xDFFFF4, accent: 0x7DF9C8, style: .neonAqua)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0x7DF9C8)
            FacePresets.fall(&d, .snow, density: 0.2)
            FacePresets.aodBackdrop(&d, "aodStars", hand: 0x5CC9A7, marks: 0x2F6B5A)
            return d
        },
        FacePreset(id: "galaxy", title: "Thiên hà") {
            var d = FacePresets.base(0x05030F, 0x2A0B4A)
            FacePresets.dayBackdrop(&d, "starryNight")
            d.decor = [DecorLayer(pattern: .constellation, color: Color(wm: 0xC9B6FF), opacity: 0.4, scale: 0.9, spin: .minute)]
            d.marks = .dots; d.marksColor = Color(wm: 0xE6D9FF)
            FacePresets.vectorHands(&d, .luminousPurple, second: 0xFFD166, cap: 0xC9B6FF)
            FacePresets.standardInfo(&d, text: 0xEFE6FF, accent: 0xC9B6FF, style: .neonPurple)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xE6D9FF)
            FacePresets.fall(&d, .snow, density: 0.15)
            FacePresets.aodBackdrop(&d, "aodStars", hand: 0x9C86D9, marks: 0x4A3F75)
            return d
        },
        FacePreset(id: "cyber", title: "Cyberpunk") {
            var d = FacePresets.base(0x0A0014, 0x2A0040)
            d.decor = [DecorLayer(pattern: .hexGrid, color: Color(wm: 0xFF2BD6), opacity: 0.28, scale: 0.92, spin: .none)]
            d.marks = .ticks; d.marksColor = Color(wm: 0x00F0FF)
            FacePresets.vectorHands(&d, .future, second: 0xFF2BD6, cap: 0x00F0FF)
            FacePresets.standardInfo(&d, text: 0xB8F6FF, accent: 0x00F0FF, style: .futureBlue, weekdayFX: 0)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0xFF2BD6)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0x00B8C4, marks: 0x7A1B6B)
            return d
        },
        FacePreset(id: "sakura", title: "Anh đào") {
            var d = FacePresets.base(0x2B0F1E, 0x7A2A4A)
            FacePresets.dayBackdrop(&d, "blossom")
            d.decor = [DecorLayer(pattern: .cherry, color: Color(wm: 0xFFC2D9), opacity: 0.35, scale: 0.9, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD1E3)
            FacePresets.vectorHands(&d, .roseGold, second: 0xFF5C8A, cap: 0xFFD1E3)
            FacePresets.standardInfo(&d, text: 0xFFE4EF, accent: 0xFFB3CF, style: .dotRose)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFD1E3)
            FacePresets.fall(&d, .petals, density: 0.4)
            FacePresets.aodBackdrop(&d, "aodSpring", hand: 0xD98AA8, marks: 0x7A3B52)
            return d
        },
        FacePreset(id: "luxury", title: "Vàng đen") {
            var d = FacePresets.base(0x000000, 0x141008)
            d.decor = [DecorLayer(pattern: .rosette, color: Color(wm: 0xF2C879), opacity: 0.32, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.numeralStyle = .romanGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .luxury, second: 0xF2C879, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xF6DDA4, accent: 0xF2C879, style: .goldHex)
            d.secondFX = .ticks; d.secondFXColor = Color(wm: 0xF2C879)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "jelly", title: "Sứa đêm") {
            var d = FacePresets.base(0x01131F, 0x05526B)
            FacePresets.dayBackdrop(&d, "waves")
            d.decor = [DecorLayer(pattern: .waves, color: Color(wm: 0x7FE7FF), opacity: 0.3, scale: 0.9, spin: .none)]
            d.marks = .ticks; d.marksColor = Color(wm: 0xBFEFFF)
            FacePresets.vectorHands(&d, .sapphire, second: 0xFFB020, cap: 0x7FE7FF)
            FacePresets.standardInfo(&d, text: 0xD6F6FF, accent: 0x7FE7FF, style: .futureBlue)
            d.secondFX = .pulse; d.secondFXColor = Color(wm: 0x7FE7FF)
            FacePresets.fall(&d, .snow, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodWaves", hand: 0x4DB5CF, marks: 0x1F5A78)
            return d
        },
        FacePreset(id: "fireworkNight", title: "Pháo hoa đêm") {
            var d = FacePresets.base(0x02040F, 0x0B1B3A)
            FacePresets.dayBackdrop(&d, "cityNight")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFB347)
            FacePresets.vectorHands(&d, .royal, second: 0xFF4D5A, cap: 0xFFB347)
            FacePresets.standardInfo(&d, text: 0xFFE9C7, accent: 0xFFB347, style: .dotAmber)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFB347)
            FacePresets.fall(&d, .firework, density: 0.4)
            FacePresets.aodBackdrop(&d, "aodStars", hand: 0xC98A2E, marks: 0x6B4A22)
            return d
        },
        FacePreset(id: "kaleido", title: "Vạn hoa") {
            var d = FacePresets.base(0x0B0620, 0x1E1B5C)
            d.decor = [
                DecorLayer(pattern: .flowerOfLife, color: Color(wm: 0xFF8AD8), opacity: 0.4, scale: 0.92, spin: .minute),
                DecorLayer(pattern: .mandala, color: Color(wm: 0x6FE7FF), opacity: 0.3, scale: 0.7, spin: .hour)
            ]
            d.marks = .dots; d.marksColor = Color.white
            FacePresets.vectorHands(&d, .luminous, second: 0xFFD166, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xE8E4FF, style: .silverTech)
            d.secondFX = .rainbow
            FacePresets.aodBackdrop(&d, "aodRings", hand: 0xB8B2E6, marks: 0x4A4680)
            return d
        },
        FacePreset(id: "retroLED", title: "LED hoài cổ") {
            var d = FacePresets.base(0x000000, nil)
            d.decor = [DecorLayer(pattern: .dotRings, color: Color(wm: 0xFFA000), opacity: 0.25, scale: 0.9, spin: .second)]
            d.marks = .ticks; d.marksColor = Color(wm: 0xFFA000)
            FacePresets.vectorHands(&d, .baton, second: 0xFF3B1F, cap: 0xFFA000)
            FacePresets.standardInfo(&d, text: 0xFFC766, accent: 0xFFA000, style: .ledAmber, weekdayFX: 0)
            d.secondFX = .ticks; d.secondFXColor = Color(wm: 0xFFA000)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xC77A00, marks: 0x6B4300)
            return d
        },
        FacePreset(id: "bamboo", title: "Tre xanh") {
            var d = FacePresets.base(0x04140B, 0x0F3D24)
            FacePresets.dayBackdrop(&d, "bamboo")
            d.marks = .dots; d.marksColor = Color(wm: 0xBFF0C8)
            FacePresets.vectorHands(&d, .leafGold, second: 0xE8A33D, cap: 0xE8A33D)
            FacePresets.standardInfo(&d, text: 0xE8F7EA, accent: 0xBFF0C8, style: .thinGold)
            d.secondFX = .arc; d.secondFXColor = Color(wm: 0x7BD88F)
            FacePresets.fall(&d, .leaves, density: 0.35)
            FacePresets.aodBackdrop(&d, "aodBamboo", hand: 0x7BB98A, marks: 0x2F6B44)
            return d
        },
        FacePreset(id: "sunset", title: "Hoàng hôn") {
            var d = FacePresets.base(0x2A0A10, 0xC4561A)
            FacePresets.dayBackdrop(&d, "sunsetMountain")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFE0A8)
            FacePresets.vectorHands(&d, .roseGold, second: 0xFFD27A, cap: 0xFFD27A)
            FacePresets.standardInfo(&d, text: 0xFFF0D6, accent: 0xFFD27A, style: .goldSlant)
            d.secondFX = .sunburst; d.secondFXColor = Color(wm: 0xFFD27A)
            FacePresets.aodBackdrop(&d, "aodMountain", hand: 0xE0A24A, marks: 0x7A5A2B)
            return d
        },
        // ---- Theo mùa và lễ hội ----
        FacePreset(id: "noel", title: "Giáng sinh") {
            var d = FacePresets.base(0x04122A, 0x0B2A52)
            FacePresets.dayBackdrop(&d, "noelNight")
            d.decor = [DecorLayer(pattern: .noelStar, color: Color(wm: 0xFFE9A8), opacity: 0.3, scale: 0.9, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFE9A8)
            FacePresets.vectorHands(&d, .ruby, second: 0x2EC66D, cap: 0xFFE9A8)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF5A5A, style: .dotRuby)
            d.secondFX = .sparkle; d.secondFXColor = Color.white
            FacePresets.fall(&d, .snow, density: 0.5)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "tetMai", title: "Tết hoa mai") {
            var d = FacePresets.base(0x2A0A08, 0x6B1D10)
            FacePresets.dayBackdrop(&d, "tetMai")
            d.decor = [DecorLayer(pattern: .tetMai, color: Color(wm: 0xFFD84A), opacity: 0.35, scale: 0.85, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD84A)
            FacePresets.vectorHands(&d, .swordGold, second: 0xFF4015, cap: 0xFFD84A)
            FacePresets.standardInfo(&d, text: 0xFFF0B8, accent: 0xFFD84A, style: .dotAmber)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFD84A)
            FacePresets.fall(&d, .mai, density: 0.4)
            FacePresets.aodBackdrop(&d, "aodMai", hand: 0xC7862E, marks: 0x856B42)
            return d
        },
        FacePreset(id: "tetDao", title: "Tết hoa đào") {
            var d = FacePresets.base(0x2B0A14, 0x7A1D3A)
            FacePresets.dayBackdrop(&d, "tetDao")
            d.decor = [DecorLayer(pattern: .tetDao, color: Color(wm: 0xFFB3CF), opacity: 0.35, scale: 0.85, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFC9DC)
            FacePresets.vectorHands(&d, .roseGold, second: 0xFFD84A, cap: 0xFFC9DC)
            FacePresets.standardInfo(&d, text: 0xFFE4EF, accent: 0xFFB3CF, style: .dotRose)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFC9DC)
            FacePresets.fall(&d, .dao, density: 0.4)
            FacePresets.aodBackdrop(&d, "aodDao", hand: 0xD98AA8, marks: 0x7A3B52)
            return d
        },
        FacePreset(id: "tetPhao", title: "Pháo Tết") {
            var d = FacePresets.base(0x1A0206, 0x5A0A14)
            FacePresets.dayBackdrop(&d, "tetPhao")
            d.decor = [DecorLayer(pattern: .tetFirework, color: Color(wm: 0xFFD84A), opacity: 0.35, scale: 0.85, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD84A)
            FacePresets.vectorHands(&d, .royal, second: 0xFF4D5A, cap: 0xFFD84A)
            FacePresets.standardInfo(&d, text: 0xFFF0B8, accent: 0xFFD84A, style: .dotRuby)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFF6B4A)
            FacePresets.fall(&d, .firework, density: 0.45)
            FacePresets.aodBackdrop(&d, "aodPhao", hand: 0xC7862E, marks: 0x856B42)
            return d
        },
        FacePreset(id: "spring", title: "Xuân") {
            var d = FacePresets.base(0x0E2A1A, 0x2E7A4A)
            FacePresets.dayBackdrop(&d, "seasonSpring")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFF3B0)
            FacePresets.vectorHands(&d, .leaf, second: 0xFF7AA8, cap: 0xFFF3B0)
            FacePresets.standardInfo(&d, text: 0xF2FFE8, accent: 0xFFF3B0, style: .thinGold)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFB3CF)
            FacePresets.fall(&d, .petals, density: 0.35)
            FacePresets.aodBackdrop(&d, "aodSpring", hand: 0xB8D98A, marks: 0x4A6B3A)
            return d
        },
        FacePreset(id: "summer", title: "Hạ") {
            var d = FacePresets.base(0x04284A, 0x0E8FB5)
            FacePresets.dayBackdrop(&d, "seasonSummer")
            d.marks = .ticks; d.marksColor = Color.white
            FacePresets.vectorHands(&d, .sport, second: 0xFF5A36, cap: 0xFFD166)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFD166, style: .boldWhite, weekdayFX: 0)
            d.secondFX = .pulse; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.aodBackdrop(&d, "aodSummer", hand: 0xE0A24A, marks: 0x80651E)
            return d
        },
        FacePreset(id: "autumn", title: "Thu") {
            var d = FacePresets.base(0x2A1206, 0x8A3A12)
            FacePresets.dayBackdrop(&d, "seasonAutumn")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD08A)
            FacePresets.vectorHands(&d, .baroque, second: 0xFF5A2E, cap: 0xFFD08A)
            FacePresets.standardInfo(&d, text: 0xFFEBD0, accent: 0xFFB45A, style: .neonOrange)
            d.secondFX = .arc; d.secondFXColor = Color(wm: 0xFFB45A)
            FacePresets.fall(&d, .leaves, density: 0.45)
            FacePresets.aodBackdrop(&d, "aodAutumn", hand: 0xD98A3A, marks: 0x7A3F1A)
            return d
        },
        FacePreset(id: "winter", title: "Đông") {
            var d = FacePresets.base(0x050E1F, 0x2A4A78)
            FacePresets.dayBackdrop(&d, "seasonWinter")
            d.decor = [DecorLayer(pattern: .snowflake, color: Color(wm: 0xBFE1FF), opacity: 0.3, scale: 0.9, spin: .minute)]
            d.marks = .dots; d.marksColor = Color(wm: 0xE6F2FF)
            FacePresets.vectorHands(&d, .blueSteel, second: 0x7CC4FF, cap: 0xE6F2FF)
            FacePresets.standardInfo(&d, text: 0xEAF4FF, accent: 0xBFE1FF, style: .silverLine)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xE6F2FF)
            FacePresets.fall(&d, .snow, density: 0.5)
            FacePresets.aodBackdrop(&d, "aodWinter", hand: 0x8AA8D0, marks: 0x34506F)
            return d
        },
        // ---- Phong cách khác ----
        FacePreset(id: "moon", title: "Trăng khuya") {
            var d = FacePresets.base(0x03060F, 0x14213D)
            FacePresets.dayBackdrop(&d, "moonSea")
            d.decor = [DecorLayer(pattern: .moonPhases, color: Color(wm: 0xE6EEFF), opacity: 0.3, scale: 0.88, spin: .none)]
            d.marks = .dots; d.marksColor = Color(wm: 0xE6EEFF)
            FacePresets.vectorHands(&d, .dauphineSilver, second: 0xFFD166, cap: 0xE6EEFF)
            FacePresets.standardInfo(&d, text: 0xE6EEFF, accent: 0xCFE0FF, style: .silverLine)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xCFE0FF)
            FacePresets.aodBackdrop(&d, "aodMoon", hand: 0x9FB4D9, marks: 0x3E4F73)
            return d
        },
        FacePreset(id: "lotusPond", title: "Đầm sen") {
            var d = FacePresets.base(0x06201A, 0x1A5A4A)
            FacePresets.dayBackdrop(&d, "lotusPond")
            d.decor = [DecorLayer(pattern: .lotus, color: Color(wm: 0xFFC2D9), opacity: 0.35, scale: 0.85, spin: .second)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFD6E6)
            FacePresets.vectorHands(&d, .leafGold, second: 0xFF7AA8, cap: 0xFFD6E6)
            FacePresets.standardInfo(&d, text: 0xF2FFF6, accent: 0xFFC2D9, style: .dotRose)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFC2D9)
            FacePresets.fall(&d, .petals, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodWaves", hand: 0xD98AA8, marks: 0x2F6B5A)
            return d
        },
        FacePreset(id: "steampunk", title: "Cơ khí") {
            var d = FacePresets.base(0x1A0F06, 0x4A2A10)
            d.decor = [
                DecorLayer(pattern: .gear, color: Color(wm: 0xD9A441), opacity: 0.35, scale: 0.9, spin: .minute),
                DecorLayer(pattern: .gear, color: Color(wm: 0xB07A2A), opacity: 0.3, scale: 0.55, spin: .hour)
            ]
            d.marks = .numerals; d.numeralStyle = .arabicGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .cathedral, second: 0xE0572F, cap: 0xD9A441)
            FacePresets.standardInfo(&d, text: 0xF1D48A, accent: 0xD9A441, style: .goldHex)
            d.secondFX = .sunburst; d.secondFXColor = Color(wm: 0xD9A441)
            FacePresets.aodBackdrop(&d, "aodRings", hand: 0xB8892E, marks: 0x6B4A1F)
            return d
        },
        FacePreset(id: "compass", title: "La bàn") {
            var d = FacePresets.base(0x1A1408, 0x5A4420)
            FacePresets.dayBackdrop(&d, "dunes")
            d.decor = [DecorLayer(pattern: .compass, color: Color(wm: 0xF2D9A0), opacity: 0.35, scale: 0.9, spin: .none)]
            d.marks = .ticks; d.marksColor = Color(wm: 0xF2D9A0)
            FacePresets.vectorHands(&d, .arrow, second: 0xE0572F, cap: 0xF2D9A0)
            FacePresets.standardInfo(&d, text: 0xF8EBD0, accent: 0xF2D9A0, style: .silverTech)
            d.secondFX = .dotChase; d.secondFXColor = Color(wm: 0xF2D9A0)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "racing", title: "Đua xe") {
            var d = FacePresets.base(0x050505, 0x1C1C1C)
            d.decor = [DecorLayer(pattern: .laurel, color: Color(wm: 0xFF2D2D), opacity: 0.25, scale: 0.9, spin: .none)]
            d.marks = .ticks; d.marksColor = Color.white
            FacePresets.vectorHands(&d, .racing, second: 0xFF2D2D, cap: 0xFF2D2D)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF2D2D, style: .boldWhite, weekdayFX: 0)
            d.secondFX = .arc; d.secondFXColor = Color(wm: 0xFF2D2D)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xB82020, marks: 0x555555)
            return d
        },
        FacePreset(id: "dragonRed", title: "Rồng đỏ") {
            var d = FacePresets.base(0x3A0508, 0x8E1616)
            d.decor = [
                DecorLayer(pattern: .scales, color: Color(wm: 0xF2C879), opacity: 0.28, scale: 0.95, spin: .none),
                DecorLayer(pattern: .sunburst, color: Color(wm: 0xFF6B4A), opacity: 0.2, scale: 0.8, spin: .minute)
            ]
            d.marks = .ticks; d.marksColor = Color(wm: 0xF2C879)
            FacePresets.vectorHands(&d, .baroque, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xF2C879, style: .goldHex)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFFD24A)
            FacePresets.fall(&d, .firework, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "emerald", title: "Lục bảo") {
            var d = FacePresets.base(0x03201A, 0x0B5A46)
            d.decor = [DecorLayer(pattern: .laurel, color: Color(wm: 0xE8C872), opacity: 0.3, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.numeralStyle = .romanGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .swordGold, second: 0xFFD24A, cap: 0xE8C872)
            FacePresets.standardInfo(&d, text: 0xE6FFF1, accent: 0xE8C872, style: .goldHex)
            d.secondFX = .ticks; d.secondFXColor = Color(wm: 0xE8C872)
            FacePresets.aodBackdrop(&d, "aodBamboo", hand: 0xE8C872, marks: 0x2F6B5A)
            return d
        },
        FacePreset(id: "silverLight", title: "Bạc trắng") {
            var d = FacePresets.base(0xEDEEF0, 0xB9BEC8)
            d.textOutline = false
            d.decor = [DecorLayer(pattern: .ring, color: Color(wm: 0x1B1D22), opacity: 0.25, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.marksColor = Color(wm: 0x1B1D22)
            d.handStyle = .classic; d.handOutline = false
            d.hourColor = Color(wm: 0x1B1D22); d.minuteColor = Color(wm: 0x1B1D22)
            d.secondColor = Color(wm: 0xD0342C); d.capColor = Color(wm: 0xD0342C)
            FacePresets.standardInfo(&d, text: 0x1B1D22, accent: 0x1B1D22, style: .boldLine, weekdayFX: 0, plate: false)
            d.dataOwnColors = false; d.solarOwnColors = false; d.lunarOwnColors = false
            d.secondFX = .arc; d.secondFXColor = Color(wm: 0xD0342C)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xBBBBBB, marks: 0x555555)
            return d
        },
        FacePreset(id: "lcdRetro", title: "LCD cổ điển") {
            var d = FacePresets.base(0x23282A, 0x3A423F)
            d.decor = [DecorLayer(pattern: .hexGrid, color: Color(wm: 0xBFE3A0), opacity: 0.15, scale: 0.9, spin: .none)]
            d.marks = .ticks; d.marksColor = Color(wm: 0xC9D1C0)
            FacePresets.vectorHands(&d, .bar, second: 0xFF5A3C, cap: 0xC9D1C0)
            d.hourColor = Color(wm: 0xE6EBDD); d.minuteColor = Color(wm: 0xE6EBDD)
            d.handOwnColors = false
            FacePresets.standardInfo(&d, text: 0xD8E4C8, accent: 0xBFE3A0, style: .lcd, weekdayFX: 0)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .dotChase; d.secondFXColor = Color(wm: 0xBFE3A0)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0x9DB88A, marks: 0x4A5A44)
            return d
        },
        FacePreset(id: "sunsetRoad", title: "Hoàng hôn") {
            var d = FacePresets.base(0x2A1046, 0xF0764A)
            FacePresets.dayBackdrop(&d, "sunsetMountain")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFE3B0)
            FacePresets.vectorHands(&d, .sport, second: 0xFF7A3C, cap: 0xFFE3B0)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFD27A, style: .dotAmber)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .sunburst; d.secondFXColor = Color(wm: 0xFFD27A)
            FacePresets.aodBackdrop(&d, "aodMountain", hand: 0xE0894F, marks: 0x6B4A2F)
            return d
        },
        FacePreset(id: "moonNight", title: "Trăng đêm") {
            var d = FacePresets.base(0x050B1F, 0x123A63)
            FacePresets.dayBackdrop(&d, "moonSea")
            d.marks = .none
            FacePresets.vectorHands(&d, .luminousBlue, second: 0xFFD84A, cap: 0xBFE8FF)
            FacePresets.standardInfo(&d, text: 0xEAF4FF, accent: 0x9FD4FF, style: .neonBlue)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xBFE8FF)
            FacePresets.fall(&d, .snow, density: 0.2)
            FacePresets.aodBackdrop(&d, "aodMoon", hand: 0x9FB4D9, marks: 0x3E4F73)
            return d
        },
        FacePreset(id: "blackGold", title: "Đen vàng thể thao") {
            var d = FacePresets.base(0x030303, 0x14110A)
            d.decor = [DecorLayer(pattern: .hexGrid, color: Color(wm: 0xD9A441), opacity: 0.16, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.numeralStyle = .cardinalGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .chronograph, second: 0xFF3B2F, cap: 0xD9A441)
            FacePresets.standardInfo(&d, text: 0xF1D48A, accent: 0xD9A441, style: .goldHex)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0xD9A441)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "iceFruit", title: "Băng giá") {
            var d = FacePresets.base(0x0B1B3D, 0x6F9CCB)
            FacePresets.dayBackdrop(&d, "seasonWinter")
            d.marks = .ticks; d.marksColor = Color(wm: 0xE6F6FF)
            FacePresets.vectorHands(&d, .blueSteel, second: 0x38BDF8, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xF2FBFF, accent: 0xBFE8FF, style: .ledIce)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.fall(&d, .snow, density: 0.35)
            FacePresets.aodBackdrop(&d, "aodWinter", hand: 0x9CC4EA, marks: 0x3E5A7A)
            return d
        },
        FacePreset(id: "poolAqua", title: "Hồ bơi") {
            var d = FacePresets.base(0x0A3D91, 0x00B4D8)
            FacePresets.dayBackdrop(&d, "waves")
            d.marks = .numerals; d.numeralStyle = .lumeAqua; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .luminousAqua, second: 0xFFD84A, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xBFF3FF, style: .neonAqua)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xBFF3FF)
            FacePresets.aodBackdrop(&d, "aodWaves", hand: 0x7FE7FF, marks: 0x2F6B8A)
            return d
        },
        FacePreset(id: "fortune", title: "Phước lộc") {
            var d = FacePresets.base(0x4A0508, 0xB3201A)
            FacePresets.dayBackdrop(&d, "tetMai")
            d.marks = .numerals; d.numeralStyle = .chineseGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .royal, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xF2C879, style: .goldHex)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFD24A)
            FacePresets.fall(&d, .mai, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodMai", hand: 0xC7862E, marks: 0x856B42)
            return d
        },
        FacePreset(id: "auroraBand", title: "Cực quang") {
            var d = FacePresets.base(0x021018, 0x14083A)
            FacePresets.dayBackdrop(&d, "aurora")
            d.marks = .ticks; d.marksColor = Color(wm: 0xBFFFE8)
            FacePresets.vectorHands(&d, .luminousGreen, second: 0xFF7AD9, cap: 0xBFFFE8)
            FacePresets.standardInfo(&d, text: 0xEFFFF8, accent: 0x7CFFCB, style: .neonGreen)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0x7CFFCB)
            FacePresets.aodBackdrop(&d, "aodStars", hand: 0x5FBFA0, marks: 0x2F5A4F)
            return d
        },
        FacePreset(id: "cityNeon", title: "Phố đêm") {
            var d = FacePresets.base(0x070B1E, 0x2A1B5E)
            FacePresets.dayBackdrop(&d, "cityNight")
            d.marks = .dots; d.marksColor = Color(wm: 0xFF6AD5)
            FacePresets.vectorHands(&d, .future, second: 0x3DF5FF, cap: 0xFF6AD5)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF6AD5, style: .neonPurple)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0xFF6AD5)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xB04F9A, marks: 0x555555)
            return d
        },
        // ---- Giáng sinh ----
        FacePreset(id: "noelWreathFace", title: "Noel vòng thông") {
            var d = FacePresets.base(0x0A2A1F, 0x14513A)
            FacePresets.dayBackdrop(&d, "noelWreath")
            d.decor = [DecorLayer(pattern: .noelStar, color: Color(wm: 0xFFE9A8), opacity: 0.25, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.numeralStyle = .gemRuby; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .swordGold, second: 0xFF3B30, cap: 0xE8C872)
            FacePresets.standardInfo(&d, text: 0xF6FFF0, accent: 0xE8C872, style: .goldHex)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFE9A8)
            FacePresets.fall(&d, .snow, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodNoel", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelSnowTree", title: "Noel cây thông tuyết") {
            var d = FacePresets.base(0x050C28, 0x1D4673)
            FacePresets.dayBackdrop(&d, "noelNight")
            d.marks = .none
            FacePresets.vectorHands(&d, .luminousGreen, second: 0xFF4D4D, cap: 0xFFE9A8)
            FacePresets.standardInfo(&d, text: 0xF2FBFF, accent: 0xBFE8FF, style: .ledIce)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.fall(&d, .snow, density: 0.4)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelNeon", title: "Noel đèn màu") {
            var d = FacePresets.base(0x000000, 0x050014)
            d.decor = [DecorLayer(pattern: .noelStar, color: Color(wm: 0xFFD84A), opacity: 0.35, scale: 0.8, spin: .second)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFF4D6D)
            FacePresets.vectorHands(&d, .future, second: 0x39FF88, cap: 0xFFD84A)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF4D6D, style: .neonRuby)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .rainbow; d.secondFXColor = Color(wm: 0xFFD84A)
            FacePresets.fall(&d, .snow, density: 0.15)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelGilded", title: "Noel dát vàng") {
            var d = FacePresets.base(0x000000, 0x0B0B0B)
            d.decor = [
                DecorLayer(pattern: .noelWreath, color: Color(wm: 0xE8C872), opacity: 0.3, scale: 0.9, spin: .none),
                DecorLayer(pattern: .noelStar, color: Color(wm: 0xE8C872), opacity: 0.25, scale: 0.55, spin: .minute)
            ]
            d.marks = .ticks; d.marksColor = Color(wm: 0xE8C872)
            FacePresets.vectorHands(&d, .luxury, second: 0xE0302A, cap: 0xE8C872)
            FacePresets.standardInfo(&d, text: 0xF6DDA4, accent: 0xE8C872, style: .goldHex)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xE8C872)
            FacePresets.fall(&d, .snow, density: 0.2)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelSanta", title: "Ông già Noel") {
            var d = FacePresets.base(0x8E1616, 0xD23B2E)
            d.decor = [DecorLayer(pattern: .noelSnow, color: Color.white, opacity: 0.35, scale: 0.9, spin: .none)]
            d.marks = .numerals; d.numeralStyle = .badgeSilver; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .sword, second: 0xFFD84A, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFFFFF, style: .boldWhite)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.fall(&d, .snow, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodNoel", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelSnowman", title: "Noel người tuyết") {
            var d = FacePresets.base(0x0B1B3D, 0x6F9CCB)
            FacePresets.dayBackdrop(&d, "seasonWinter")
            d.decor = [DecorLayer(pattern: .snowflake, color: Color.white, opacity: 0.3, scale: 0.9, spin: .minute)]
            d.marks = .dots; d.marksColor = Color(wm: 0xFFFFFF)
            FacePresets.vectorHands(&d, .ruby, second: 0xFFD84A, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFB3B3, style: .dotRuby)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFD84A)
            FacePresets.fall(&d, .snow, density: 0.5)
            FacePresets.aodBackdrop(&d, "aodNoel", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        // ---- Tranh vẽ riêng (nền SVG mới) ----
        FacePreset(id: "artSanta", title: "Ông già Noel vui") {
            var d = FacePresets.base(0xB3201A, 0x7A0F12)
            FacePresets.dayBackdrop(&d, "artSanta")
            d.marks = .none
            FacePresets.vectorHands(&d, .dauphine, second: 0xFFD84A, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFD84A, style: .goldHex)
            FacePresets.columnsLayout(&d)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.fall(&d, .snow, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodNoel", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "artSnowman", title: "Người tuyết đêm đông") {
            var d = FacePresets.base(0x0B1B3D, 0x2D5A8C)
            FacePresets.dayBackdrop(&d, "artSnowman")
            d.marks = .dots; d.marksColor = Color(wm: 0xDDEEFF)
            FacePresets.vectorHands(&d, .blueSteel, second: 0xFF5A4D, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xBFE8FF, style: .ledIce)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFFFFF)
            FacePresets.fall(&d, .snow, density: 0.45)
            FacePresets.aodBackdrop(&d, "aodWinter", hand: 0x9CC4EA, marks: 0x3E5A7A)
            return d
        },
        FacePreset(id: "artLightTree", title: "Cây thông đèn màu") {
            var d = FacePresets.base(0x040A1A, 0x0A2A33)
            FacePresets.dayBackdrop(&d, "artLightTree")
            d.marks = .none
            FacePresets.vectorHands(&d, .luminousGreen, second: 0xFF4D6D, cap: 0xFFD84A)
            FacePresets.standardInfo(&d, text: 0xF2FFF6, accent: 0xFFD84A, style: .neonGreen)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFD84A)
            FacePresets.fall(&d, .snow, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "artDragon", title: "Rồng vàng") {
            var d = FacePresets.base(0x2A0306, 0x7A1010)
            FacePresets.dayBackdrop(&d, "artDragon")
            d.marks = .ticks; d.marksColor = Color(wm: 0xE8B040)
            FacePresets.vectorHands(&d, .baroque, second: 0xFFD24A, cap: 0xE8B040)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xE8B040, style: .goldHex)
            FacePresets.columnsLayout(&d)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFFD24A)
            FacePresets.fall(&d, .firework, density: 0.2)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "artSakura", title: "Anh đào dưới trăng") {
            var d = FacePresets.base(0x1A0F2E, 0x5C2A5E)
            FacePresets.dayBackdrop(&d, "artSakura")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFC2DA)
            FacePresets.vectorHands(&d, .roseGold, second: 0xFF5C8A, cap: 0xFFD1E3)
            FacePresets.standardInfo(&d, text: 0xFFF0F6, accent: 0xFFB3CF, style: .dotRose)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFC2DA)
            FacePresets.fall(&d, .petals, density: 0.35)
            FacePresets.aodBackdrop(&d, "aodMoon", hand: 0xD98AA8, marks: 0x7A3B52)
            return d
        },
        FacePreset(id: "artKoi", title: "Cá koi") {
            var d = FacePresets.base(0x063A4A, 0x0B6E6B)
            FacePresets.dayBackdrop(&d, "artKoi")
            d.marks = .ticks; d.marksColor = Color(wm: 0xBFFFF0)
            FacePresets.vectorHands(&d, .leafGold, second: 0xFF7A2E, cap: 0xFFE9B8)
            FacePresets.standardInfo(&d, text: 0xF0FFFB, accent: 0xBFF3FF, style: .neonAqua)
            FacePresets.columnsLayout(&d)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xBFF3FF)
            FacePresets.aodBackdrop(&d, "aodWaves", hand: 0x7FE7FF, marks: 0x2F6B8A)
            return d
        },
        FacePreset(id: "artPlanet", title: "Hành tinh") {
            var d = FacePresets.base(0x05030F, 0x1B0B3A)
            FacePresets.dayBackdrop(&d, "artPlanet")
            d.marks = .ticks; d.marksColor = Color(wm: 0xD8CCFF)
            FacePresets.vectorHands(&d, .future, second: 0xFF7AD9, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xF4F0FF, accent: 0xC9B8FF, style: .silverTech)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0xC9B8FF)
            FacePresets.aodBackdrop(&d, "aodStars", hand: 0x9B8AD9, marks: 0x3E3A66)
            return d
        },
        FacePreset(id: "artSynth", title: "Synthwave") {
            var d = FacePresets.base(0x12002E, 0x4A0A5C)
            FacePresets.dayBackdrop(&d, "artSynth")
            d.marks = .dots; d.marksColor = Color(wm: 0xFF4FD8)
            FacePresets.vectorHands(&d, .geometric, second: 0xFFD84A, cap: 0xFF4FD8)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF4FD8, style: .neonPurple)
            FacePresets.bigBottomLayout(&d)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFF4FD8)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xB04F9A, marks: 0x555555)
            return d
        },
        // ---- Phần 60: neon, ống neon, rồng chữ S, Tết neon (theo ảnh mẫu của chủ app) ----
        FacePreset(id: "noelTube", title: "Noel ống neon") {
            var d = FacePresets.base(0x000000, 0x050A1C)
            FacePresets.dayBackdrop(&d, "artNeonTree")
            d.marks = .dots; d.marksColor = Color(wm: 0xFF2DAE)
            FacePresets.vectorHands(&d, .future, second: 0xFF2D6F, cap: 0xFFD400)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0x2D9BFF, style: .tubeBlue, weekdayFX: 32)
            FacePresets.bigBottomLayout(&d)
            d.plates["digital"] = PlateStyle(shape: 17, fill: .black, line: Color(wm: 0x2D9BFF), opacity: 0.55, outline: true)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFD400)
            FacePresets.fall(&d, .snow, density: 0.2)
            FacePresets.aodBackdrop(&d, "aodNoelTree", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "noelRudolf", title: "Santa và Rudolf") {
            var d = FacePresets.base(0xCDEBDD, 0x8FCFB8)
            FacePresets.dayBackdrop(&d, "artReindeer")
            d.marks = .dots; d.marksColor = Color(wm: 0xE32A2A)
            FacePresets.vectorHands(&d, .ruby, second: 0x1F8A4C, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0x1F4A2C, accent: 0x1F8A4C, style: .ledGreen, weekdayFX: 39)
            FacePresets.bigBottomLayout(&d)
            d.plates["digital"] = PlateStyle(shape: 2, fill: .white, line: Color(wm: 0x1F8A4C), opacity: 0.85, outline: true)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xE32A2A)
            FacePresets.fall(&d, .snow, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodNoel", hand: 0xE8C77A, marks: 0x6B5A3A)
            return d
        },
        FacePreset(id: "dragonCarved", title: "Rồng khắc đỏ") {
            var d = FacePresets.base(0x4A0508, 0x9E1B1B)
            FacePresets.dayBackdrop(&d, "artDragonRed")
            d.marks = .ticks; d.marksColor = Color(wm: 0xF2C879)
            FacePresets.vectorHands(&d, .baroque, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xF2C879, style: .goldHex)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.plates["digital"] = PlateStyle(shape: 25, fill: .black, line: Color(wm: 0xF2C879), opacity: 0.55, outline: true)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFFD24A)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "dragonJade", title: "Rồng thanh long") {
            var d = FacePresets.base(0x02240F, 0x0C4A22)
            FacePresets.dayBackdrop(&d, "artDragonJade")
            d.marks = .numerals; d.numeralStyle = .arabicGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .cathedral, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xE8FFE8, accent: 0xF2C879, style: .goldPill)
            d.plates["digital"] = PlateStyle(shape: 4, fill: .black, line: Color(wm: 0xF2C879), opacity: 0.6, outline: true)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xF2C879)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "dragonTeal", title: "Rồng ngọc lam") {
            var d = FacePresets.base(0x0C4A3C, 0x1C7A66)
            FacePresets.dayBackdrop(&d, "artDragonTeal")
            d.marks = .ticks; d.marksColor = Color(wm: 0xE8B040)
            FacePresets.vectorHands(&d, .leafGold, second: 0xFF7A2E, cap: 0xE8B040)
            FacePresets.standardInfo(&d, text: 0xF0FFFB, accent: 0xE8B040, style: .dotGold)
            FacePresets.ringLayout(&d, spread: 1.22, grow: 1.2)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFE08A)
            FacePresets.aodBackdrop(&d, "aodWaves", hand: 0x7FE7FF, marks: 0x2F6B8A)
            return d
        },
        FacePreset(id: "dragonSilver", title: "Rồng bạc") {
            var d = FacePresets.base(0x3A0A14, 0x7A1E2C)
            FacePresets.dayBackdrop(&d, "artDragonSilver")
            d.marks = .numerals; d.numeralStyle = .cardinalGold; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .royal, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xFFE9D0, accent: 0xF2C879, style: .silverPill)
            d.plates["digital"] = PlateStyle(shape: 24, fill: .black, line: Color(wm: 0xF2C879), opacity: 0.5, outline: true)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFFD9B0)
            FacePresets.aodBackdrop(&d, "aodGold", hand: 0xC7A25A, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "tetNeonLantern", title: "Tết neon lồng đèn") {
            var d = FacePresets.base(0x1A0206, 0x4A0A12)
            FacePresets.dayBackdrop(&d, "artTetNeon")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFC857)
            FacePresets.vectorHands(&d, .luxury, second: 0xFF3B2F, cap: 0xFFC857)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xFFC857, style: .tubeTet, weekdayFX: 43)
            FacePresets.bigBottomLayout(&d)
            d.plates["digital"] = PlateStyle(shape: 24, fill: Color(wm: 0x3A0508), line: Color(wm: 0xFFC857), opacity: 0.7, outline: true)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFC857)
            FacePresets.fall(&d, .mai, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodMai", hand: 0xC7862E, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "tetLedMai", title: "Tết LED hoa mai") {
            var d = FacePresets.base(0x4A0508, 0xB3201A)
            FacePresets.dayBackdrop(&d, "tetMai")
            d.marks = .numerals; d.numeralStyle = .tetGlow; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .baroque, second: 0xFFD24A, cap: 0xF2C879)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xFFC857, style: .ledTet, weekdayFX: 41)
            d.plates["digital"] = PlateStyle(shape: 26, fill: Color(wm: 0x3A0508), line: Color(wm: 0xFFC857), opacity: 0.75, outline: true)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFD24A)
            FacePresets.fall(&d, .mai, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodMai", hand: 0xC7862E, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "tetDaoNeon", title: "Đào neon hồng") {
            var d = FacePresets.base(0x3A0D1E, 0x9E2A47)
            FacePresets.dayBackdrop(&d, "tetDao")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFC2DA)
            FacePresets.vectorHands(&d, .roseGold, second: 0xFF5C8A, cap: 0xFFD1E3)
            FacePresets.standardInfo(&d, text: 0xFFF0F6, accent: 0xFF7AC0, style: .tubePink, weekdayFX: 46)
            FacePresets.bigBottomLayout(&d)
            d.plates["digital"] = PlateStyle(shape: 17, fill: .black, line: Color(wm: 0xFF2DAE), opacity: 0.45, outline: true)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xFFC2DA)
            FacePresets.fall(&d, .dao, density: 0.3)
            FacePresets.aodBackdrop(&d, "aodDao", hand: 0xD98AA8, marks: 0x7A3B52)
            return d
        },
        FacePreset(id: "tetHanGold", title: "Tết Hán vàng") {
            var d = FacePresets.base(0x180510, 0x5C0F22)
            FacePresets.dayBackdrop(&d, "tetPhao")
            d.marks = .numerals; d.numeralStyle = .tetChinese; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .luxury, second: 0xFF3B2F, cap: 0xFFC857)
            FacePresets.standardInfo(&d, text: 0xFFE9B8, accent: 0xFFC857, style: .dotTet, weekdayFX: 44)
            d.plates["digital"] = PlateStyle(shape: 25, fill: .black, line: Color(wm: 0xFFC857), opacity: 0.6, outline: true)
            d.secondFX = .firework; d.secondFXColor = Color(wm: 0xFFC857)
            FacePresets.fall(&d, .firework, density: 0.25)
            FacePresets.aodBackdrop(&d, "aodPhao", hand: 0xC7862E, marks: 0x7A5F2B)
            return d
        },
        FacePreset(id: "neonPinkCity", title: "Neon hồng phố đêm") {
            var d = FacePresets.base(0x070B1E, 0x2A1B5E)
            FacePresets.dayBackdrop(&d, "cityNight")
            d.marks = .dots; d.marksColor = Color(wm: 0xFF2DAE)
            FacePresets.vectorHands(&d, .geometric, second: 0x2DD4FF, cap: 0xFF2DAE)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFF2DAE, style: .tubePink, weekdayFX: 33)
            FacePresets.bigBottomLayout(&d)
            d.plates["digital"] = PlateStyle(shape: 17, fill: .black, line: Color(wm: 0xFF2DAE), opacity: 0.5, outline: true)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xFF2DAE)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xB04F9A, marks: 0x555555)
            return d
        },
        FacePreset(id: "neonLimeTube", title: "Ống neon lục") {
            var d = FacePresets.base(0x000000, 0x06140A)
            d.marks = .numerals; d.numeralStyle = .tubeGreen; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .luminousGreen, second: 0xFF2D6F, cap: 0x7CFF24)
            FacePresets.standardInfo(&d, text: 0xE8FFE8, accent: 0x7CFF24, style: .tubeSegGreen, weekdayFX: 35)
            d.plates["digital"] = PlateStyle(shape: 22, fill: .black, line: Color(wm: 0x7CFF24), opacity: 0.6, outline: true)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0x7CFF24)
            FacePresets.aodBackdrop(&d, "aodRings", hand: 0x3FB300, marks: 0x1C6600)
            return d
        },
        FacePreset(id: "neonRainbow", title: "Neon cầu vồng") {
            var d = FacePresets.base(0x12002E, 0x4A0A5C)
            FacePresets.dayBackdrop(&d, "artSynth")
            d.marks = .numerals; d.numeralStyle = .neonCyan; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .future, second: 0xFFD84A, cap: 0xFF4FD8)
            FacePresets.standardInfo(&d, text: 0xFFFFFF, accent: 0xFFE02A, style: .neonYellow, weekdayFX: 37)
            d.plates["digital"] = PlateStyle(shape: 21, fill: .black, line: Color(wm: 0xFFE02A), opacity: 0.5, outline: true)
            d.secondFX = .rainbow; d.secondFXColor = Color(wm: 0xFFD84A)
            FacePresets.aodBackdrop(&d, "aodDots", hand: 0xB04F9A, marks: 0x555555)
            return d
        },
        FacePreset(id: "neonWhiteMinimal", title: "Neon trắng tối giản") {
            var d = FacePresets.base(0x000000, 0x0A0A12)
            d.marks = .numerals; d.numeralStyle = .neonWhite; d.numeralOwnColors = true
            FacePresets.vectorHands(&d, .minimalist, second: 0xFF4D6D, cap: 0xFFFFFF)
            FacePresets.standardInfo(&d, text: 0xF4F8FF, accent: 0xDCE8FF, style: .ledWhite, weekdayFX: 25)
            d.plates["digital"] = PlateStyle(shape: 18, fill: .black, line: Color(wm: 0xDCE8FF), opacity: 0.5, outline: true)
            d.secondFX = .pulse; d.secondFXColor = Color(wm: 0xDCE8FF)
            FacePresets.aodBackdrop(&d, "aodRings", hand: 0x9FB4E0, marks: 0x5A6B96)
            return d
        }
    ]
}

/// Ảnh xem trước nhỏ của từng mẫu (vẽ bằng chính bộ vẽ mặt đồng hồ, lưu nhớ tạm).
enum FacePresetThumbs {
    private static let cache = LockedCache<String, UIImage>()

    static func image(_ p: FacePreset) -> UIImage {
        if let c = cache[p.id] { return c }
        let img = FaceRenderer.image(design: p.make(), ambient: false, pixels: 128, circle: true)
        cache[p.id] = img
        return img
    }
}
