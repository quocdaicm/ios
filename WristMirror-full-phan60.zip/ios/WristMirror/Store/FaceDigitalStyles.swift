// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Kiểu số giờ kỹ thuật số vector (48 kiểu): 7 đoạn LCD/LED, chấm ma trận, pixel, nét đơn neon/mảnh/tròn.
// Hình số được dựng từ path (cùng bộ vẽ SVG của app) rồi tô phẳng / dải kim loại / quầng sáng / viền rỗng,
// vẽ thành ảnh nên không cần cài font lên đồng hồ. Bản xem trước SVG: so-gio-ky-thuat-so-13-00.svg.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Tên case (rawValue) phải trùng khoá trong `DigitalShapes.table`; `.classic` = kiểu cũ (số thường theo font số).
enum DigitalStyle: String, CaseIterable, Identifiable {
    case classic
    case lcd, lcdPill, lcdSlant, ledRed, futureBlue, silverTech, goldHex, roseGold, neonAqua, neonPurple, thinLine, roundGold, outlineSeg, dotMatrix, dotAmber, diamondGold, pixel
    case ledGreen, ledAmber, ledViolet, ledIce, goldSlant, roseSlant, silverPill, goldPill, bluePill, rubyChunk, thinSeg, outlineGold, outlineRuby, boldWhite, outlinePill, dotRose, dotBlue, dotRuby, dotSilver, neonGreen, neonOrange, neonRuby, neonBlue, silverLine, roseLine, thinGold, boldLine, pixelGreen, pixelGold, pixelRuby, pixelIce
    // Phần 60: neon, ống neon, LED/chấm/pixel màu mới và kiểu Tết
    case neonPink, neonYellow, neonWhite, neonLime, neonGold, neonTet
    case tubeBlue, tubeRed, tubePink, tubeGreen, tubeGold, tubeWhite, tubeTet
    case tubeSegBlue, tubeSegPink, tubeSegGreen
    case ledPink, ledLime, ledWhite, ledTet
    case dotPink, dotGold, dotTet, dotLime
    case pixelPink, pixelTet, pixelLime
    var id: String { rawValue }
    var title: String { self == .classic ? "Số thường" : (DigitalShapes.titles[rawValue] ?? rawValue) }
    var def: DigitalShapes.Def? { DigitalShapes.table[rawValue] }
    /// Có bảng màu riêng (kim loại, LED, neon) - tắt "màu gốc" thì suy ra từ màu chữ.
    var hasOwnPalette: Bool { def?.pal != nil }
}

enum DigitalShapes {
    struct Def {
        enum Geo { case seven, matrix, pixel, line }
        enum Shape { case hex, bar, cut }
        enum Dot { case round, square, diamond }
        /// `.tube` = ống neon: viền sáng có lõi trắng, ruột tối (kiểu số rỗng phát sáng như đèn neon thật).
        enum Paint {
            case flat, metal, glow, outline, tube
            /// Có quầng sáng toả ra ngoài (cần lề rộng hơn quanh ô số).
            var glows: Bool { self == .glow || self == .tube }
        }
        var geo: Geo
        var paint: Paint
        var pal: HandPal? = nil
        /// Vẽ mờ các đoạn/chấm đang tắt (kiểu số "8" mờ phía sau).
        var ghost = false
        // Kiểu 7 đoạn
        var shape: Shape = .hex
        var thick: CGFloat = 12
        var gap: CGFloat = 2.4
        var slant: CGFloat = 0
        var pill = false
        // Kiểu chấm ma trận 5x7
        var dot: Dot = .round
        // Kiểu nét đơn (độ dày nét, đơn vị hộp 100 cao)
        var stroke: CGFloat = 6
    }

    static let table: [String: Def] = {
        var t = [String: Def]()
        t["lcd"] = Def(geo: .seven, paint: .flat, ghost: true, shape: .hex, thick: 13, gap: 2.4)
        t["lcdPill"] = Def(geo: .seven, paint: .flat, ghost: true, shape: .bar, thick: 12, gap: 3.6, pill: true)
        t["lcdSlant"] = Def(geo: .seven, paint: .metal, pal: HP.silver, shape: .hex, thick: 12, gap: 2.4, slant: 0.16)
        t["ledRed"] = Def(geo: .seven, paint: .glow, pal: HP.ruby, ghost: true, shape: .cut, thick: 12, gap: 2.8)
        t["futureBlue"] = Def(geo: .seven, paint: .glow, pal: HP.future, ghost: true, shape: .cut, thick: 6.5, gap: 3.2)
        t["silverTech"] = Def(geo: .seven, paint: .metal, pal: HP.silver, ghost: true, shape: .bar, thick: 11, gap: 2.8)
        t["goldHex"] = Def(geo: .seven, paint: .metal, pal: HP.gold, shape: .hex, thick: 14, gap: 2.4)
        t["roseGold"] = Def(geo: .seven, paint: .metal, pal: HP.rose, shape: .bar, thick: 12, gap: 3.6, pill: true)
        t["neonAqua"] = Def(geo: .line, paint: .glow, pal: HP.aqua, stroke: 6.5)
        t["neonPurple"] = Def(geo: .line, paint: .glow, pal: HP.purple, stroke: 5.0)
        t["thinLine"] = Def(geo: .line, paint: .flat, stroke: 3.4)
        t["roundGold"] = Def(geo: .line, paint: .metal, pal: HP.gold, stroke: 11.0)
        t["outlineSeg"] = Def(geo: .seven, paint: .outline, pal: HP.lblue, shape: .hex, thick: 15, gap: 2.8)
        t["dotMatrix"] = Def(geo: .matrix, paint: .glow, pal: HP.green, ghost: true, dot: .round)
        t["dotAmber"] = Def(geo: .matrix, paint: .glow, pal: HP.orange, ghost: true, dot: .square)
        t["diamondGold"] = Def(geo: .matrix, paint: .metal, pal: HP.gold, dot: .diamond)
        t["pixel"] = Def(geo: .pixel, paint: .flat)
        t["ledGreen"] = Def(geo: .seven, paint: .glow, pal: HP.green, ghost: true, shape: .cut, thick: 11, gap: 2.8)
        t["ledAmber"] = Def(geo: .seven, paint: .glow, pal: HP.orange, ghost: true, shape: .bar, thick: 11, gap: 3.0)
        t["ledViolet"] = Def(geo: .seven, paint: .glow, pal: HP.purple, ghost: true, shape: .hex, thick: 11, gap: 2.6, slant: 0.12)
        t["ledIce"] = Def(geo: .seven, paint: .glow, pal: HP.aqua, ghost: true, shape: .cut, thick: 8, gap: 3.0)
        t["goldSlant"] = Def(geo: .seven, paint: .metal, pal: HP.gold, shape: .hex, thick: 12, gap: 2.4, slant: 0.14)
        t["roseSlant"] = Def(geo: .seven, paint: .metal, pal: HP.rose, shape: .cut, thick: 11, gap: 2.6, slant: 0.12)
        t["silverPill"] = Def(geo: .seven, paint: .metal, pal: HP.silver, ghost: true, shape: .bar, thick: 12, gap: 3.6, pill: true)
        t["goldPill"] = Def(geo: .seven, paint: .metal, pal: HP.gold, shape: .bar, thick: 12, gap: 3.6, pill: true)
        t["bluePill"] = Def(geo: .seven, paint: .glow, pal: HP.future, ghost: true, shape: .bar, thick: 11, gap: 3.6, pill: true)
        t["rubyChunk"] = Def(geo: .seven, paint: .metal, pal: HP.ruby, shape: .hex, thick: 17, gap: 2.2)
        t["thinSeg"] = Def(geo: .seven, paint: .flat, shape: .cut, thick: 4.5, gap: 3.5)
        t["outlineGold"] = Def(geo: .seven, paint: .outline, pal: HP.gold, shape: .cut, thick: 16, gap: 2.8)
        t["outlineRuby"] = Def(geo: .seven, paint: .outline, pal: HP.ruby, shape: .bar, thick: 15, gap: 3.0)
        t["boldWhite"] = Def(geo: .seven, paint: .flat, shape: .bar, thick: 18, gap: 2.4)
        t["outlinePill"] = Def(geo: .seven, paint: .outline, pal: HP.aqua, shape: .bar, thick: 13, gap: 3.6, pill: true)
        t["dotRose"] = Def(geo: .matrix, paint: .metal, pal: HP.rose, dot: .round)
        t["dotBlue"] = Def(geo: .matrix, paint: .glow, pal: HP.future, ghost: true, dot: .diamond)
        t["dotRuby"] = Def(geo: .matrix, paint: .glow, pal: HP.ruby, ghost: true, dot: .round)
        t["dotSilver"] = Def(geo: .matrix, paint: .metal, pal: HP.silver, dot: .square)
        t["neonGreen"] = Def(geo: .line, paint: .glow, pal: HP.green, stroke: 5.5)
        t["neonOrange"] = Def(geo: .line, paint: .glow, pal: HP.orange, stroke: 6.0)
        t["neonRuby"] = Def(geo: .line, paint: .glow, pal: HP.ruby, stroke: 5.5)
        t["neonBlue"] = Def(geo: .line, paint: .glow, pal: HP.future, stroke: 6.0)
        t["silverLine"] = Def(geo: .line, paint: .metal, pal: HP.silver, stroke: 9.0)
        t["roseLine"] = Def(geo: .line, paint: .metal, pal: HP.rose, stroke: 10.0)
        t["thinGold"] = Def(geo: .line, paint: .flat, pal: HP.gold, stroke: 3.4)
        t["boldLine"] = Def(geo: .line, paint: .flat, stroke: 9.0)
        t["pixelGreen"] = Def(geo: .pixel, paint: .glow, pal: HP.green)
        t["pixelGold"] = Def(geo: .pixel, paint: .metal, pal: HP.gold)
        t["pixelRuby"] = Def(geo: .pixel, paint: .glow, pal: HP.ruby)
        t["pixelIce"] = Def(geo: .pixel, paint: .flat, pal: HP.aqua)
        // Phần 60 - neon nét đơn
        t["neonPink"] = Def(geo: .line, paint: .glow, pal: HP.pink, stroke: 5.5)
        t["neonYellow"] = Def(geo: .line, paint: .glow, pal: HP.yellow, stroke: 5.5)
        t["neonWhite"] = Def(geo: .line, paint: .glow, pal: HP.white, stroke: 5.0)
        t["neonLime"] = Def(geo: .line, paint: .glow, pal: HP.lime, stroke: 5.5)
        t["neonGold"] = Def(geo: .line, paint: .glow, pal: HP.tetGold, stroke: 6.5)
        t["neonTet"] = Def(geo: .line, paint: .glow, pal: HP.tetRed, stroke: 6.5)
        // Ống neon rỗng (số dày, viền sáng, lõi trắng)
        t["tubeBlue"] = Def(geo: .line, paint: .tube, pal: HP.cyan, stroke: 11.0)
        t["tubeRed"] = Def(geo: .line, paint: .tube, pal: HP.hotRed, stroke: 11.0)
        t["tubePink"] = Def(geo: .line, paint: .tube, pal: HP.pink, stroke: 11.0)
        t["tubeGreen"] = Def(geo: .line, paint: .tube, pal: HP.lime, stroke: 11.0)
        t["tubeGold"] = Def(geo: .line, paint: .tube, pal: HP.tetGold, stroke: 11.0)
        t["tubeWhite"] = Def(geo: .line, paint: .tube, pal: HP.white, stroke: 11.0)
        t["tubeTet"] = Def(geo: .line, paint: .tube, pal: HP.tetRed, stroke: 11.5)
        t["tubeSegBlue"] = Def(geo: .seven, paint: .tube, pal: HP.cyan, ghost: true, shape: .bar, thick: 14, gap: 3.4, pill: true)
        t["tubeSegPink"] = Def(geo: .seven, paint: .tube, pal: HP.pink, ghost: true, shape: .hex, thick: 14, gap: 3.0)
        t["tubeSegGreen"] = Def(geo: .seven, paint: .tube, pal: HP.lime, ghost: true, shape: .cut, thick: 14, gap: 3.2)
        // LED 7 đoạn màu mới
        t["ledPink"] = Def(geo: .seven, paint: .glow, pal: HP.pink, ghost: true, shape: .cut, thick: 11, gap: 2.8)
        t["ledLime"] = Def(geo: .seven, paint: .glow, pal: HP.lime, ghost: true, shape: .bar, thick: 11, gap: 3.0)
        t["ledWhite"] = Def(geo: .seven, paint: .glow, pal: HP.white, ghost: true, shape: .hex, thick: 10, gap: 2.6)
        t["ledTet"] = Def(geo: .seven, paint: .glow, pal: HP.tetRed, ghost: true, shape: .cut, thick: 12, gap: 2.8, slant: 0.1)
        // Chấm ma trận
        t["dotPink"] = Def(geo: .matrix, paint: .glow, pal: HP.pink, ghost: true, dot: .round)
        t["dotGold"] = Def(geo: .matrix, paint: .glow, pal: HP.tetGold, ghost: true, dot: .diamond)
        t["dotTet"] = Def(geo: .matrix, paint: .glow, pal: HP.tetRed, ghost: true, dot: .round)
        t["dotLime"] = Def(geo: .matrix, paint: .glow, pal: HP.lime, ghost: true, dot: .square)
        // Pixel
        t["pixelPink"] = Def(geo: .pixel, paint: .glow, pal: HP.pink)
        t["pixelTet"] = Def(geo: .pixel, paint: .glow, pal: HP.tetRed)
        t["pixelLime"] = Def(geo: .pixel, paint: .glow, pal: HP.lime)
        return t
    }()

    static let titles: [String: String] = [
        "lcd": "LCD Cổ Điển",
        "lcdPill": "Viên Thuốc",
        "lcdSlant": "Thể Thao",
        "ledRed": "LED Đỏ",
        "futureBlue": "Tương Lai",
        "silverTech": "Bạc Công Nghệ",
        "goldHex": "Vàng Lục Giác",
        "roseGold": "Hồng Viên Thuốc",
        "neonAqua": "Neon Ngọc",
        "neonPurple": "Neon Tím",
        "thinLine": "Nét Mảnh",
        "roundGold": "Tròn Vàng",
        "outlineSeg": "Viền Rỗng",
        "dotMatrix": "Chấm Tròn",
        "dotAmber": "LED Vuông",
        "diamondGold": "Chấm Thoi Vàng",
        "pixel": "Pixel 8-bit",
        "ledGreen": "LED Xanh Lá",
        "ledAmber": "LED Hổ Phách",
        "ledViolet": "LED Tím Nghiêng",
        "ledIce": "LED Băng Mảnh",
        "goldSlant": "Vàng Nghiêng",
        "roseSlant": "Hồng Nghiêng",
        "silverPill": "Bạc Viên Thuốc",
        "goldPill": "Vàng Viên Thuốc",
        "bluePill": "Xanh Viên Thuốc",
        "rubyChunk": "Ruby Dày",
        "thinSeg": "Đoạn Mảnh",
        "outlineGold": "Viền Vàng",
        "outlineRuby": "Viền Đỏ",
        "boldWhite": "Trắng Đậm",
        "outlinePill": "Viền Viên Thuốc",
        "dotRose": "Chấm Hồng",
        "dotBlue": "Chấm Thoi Xanh",
        "dotRuby": "Chấm Đỏ",
        "dotSilver": "Chấm Vuông Bạc",
        "neonGreen": "Neon Xanh Lá",
        "neonOrange": "Neon Cam",
        "neonRuby": "Neon Đỏ",
        "neonBlue": "Neon Xanh",
        "silverLine": "Tròn Bạc",
        "roseLine": "Tròn Hồng",
        "thinGold": "Nét Mảnh Vàng",
        "boldLine": "Nét Đậm",
        "pixelGreen": "Pixel Xanh Lá",
        "pixelGold": "Pixel Vàng",
        "pixelRuby": "Pixel Đỏ",
        "pixelIce": "Pixel Băng",
        "neonPink": "Neon Hồng",
        "neonYellow": "Neon Vàng",
        "neonWhite": "Neon Trắng",
        "neonLime": "Neon Chanh",
        "neonGold": "Neon Vàng Kim",
        "neonTet": "Neon Tết",
        "tubeBlue": "Ống Neon Xanh",
        "tubeRed": "Ống Neon Đỏ",
        "tubePink": "Ống Neon Hồng",
        "tubeGreen": "Ống Neon Lục",
        "tubeGold": "Ống Neon Vàng",
        "tubeWhite": "Ống Neon Trắng",
        "tubeTet": "Ống Neon Tết",
        "tubeSegBlue": "Ống LED Xanh",
        "tubeSegPink": "Ống LED Hồng",
        "tubeSegGreen": "Ống LED Lục",
        "ledPink": "LED Hồng",
        "ledLime": "LED Chanh",
        "ledWhite": "LED Trắng",
        "ledTet": "LED Tết",
        "dotPink": "Chấm Neon Hồng",
        "dotGold": "Chấm Thoi Neon Vàng",
        "dotTet": "Chấm Tết",
        "dotLime": "Chấm Vuông Chanh",
        "pixelPink": "Pixel Hồng",
        "pixelTet": "Pixel Tết",
        "pixelLime": "Pixel Chanh"
    ]

    // MARK: - Hình học (hộp số cao 100 đơn vị, gốc trên-trái)

    private static let segs: [String: String] = ["0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg", "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg"]

    private static let font57: [String: [String]] = [
        "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
        "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
        "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
        "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
        "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
        "5": ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
        "6": ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
        "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
        "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
        "9": ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
        "/": ["00001", "00010", "00010", "00100", "01000", "01000", "10000"],
        "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"]
    ]

    private static let font35: [String: [String]] = [
        "0": ["111", "101", "101", "101", "111"],
        "1": ["010", "110", "010", "010", "111"],
        "2": ["111", "001", "111", "100", "111"],
        "3": ["111", "001", "111", "001", "111"],
        "4": ["101", "101", "111", "001", "001"],
        "5": ["111", "100", "111", "001", "111"],
        "6": ["111", "100", "111", "101", "111"],
        "7": ["111", "001", "010", "010", "010"],
        "8": ["111", "101", "111", "101", "111"],
        "9": ["111", "101", "111", "001", "111"],
        "/": ["001", "001", "010", "100", "100"],
        "-": ["000", "000", "111", "000", "000"]
    ]

    /// Đường xương của số kiểu nét đơn (M L C Z, hộp 60 x 100).
    private static let skeleton: [String: String] = [
        "0": "M30 8 C13 8 8 28 8 50 C8 72 13 92 30 92 C47 92 52 72 52 50 C52 28 47 8 30 8 Z",
        "1": "M16 30 L34 10 L34 92",
        "2": "M10 28 C10 14 20 8 30 8 C42 8 51 16 51 29 C51 46 34 62 10 92 L52 92",
        "3": "M10 16 C18 8 42 4 49 21 C53 36 40 46 22 46 C40 46 56 56 51 74 C46 94 18 96 8 82",
        "4": "M42 92 L42 8 L6 66 L56 66",
        "5": "M50 8 L14 8 L10 46 C20 38 36 36 46 46 C57 58 52 80 40 88 C28 96 14 92 8 82",
        "6": "M46 12 C36 4 18 8 12 30 L10 62 C8 84 22 96 32 94 C46 92 54 78 52 66 C50 52 38 46 26 48 C16 50 10 58 10 62",
        "7": "M8 8 L52 8 L22 92",
        "8": "M30 48 C12 48 10 28 14 20 C18 10 42 10 46 20 C50 28 48 48 30 48 C10 48 6 70 12 82 C18 94 42 94 48 82 C54 70 50 48 30 48 Z",
        "9": "M14 88 C24 96 42 92 48 70 L50 38 C52 16 38 4 28 6 C14 8 6 22 8 34 C10 48 22 54 34 52 C44 50 50 42 50 38",
        "/": "M38 8 L12 92",
        "-": "M9 50 L41 50"
    ]

    struct Glyph {
        let on: CGPath
        let off: CGPath
        /// Đường `on` là xương nét - phải tô nét (độ dày `Def.stroke`) mới ra hình.
        let stroked: Bool
    }

    static func digitWidth(_ d: Def) -> CGFloat {
        switch d.geo {
        case .seven: return 60 + d.slant * 100
        case .matrix: return 62
        case .pixel, .line: return 60
        }
    }

    static func colonWidth(_ d: Def) -> CGFloat {
        switch d.geo {
        case .seven: return d.thick * 1.9 + 4 + d.slant * 100 * 0.5
        case .matrix: return 26
        case .pixel: return 18
        case .line: return 22
        }
    }

    /// Bề rộng dấu phân cách ngày/tháng ("/" hoặc "-").
    static func sepWidth(_ d: Def) -> CGFloat {
        switch d.geo {
        case .seven: return 38 + d.slant * 100 * 0.5
        case .matrix: return 62
        case .pixel: return 60
        case .line: return 50
        }
    }

    static func charWidth(_ d: Def, _ ch: Character) -> CGFloat {
        switch ch {
        case ":": return colonWidth(d)
        case "/", "-": return sepWidth(d)
        default: return digitWidth(d)
        }
    }

    static func glyph(_ d: Def, _ ch: Character) -> Glyph {
        switch d.geo {
        case .seven:
            if ch == ":" { return sevenColon(d) }
            if ch == "/" || ch == "-" { return sevenSep(d, ch) }
            return sevenDigit(d, ch)
        case .matrix: return matrixGlyph(d, ch)
        case .pixel: return pixelGlyph(ch)
        case .line: return lineGlyph(ch)
        }
    }

    private static func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x, y: y) }

    private static func sevenPolys(_ d: Def) -> [String: [CGPoint]] {
        let w: CGFloat = 60
        let t = d.thick, g = d.gap, h = t / 2
        let top = h, mid: CGFloat = 50, bot: CGFloat = 100 - h
        let l = h, r = w - h
        func hor(_ y: CGFloat) -> [CGPoint] {
            switch d.shape {
            case .hex:
                return [pt(l + g, y), pt(l + g + h, y - h), pt(r - g - h, y - h), pt(r - g, y), pt(r - g - h, y + h), pt(l + g + h, y + h)]
            case .bar:
                return [pt(l + g, y - h), pt(r - g, y - h), pt(r - g, y + h), pt(l + g, y + h)]
            case .cut:
                let c = h * 0.7
                return [pt(l + g + c, y - h), pt(r - g - c, y - h), pt(r - g, y), pt(r - g - c, y + h), pt(l + g + c, y + h), pt(l + g, y)]
            }
        }
        func ver(_ x: CGFloat, _ y0: CGFloat, _ y1: CGFloat) -> [CGPoint] {
            switch d.shape {
            case .hex:
                return [pt(x, y0 + g), pt(x + h, y0 + g + h), pt(x + h, y1 - g - h), pt(x, y1 - g), pt(x - h, y1 - g - h), pt(x - h, y0 + g + h)]
            case .bar:
                return [pt(x - h, y0 + g), pt(x + h, y0 + g), pt(x + h, y1 - g), pt(x - h, y1 - g)]
            case .cut:
                let c = h * 0.7
                return [pt(x - h, y0 + g + c), pt(x, y0 + g), pt(x + h, y0 + g + c), pt(x + h, y1 - g - c), pt(x, y1 - g), pt(x - h, y1 - g - c)]
            }
        }
        return ["a": hor(top), "g": hor(mid), "d": hor(bot),
                "f": ver(l, top, mid), "b": ver(r, top, mid),
                "e": ver(l, mid, bot), "c": ver(r, mid, bot)]
    }

    private static func sevenDigit(_ d: Def, _ ch: Character) -> Glyph {
        let polys = sevenPolys(d)
        let lit = segs[String(ch)] ?? ""
        let on = CGMutablePath()
        let off = CGMutablePath()
        for s in ["a", "b", "c", "d", "e", "f", "g"] {
            guard var pts = polys[s] else { continue }
            if d.slant != 0 { pts = pts.map { pt($0.x + d.slant * (100 - $0.y), $0.y) } }
            let target = lit.contains(s) ? on : off
            if d.pill && d.slant == 0 {
                let xs = pts.map { $0.x }, ys = pts.map { $0.y }
                let r = CGRect(x: xs.min() ?? 0, y: ys.min() ?? 0, width: (xs.max() ?? 0) - (xs.min() ?? 0), height: (ys.max() ?? 0) - (ys.min() ?? 0))
                let rad = min(r.width, r.height) / 2
                target.addPath(CGPath(roundedRect: r, cornerWidth: rad, cornerHeight: rad, transform: nil))
            } else if let first = pts.first {
                target.move(to: first)
                for p in pts.dropFirst() { target.addLine(to: p) }
                target.closeSubpath()
            }
        }
        return Glyph(on: on, off: off, stroked: false)
    }

    /// Dấu "-" (đoạn giữa) và "/" (thanh chéo) của kiểu 7 đoạn, hộp rộng `sepWidth`.
    private static func sevenSep(_ d: Def, _ ch: Character) -> Glyph {
        let w: CGFloat = 38
        let t = d.thick, h = t / 2
        var pts: [CGPoint]
        var rect: CGRect? = nil
        if ch == "-" {
            let c = h * 0.7
            switch d.shape {
            case .hex:
                pts = [pt(0, 50), pt(h, 50 - h), pt(w - h, 50 - h), pt(w, 50), pt(w - h, 50 + h), pt(h, 50 + h)]
            case .bar:
                pts = [pt(0, 50 - h), pt(w, 50 - h), pt(w, 50 + h), pt(0, 50 + h)]
            case .cut:
                pts = [pt(c, 50 - h), pt(w - c, 50 - h), pt(w, 50), pt(w - c, 50 + h), pt(c, 50 + h), pt(0, 50)]
            }
            if d.pill && d.slant == 0 { rect = CGRect(x: 0, y: 50 - h, width: w, height: t) }
        } else {
            let k = t * 1.15
            pts = [pt(2, 94), pt(2 + k, 94), pt(w - 2, 6), pt(w - 2 - k, 6)]
        }
        if d.slant != 0 { pts = pts.map { pt($0.x + d.slant * (100 - $0.y), $0.y) } }
        let on = CGMutablePath()
        if let r = rect {
            on.addPath(CGPath(roundedRect: r, cornerWidth: r.height / 2, cornerHeight: r.height / 2, transform: nil))
        } else if let first = pts.first {
            on.move(to: first)
            for p in pts.dropFirst() { on.addLine(to: p) }
            on.closeSubpath()
        }
        return Glyph(on: on, off: CGMutablePath(), stroked: false)
    }

    private static func sevenColon(_ d: Def) -> Glyph {
        let cw = colonWidth(d)
        let r = d.thick * 0.62
        let on = CGMutablePath()
        for y in [CGFloat(30), CGFloat(70)] {
            let x = cw / 2 + d.slant * (100 - y)
            if d.shape == .bar && !d.pill {
                on.addPath(CGPath(roundedRect: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r), cornerWidth: 1.5, cornerHeight: 1.5, transform: nil))
            } else if d.shape == .hex {
                let q = r * 1.15
                on.move(to: pt(x, y - q))
                on.addLine(to: pt(x + q, y))
                on.addLine(to: pt(x, y + q))
                on.addLine(to: pt(x - q, y))
                on.closeSubpath()
            } else {
                on.addEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
            }
        }
        return Glyph(on: on, off: CGMutablePath(), stroked: false)
    }

    private static func matrixGlyph(_ d: Def, _ ch: Character) -> Glyph {
        let pitchX: CGFloat = 62 / 5
        let pitchY: CGFloat = 100 / 7
        let p = min(pitchX, pitchY)
        func shape(_ cx: CGFloat, _ cy: CGFloat) -> CGPath {
            switch d.dot {
            case .round:
                let r = p * 0.40
                return CGPath(ellipseIn: CGRect(x: cx - r, y: cy - r, width: 2 * r, height: 2 * r), transform: nil)
            case .square:
                let s = p * 0.84
                return CGPath(roundedRect: CGRect(x: cx - s / 2, y: cy - s / 2, width: s, height: s), cornerWidth: 2, cornerHeight: 2, transform: nil)
            case .diamond:
                let q = p * 0.5
                let m = CGMutablePath()
                m.move(to: pt(cx, cy - q))
                m.addLine(to: pt(cx + q, cy))
                m.addLine(to: pt(cx, cy + q))
                m.addLine(to: pt(cx - q, cy))
                m.closeSubpath()
                return m
            }
        }
        let on = CGMutablePath()
        let off = CGMutablePath()
        if ch == ":" {
            for y in [CGFloat(100) * 2.5 / 7, CGFloat(100) * 4.5 / 7] { on.addPath(shape(13, y)) }
            return Glyph(on: on, off: off, stroked: false)
        }
        let rows = font57[String(ch)] ?? []
        for (r, line) in rows.enumerated() {
            for (c, bit) in line.enumerated() {
                let cell = shape(pitchX * (CGFloat(c) + 0.5), pitchY * (CGFloat(r) + 0.5))
                if bit == "1" { on.addPath(cell) } else { off.addPath(cell) }
            }
        }
        return Glyph(on: on, off: off, stroked: false)
    }

    private static func pixelGlyph(_ ch: Character) -> Glyph {
        let gap: CGFloat = 3
        let cw: CGFloat = (60 - gap * 2) / 3
        let chh: CGFloat = (100 - gap * 4) / 5
        let on = CGMutablePath()
        func block(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) {
            on.addPath(CGPath(roundedRect: CGRect(x: x, y: y, width: w, height: h), cornerWidth: 2.2, cornerHeight: 2.2, transform: nil))
        }
        if ch == ":" {
            block(9 - chh / 2, 1 * (chh + gap), chh, chh)
            block(9 - chh / 2, 3 * (chh + gap), chh, chh)
            return Glyph(on: on, off: CGMutablePath(), stroked: false)
        }
        let rows = font35[String(ch)] ?? []
        for (r, line) in rows.enumerated() {
            for (c, bit) in line.enumerated() where bit == "1" {
                block(CGFloat(c) * (cw + gap), CGFloat(r) * (chh + gap), cw, chh)
            }
        }
        return Glyph(on: on, off: CGMutablePath(), stroked: false)
    }

    private static func lineGlyph(_ ch: Character) -> Glyph {
        if ch == ":" {
            let on = CGMutablePath()
            for y in [CGFloat(32), CGFloat(68)] { on.addEllipse(in: CGRect(x: 11 - 4.6, y: y - 4.6, width: 9.2, height: 9.2)) }
            return Glyph(on: on, off: CGMutablePath(), stroked: false)
        }
        return Glyph(on: MiniSVG.parsePath(skeleton[String(ch)] ?? ""), off: CGMutablePath(), stroked: true)
    }

    // MARK: - Kích thước ô (điểm ảnh)

    struct Cells {
        let pad: Int
        let digitW: Int
        let colonW: Int
        let sepW: Int
        let lineH: Int
    }

    /// Ô một chữ số / dấu hai chấm. `scale` = `digitalSize` (0.6 ... 1.8). Có lề `pad` để quầng sáng không bị cắt.
    static func cells(_ d: Def, scale k: CGFloat, base: CGFloat = 42) -> Cells {
        let glyphH = max(8, Int((base * k).rounded()))
        let pad = d.paint.glows ? 7 : 3
        let s = CGFloat(glyphH) / 100
        return Cells(pad: pad,
                     digitW: Int(ceil(digitWidth(d) * s)) + 2 * pad,
                     colonW: Int(ceil(colonWidth(d) * s)) + 2 * pad,
                     sepW: Int(ceil(sepWidth(d) * s)) + 2 * pad,
                     lineH: glyphH + 2 * pad)
    }

    // MARK: - Vẽ

    private static func gradient(_ ctx: CGContext, _ colors: [UIColor], _ stops: [CGFloat], from: CGPoint, to: CGPoint) {
        guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors.map { $0.cgColor } as CFArray,
                                 locations: stops) else { return }
        ctx.drawLinearGradient(g, start: from, end: to, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    /// Vẽ một ký tự (0...9, ":", "/" hoặc "-") vào `rect` (gốc trên-trái, y hướng xuống). `pad` = lề trên/dưới/hai bên của ô.
    static func draw(_ ctx: CGContext, def d: Def, char: Character, in rect: CGRect, pad: CGFloat, color: UIColor, own: Bool) {
        let gl = glyph(d, char)
        let boxW = charWidth(d, char)
        let s = (rect.height - 2 * pad) / 100
        guard s > 0 else { return }
        var t = CGAffineTransform(translationX: rect.midX - boxW * s / 2, y: rect.minY + pad).scaledBy(x: s, y: s)
        let top = rect.minY + pad
        let bottom = top + 100 * s
        let pal: HandPal? = d.pal.map { own ? $0 : HandPal.derive(color) }
        let base = pal?.mid ?? color

        // Đoạn / chấm đang tắt
        if d.ghost, !gl.off.isEmpty {
            let off = gl.off.copy(using: &t) ?? gl.off
            let ghostColor = d.paint.glows ? base : (pal?.dark ?? color)
            ctx.addPath(off)
            ctx.setFillColor(ghostColor.withAlphaComponent(0.13).cgColor)
            ctx.fillPath()
        }

        let moved = gl.on.copy(using: &t) ?? gl.on
        let on: CGPath = gl.stroked
            ? moved.copy(strokingWithWidth: d.stroke * s, lineCap: .round, lineJoin: .round, miterLimit: 10)
            : moved
        // Viền tối quanh nét kim loại (tô nét dày hơn rồi phủ dải kim loại lên)
        let under: CGPath? = (d.paint == .metal && gl.stroked)
            ? moved.copy(strokingWithWidth: (d.stroke + 2.4) * s, lineCap: .round, lineJoin: .round, miterLimit: 10)
            : nil
        fillStyled(ctx, paint: d.paint, path: on, under: under, top: top, bottom: bottom, s: s, pal: pal, color: color, blur: 9)
    }

    /// Tô một path đặc theo kiểu của số (phẳng / viền rỗng / dải kim loại / quầng sáng).
    private static func fillStyled(_ ctx: CGContext, paint: Def.Paint, path on: CGPath, under: CGPath?, top: CGFloat, bottom: CGFloat,
                                   s: CGFloat, pal: HandPal?, color: UIColor, blur: CGFloat) {
        let base = pal?.mid ?? color
        switch paint {
        case .flat:
            ctx.addPath(on)
            ctx.setFillColor(base.cgColor)
            ctx.fillPath()
        case .outline:
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.addPath(on)
            ctx.setStrokeColor((pal?.light ?? color).cgColor)
            ctx.setLineWidth(max(1.4, 1.8 * s))
            ctx.strokePath()
            ctx.restoreGState()
        case .metal:
            guard let p = pal else { return }
            if let u = under {
                ctx.addPath(u)
                ctx.setFillColor(p.deep.withAlphaComponent(0.85).cgColor)
                ctx.fillPath()
            }
            ctx.saveGState()
            ctx.addPath(on)
            ctx.clip()
            gradient(ctx, [p.hi, p.light, p.mid, p.dark], [0, 0.3, 0.62, 1],
                     from: CGPoint(x: 0, y: top), to: CGPoint(x: 0, y: bottom))
            ctx.restoreGState()
        case .tube:
            guard let p = pal else { return }
            // Ruột tối để chữ nổi trên nền, rồi viền màu phát sáng, cuối cùng lõi trắng mảnh như ống neon thật.
            ctx.addPath(on)
            ctx.setFillColor(p.deep.withAlphaComponent(0.5).cgColor)
            ctx.fillPath()
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.setShadow(offset: .zero, blur: blur, color: p.light.withAlphaComponent(0.95).cgColor)
            ctx.addPath(on)
            ctx.setStrokeColor(p.mid.cgColor)
            ctx.setLineWidth(max(1.8, 3.4 * s))
            ctx.strokePath()
            ctx.restoreGState()
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.addPath(on)
            ctx.setStrokeColor(p.hi.cgColor)
            ctx.setLineWidth(max(0.9, 1.2 * s))
            ctx.strokePath()
            ctx.restoreGState()
        case .glow:
            guard let p = pal else { return }
            ctx.saveGState()
            ctx.setShadow(offset: .zero, blur: blur, color: p.light.withAlphaComponent(0.95).cgColor)
            ctx.addPath(on)
            ctx.setFillColor(p.mid.cgColor)
            ctx.fillPath()
            ctx.restoreGState()
            ctx.saveGState()
            ctx.addPath(on)
            ctx.clip()
            gradient(ctx, [p.hi, p.light, p.mid], [0, 0.45, 1],
                     from: CGPoint(x: 0, y: top), to: CGPoint(x: 0, y: bottom))
            ctx.restoreGState()
        }
    }

    /// Vẽ nhãn chữ vector (đã đổi thành path, gốc ở tâm, y hướng xuống) vào giữa `rect` theo cùng kiểu tô của số.
    /// `scale` = tỉ lệ từ đơn vị path (cỡ chữ 100) sang điểm ảnh. Kiểu "viền rỗng" vẽ nhãn dạng đặc cho dễ đọc.
    static func drawLabel(_ ctx: CGContext, def d: Def, shape: CGPath, scale: CGFloat, in rect: CGRect, color: UIColor, own: Bool) {
        var t = CGAffineTransform(translationX: rect.midX, y: rect.midY).scaledBy(x: scale, y: scale)
        let moved = shape.copy(using: &t) ?? shape
        let pal: HandPal? = d.pal.map { own ? $0 : HandPal.derive(color) }
        let paint: Def.Paint = d.paint == .outline ? .flat : d.paint
        fillStyled(ctx, paint: paint, path: moved, under: nil, top: rect.minY, bottom: rect.maxY, s: 0.3, pal: pal, color: color, blur: 5)
    }
}

// MARK: - Hình thu nhỏ "13:00" trong bộ chọn kiểu giờ số

enum DigitalThumbs {
    private static let cache = LockedCache<DigitalStyle, UIImage>()

    static func image(_ st: DigitalStyle) -> UIImage {
        if let c = cache[st] { return c }
        let size = CGSize(width: 240, height: 84)
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(origin: .zero, size: size))
            let ctx = c.cgContext
            let text = "13:00"
            if let def = st.def {
                let cl = DigitalShapes.cells(def, scale: 1.1)
                let total = cl.digitW * 4 + cl.colonW
                var x = (size.width - CGFloat(total)) / 2
                let y = (size.height - CGFloat(cl.lineH)) / 2
                for ch in text {
                    let w = ch == ":" ? cl.colonW : cl.digitW
                    DigitalShapes.draw(ctx, def: def, char: ch, in: CGRect(x: x, y: y, width: CGFloat(w), height: CGFloat(cl.lineH)),
                                       pad: CGFloat(cl.pad), color: .white, own: true)
                    x += CGFloat(w)
                }
            } else {
                let font = UIFont.monospacedDigitSystemFont(ofSize: 46, weight: .bold)
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white]
                let sz = (text as NSString).size(withAttributes: attrs)
                (text as NSString).draw(at: CGPoint(x: (size.width - sz.width) / 2, y: (size.height - sz.height) / 2), withAttributes: attrs)
            }
        }
        cache[st] = img
        return img
    }
}
