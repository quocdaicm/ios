// Bộ kim vector: 40 kiểu theo ảnh thiết kế (Dauphine, Sword, Leaf, Cathedral, Skeleton, Baton, Arrow, Feather,
// Trident, Diamond, Blue Steel, Blue Gold, Rose Gold, Ruby, Sapphire, Luminous x6, Sport, Racing, Royal, Baroque,
// Luxury, Elegant, Chronograph, Minimalist, Geometric, Future). Mỗi kim được vẽ bằng path: hai nửa/các mặt cắt có
// dải sáng-tối kim loại, đường sống, đá quý, dây bện, khung rỗng, quầng sáng dạ quang.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Bảng màu kim loại (5 mức: sáng nhất → tối nhất)

struct HandPal {
    let c: [UIColor]
    var hi: UIColor { c[0] }
    var light: UIColor { c[1] }
    var mid: UIColor { c[2] }
    var dark: UIColor { c[3] }
    var deep: UIColor { c[4] }

    init(colors: [UIColor]) { c = colors }

    init(hex: [UInt32]) {
        c = hex.map {
            UIColor(red: CGFloat(($0 >> 16) & 255) / 255, green: CGFloat(($0 >> 8) & 255) / 255,
                    blue: CGFloat($0 & 255) / 255, alpha: 1)
        }
    }

    /// Bảng màu suy ra từ một màu bất kỳ (dùng khi tắt "màu gốc của kiểu kim" và cho AOD).
    static func derive(_ base: UIColor) -> HandPal {
        HandPal(colors: [
            handMix(base, .white, 0.70), handMix(base, .white, 0.32), base,
            handMix(base, .black, 0.35), handMix(base, .black, 0.66)
        ])
    }
}

private func handMix(_ a: UIColor, _ b: UIColor, _ t: CGFloat) -> UIColor {
    var ar: CGFloat = 0, ag: CGFloat = 0, ab: CGFloat = 0, aa: CGFloat = 0
    var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
    guard a.getRed(&ar, green: &ag, blue: &ab, alpha: &aa), b.getRed(&br, green: &bg, blue: &bb, alpha: &ba) else { return a }
    return UIColor(red: ar + (br - ar) * t, green: ag + (bg - ag) * t, blue: ab + (bb - ab) * t, alpha: 1)
}

enum HP {
        static let gold = HandPal(hex: [0xFFF0B8, 0xF0C878, 0xCF9A40, 0x946A22, 0x58390E])
        static let silver = HandPal(hex: [0xFFFFFF, 0xEDF0F5, 0xBAC1CC, 0x808792, 0x474D58])
        static let rose = HandPal(hex: [0xFFE2D4, 0xF3B9A2, 0xD58F76, 0x9A5C49, 0x5C3025])
        static let blue = HandPal(hex: [0xB4D0FF, 0x5B90FF, 0x2358E0, 0x1230A0, 0x081A5E])
        static let ruby = HandPal(hex: [0xFFB0B0, 0xFF4A52, 0xD8121F, 0x8F0A14, 0x4A050A])
        static let sapphire = HandPal(hex: [0xBBD2FF, 0x5584FF, 0x2145E6, 0x1228A0, 0x08104E])
        static let mint = HandPal(hex: [0xFFFFFF, 0xE2FFF0, 0xB4F5D2, 0x6FD6A6, 0x2E9A72])
        static let green = HandPal(hex: [0xF2FFF6, 0xBDF7D4, 0x7FE5B0, 0x3FB587, 0x1D7052])
        static let lblue = HandPal(hex: [0xEAF4FF, 0xA6D0FF, 0x5B9CF5, 0x2A5CC0, 0x123074])
        static let aqua = HandPal(hex: [0xF2FFFF, 0xC2F4FF, 0x74DAEF, 0x30A3C4, 0x146A86])
        static let purple = HandPal(hex: [0xF6ECFF, 0xD2B4F8, 0xA27AE6, 0x6C46B8, 0x3C2476])
        static let orange = HandPal(hex: [0xFFF3D6, 0xFFCA80, 0xF59A38, 0xB8601A, 0x6E3508])
        static let steel = HandPal(hex: [0xB5BDC9, 0x8892A0, 0x4A515C, 0x2A2E36, 0x101216])
        static let black = HandPal(hex: [0x4A4D55, 0x2E3036, 0x1C1D22, 0x0F1013, 0x040405])
        static let future = HandPal(hex: [0xFFFFFF, 0xBFE0FF, 0x3C8CFF, 0x1B3DB0, 0x0A1650])
        static let ice = HandPal(hex: [0xFFFFFF, 0xF2F6FB, 0xD8E1EC, 0xA9B5C4, 0x77828F])
        // Bảng màu neon mới (Phần 60): sáng nhất → tối nhất; "light" cũng là màu quầng sáng.
        static let pink = HandPal(hex: [0xFFF0F8, 0xFFB0DC, 0xFF3FB0, 0xB0157A, 0x5C0A40])
        static let yellow = HandPal(hex: [0xFFFFF2, 0xFFF48A, 0xFFE02A, 0xC79A00, 0x6B5000])
        static let white = HandPal(hex: [0xFFFFFF, 0xF4F8FF, 0xDCE8FF, 0x9FB4E0, 0x5A6B96])
        static let lime = HandPal(hex: [0xF8FFE8, 0xD0FF80, 0x7CFF24, 0x38B000, 0x1A6200])
        static let cyan = HandPal(hex: [0xF0FFFF, 0x9CF6FF, 0x14DCFF, 0x0A8CC0, 0x04507A])
        static let hotRed = HandPal(hex: [0xFFE8E8, 0xFF8088, 0xFF2438, 0xB0001A, 0x500008])
        static let tetGold = HandPal(hex: [0xFFFBE0, 0xFFE27A, 0xFFB81F, 0xB87A00, 0x5C3A00])
        static let tetRed = HandPal(hex: [0xFFF1B8, 0xFFC857, 0xFF3B2F, 0xB00E14, 0x5A0508])
}

// MARK: - Định nghĩa kim

struct HandExtras: OptionSet {
    let rawValue: Int
    static let ridge = HandExtras(rawValue: 1 << 0)
    static let vein = HandExtras(rawValue: 1 << 1)
    static let barbs = HandExtras(rawValue: 1 << 2)
    static let gem = HandExtras(rawValue: 1 << 3)
    static let gems = HandExtras(rawValue: 1 << 4)
    static let braid = HandExtras(rawValue: 1 << 5)
    static let rings = HandExtras(rawValue: 1 << 6)
    static let struts = HandExtras(rawValue: 1 << 7)
    static let diag = HandExtras(rawValue: 1 << 8)
    static let ring = HandExtras(rawValue: 1 << 9)
    static let ringSmall = HandExtras(rawValue: 1 << 10)
    static let trident = HandExtras(rawValue: 1 << 11)
}

enum HandPaint { case halves, facets, glow }

enum HandShapes {
    /// (t, w): t = 0 ở đầu kim, 1 ở trục xoay, 1...2 là phần đuôi; w tính theo nửa bề rộng kim (geo.width / 2).
    typealias Pt = (t: CGFloat, w: CGFloat)

    /// Ô hình thoi (lens) nằm giữa t0...t1, bề rộng k lần bề rộng kim ở đó.
    struct Lens {
        let t0: CGFloat, t1: CGFloat, k: CGFloat
        init(_ t0: CGFloat, _ t1: CGFloat, _ k: CGFloat) { self.t0 = t0; self.t1 = t1; self.k = k }
    }

    struct Def {
        var profile: [Pt]
        var smooth = false
        var pal: HandPal
        var paint: HandPaint = .halves
        var window: Lens? = nil
        var extras: HandExtras = []
        var edge: HandPal? = nil
        var core: HandPal? = nil
        var coreWin: Lens? = nil
        var wf: CGFloat = 1
    }

    static let table: [String: Def] = {
        var t = [String: Def]()
        t["dauphine"] = Def(profile: [(0, 0), (0.58, 1.55), (0.93, 0.62), (1, 0.42), (1.3, 0.4), (2, 0.4)], pal: HP.gold, paint: .facets, extras: [.ridge])
        t["dauphineSilver"] = Def(profile: [(0, 0), (0.58, 1.55), (0.93, 0.62), (1, 0.42), (1.3, 0.4), (2, 0.4)], pal: HP.silver, paint: .facets, extras: [.ridge])
        t["dauphineRose"] = Def(profile: [(0, 0), (0.58, 1.55), (0.93, 0.62), (1, 0.42), (1.3, 0.4), (2, 0.4)], pal: HP.rose, paint: .facets, extras: [.ridge])
        t["sword"] = Def(profile: [(0, 0), (0.05, 0.3), (0.72, 0.62), (0.8, 1), (0.88, 0.5), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.silver, extras: [.ridge])
        t["swordGold"] = Def(profile: [(0, 0), (0.05, 0.3), (0.72, 0.62), (0.8, 1), (0.88, 0.5), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.gold, extras: [.ridge])
        t["leaf"] = Def(profile: [(0, 0), (0.22, 0.85), (0.5, 1.45), (0.78, 1.1), (0.95, 0.5), (1, 0.38), (1.3, 0.4), (2, 0.4)], smooth: true, pal: HP.silver, extras: [.vein])
        t["leafGold"] = Def(profile: [(0, 0), (0.22, 0.85), (0.5, 1.45), (0.78, 1.1), (0.95, 0.5), (1, 0.38), (1.3, 0.4), (2, 0.4)], smooth: true, pal: HP.gold, extras: [.vein])
        t["cathedral"] = Def(profile: [(0, 0), (0.12, 0.7), (0.5, 1.5), (0.85, 1), (0.95, 0.55), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.silver, window: Lens(0.16, 0.78, 0.52), extras: [.struts])
        t["skeleton"] = Def(profile: [(0, 0), (0.4, 1.05), (0.88, 0.75), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.silver, window: Lens(0.12, 0.86, 0.55), extras: [.struts, .diag])
        t["baton"] = Def(profile: [(0, 0.34), (0.03, 0.58), (0.97, 0.58), (1, 0.58), (1.3, 0.5), (2, 0.5)], pal: HP.silver, extras: [.ridge])
        t["batonGold"] = Def(profile: [(0, 0.34), (0.03, 0.58), (0.97, 0.58), (1, 0.58), (1.3, 0.5), (2, 0.5)], pal: HP.gold, extras: [.ridge])
        t["arrow"] = Def(profile: [(0, 0), (0.26, 1.45), (0.19, 0.36), (0.93, 0.36), (1, 0.36), (1.3, 0.36), (2, 0.36)], pal: HP.silver, extras: [.ridge])
        t["arrowGold"] = Def(profile: [(0, 0), (0.26, 1.45), (0.19, 0.36), (0.93, 0.36), (1, 0.36), (1.3, 0.36), (2, 0.36)], pal: HP.gold, extras: [.ridge])
        t["feather"] = Def(profile: [(0, 0), (0.2, 0.8), (0.5, 1.5), (0.8, 1.05), (0.95, 0.45), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.silver, extras: [.barbs])
        t["featherGold"] = Def(profile: [(0, 0), (0.2, 0.8), (0.5, 1.5), (0.8, 1.05), (0.95, 0.45), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.gold, extras: [.barbs])
        t["trident"] = Def(profile: [(0.22, 0.2), (0.9, 0.2), (1, 0.24), (1.3, 0.3), (2, 0.3)], pal: HP.silver, extras: [.trident])
        t["tridentGold"] = Def(profile: [(0.22, 0.2), (0.9, 0.2), (1, 0.24), (1.3, 0.3), (2, 0.3)], pal: HP.gold, extras: [.trident])
        t["diamond"] = Def(profile: [(0, 0), (0.4, 1.3), (0.88, 0.62), (1, 0.42), (1.3, 0.4), (2, 0.4)], pal: HP.silver, paint: .facets, extras: [.gem, .ridge])
        t["diamondGold"] = Def(profile: [(0, 0), (0.4, 1.3), (0.88, 0.62), (1, 0.42), (1.3, 0.4), (2, 0.4)], pal: HP.gold, paint: .facets, extras: [.gem, .ridge])
        t["blueSteel"] = Def(profile: [(0, 0), (0.36, 1.35), (0.78, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.blue, paint: .facets, extras: [.ridge])
        t["blueGold"] = Def(profile: [(0, 0), (0.36, 1.35), (0.78, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.blue, paint: .facets, extras: [.ridge], edge: HP.gold)
        t["roseGold"] = Def(profile: [(0, 0), (0.36, 1.35), (0.78, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.rose, paint: .facets, extras: [.ridge], edge: HP.rose)
        t["ruby"] = Def(profile: [(0, 0), (0.36, 1.35), (0.78, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.ruby, paint: .facets, extras: [.ridge])
        t["sapphire"] = Def(profile: [(0, 0), (0.36, 1.35), (0.78, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.sapphire, paint: .facets, extras: [.ridge])
        t["luminous"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.mint, paint: .glow)
        t["luminousGreen"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.green, paint: .glow)
        t["luminousBlue"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.lblue, paint: .glow)
        t["luminousAqua"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.aqua, paint: .glow)
        t["luminousPurple"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.purple, paint: .glow)
        t["luminousOrange"] = Def(profile: [(0, 0), (0.3, 0.9), (0.7, 1), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.orange, paint: .glow)
        t["sport"] = Def(profile: [(0, 0), (0.3, 1.25), (0.6, 1.3), (0.9, 0.62), (1, 0.5), (1.3, 0.4), (2, 0.4)], pal: HP.silver, extras: [.ridge], core: HP.ice, coreWin: Lens(0.28, 0.85, 0.5))
        t["racing"] = Def(profile: [(0, 0), (0.25, 1.1), (0.62, 1.5), (0.9, 0.8), (1, 0.6), (1.3, 0.4), (2, 0.4)], pal: HP.silver, window: Lens(0.2, 0.82, 0.55), extras: [.struts, .diag, .ringSmall])
        t["royal"] = Def(profile: [(0, 0), (0.2, 0.8), (0.55, 1.45), (0.9, 0.9), (1, 0.5), (1.3, 0.4), (2, 0.4)], pal: HP.gold, window: Lens(0.1, 0.9, 0.6), extras: [.braid])
        t["baroque"] = Def(profile: [(0, 0), (0.3, 1.2), (0.6, 1.55), (0.9, 1), (1, 0.55), (1.3, 0.4), (2, 0.4)], pal: HP.gold, window: Lens(0.08, 0.92, 0.62), extras: [.braid, .rings])
        t["luxury"] = Def(profile: [(0, 0), (0.45, 1), (0.9, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.gold, paint: .facets, extras: [.gems])
        t["elegant"] = Def(profile: [(0, 0), (0.4, 0.95), (0.8, 0.8), (0.97, 0.4), (1, 0.38), (1.3, 0.4), (2, 0.4)], smooth: true, pal: HP.gold, extras: [.ridge])
        t["chronograph"] = Def(profile: [(0, 0), (0.35, 0.3), (0.95, 0.3), (1, 0.3), (1.3, 0.3), (2, 0.3)], pal: HP.gold, extras: [.ring])
        t["minimalist"] = Def(profile: [(0, 0), (0.5, 0.5), (0.95, 0.34), (1, 0.3), (1.3, 0.3), (2, 0.3)], pal: HP.steel, edge: HP.gold)
        t["geometric"] = Def(profile: [(0, 0), (0.42, 1.3), (0.9, 0.7), (1, 0.45), (1.3, 0.4), (2, 0.4)], pal: HP.gold, paint: .facets, core: HP.black, coreWin: Lens(0.2, 0.84, 0.52))
        t["future"] = Def(profile: [(0, 0), (0.3, 0.85), (0.7, 0.95), (0.95, 0.4), (1, 0.3), (1.3, 0.3), (2, 0.3)], smooth: true, pal: HP.future, paint: .glow)
        return t
    }()

    static let titles: [String: (String, String)] = [
        "dauphine": ("Dauphine", "Vàng Gold"),
        "dauphineSilver": ("Dauphine", "Bạc"),
        "dauphineRose": ("Dauphine", "Hồng"),
        "sword": ("Sword", "Bạc"),
        "swordGold": ("Sword", "Vàng"),
        "leaf": ("Leaf", "Bạc"),
        "leafGold": ("Leaf", "Vàng"),
        "cathedral": ("Cathedral", "Bạc"),
        "skeleton": ("Skeleton", "Hiện Đại"),
        "baton": ("Baton", "Bạc"),
        "batonGold": ("Baton", "Vàng"),
        "arrow": ("Arrow", "Bạc"),
        "arrowGold": ("Arrow", "Vàng"),
        "feather": ("Feather", "Bạc"),
        "featherGold": ("Feather", "Vàng"),
        "trident": ("Trident", "Bạc"),
        "tridentGold": ("Trident", "Vàng"),
        "diamond": ("Diamond", "Bạc"),
        "diamondGold": ("Diamond", "Vàng"),
        "blueSteel": ("Blue Steel", "Xanh"),
        "blueGold": ("Blue Gold", "Xanh Vàng"),
        "roseGold": ("Rose Gold", "Hồng"),
        "ruby": ("Ruby", "Đỏ"),
        "sapphire": ("Sapphire", "Xanh"),
        "luminous": ("Luminous", "Dạ Quang"),
        "luminousGreen": ("Luminous Green", "Xanh Lá"),
        "luminousBlue": ("Luminous Blue", "Xanh Dương"),
        "luminousAqua": ("Luminous Aqua", "Xanh Ngọc"),
        "luminousPurple": ("Luminous Purple", "Tím"),
        "luminousOrange": ("Luminous Orange", "Cam"),
        "sport": ("Sport", "Thể Thao"),
        "racing": ("Racing", "Đua Xe"),
        "royal": ("Royal", "Hoàng Gia"),
        "baroque": ("Baroque", "Cổ Điển"),
        "luxury": ("Luxury", "Sang Trọng"),
        "elegant": ("Elegant", "Thanh Lịch"),
        "chronograph": ("Chronograph", "Bấm Giờ"),
        "minimalist": ("Minimalist", "Tối Giản"),
        "geometric": ("Geometric", "Hình Học"),
        "future": ("Future", "Tương Lai")
    ]

    static func title(_ raw: String) -> String {
        if let t = titles[raw] { return t.0 + " " + t.1 }
        return raw.prefix(1).uppercased() + raw.dropFirst()
    }

    // MARK: Hàm hỗ trợ

    private static func ramp(_ p: HandPal, _ x: CGFloat) -> UIColor {
        let v = max(0, min(1, x)) * 4
        let i = min(3, Int(v))
        return handMix(p.c[i], p.c[i + 1], v - CGFloat(i))
    }

    private static func gradient(_ ctx: CGContext, _ colors: [UIColor], _ stops: [CGFloat]? = nil, from: CGPoint, to: CGPoint) {
        let cs = CGColorSpaceCreateDeviceRGB()
        guard let g = CGGradient(colorsSpace: cs, colors: colors.map { $0.cgColor } as CFArray, locations: stops) else { return }
        ctx.drawLinearGradient(g, start: from, end: to, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    /// Thêm các đoạn nối pts[0] → pts.last vào path (đã đứng sẵn ở pts[0]); smooth = Catmull-Rom đổi sang Bézier.
    private static func addEdge(_ path: CGMutablePath, _ pts: [CGPoint], smooth: Bool) {
        guard pts.count >= 2 else { return }
        for i in 0..<(pts.count - 1) {
            let p1 = pts[i], p2 = pts[i + 1]
            if smooth {
                let p0 = i > 0 ? pts[i - 1] : p1
                let p3 = i + 2 < pts.count ? pts[i + 2] : p2
                let c1 = CGPoint(x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6)
                let c2 = CGPoint(x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6)
                path.addCurve(to: p2, control1: c1, control2: c2)
            } else {
                path.addLine(to: p2)
            }
        }
    }

    /// Nét "ống kim loại": viền tối, thân, vệt sáng giữa.
    private static func tube(_ ctx: CGContext, _ path: CGPath, width: CGFloat, pal: HandPal) {
        ctx.saveGState()
        ctx.setLineCap(.round)
        ctx.setLineJoin(.round)
        ctx.addPath(path)
        ctx.setStrokeColor(pal.deep.withAlphaComponent(0.85).cgColor)
        ctx.setLineWidth(width + 1.0)
        ctx.strokePath()
        ctx.addPath(path)
        ctx.setStrokeColor(pal.mid.cgColor)
        ctx.setLineWidth(width)
        ctx.strokePath()
        ctx.addPath(path)
        ctx.setStrokeColor(pal.hi.withAlphaComponent(0.85).cgColor)
        ctx.setLineWidth(max(0.5, width * 0.32))
        ctx.strokePath()
        ctx.restoreGState()
    }

    private static func line(_ a: CGPoint, _ b: CGPoint) -> CGPath {
        let p = CGMutablePath()
        p.move(to: a)
        p.addLine(to: b)
        return p
    }

    private static func fillGradientH(_ ctx: CGContext, _ path: CGPath, _ c0: UIColor, _ c1: UIColor, _ x0: CGFloat, _ x1: CGFloat) {
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        gradient(ctx, [c0, c1], from: CGPoint(x: x0, y: 0), to: CGPoint(x: x1, y: 0))
        ctx.restoreGState()
    }

    // MARK: Vẽ

    /// Vẽ một kim vector trong toạ độ cục bộ: trục xoay ở (0,0), đầu kim hướng lên (0, -reach).
    static func draw(_ ctx: CGContext, def d: Def, kind: FaceRenderer.HandKind, geo: FaceRenderer.HandGeometry,
                     color: UIColor, outline: Bool, own: Bool) {
        let L = geo.reach, T = geo.tail
        let hw = geo.width / 2 * d.wf
        let pal = own ? d.pal : HandPal.derive(color)
        let prof = d.profile
        guard prof.count >= 2 else { return }

        func P(_ t: CGFloat, _ w: CGFloat) -> CGPoint {
            CGPoint(x: w * hw, y: t <= 1 ? -L * (1 - t) : (t - 1) * T)
        }
        func widthAt(_ t: CGFloat) -> CGFloat {
            for i in 0..<(prof.count - 1) {
                let a = prof[i], b = prof[i + 1]
                if a.t != b.t, t >= min(a.t, b.t), t <= max(a.t, b.t) {
                    return a.w + (b.w - a.w) * (t - a.t) / (b.t - a.t)
                }
            }
            return prof[prof.count - 1].w
        }
        func lensPath(_ l: Lens) -> CGPath {
            var lp = [CGPoint](), rp = [CGPoint]()
            for j in 0...8 {
                let u = CGFloat(j) / 8
                let t = l.t0 + (l.t1 - l.t0) * u
                let w = widthAt(t) * l.k * pow(sin(CGFloat.pi * u), 0.7)
                lp.append(P(t, -w))
                rp.append(P(t, w))
            }
            let p = CGMutablePath()
            p.move(to: lp[0])
            addEdge(p, lp, smooth: true)
            p.addLine(to: rp[rp.count - 1])
            addEdge(p, Array(rp.reversed()), smooth: true)
            p.closeSubpath()
            return p
        }
        func halfPath(_ pts: [CGPoint]) -> CGPath {
            let p = CGMutablePath()
            p.move(to: pts[0])
            addEdge(p, pts, smooth: d.smooth)
            p.addLine(to: CGPoint(x: 0, y: pts[pts.count - 1].y))
            p.addLine(to: CGPoint(x: 0, y: pts[0].y))
            p.closeSubpath()
            return p
        }

        let left = prof.map { P($0.t, -$0.w) }
        let right = prof.map { P($0.t, $0.w) }
        let outlinePath = CGMutablePath()
        outlinePath.move(to: left[0])
        addEdge(outlinePath, left, smooth: d.smooth)
        outlinePath.addLine(to: right[right.count - 1])
        addEdge(outlinePath, Array(right.reversed()), smooth: d.smooth)
        outlinePath.closeSubpath()
        let windowPath: CGPath? = d.window.map { lensPath($0) }
        let maxW = (prof.map { $0.w }.max() ?? 1) * hw
        let glow = d.paint == .glow

        ctx.saveGState()
        ctx.setLineJoin(.round)

        // 1) Viền tối bên ngoài + quầng sáng dạ quang
        if outline && !glow {
            ctx.addPath(outlinePath)
            ctx.setStrokeColor(UIColor.black.withAlphaComponent(0.55).cgColor)
            ctx.setLineWidth(2.5)
            ctx.strokePath()
        }
        if glow && own {
            ctx.saveGState()
            ctx.setShadow(offset: .zero, blur: 6, color: pal.light.withAlphaComponent(0.95).cgColor)
            ctx.addPath(outlinePath)
            ctx.setFillColor(pal.mid.cgColor)
            ctx.fillPath()
            ctx.restoreGState()
        }

        // 2) Thân kim (cắt theo hình, khoét cửa sổ nếu là kiểu rỗng)
        ctx.saveGState()
        ctx.addPath(outlinePath)
        if let w = windowPath { ctx.addPath(w) }
        ctx.clip(using: .evenOdd)

        switch d.paint {
        case .halves:
            fillGradientH(ctx, halfPath(left), ramp(pal, 0.42), ramp(pal, 0.08), -maxW, 0)
            fillGradientH(ctx, halfPath(right), ramp(pal, 0.22), ramp(pal, 0.78), 0, maxW)
        case .glow:
            fillGradientH(ctx, halfPath(left), ramp(pal, 0.5), ramp(pal, 0), -maxW, 0)
            fillGradientH(ctx, halfPath(right), ramp(pal, 0), ramp(pal, 0.5), 0, maxW)
        case .facets:
            let n = prof.count
            for i in 0..<(n - 1) {
                for side in [-1, 1] {
                    let pts = side < 0 ? left : right
                    let poly = CGMutablePath()
                    poly.move(to: pts[i])
                    poly.addLine(to: pts[i + 1])
                    poly.addLine(to: CGPoint(x: 0, y: pts[i + 1].y))
                    poly.addLine(to: CGPoint(x: 0, y: pts[i].y))
                    poly.closeSubpath()
                    var f: CGFloat = (side < 0 ? 0.30 : 0.62) + (i % 2 == 0 ? -0.14 : 0.10)
                    if n > 2 { f -= 0.12 * (1 - CGFloat(i) / CGFloat(n - 1)) }
                    let c0 = ramp(pal, f - 0.18), c1 = ramp(pal, f + 0.12)
                    if side < 0 {
                        fillGradientH(ctx, poly, c1, c0, -maxW, 0)
                    } else {
                        fillGradientH(ctx, poly, c0, c1, 0, maxW)
                    }
                }
            }
        }

        // Dải sáng ở đầu kim, tối dần về trục
        if !glow {
            gradient(ctx,
                     [UIColor.white.withAlphaComponent(0.30), UIColor.white.withAlphaComponent(0),
                      UIColor.black.withAlphaComponent(0), UIColor.black.withAlphaComponent(0.28)],
                     [0, 0.25, 0.6, 1], from: CGPoint(x: 0, y: -L), to: CGPoint(x: 0, y: T))
        }

        // Lõi lồng bên trong (Geometric: lõi đen; Sport: mặt sáng)
        if let cw = d.coreWin, let cp = d.core {
            ctx.saveGState()
            ctx.addPath(lensPath(cw))
            ctx.clip()
            gradient(ctx, [ramp(cp, 0.55), ramp(cp, 0.15)], from: CGPoint(x: -maxW, y: 0), to: CGPoint(x: maxW, y: 0))
            ctx.restoreGState()
        }

        // Chi tiết nằm trong thân kim
        if d.extras.contains(.ridge) {
            ctx.setStrokeColor(pal.hi.withAlphaComponent(0.75).cgColor)
            ctx.setLineWidth(0.9)
            ctx.addPath(line(P(0.04, 0), P(0.82, 0)))
            ctx.strokePath()
        }
        if d.extras.contains(.vein) {
            ctx.setStrokeColor(pal.dark.withAlphaComponent(0.6).cgColor)
            ctx.setLineWidth(0.9)
            ctx.addPath(line(P(0.12, 0), P(0.85, 0)))
            ctx.strokePath()
        }
        if d.extras.contains(.barbs) {
            ctx.setStrokeColor(pal.dark.withAlphaComponent(0.55).cgColor)
            ctx.setLineWidth(0.7)
            for k in 1...9 {
                let t = 0.12 + 0.085 * CGFloat(k)
                let w = widthAt(t - 0.1) * 0.92
                for s: CGFloat in [-1, 1] {
                    ctx.addPath(line(P(t, 0), P(t - 0.1, s * w)))
                    ctx.strokePath()
                }
            }
        }
        if d.extras.contains(.gem) {
            let c = P(0.42, 0)
            let r = hw * 0.5
            let rhombus = CGMutablePath()
            rhombus.move(to: CGPoint(x: c.x, y: c.y - r * 1.2))
            rhombus.addLine(to: CGPoint(x: c.x + r * 0.8, y: c.y))
            rhombus.addLine(to: CGPoint(x: c.x, y: c.y + r * 1.2))
            rhombus.addLine(to: CGPoint(x: c.x - r * 0.8, y: c.y))
            rhombus.closeSubpath()
            ctx.addPath(rhombus)
            ctx.setFillColor(UIColor.white.cgColor)
            ctx.fillPath()
            ctx.addPath(rhombus)
            ctx.setStrokeColor(pal.deep.withAlphaComponent(0.5).cgColor)
            ctx.setLineWidth(0.6)
            ctx.strokePath()
        }
        if d.extras.contains(.gems) {
            for t: CGFloat in [0.2, 0.36, 0.52, 0.68] {
                let c = P(t, 0)
                let r = max(1.4, hw * 0.22)
                let rect = CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2)
                ctx.setFillColor(UIColor.white.cgColor)
                ctx.fillEllipse(in: rect)
                ctx.setStrokeColor(pal.deep.withAlphaComponent(0.5).cgColor)
                ctx.setLineWidth(0.5)
                ctx.strokeEllipse(in: rect)
            }
        }
        ctx.restoreGState()

        // 3) Viền mảnh quanh kim (kim loại khác màu nếu có)
        if let e = d.edge {
            tube(ctx, outlinePath, width: 1.2, pal: e)
        } else {
            ctx.addPath(outlinePath)
            ctx.setStrokeColor(pal.deep.withAlphaComponent(0.7).cgColor)
            ctx.setLineWidth(0.8)
            ctx.strokePath()
        }
        if let w = windowPath {
            ctx.addPath(w)
            ctx.setStrokeColor(pal.deep.withAlphaComponent(0.6).cgColor)
            ctx.setLineWidth(0.7)
            ctx.strokePath()
        }

        // 4) Thanh giằng, dây bện, đinh ba, vòng (vẽ đè lên phần rỗng)
        if let win = d.window {
            func wp(_ u: CGFloat, _ s: CGFloat) -> CGPoint {
                let t = win.t0 + (win.t1 - win.t0) * u
                return P(t, s * widthAt(t) * win.k * pow(sin(CGFloat.pi * u), 0.7))
            }
            if d.extras.contains(.struts) {
                for u: CGFloat in [0.35, 0.68] {
                    tube(ctx, line(wp(u, -1), wp(u, 1)), width: max(1.1, hw * 0.16), pal: pal)
                }
            }
            if d.extras.contains(.diag) {
                tube(ctx, line(wp(0.2, -1), wp(0.8, 1)), width: max(1.0, hw * 0.14), pal: pal)
                tube(ctx, line(wp(0.2, 1), wp(0.8, -1)), width: max(1.0, hw * 0.14), pal: pal)
            }
            if d.extras.contains(.braid) {
                let n = d.extras.contains(.rings) ? 10 : 8
                for k in 0..<n {
                    let ta = win.t0 + (win.t1 - win.t0) * (0.08 + 0.84 * CGFloat(k) / CGFloat(n))
                    let tb = win.t0 + (win.t1 - win.t0) * (0.08 + 0.84 * CGFloat(k + 1) / CGFloat(n))
                    let tm = (ta + tb) / 2
                    let a0 = widthAt(ta) * win.k * 0.66, a1 = widthAt(tb) * win.k * 0.66
                    let dir: CGFloat = k % 2 == 0 ? 1 : -1
                    for sgn: CGFloat in [1, -1] {
                        let s = dir * sgn
                        let p = CGMutablePath()
                        p.move(to: P(ta, -s * a0))
                        p.addCurve(to: P(tb, s * a1), control1: P(tm, -s * a0), control2: P(tm, s * a1))
                        tube(ctx, p, width: max(1.5, hw * 0.2), pal: pal)
                    }
                    if d.extras.contains(.rings) {
                        let c = P(tm, 0), r = hw * 0.3
                        let ring = CGMutablePath()
                        ring.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2))
                        tube(ctx, ring, width: max(1.0, hw * 0.12), pal: pal)
                    }
                }
            }
        }
        if d.extras.contains(.trident) {
            let u = CGMutablePath()
            for q in 0...16 {
                let x = CGFloat(q - 8) / 8
                let pt = P(0.28 - 0.18 * x * x, x * 1.35)
                if q == 0 { u.move(to: pt) } else { u.addLine(to: pt) }
            }
            tube(ctx, u, width: max(1.3, hw * 0.2), pal: pal)
            for cx: CGFloat in [-1.35, 0, 1.35] {
                let y0 = 0.28 - 0.18 * (cx / 1.35) * (cx / 1.35)
                tube(ctx, line(P(y0, cx), P(0.05, cx)), width: max(1.1, hw * 0.16), pal: pal)
                let s = hw * 0.5
                let a = P(0.09, cx), b = P(0.0, cx)
                let spike = CGMutablePath()
                spike.move(to: CGPoint(x: a.x - s, y: a.y))
                spike.addLine(to: CGPoint(x: a.x + s, y: a.y))
                spike.addLine(to: b)
                spike.closeSubpath()
                ctx.addPath(spike)
                ctx.setFillColor(pal.light.cgColor)
                ctx.fillPath()
                ctx.addPath(spike)
                ctx.setStrokeColor(pal.deep.withAlphaComponent(0.7).cgColor)
                ctx.setLineWidth(0.6)
                ctx.strokePath()
            }
        }
        if d.extras.contains(.ring) {
            let c = P(1.0, 0), r = hw * 1.35
            let ring = CGMutablePath()
            ring.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2))
            tube(ctx, ring, width: hw * 0.38, pal: pal)
        }
        if d.extras.contains(.ringSmall) {
            let c = P(1.2, 0), r = hw * 0.8
            let ring = CGMutablePath()
            ring.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2))
            tube(ctx, ring, width: hw * 0.3, pal: pal)
        }
        ctx.restoreGState()
    }
}

// MARK: - Hình thu nhỏ trong bộ chọn kiểu kim (cặp kim giờ + phút xếp hình chữ V như ảnh thiết kế)

enum HandThumbs {
    private static let cache = LockedCache<FaceDesign.HandStyle, UIImage>()

    static func image(_ st: FaceDesign.HandStyle) -> UIImage {
        if let c = cache[st] { return c }
        let px: CGFloat = 132
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: CGSize(width: px, height: px), format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(x: 0, y: 0, width: px, height: px))
            let ctx = c.cgContext
            let own = HandShapes.table[st.rawValue] != nil
            let hourGeo = FaceRenderer.HandGeometry(reach: 62, tail: 9, width: 14)
            let minGeo = FaceRenderer.HandGeometry(reach: 92, tail: 9, width: 11)
            func one(_ kind: FaceRenderer.HandKind, _ geo: FaceRenderer.HandGeometry, _ angle: CGFloat) {
                ctx.saveGState()
                ctx.translateBy(x: px * 0.5, y: px * 0.90)
                ctx.rotate(by: angle)
                FaceRenderer.drawHand(ctx, kind: kind, geo: geo, style: st, color: .white, outline: false, own: own)
                ctx.restoreGState()
            }
            one(.hour, hourGeo, -0.72)
            one(.minute, minGeo, 0.62)
            let r: CGFloat = 4.5
            ctx.setFillColor(UIColor(white: 0.75, alpha: 1).cgColor)
            ctx.fillEllipse(in: CGRect(x: px * 0.5 - r, y: px * 0.90 - r, width: r * 2, height: r * 2))
            ctx.setFillColor(UIColor(white: 0.25, alpha: 1).cgColor)
            ctx.fillEllipse(in: CGRect(x: px * 0.5 - 1.8, y: px * 0.90 - 1.8, width: 3.6, height: 3.6))
        }
        cache[st] = img
        return img
    }
}
