// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

// MARK: - Nền tranh vẽ mới (nhân vật / phong cảnh vẽ riêng bằng path, không dùng lại nền cũ)

extension FaceBackdrops {
    static let dayArt: [FaceBackdrop] = [
        FaceBackdrop(id: "artSanta", title: "Ông già Noel", top: 0xB3201A, bottom: 0x7A0F12, svg: artSanta()),
        FaceBackdrop(id: "artSnowman", title: "Người tuyết", top: 0x0B1B3D, bottom: 0x2D5A8C, svg: artSnowman()),
        FaceBackdrop(id: "artLightTree", title: "Cây thông đèn", top: 0x040A1A, bottom: 0x0A2A33, svg: artLightTree()),
        FaceBackdrop(id: "artDragon", title: "Rồng vàng", top: 0x2A0306, bottom: 0x7A1010, svg: artDragon()),
        FaceBackdrop(id: "artSakura", title: "Anh đào dưới trăng", top: 0x1A0F2E, bottom: 0x5C2A5E, svg: artSakura()),
        FaceBackdrop(id: "artKoi", title: "Cá koi", top: 0x063A4A, bottom: 0x0B6E6B, svg: artKoi()),
        FaceBackdrop(id: "artPlanet", title: "Hành tinh", top: 0x05030F, bottom: 0x1B0B3A, svg: artPlanet()),
        FaceBackdrop(id: "artSynth", title: "Hoàng hôn synthwave", top: 0x12002E, bottom: 0x4A0A5C, svg: artSynth())
    ]

    private static func artSanta() -> String {
        var s = SVGBuilder(seed: 301)
        s.glow(233, 230, 220, "#FF7A66", steps: 6, peak: 0.25)
        s.stars(46, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 2.4, op: 0.6)
        s.ellipse(233, 262, 96, 86, fill: "#F8CBAE")
        s.path("M 92 176 Q 110 66 232 52 Q 330 44 398 98 Q 362 96 344 116 Q 376 148 374 176 Z", fill: "#E8302A")
        s.path("M 232 52 Q 330 44 398 98 Q 362 96 344 116", stroke: "#FF8A78", sw: 3, op: 0.5)
        s.circle(402, 100, 30, "#FFFFFF")
        s.circle(392, 90, 12, "#EAF1FF", 0.7)
        for i in 0..<9 { s.circle(86 + Double(i) * 36, 182, 24, "#FFFFFF") }
        s.circle(195, 246, 9, "#2B1A14"); s.circle(271, 246, 9, "#2B1A14")
        s.circle(198, 243, 3, "#FFFFFF"); s.circle(274, 243, 3, "#FFFFFF")
        s.circle(166, 284, 21, "#FF8FA3", 0.75); s.circle(300, 284, 21, "#FF8FA3", 0.75)
        s.ellipse(233, 352, 118, 66, fill: "#FFFFFF")
        let beard: [(Double, Double, Double)] = [(100, 300, 36), (122, 346, 38), (158, 392, 40), (233, 420, 46), (308, 392, 40), (344, 346, 38), (366, 300, 36)]
        for b in beard { s.circle(b.0, b.1, b.2, "#FFFFFF") }
        s.ellipse(233, 340, 15, 7, fill: "#C8372D")
        s.ellipse(198, 314, 56, 24, fill: "#F2F5FF")
        s.ellipse(268, 314, 56, 24, fill: "#F2F5FF")
        s.circle(233, 285, 18, "#E0201B")
        s.circle(227, 279, 5, "#FF9A90", 0.9)
        return s.out
    }

    private static func artSnowman() -> String {
        var s = SVGBuilder(seed: 311)
        s.glow(90, 90, 120, "#CFE6FF", steps: 6, peak: 0.3)
        s.circle(90, 90, 30, "#F4F8FF", 0.95)
        s.stars(70, x0: 0, y0: 0, x1: 466, y1: 300, color: "#FFFFFF", maxR: 2.2, op: 0.8)
        let trees: [(Double, Double, Double)] = [(70, 380, 70), (140, 395, 56), (40, 330, 46)]
        for t in trees {
            for k in 0..<3 {
                let y = t.1 - Double(k) * t.2 * 0.42
                let w = t.2 * (0.62 - Double(k) * 0.14)
                s.path("M \(t.0) \(y - t.2 * 0.62) L \(t.0 + w) \(y) L \(t.0 - w) \(y) Z", fill: "#14653F")
                s.path("M \(t.0) \(y - t.2 * 0.62) L \(t.0 + w * 0.55) \(y - t.2 * 0.2) L \(t.0 - w * 0.55) \(y - t.2 * 0.2) Z", fill: "#FFFFFF", op: 0.55)
            }
        }
        s.waveFill(y: 392, amp: 14, color: "#EAF4FF", op: 0.96)
        s.waveFill(y: 424, amp: 10, color: "#BFD6F2", op: 0.9, phase: 6)
        s.circle(332, 352, 72, "#FFFFFF")
        s.circle(332, 262, 50, "#FFFFFF")
        s.circle(332, 352, 72, "#CFE0F7", 0.18)
        s.rect(302, 192, 60, 40, "#1E1E26")
        s.rect(288, 228, 88, 9, "#1E1E26", rx: 3)
        s.rect(302, 212, 60, 8, "#D2231B")
        s.path("M 288 296 Q 332 322 376 296 L 372 316 Q 332 342 292 316 Z", fill: "#D2231B")
        s.path("M 360 312 L 372 352 L 350 346 Z", fill: "#D2231B")
        s.path("M 332 266 L 384 274 L 332 282 Z", fill: "#FF8A1F")
        s.circle(316, 250, 5, "#1E1E26"); s.circle(348, 250, 5, "#1E1E26")
        for i in 0..<4 { s.circle(332, 340 + Double(i) * 18, 5, "#1E1E26") }
        s.path("M 262 330 L 232 300 M 232 300 L 220 306 M 232 300 L 236 286", stroke: "#5A3A22", sw: 5)
        s.path("M 402 330 L 436 304 M 436 304 L 446 312 M 436 304 L 438 288", stroke: "#5A3A22", sw: 5)
        return s.out
    }

    private static func artLightTree() -> String {
        var s = SVGBuilder(seed: 321)
        s.stars(60, x0: 0, y0: 0, x1: 466, y1: 330, color: "#FFFFFF", maxR: 2, op: 0.7)
        s.glow(233, 220, 190, "#2BFF88", steps: 7, peak: 0.16)
        s.path("M 233 66 L 304 172 L 162 172 Z", fill: "#1E8A4A")
        s.path("M 233 118 L 334 252 L 132 252 Z", fill: "#17753D")
        s.path("M 233 178 L 366 342 L 100 342 Z", fill: "#0F5F31")
        s.rect(216, 342, 34, 42, "#6B3E1E")
        let lights: [(Double, Double, String)] = [
            (233, 110, "#FF4D6D"), (210, 148, "#FFD84A"), (258, 150, "#4DB8FF"), (190, 200, "#FF4D6D"), (240, 196, "#FFD84A"),
            (284, 214, "#4DFFB0"), (166, 252, "#4DB8FF"), (214, 262, "#FF8A1F"), (262, 268, "#FF4D6D"), (312, 270, "#FFD84A"),
            (140, 310, "#FFD84A"), (192, 320, "#4DFFB0"), (246, 322, "#4DB8FF"), (300, 318, "#FF4D6D"), (344, 322, "#FF8A1F")
        ]
        for l in lights {
            s.glow(l.0, l.1, 14, l.2, steps: 3, peak: 0.5)
            s.circle(l.0, l.1, 4.5, l.2)
        }
        s.path("M 170 170 Q 233 200 296 170 M 150 248 Q 233 286 316 248 M 120 336 Q 233 380 346 336", stroke: "#FFD84A", sw: 2, op: 0.6)
        s.glow(233, 64, 42, "#FFE27A", steps: 5, peak: 0.6)
        s.sparkle(233, 64, 26, "#FFD84A", 1)
        s.waveFill(y: 408, amp: 12, color: "#EAF4FF", op: 0.95)
        s.rect(96, 374, 56, 44, "#D2231B", rx: 3); s.rect(120, 374, 8, 44, "#FFD84A"); s.rect(96, 392, 56, 8, "#FFD84A")
        s.rect(316, 382, 60, 40, "#2B6FD6", rx: 3); s.rect(342, 382, 8, 40, "#FFFFFF"); s.rect(316, 398, 60, 8, "#FFFFFF")
        return s.out
    }

    private static func artDragon() -> String {
        var s = SVGBuilder(seed: 331)
        s.glow(233, 233, 210, "#FF5A3C", steps: 7, peak: 0.28)
        s.ring(233, 233, 214, "#E8B040", 1.4, 0.5)
        s.ring(233, 233, 202, "#E8B040", 0.8, 0.35)
        let clouds: [(Double, Double, Double)] = [(90, 330, 34), (130, 350, 26), (380, 140, 30), (340, 118, 22), (60, 200, 22)]
        for c in clouds { s.circle(c.0, c.1, c.2, "#FFD97A", 0.18); s.ring(c.0, c.1, c.2, "#FFD97A", 1.2, 0.35) }
        s.circle(382, 330, 24, "#FF4A3A", 0.95)
        s.glow(382, 330, 44, "#FF8A5A", steps: 5, peak: 0.5)
        let body = "M 120 120 C 340 80 372 226 233 233 C 94 240 128 388 340 352"
        s.path(body, stroke: "#9A5A12", sw: 30, op: 0.9)
        s.path(body, stroke: "#E8B040", sw: 24)
        s.path(body, stroke: "#FFE3A0", sw: 6, op: 0.7)
        s.path("M 340 352 Q 380 372 398 346 Q 384 366 352 354", fill: "#E8B040", stroke: "#E8B040", sw: 3)
        s.circle(112, 120, 31, "#E8B040")
        s.ellipse(80, 132, 28, 15, fill: "#E8B040")
        s.path("M 98 92 Q 80 58 50 54 Q 78 76 88 100", fill: "#FFD97A")
        s.path("M 124 88 Q 118 56 96 40 Q 112 66 114 92", fill: "#FFD97A")
        s.path("M 60 146 Q 40 168 54 186 Q 60 166 76 150", fill: "#FFD97A")
        s.circle(106, 112, 6, "#2B0A0A"); s.circle(108, 110, 2, "#FFFFFF")
        let scales: [(Double, Double)] = [(180, 108), (236, 118), (300, 150), (322, 196), (280, 232), (200, 244), (150, 290), (176, 340), (240, 372), (300, 372)]
        for sc in scales { s.ring(sc.0, sc.1, 6, "#7A3A08", 1.6, 0.6) }
        return s.out
    }

    private static func artSakura() -> String {
        var s = SVGBuilder(seed: 341)
        s.stars(46, x0: 0, y0: 0, x1: 466, y1: 260, color: "#FFFFFF", maxR: 1.8, op: 0.7)
        s.glow(350, 110, 120, "#FFE9D6", steps: 6, peak: 0.3)
        s.circle(350, 110, 52, "#FFF4E8", 0.95)
        s.circle(336, 98, 9, "#F2DFCB", 0.5); s.circle(366, 126, 6, "#F2DFCB", 0.5)
        s.path("M 0 150 C 90 170 150 110 240 170 C 300 210 340 250 466 238", stroke: "#2F1A12", sw: 12)
        s.path("M 150 128 C 170 90 200 74 236 70", stroke: "#2F1A12", sw: 7)
        s.path("M 240 170 C 250 210 236 250 214 290", stroke: "#2F1A12", sw: 6)
        s.path("M 330 232 C 346 270 380 290 420 300", stroke: "#2F1A12", sw: 5)
        let flowers: [(Double, Double, Double)] = [(60, 164, 22), (130, 140, 26), (190, 118, 20), (236, 72, 24), (262, 186, 28), (214, 292, 22), (300, 214, 22), (372, 250, 26), (420, 302, 20), (100, 190, 16), (340, 300, 14)]
        for f in flowers { s.blossom(f.0, f.1, f.2, "#FFB3D1", "#FFD54A") }
        for _ in 0..<26 {
            let x = s.rnd() * 466, y = 200 + s.rnd() * 220
            let o = 0.5 + s.rnd() * 0.4
            s.ellipse(x, y, 5, 3, fill: "#FFC2DA", op: o)
        }
        s.waveFill(y: 416, amp: 10, color: "#2A1A44", op: 0.95)
        s.waveLine(y: 430, amp: 6, color: "#FFC2DA", sw: 1.2, op: 0.4)
        return s.out
    }

    private static func artKoi() -> String {
        var s = SVGBuilder(seed: 351)
        s.glow(233, 100, 170, "#BFFFF0", steps: 6, peak: 0.2)
        for i in 0..<6 {
            s.ellipse(233, 250, 60 + Double(i) * 30, 40 + Double(i) * 22, stroke: "#A8F0E6", sw: 1, op: 0.26 - Double(i) * 0.03)
        }
        let pads: [(Double, Double, Double)] = [(80, 110, 40), (390, 90, 34), (60, 380, 44), (400, 390, 48), (230, 430, 30)]
        for p in pads {
            s.ellipse(p.0, p.1, p.2, p.2 * 0.7, fill: "#2E8B57", op: 0.85)
            s.path("M \(p.0) \(p.1) L \(p.0 + p.2) \(p.1 - p.2 * 0.2)", stroke: "#0B4A2E", sw: 1.4, op: 0.6)
        }
        s.blossom(80, 100, 20, "#FFB6D0", "#FFD54A")
        s.blossom(400, 398, 24, "#FFFFFF", "#FFD54A")
        s.path("M 124 232 Q 92 204 68 224 Q 94 234 68 250 Q 96 260 124 232 Z", fill: "#FF9A4A", op: 0.9)
        s.ellipse(172, 232, 50, 19, fill: "#FF7A2E")
        s.ellipse(162, 229, 20, 10, fill: "#FFF3E6")
        s.path("M 172 214 Q 186 196 200 210 Q 190 216 180 216 Z", fill: "#FF9A4A", op: 0.9)
        s.circle(212, 228, 3, "#2B0A0A")
        s.path("M 366 322 Q 396 296 418 314 Q 394 324 418 340 Q 392 350 366 322 Z", fill: "#FFFFFF", op: 0.85)
        s.ellipse(318, 322, 46, 17, fill: "#F4F4F4")
        s.ellipse(326, 319, 17, 9, fill: "#E0402A")
        s.path("M 318 306 Q 304 290 290 302 Q 300 308 308 308 Z", fill: "#FFFFFF", op: 0.85)
        s.circle(280, 320, 3, "#2B0A0A")
        return s.out
    }

    private static func artPlanet() -> String {
        var s = SVGBuilder(seed: 361)
        s.glow(120, 120, 160, "#7A3CFF", steps: 7, peak: 0.3)
        s.glow(360, 360, 180, "#FF3C9A", steps: 7, peak: 0.25)
        s.stars(130, x0: 0, y0: 0, x1: 466, y1: 466, color: "#FFFFFF", maxR: 2.2, op: 0.85)
        s.circle(110, 340, 24, "#C9CCE0"); s.circle(102, 332, 6, "#A9ADC4", 0.8); s.circle(120, 350, 4, "#A9ADC4", 0.8)
        s.circle(300, 250, 96, "#E8884A")
        s.ellipse(300, 205, 80, 9, fill: "#F4B27A", op: 0.65)
        s.ellipse(300, 235, 90, 7, fill: "#B85A2A", op: 0.6)
        s.ellipse(300, 270, 88, 10, fill: "#F6C08A", op: 0.6)
        s.ellipse(300, 302, 74, 8, fill: "#B85A2A", op: 0.55)
        s.circle(268, 214, 70, "#FFFFFF", 0.06)
        s.ellipse(300, 254, 160, 32, stroke: "#F6D9A8", sw: 7, op: 0.7)
        s.ellipse(300, 254, 140, 26, stroke: "#C99A5A", sw: 3, op: 0.5)
        s.sparkle(70, 90, 16, "#FFFFFF"); s.sparkle(420, 70, 12, "#FFFFFF"); s.sparkle(400, 420, 14, "#FFD6F0")
        return s.out
    }

    private static func artSynth() -> String {
        var s = SVGBuilder(seed: 371)
        s.stars(60, x0: 0, y0: 0, x1: 466, y1: 230, color: "#FFFFFF", maxR: 1.8, op: 0.8)
        s.glow(233, 220, 200, "#FF4FD8", steps: 7, peak: 0.28)
        s.circle(233, 215, 105, "#FF4F8B")
        s.circle(233, 185, 75, "#FF8C5A", 0.55)
        s.rect(120, 250, 226, 4, "#2A0845"); s.rect(120, 270, 226, 6, "#2A0845"); s.rect(120, 290, 226, 8, "#2A0845")
        s.path("M 0 300 L 40 262 L 80 290 L 120 250 L 170 300 Z", fill: "#240A4A")
        s.path("M 300 300 L 350 256 L 392 288 L 430 240 L 466 280 L 466 300 Z", fill: "#240A4A")
        s.rect(0, 300, 466, 166, "#1A0536")
        s.rect(0, 298, 466, 3, "#FF4FD8", 0.9)
        var x = -300.0
        while x <= 766 {
            s.path("M 233 300 L \(x) 466", stroke: "#FF4FD8", sw: 1.2, op: 0.5)
            x += 70
        }
        for y in [312.0, 328, 348, 374, 410, 454] {
            s.path("M 0 \(y) L 466 \(y)", stroke: "#FF4FD8", sw: 1.2, op: 0.5)
        }
        return s.out
    }
}
