# Bộ SVG kim đồng hồ và vật thể xoay

Xem trước: chạy `python3 -m http.server` trong thư mục `svg/` rồi mở `xem-truoc.html`.

## Quy ước chung (khớp `FaceRenderer` trong FaceDesign.swift)
- Canvas 512×512, tâm xoay (256,256), đầu kim hướng lên (12 giờ). Mặt app 466 px nên nhân 466/512 khi vẽ.
- Kích thước ở hệ 512 (đã quy đổi từ `geometry()`): giờ reach 137 / tail 26, phút 203 / 30, giây 226 / 46.
- Màu mặc định: giờ, phút `#FFFFFF`; giây `#FF4D59`. Đổi màu bằng cách thay đúng mã đó. Chỗ rỗng là khoảng trong suốt thật (fill-rule evenodd), chỗ đậm thêm là `#000000` có opacity.
- Mỗi kiểu có 3 file: `gio.svg`, `phut.svg`, `giay.svg`. Danh sách và số đo: `kim/kim.json`.

## kim/ (26 kiểu)
thanh, nhon, dauphine, kiem, la-tre, la-sen, canh-sen, mui-ten, breguet, nha-tho, khung-rong, alpha, da-quang, hoa-tuyet, keo-mut, long-vu, tia-set, but-chi, mui-giao, sao-vang, trong-dong, giot-nuoc, chuoi-hat, non-la, kim-cuong, ten-lua

## dong/ (17 vật thể xoay)
Vật thể nằm ở đỉnh quỹ đạo (bán kính 205), có sẵn vệt sáng phía sau. Dùng như lớp trang trí xoay theo kim giờ, phút hoặc giây (tương ứng `DecorSpin`). Danh sách: `dong/dong.json`.

## Tái tạo
`python3 -I _tao/hands.py kim` và `python3 -I _tao/dong.py dong`.

## so-gio/ (8 kiểu số giờ)
manh, dam, vuong (bảy đoạn), la-ma, la-ma-xoay, huong-tam, vong, bon-so. Mỗi kiểu có `mat-so.svg` (cả vòng 1–12 trên canvas 512, tâm (256,256), màu `#FFFFFF`) và thư mục `so/` chứa từng số riêng (128×128) để tự xếp vị trí. Số vẽ bằng nét vector, không phụ thuộc font. Tái tạo: `python3 -I _tao/so.py so-gio`.

## so-gio-cach-dieu/ (12 kiểu số giờ từ nét chữ)
cardo, cardo-nghieng, crimson-nghieng, free-serif, dunhill, inter-manh, anton, archivo, vien-rong, bong-doi, la-ma-cardo, la-ma-vien. Cấu trúc giống `so-gio/` (`mat-so.svg` cả vòng + `so/01..12.svg`), nhưng nét chữ được chuyển thành đường vẽ nên không cần font khi app dựng ảnh. Tái tạo: `python3 -I _tao/sofont.py so-gio-cach-dieu` (cần fontTools và các font nêu trong script).
Nguồn font: Cardo, Crimson Text, Anton, Archivo Black, Inter Display (SIL OFL); FreeSerif (GPL kèm ngoại lệ font); Latin Modern Dunhill (GUST Font License). Các giấy phép này cho phép dùng đường vẽ chuyển từ font; nên ghi công vào THIRD_PARTY_NOTICES.md.

## hieu-ung/ (23 hiệu ứng động, nền trong suốt, tâm (256,256))
Dùng SMIL (animate, animateTransform, animateMotion), chạy được khi nhúng bằng thẻ `<img>` hoặc `WKWebView`. Danh sách: `hieu-ung/hieu-ung.json`. Xem thử và chồng nhiều lớp: `xem-truoc-hieu-ung.html`.
- neon/: vong-xoay, vach, radar, song-lan, so, luc-giac, tia, cung-hud, cau-vong, sao, kim-gio, kim-phut, kim-giay
- tet/: mai-roi, dao-roi, phao-hoa, long-den, mai-vong, li-xi, dong-tien, lap-lanh, vien-tet, canh-mai
Lưu ý: bộ dựng HWT hiện rasterize ảnh tĩnh nên các hiệu ứng này chạy động trong phần xem trước và giao diện tạo mặt; khi xuất ra đồng hồ chỉ lấy được một khung hình. Hiệu ứng chuyển động thật trên đồng hồ cần dùng lớp xoay (`dong/`) hoặc kim.
Tái tạo: `python3 -I _tao/hieuung.py hieu-ung`.
