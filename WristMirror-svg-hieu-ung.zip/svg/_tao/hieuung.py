import os, sys, math, random, json
OUT=sys.argv[1]
random.seed(7)
def n(v):
    s=("%.1f"%v).rstrip("0").rstrip("."); return "0" if s in("-0","") else s
CYAN,MAG,LIME,ORG,WHT="#00F0FF","#FF2BD6","#B6FF3B","#FF8A00","#FFFFFF"
GLOW='<filter id="g" filterUnits="userSpaceOnUse" x="-20" y="-20" width="552" height="552"><feGaussianBlur stdDeviation="3.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
def svg(title,defs,body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">\n<title>{title}</title>\n'
            f'<!-- hiệu ứng động SMIL, nền trong suốt, tâm (256,256) -->\n<defs>{defs}</defs>\n{body}\n</svg>\n')
def rot(dur,fr=0,to=360,c="256 256",extra=""):
    return f'<animateTransform attributeName="transform" type="rotate" from="{fr} {c}" to="{to} {c}" dur="{dur}s" repeatCount="indefinite" {extra}/>'
def pulse(vals,dur,begin=0,attr="opacity"):
    return f'<animate attributeName="{attr}" values="{vals}" dur="{dur}s" begin="{begin}s" repeatCount="indefinite"/>'
def neon_ring(r,col,w=4,dash="",extra=""):
    d=f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<circle cx="256" cy="256" r="{r}" fill="none" stroke="{col}" stroke-width="{w}"{d} stroke-linecap="round" filter="url(#g)">{extra}</circle>'
            f'<circle cx="256" cy="256" r="{r}" fill="none" stroke="#fff" stroke-width="{n(w*.3)}"{d} stroke-linecap="round" opacity=".85">{extra}</circle>')
E={}  # slug -> (nhóm, tên, svg)
# ---------- NEON ----------
def N(slug,name,s): E[slug]=("neon",name,s)
N("vong-xoay","Vòng neon xoay",svg("Vòng neon xoay",GLOW,
  f'<g>{neon_ring(240,CYAN,4,"120 40 20 40",rot(14))}</g>'.replace("<circle","<circle",1)
  + f'<g>{neon_ring(216,MAG,4,"60 30 200 30",rot(10,360,0))}</g>'
  + f'<g>{neon_ring(192,LIME,3,"10 14",rot(30))}</g>'))
t=""
for i in range(60):
    a=i*6; M=i%5==0
    col=CYAN if M else "#7fe8ff"
    r1,r2=(224,252) if M else (236,252)
    t+=f'<line x1="256" y1="{256-r1}" x2="256" y2="{256-r2}" stroke="{col}" stroke-width="{6 if M else 2.5}" stroke-linecap="round" transform="rotate({a} 256 256)" filter="url(#g)">{pulse(".35;1;.35",3,-i*0.05)}</line>'
N("vach","Vạch neon nhấp nháy",svg("Vạch neon nhấp nháy",GLOW,t))
N("radar","Quét radar neon",svg("Quét radar neon",
  f'{GLOW}<linearGradient id="w" gradientUnits="userSpaceOnUse" x1="256" y1="16" x2="30" y2="174"><stop offset="0" stop-color="{LIME}" stop-opacity=".6"/><stop offset="1" stop-color="{LIME}" stop-opacity="0"/></linearGradient>',
  f'<g><path d="M256,256L256,16A240,240 0 0,0 30.4,173.9Z" fill="url(#w)"/><line x1="256" y1="256" x2="256" y2="16" stroke="{LIME}" stroke-width="3" filter="url(#g)"/>{rot(4)}</g>'
  +"".join(f'<circle cx="256" cy="256" r="{r}" fill="none" stroke="{LIME}" stroke-width="1.5" opacity=".4"/>' for r in (60,120,180,240))))
N("song-lan","Sóng lan neon",svg("Sóng lan neon",GLOW,
  "".join(f'<circle cx="256" cy="256" r="20" fill="none" stroke="{c}" stroke-width="4" filter="url(#g)"><animate attributeName="r" values="20;245" dur="4s" begin="{b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="4s" begin="{b}s" repeatCount="indefinite"/></circle>' for c,b in ((CYAN,0),(MAG,1.33),(LIME,2.66)))))
# số neon bằng nét
G={'0':"M5,0C9,0 10,4 10,8C10,12 9,16 5,16C1,16 0,12 0,8C0,4 1,0 5,0Z",'1':"M2,3.5L6,0V16",'2':"M0.5,4C0.5,-1.5 9.5,-1.5 9.5,4.5C9.5,8 3,11 0.5,16H10",'3':"M1,1.5C5,-1.5 9.5,1 8.5,5C8,7.5 5,8 4,8C6,8 10,9 9.5,12C9,17 3,17.5 0.5,14.5",'4':"M8,16V0L0,11H10",'5':"M9,0H2L1,7.5C5,5.5 10,7 9.5,11.5C9,16.5 3,17 0.5,14",'6':"M8.5,1.5C5,-1 1,3 0.5,9C0,16 9,17 9.5,11.5C10,7 4,6 0.5,10",'7':"M0.5,0H9.5L3.5,16",'8':"M5,8C0,7 0.5,0 5,0C9.5,0 10,7 5,8C0,9 -0.5,16 5,16C10.5,16 10,9 5,8Z",'9':"M1.5,14.5C5,17 9,13 9.5,7C10,0 1,-1 0.5,4.5C0,9 6,10 9.5,6"}
def num(k):
    x=0;ps=[]
    for c in str(k): ps.append(f'<path transform="translate({x} 0)" d="{G[c]}"/>'); x+=13.5
    return x-3.5,"".join(ps)
t=""
for k in range(1,13):
    a=math.radians(k*30); cx,cy=256+186*math.sin(a),256-186*math.cos(a); w,ps=num(k); s=34/16
    col=MAG if k%3==0 else CYAN
    fl=pulse("1;1;.35;1;.2;1;1",4+k*.37,-k) if k in(2,5,9,11) else ""
    t+=(f'<g transform="translate({n(cx)} {n(cy)}) scale({n(s)}) translate({n(-w/2)} -8)" fill="none" stroke-linecap="round" stroke-linejoin="round">'
        f'<g stroke="{col}" stroke-width="{n(3.2/s)}" filter="url(#g)">{ps}</g><g stroke="#fff" stroke-width="{n(1/s)}">{ps}</g>{fl}</g>')
N("so","Số neon",svg("Số neon",GLOW,t))
def hexp(r,off=0): return " ".join(f"{n(256+r*math.cos(math.radians(60*i+off-90)))},{n(256+r*math.sin(math.radians(60*i+off-90)))}" for i in range(6))
N("luc-giac","Lục giác neon",svg("Lục giác neon",GLOW,
  f'<g><polygon points="{hexp(238)}" fill="none" stroke="{CYAN}" stroke-width="4" stroke-linejoin="round" filter="url(#g)"/><polygon points="{hexp(238)}" fill="none" stroke="#fff" stroke-width="1.2"/>{rot(24)}</g>'
  f'<g><polygon points="{hexp(205,30)}" fill="none" stroke="{MAG}" stroke-width="3" stroke-linejoin="round" filter="url(#g)"/>{rot(18,360,0)}</g>'
  +"".join(f'<circle cx="{hexp(238).split()[i].split(",")[0]}" cy="{hexp(238).split()[i].split(",")[1]}" r="5" fill="#fff" filter="url(#g)">{pulse("1;.2;1",2,-i*.33)}</circle>' for i in range(6))))
t=""
for i in range(24):
    L=(150,240) if i%2==0 else (185,240)
    t+=f'<line x1="256" y1="{256-L[0]}" x2="256" y2="{256-L[1]}" stroke="{CYAN}" stroke-width="3" stroke-linecap="round" transform="rotate({i*15} 256 256)" filter="url(#g)"><animate attributeName="stroke" values="{CYAN};{MAG};{LIME};{CYAN}" dur="8s" begin="{-i*.3}s" repeatCount="indefinite"/>{pulse(".3;1;.3",2.4,-i*.1)}</line>'
N("tia","Tia neon đổi màu",svg("Tia neon đổi màu",GLOW,f'<g>{t}{rot(40)}</g>'))
def arc(r,a0,a1):
    p0=(256+r*math.sin(math.radians(a0)),256-r*math.cos(math.radians(a0))); p1=(256+r*math.sin(math.radians(a1)),256-r*math.cos(math.radians(a1)))
    return f'M{n(p0[0])},{n(p0[1])}A{r},{r} 0 {1 if a1-a0>180 else 0},1 {n(p1[0])},{n(p1[1])}'
t=""
for r,a,b,c,sp in ((246,0,100,CYAN,9),(228,120,200,MAG,7),(210,220,350,LIME,12),(192,30,150,ORG,5)):
    t+=f'<g><path d="{arc(r,a,b)}" fill="none" stroke="{c}" stroke-width="5" stroke-linecap="round" filter="url(#g)"/><path d="{arc(r,a,b)}" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>{rot(sp,0,360 if r%4==0 else -360)}</g>'
N("cung-hud","Cung HUD neon",svg("Cung HUD neon",GLOW,t))
N("cau-vong","Vành cầu vồng",svg("Vành cầu vồng",
  f'{GLOW}<linearGradient id="r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF2BD6"/><stop offset=".33" stop-color="#00F0FF"/><stop offset=".66" stop-color="#B6FF3B"/><stop offset="1" stop-color="#FF2BD6"/></linearGradient>',
  f'<g><circle cx="256" cy="256" r="236" fill="none" stroke="url(#r)" stroke-width="9" filter="url(#g)"/><circle cx="256" cy="256" r="236" fill="none" stroke="#fff" stroke-width="2" opacity=".8"/>{rot(8)}</g>'))
def star(cx,cy,ro,ri):
    return " ".join(f"{n(cx+(ro if i%2==0 else ri)*math.cos(-math.pi/2+i*math.pi/5))},{n(cy+(ro if i%2==0 else ri)*math.sin(-math.pi/5*0-math.pi/2+i*math.pi/5))}" for i in range(10))
N("sao","Sao neon thở",svg("Sao neon thở",GLOW,
  "".join(f'<polygon points="{star(256,256,r,r*.4)}" fill="none" stroke="{c}" stroke-width="3" stroke-linejoin="round" filter="url(#g)" opacity=".7" transform-origin="256 256"><animateTransform attributeName="transform" type="scale" additive="sum" values="1;1.08;1" dur="3s" begin="{-b}s" repeatCount="indefinite"/>{pulse(".3;1;.3",3,-b)}</polygon>' for r,c,b in ((220,CYAN,0),(150,MAG,1),(85,LIME,2)))))
# kim neon
def hand(R,T,W,col,name):
    p=f"{n(0)},{n(-R)} {n(W/2)},{n(-R*.3)} {n(W*.3)},{n(T)} {n(-W*.3)},{n(T)} {n(-W/2)},{n(-R*.3)}"
    return svg(name,GLOW,f'<g transform="translate(256 256)"><polygon points="{p}" fill="{col}" fill-opacity=".12" stroke="{col}" stroke-width="3" stroke-linejoin="round" filter="url(#g)"/><polygon points="{p}" fill="none" stroke="#fff" stroke-width="1.2" stroke-linejoin="round"/></g>')
for k,(R,T,W,c,nm) in {"kim-gio":(137,26,26,CYAN,"Kim giờ neon"),"kim-phut":(203,30,21,MAG,"Kim phút neon"),"kim-giay":(226,46,8,LIME,"Kim giây neon")}.items():
    N(k,nm,hand(R,T,W,c,nm))
# ---------- TẾT ----------
def T(slug,name,s): E[slug]=("tet",name,s)
MAI='<g id="mai"><g fill="#FFD21F" stroke="#E8A800" stroke-width=".8">'+"".join(f'<circle cx="{n(7*math.sin(math.radians(a)))}" cy="{n(-7*math.cos(math.radians(a)))}" r="6" transform="rotate(0)"/>' for a in range(0,360,72))+'</g><circle r="3.2" fill="#E8730C"/>'+"".join(f'<circle cx="{n(5*math.sin(math.radians(a+36)))}" cy="{n(-5*math.cos(math.radians(a+36)))}" r=".9" fill="#8a3b00"/>' for a in range(0,360,72))+'</g>'
DAO='<g id="dao"><g fill="#FF8DB0" stroke="#E0457B" stroke-width=".8">'+"".join(f'<ellipse cx="0" cy="-7" rx="5.5" ry="7" transform="rotate({a})"/>' for a in range(0,360,72))+'</g><circle r="3" fill="#FFE27A"/></g>'
def fall(sym,count,dur0,sc=(.7,1.4)):
    t=""
    for i in range(count):
        x=random.uniform(10,500); dx=random.uniform(-60,60); s=random.uniform(*sc); d=random.uniform(dur0,dur0*1.8); b=-random.uniform(0,d)
        t+=(f'<g><g transform="scale({n(s)})"><use href="#{sym}">{rot(random.uniform(3,7),0,random.choice((360,-360)),"0 0")}</use></g>'
            f'<animateMotion path="M{n(x)},-20 L{n(x+dx)},535" dur="{n(d)}s" begin="{n(b)}s" repeatCount="indefinite"/></g>')
    return t
T("mai-roi","Hoa mai rơi",svg("Hoa mai rơi",MAI,fall("mai",16,7)))
T("dao-roi","Hoa đào rơi",svg("Hoa đào rơi",DAO,fall("dao",16,7)))
def burst(x,y,col,col2,b,n_=16,r=70):
    ls="".join(f'<line x1="0" y1="{-r*.35}" x2="0" y2="{-r*(1 if i%2 else .75)}" stroke="{col if i%2 else col2}" stroke-width="3" stroke-linecap="round" transform="rotate({i*360/n_})"/>' for i in range(n_))
    ds="".join(f'<circle cx="0" cy="{-r*1.05}" r="3" fill="{col2}" transform="rotate({i*360/n_+11})"/>' for i in range(n_))
    return (f'<g transform="translate({x} {y})"><g opacity="0">{ls}{ds}'
            f'<animateTransform attributeName="transform" type="scale" values="0.15;1;1.15" keyTimes="0;.6;1" dur="2.6s" begin="{b}s" repeatCount="indefinite"/>'
            f'<animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.6;1" dur="2.6s" begin="{b}s" repeatCount="indefinite"/></g></g>')
T("phao-hoa","Pháo hoa",svg("Pháo hoa","",burst(150,150,"#FF4D4D","#FFD21F",0)+burst(370,130,"#FFD21F","#FF8A00",.9)+burst(260,320,"#FF2BD6","#FFE27A",1.7,20,80)+burst(110,360,"#00F0FF","#FFFFFF",2.1,14,55)))
def lantern(x,y,s,b,sw=7):
    return (f'<g transform="translate({x} {y}) scale({s})"><g>'
            f'<line x1="0" y1="-60" x2="0" y2="-30" stroke="#C99700" stroke-width="3"/>'
            f'<rect x="-14" y="-32" width="28" height="8" rx="3" fill="#E8B923"/><ellipse cx="0" cy="0" rx="34" ry="30" fill="#D7191C"/>'
            f'<ellipse cx="0" cy="0" rx="18" ry="30" fill="none" stroke="#FF6B5E" stroke-width="2.5"/><ellipse cx="0" cy="0" rx="34" ry="30" fill="none" stroke="#8E0E10" stroke-width="2"/>'
            f'<rect x="-14" y="26" width="28" height="8" rx="3" fill="#E8B923"/>'
            f'<g stroke="#FFD21F" stroke-width="2.4" stroke-linecap="round"><line x1="-8" y1="34" x2="-8" y2="62"/><line x1="0" y1="34" x2="0" y2="68"/><line x1="8" y1="34" x2="8" y2="62"/></g>'
            f'<animateTransform attributeName="transform" type="rotate" values="{-sw} 0 -60;{sw} 0 -60;{-sw} 0 -60" keyTimes="0;.5;1" dur="3.6s" begin="{b}s" repeatCount="indefinite" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1"/>'
            f'</g></g>')
T("long-den","Lồng đèn đung đưa",svg("Lồng đèn đung đưa","",lantern(96,95,1,0)+lantern(416,95,1,-1.2)+lantern(256,40,.7,-.6,5)))
t="".join(f'<g transform="rotate({i*30} 256 256)"><use href="#mai" transform="translate(256 22) scale({1.5 if i%2==0 else 1.1})"/></g>' for i in range(12))
T("mai-vong","Vòng hoa mai xoay",svg("Vòng hoa mai xoay",MAI,f'<g>{t}{rot(90)}</g>'))
def lixi(x,b,d,s):
    return (f'<g><g transform="scale({s})"><g><rect x="-17" y="-24" width="34" height="48" rx="4" fill="#D7191C" stroke="#8E0E10" stroke-width="1.5"/>'
            f'<path d="M-17,-24L0,-4L17,-24" fill="#B01214"/><circle cx="0" cy="6" r="8" fill="#FFD21F"/><circle cx="0" cy="6" r="4.5" fill="none" stroke="#B88700" stroke-width="1.2"/>'
            f'<animateTransform attributeName="transform" type="rotate" values="-14;14;-14" dur="2.4s" begin="{b}s" repeatCount="indefinite"/></g></g>'
            f'<animateMotion path="M{x},-40 L{x+random.uniform(-40,40)},550" dur="{d}s" begin="{b}s" repeatCount="indefinite"/></g>')
T("li-xi","Lì xì rơi",svg("Lì xì rơi","","".join(lixi(60+i*75,-i*1.3,8+i%3,.9+(i%2)*.3) for i in range(6))))
def coin(i,n_=8,r=215):
    a=i*360/n_
    return (f'<g transform="rotate({a} 256 256) translate(256 {256-r})"><g><circle r="15" fill="#FFD21F" stroke="#B88700" stroke-width="2"/>'
            f'<rect x="-5" y="-5" width="10" height="10" fill="#161616" stroke="#B88700" stroke-width="1.2"/><circle r="11.5" fill="none" stroke="#fff3a8" stroke-width="1" opacity=".7"/>'
            f'<animateTransform attributeName="transform" type="scale" values="1 1;0.12 1;1 1" dur="3s" begin="{-i*.37}s" repeatCount="indefinite" calcMode="spline" keySplines=".4 0 .6 1;.4 0 .6 1" keyTimes="0;.5;1"/></g></g>')
T("dong-tien","Đồng tiền xoay",svg("Đồng tiền xoay","",f'<g>{"".join(coin(i) for i in range(8))}{rot(40)}</g>'))
t=""
for i in range(20):
    a=random.uniform(0,2*math.pi); r=random.uniform(70,235); x,y=256+r*math.cos(a),256+r*math.sin(a); s=random.uniform(.6,1.3); b=-random.uniform(0,3)
    t+=(f'<g transform="translate({n(x)} {n(y)})"><path d="M0,-10C1,-3 3,-1 10,0C3,1 1,3 0,10C-1,3 -3,1 -10,0C-3,-1 -1,-3 0,-10Z" fill="{random.choice(("#FFD21F","#FFF1A8","#FFB347"))}" transform="scale(0)">'
        f'<animateTransform attributeName="transform" type="scale" values="0;{n(s)};0" dur="{n(random.uniform(1.6,3))}s" begin="{n(b)}s" repeatCount="indefinite"/></path></g>')
T("lap-lanh","Sao lấp lánh vàng",svg("Sao lấp lánh vàng","",t))
t="".join(f'<g transform="rotate({i*15} 256 256)"><path d="M256,12L261,20L256,28L251,20Z" fill="{"#FFD21F" if i%2==0 else "#FF4D4D"}"/></g>' for i in range(24))
T("vien-tet","Viền vàng đỏ",svg("Viền vàng đỏ","",
  f'<circle cx="256" cy="256" r="236" fill="none" stroke="#D7191C" stroke-width="14" opacity=".55"/><circle cx="256" cy="256" r="246" fill="none" stroke="#FFD21F" stroke-width="2.5" stroke-dasharray="16 8"><animateTransform attributeName="transform" type="rotate" from="0 256 256" to="360 256 256" dur="50s" repeatCount="indefinite"/></circle>'
  f'<g>{t}{rot(80,360,0)}</g>'))
def branch():
    b=('<path d="M520,470C440,430 380,400 330,330C300,290 290,250 250,220" fill="none" stroke="#6b3e1b" stroke-width="7" stroke-linecap="round"/>'
       '<path d="M400,420C380,380 350,370 320,380M345,340C340,300 310,285 285,290M470,445C450,470 420,480 395,470" fill="none" stroke="#6b3e1b" stroke-width="4" stroke-linecap="round"/>')
    fl=[(250,220,1.5),(285,290,1.3),(320,380,1.4),(395,470,1.2),(330,330,1.2),(380,400,1.0),(350,360,.9),(262,250,.9),(305,255,1.0)]
    f="".join(f'<use href="#mai" transform="translate({x} {y}) scale({s})"/>' for x,y,s in fl)
    return f'<g>{b}{f}<animateTransform attributeName="transform" type="rotate" values="-2.5 512 512;2.5 512 512;-2.5 512 512" dur="6s" repeatCount="indefinite" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1" keyTimes="0;.5;1"/></g>'
T("canh-mai","Cành mai đung đưa",svg("Cành mai đung đưa",MAI,branch()))
# ghi file
os.makedirs(OUT,exist_ok=True); meta=[]
for slug,(grp,name,s) in E.items():
    d=os.path.join(OUT,grp); os.makedirs(d,exist_ok=True)
    open(os.path.join(d,slug+".svg"),"w",encoding="utf-8").write(s)
    meta.append({"id":slug,"group":grp,"title":name,"file":f"{grp}/{slug}.svg"})
json.dump({"canvas":512,"pivot":[256,256],"animation":"SMIL","effects":meta},open(os.path.join(OUT,"hieu-ung.json"),"w",encoding="utf-8"),ensure_ascii=False,indent=2)
print(len(E))
