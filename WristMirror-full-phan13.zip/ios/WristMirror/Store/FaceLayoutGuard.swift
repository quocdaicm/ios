// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Tự sắp xếp các mục thông tin để không chồng lên nhau / lên số giờ / lên trục kim,
// và viền chữ mờ phía sau để dễ đọc trên nền hoa văn.

extension FaceRenderer {
    /// Bật/tắt viền chữ (được đặt từ `FaceDesign.textOutline` trước khi vẽ).
    static var textOutlineOn = true

    /// Vẽ chữ có viền tối mờ phía sau (nếu bật) để không bị chìm vào nền.
    static func drawHaloText(_ text: String, font: UIFont, color: UIColor, at p: CGPoint) {
        guard !text.isEmpty else { return }
        if textOutlineOn {
            let halo = UIColor.black.withAlphaComponent(0.6)
            NSAttributedString(string: text, attributes: [
                .font: font, .foregroundColor: halo, .strokeColor: halo, .strokeWidth: -7
            ]).draw(at: p)
        }
        NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: color]).draw(at: p)
    }

    // MARK: Các mục

    enum InfoItem {
        case digital, weekday, solar, lunar, weather, data(DataKind), name
    }

    private static let layoutOrder: [InfoItem] = [
        .digital, .weekday, .solar, .lunar, .weather,
        .data(.battery), .data(.steps), .data(.heart), .data(.calories), .name
    ]

    private static let pivotRadius: CGFloat = 24
    private static let itemGap: CGFloat = 4

    /// Bán kính vùng an toàn (không đè lên số giờ / vạch giờ).
    static func safeRadius(_ d: FaceDesign) -> CGFloat {
        switch d.marks {
        case .numerals: return 148
        case .ticks, .dots: return 190
        case .none: return 218
        }
    }

    private static func typicalDigits(_ k: DataKind) -> Int {
        switch k {
        case .battery: return 3
        case .steps: return 5
        case .heart: return 3
        case .calories: return 4
        }
    }

    private static func isShown(_ it: InfoItem, _ d: FaceDesign) -> Bool {
        switch it {
        case .digital: return d.showDigital
        case .weekday: return d.showWeekday
        case .solar: return d.showSolar
        case .lunar: return d.showLunar
        case .weather: return d.weather.show
        case .data(let k): return d.dataWidget(k).show
        case .name: return d.showName && nameLayout(d) != nil
        }
    }

    private static func dateRect(_ L: LunarLayout) -> CGRect {
        let total = L.digitW * 4 + L.slashW
        let w = max(total, L.showLabel ? L.labelW : 0)
        let top = L.showLabel ? min(L.numY, L.labelY) : L.numY
        let h = L.lineH + (L.showLabel ? L.labelH : 0)
        return CGRect(x: L.cx - w / 2, y: top, width: w, height: h)
    }

    private static func itemRect(_ it: InfoItem, _ d: FaceDesign) -> CGRect {
        switch it {
        case .digital:
            let L = digitalLayout(d)
            return CGRect(x: L.x0, y: L.y, width: L.digitW * 4 + L.colonW, height: L.lineH)
        case .weekday:
            let L = weekdayLayout(d)
            return CGRect(x: L.x, y: L.y, width: L.w, height: L.h)
        case .solar:
            return dateRect(solarLayout(d))
        case .lunar:
            return dateRect(lunarLayout(d))
        case .weather:
            let L = WeatherLayout(d)
            var w = L.iconS + L.gap + L.digitW * 3 + L.degW
            var h = L.rowH
            if L.showText { w = max(w, L.textW); h += L.textH + 2 }
            if L.showRange { w = max(w, L.groupW * 2 + L.rangeGap); h += L.rangeLineH + 2 }
            return CGRect(x: L.x, y: L.y, width: w, height: h)
        case .data(let k):
            let L = dataNumberLayout(k, d.dataWidget(k))
            let digits = min(k.maxDigits, typicalDigits(k))
            return CGRect(x: L.x, y: L.y, width: L.digitW * digits + L.suffixW, height: L.lineH)
        case .name:
            guard let n = nameLayout(d) else { return .zero }
            return CGRect(x: n.line.x, y: n.line.y, width: n.line.w, height: n.line.h)
        }
    }

    private static func setData(_ d: inout FaceDesign, _ k: DataKind, _ f: (inout DataWidget) -> Void) {
        switch k {
        case .battery: f(&d.battery)
        case .steps: f(&d.steps)
        case .heart: f(&d.heart)
        case .calories: f(&d.calories)
        }
    }

    private static func getSize(_ it: InfoItem, _ d: FaceDesign) -> Double {
        switch it {
        case .digital: return d.digitalSize
        case .weekday: return d.weekdaySize
        case .solar: return d.solarSize
        case .lunar: return d.lunarSize
        case .weather: return d.weather.size
        case .data(let k): return d.dataWidget(k).size
        case .name: return d.nameSize
        }
    }

    private static func setSize(_ it: InfoItem, _ d: inout FaceDesign, _ v: Double) {
        switch it {
        case .digital: d.digitalSize = v
        case .weekday: d.weekdaySize = v
        case .solar: d.solarSize = v
        case .lunar: d.lunarSize = v
        case .weather: d.weather.size = v
        case .data(let k): setData(&d, k) { $0.size = v }
        case .name: d.nameSize = v
        }
    }

    /// Đặt khối vào hình chữ nhật `r` (đổi hình chữ nhật thành toạ độ tỉ lệ của từng mục).
    private static func place(_ it: InfoItem, _ d: inout FaceDesign, _ r: CGRect) {
        let s = size
        let cx = Double(r.midX / s), cy = Double(r.midY / s), left = Double(r.minX / s)
        switch it {
        case .digital: d.digitalX = cx; d.digitalY = cy
        case .weekday: d.weekdayX = cx; d.weekdayY = cy
        case .solar: d.solarX = cx; d.solarY = cy
        case .lunar: d.lunarX = cx; d.lunarY = cy
        case .weather: d.weather.x = left; d.weather.y = cy
        case .data(let k): setData(&d, k) { $0.x = left; $0.y = cy }
        case .name: d.nameX = cx; d.nameY = cy
        }
    }

    // MARK: Tìm chỗ

    private static func fits(_ r: CGRect, placed: [CGRect], radius: CGFloat) -> Bool {
        let c = center
        let corners = [CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX, y: r.minY),
                       CGPoint(x: r.minX, y: r.maxY), CGPoint(x: r.maxX, y: r.maxY)]
        for p in corners where hypot(p.x - c, p.y - c) > radius { return false }
        let nx = min(max(c, r.minX), r.maxX), ny = min(max(c, r.minY), r.maxY)
        if hypot(nx - c, ny - c) < pivotRadius { return false }
        let g = r.insetBy(dx: -itemGap, dy: -itemGap)
        for q in placed where g.intersects(q) { return false }
        return true
    }

    private static func bestSpot(_ r: CGRect, placed: [CGRect], radius: CGFloat) -> CGRect? {
        let c = center, w = r.width, h = r.height
        guard w < radius * 2, h < radius * 2 else { return nil }
        var best: CGRect?
        var bestDist = CGFloat.greatestFiniteMagnitude
        var y = c - radius
        while y + h <= c + radius {
            var x = c - radius
            while x + w <= c + radius {
                let cand = CGRect(x: x, y: y, width: w, height: h)
                let dist = hypot(cand.midX - r.midX, cand.midY - r.midY)
                if dist < bestDist && fits(cand, placed: placed, radius: radius) {
                    best = cand
                    bestDist = dist
                }
                x += 4
            }
            y += 4
        }
        return best
    }

    /// Trả về bản thiết kế đã dời (và nếu cần thu nhỏ) các mục để không chồng nhau.
    /// Thứ tự ưu tiên giữ nguyên chỗ: giờ số, thứ, dương lịch, âm lịch, thời tiết, pin, bước chân, nhịp tim, calo, tên.
    static func resolvedLayout(_ design: FaceDesign) -> FaceDesign {
        guard design.autoLayout else { return design }
        var d = design
        var placed = [CGRect]()
        let base = safeRadius(design)
        for it in layoutOrder where isShown(it, d) {
            let original = getSize(it, d)
            var done = false
            sizes: for f in [1.0, 0.9, 0.8, 0.7, 0.6] {
                var cd = d
                setSize(it, &cd, max(0.6, original * f))
                let r0 = itemRect(it, cd)
                for extra in [CGFloat(0), 18, 40] {
                    let rad = base + extra
                    if fits(r0, placed: placed, radius: rad) {
                        d = cd
                        done = true
                        break sizes
                    }
                    if let spot = bestSpot(r0, placed: placed, radius: rad) {
                        place(it, &cd, spot)
                        d = cd
                        done = true
                        break sizes
                    }
                }
            }
            _ = done
            placed.append(itemRect(it, d))
        }
        return d
    }
}
