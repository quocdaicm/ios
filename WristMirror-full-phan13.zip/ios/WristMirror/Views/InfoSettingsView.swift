// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Cài đặt các mục thông tin: dương lịch, âm lịch, thứ, giờ số, pin, bước chân, nhịp tim, calo, thời tiết, tên. Dùng chung cho Studio và "Thêm thông tin vào HWT".
struct InfoSettingsView: View {
    @Binding var design: FaceDesign

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Toggle("Tự sắp xếp, không cho chữ chồng nhau hoặc đè lên số giờ", isOn: $design.autoLayout)
                Toggle("Viền chữ mờ phía sau cho dễ đọc", isOn: $design.textOutline)
            }
            .card()
            block("Dương lịch", isOn: $design.showSolar) {
                ColorPicker("Màu chữ", selection: $design.solarColor, supportsOpacity: false)
                pos(size: $design.solarSize, x: $design.solarX, y: $design.solarY)
                Toggle("Hiện chữ D. LỊCH", isOn: $design.solarLabel)
            }
            block("Âm lịch", isOn: $design.showLunar) {
                ColorPicker("Màu chữ", selection: $design.lunarColor, supportsOpacity: false)
                pos(size: $design.lunarSize, x: $design.lunarX, y: $design.lunarY)
                Toggle("Hiện chữ ÂL", isOn: $design.lunarLabel)
            }
            block("Thứ trong tuần", isOn: $design.showWeekday) {
                ColorPicker("Màu chữ", selection: $design.weekdayColor, supportsOpacity: false)
                pos(size: $design.weekdaySize, x: $design.weekdayX, y: $design.weekdayY)
            }
            block("Giờ số (HH:MM)", isOn: $design.showDigital) {
                ColorPicker("Màu chữ", selection: $design.digitalColor, supportsOpacity: false)
                pos(size: $design.digitalSize, x: $design.digitalX, y: $design.digitalY)
            }
            dataBlock("Pin", $design.battery, unitTitle: "Hiện %")
            dataBlock("Bước chân", $design.steps, unitTitle: "Hiện chữ \"bước\"")
            dataBlock("Nhịp tim", $design.heart, unitTitle: "Hiện chữ \"bpm\"")
            dataBlock("Calo", $design.calories, unitTitle: "Hiện chữ \"kcal\"")
            block("Thời tiết", isOn: $design.weather.show) {
                ColorPicker("Màu chữ", selection: $design.weather.color, supportsOpacity: false)
                pos(size: $design.weather.size, x: $design.weather.x, y: $design.weather.y, xTitle: "Vị trí ngang (mép trái khối)")
                Toggle("Hiện tên tình trạng (nắng, mưa…)", isOn: $design.weatherText)
                Toggle("Hiện nhiệt độ cao / thấp", isOn: $design.weatherRange)
            }
            block("Tên của bạn", isOn: $design.showName) {
                TextField("Nhập tên hiển thị", text: $design.nameText)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: design.nameText) { v in
                        let c = FaceRenderer.cleanName(v)
                        if c != v && v.count > FaceRenderer.maxNameChars { design.nameText = c }
                    }
                Picker("Kiểu chữ", selection: $design.nameStyle) {
                    ForEach(0..<FaceRenderer.nameStyleTitles.count, id: \.self) { Text(FaceRenderer.nameStyleTitles[$0]).tag($0) }
                }
                .pickerStyle(.segmented)
                ColorPicker("Màu chữ", selection: $design.nameColor, supportsOpacity: false)
                pos(size: $design.nameSize, x: $design.nameX, y: $design.nameY)
            }
        }
    }

    private func block<C: View>(_ title: String, isOn: Binding<Bool>, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: isOn) { Text(title).font(.headline) }
            if isOn.wrappedValue { content() }
        }
        .card()
    }

    /// Mục số liệu do đồng hồ cập nhật (pin, bước chân, nhịp tim, calo).
    private func dataBlock(_ title: String, _ w: Binding<DataWidget>, unitTitle: String) -> some View {
        block(title, isOn: w.show) {
            ColorPicker("Màu chữ", selection: w.color, supportsOpacity: false)
            pos(size: w.size, x: w.x, y: w.y, xTitle: "Vị trí ngang (mép trái số)")
            Toggle(unitTitle, isOn: w.unit)
        }
    }

    private func pos(size: Binding<Double>, x: Binding<Double>, y: Binding<Double>, xTitle: String = "Vị trí ngang") -> some View {
        VStack(alignment: .leading, spacing: 8) {
            labeled("Cỡ chữ") { Slider(value: size, in: 0.6...1.8) }
            labeled(xTitle) { Slider(value: x, in: 0.1...0.9) }
            labeled("Vị trí dọc") { Slider(value: y, in: 0.1...0.9) }
        }
    }

    private func labeled<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.footnote).foregroundStyle(.secondary)
            content()
        }
    }
}
