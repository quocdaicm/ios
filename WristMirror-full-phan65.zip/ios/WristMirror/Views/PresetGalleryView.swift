// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 63: thư viện mẫu mặt đồng hồ - lọc theo nhóm, lưới thẻ lớn có ảnh xem trước nét, nhãn hiệu ứng, đánh dấu mẫu đã chọn.
// Ảnh xem trước dựng ở luồng nền (LazyVGrid nên chỉ dựng ô đang hiện) để cuộn mượt dù có ~90 mẫu.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

enum PresetCategory: String, CaseIterable, Identifiable {
    case all, huawei, pro, classic, neon, sport, nature, festive, dragon
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "Tất cả"
        case .huawei: return "Kiểu Huawei"
        case .pro: return "Chuyên nghiệp"
        case .classic: return "Cổ điển"
        case .neon: return "Neon & công nghệ"
        case .sport: return "Thể thao"
        case .nature: return "Thiên nhiên"
        case .festive: return "Noel & Tết"
        case .dragon: return "Rồng & văn hoá"
        }
    }
    var icon: String {
        switch self {
        case .all: return "square.grid.2x2"
        case .huawei: return "sparkles"
        case .pro: return "crown"
        case .classic: return "clock"
        case .neon: return "bolt"
        case .sport: return "speedometer"
        case .nature: return "leaf"
        case .festive: return "gift"
        case .dragon: return "flame"
        }
    }

    private static let neonIDs: Set<String> = ["neon", "cyber", "retroLED", "galaxy", "kaleido", "lcdRetro", "cityNeon", "artSynth",
                                               "neonPinkCity", "neonLimeTube", "neonRainbow", "neonWhiteMinimal", "artPlanet"]
    private static let sportIDs: Set<String> = ["racing", "blackGold", "steampunk", "compass"]
    private static let natureIDs: Set<String> = ["ocean", "forest", "aurora", "auroraBand", "sakura", "artSakura", "artKoi", "jelly", "bamboo",
                                                 "sunset", "sunsetRoad", "spring", "summer", "autumn", "winter", "moon", "moonNight",
                                                 "lotusPond", "iceFruit", "poolAqua", "midnight"]
    private static let dragonIDs: Set<String> = ["artDragon", "dragonRed", "dragonCarved", "dragonJade", "dragonTeal", "dragonSilver",
                                                 "bronze", "lotus", "star"]
    private static let festiveIDs: Set<String> = ["fireworkNight", "fortune", "artSanta", "artSnowman", "artLightTree", "tetPhao"]

    /// Nhóm của một mẫu (mỗi mẫu thuộc đúng một nhóm, ngoài "Tất cả").
    static func of(_ p: FacePreset) -> PresetCategory {
        if FacePresetsHuawei.list.contains(where: { $0.id == p.id }) { return .huawei }
        if FacePresetsPro.list.contains(where: { $0.id == p.id }) { return .pro }
        let id = p.id
        if id.hasPrefix("noel") || id.hasPrefix("tet") || festiveIDs.contains(id) { return .festive }
        if dragonIDs.contains(id) { return .dragon }
        if neonIDs.contains(id) { return .neon }
        if sportIDs.contains(id) { return .sport }
        if natureIDs.contains(id) { return .nature }
        return .classic
    }
}

struct PresetGalleryView: View {
    let onPick: (FacePreset) -> Void
    @State private var category: PresetCategory = .all
    @State private var selectedID: String? = nil
    @State private var query = ""

    private var shown: [FacePreset] {
        FacePresets.all.filter { p in
            (category == .all || PresetCategory.of(p) == category)
                && (query.isEmpty || tr(p.title).localizedCaseInsensitiveContains(query))
        }
    }

    private func count(_ c: PresetCategory) -> Int {
        c == .all ? FacePresets.all.count : FacePresets.all.filter { PresetCategory.of($0) == c }.count
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(tr("Mẫu có sẵn")).font(.headline)
                Spacer()
                Text("\(shown.count) " + tr("mẫu")).font(.caption).foregroundStyle(.secondary)
            }
            Text(tr("Chạm để áp dụng một mẫu, rồi chỉnh tiếp bên dưới. Tên và tác giả của bạn được giữ nguyên."))
                .font(.footnote).foregroundStyle(.secondary)

            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField(tr("Tìm mẫu"), text: $query)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                if !query.isEmpty {
                    Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                        .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 12).padding(.vertical, 9)
            .background(Color.primary.opacity(0.06), in: Capsule())

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(PresetCategory.allCases) { c in chip(c) }
                }
            }

            if shown.isEmpty {
                Text(tr("Không có mẫu phù hợp.")).font(.footnote).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity).padding(.vertical, 24)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 12)], spacing: 12) {
                    ForEach(shown) { p in tile(p) }
                }
            }
        }
        .card()
    }

    private func chip(_ c: PresetCategory) -> some View {
        let on = category == c
        return Button {
            withAnimation(.easeInOut(duration: 0.15)) { category = c }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: c.icon).font(.caption.weight(.semibold))
                Text(tr(c.title)).font(.footnote.weight(.semibold))
                Text("\(count(c))").font(.caption2).opacity(0.7)
            }
            .padding(.horizontal, 12).padding(.vertical, 7)
            .foregroundStyle(on ? Color.white : Color.primary)
            .background(on ? Color.accentColor : Color.primary.opacity(0.08), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func tile(_ p: FacePreset) -> some View {
        let on = selectedID == p.id
        let info = PresetInfo.of(p)
        return Button {
            selectedID = p.id
            onPick(p)
        } label: {
            VStack(spacing: 8) {
                ZStack(alignment: .topTrailing) {
                    PresetThumbView(preset: p)
                        .aspectRatio(1, contentMode: .fit)
                        .padding(8)
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(LinearGradient(colors: [info.top, info.bottom], startPoint: .top, endPoint: .bottom).opacity(0.55))
                        )
                    if on {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.title3)
                            .foregroundStyle(Color.white, Color.accentColor)
                            .padding(6)
                    }
                }
                VStack(spacing: 4) {
                    Text(tr(p.title)).font(.footnote.weight(.semibold)).foregroundStyle(.primary)
                        .lineLimit(1).minimumScaleFactor(0.8)
                    HStack(spacing: 6) {
                        if info.hasSecondFX { badge("sparkles", tr("Giây")) }
                        if info.hasFall { badge("snowflake", tr("Hạt rơi")) }
                        if info.hasBackdrop { badge("photo", tr("Nền")) }
                    }
                    .frame(minHeight: 16)
                }
            }
            .padding(8)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color.primary.opacity(0.05))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(on ? Color.accentColor : Color.primary.opacity(0.08), lineWidth: on ? 2.5 : 1)
            )
        }
        .buttonStyle(.plain)
    }

    private func badge(_ icon: String, _ text: String) -> some View {
        HStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 8, weight: .bold))
            Text(text).font(.system(size: 9, weight: .semibold))
        }
        .padding(.horizontal, 6).padding(.vertical, 2)
        .foregroundStyle(.secondary)
        .background(Color.primary.opacity(0.07), in: Capsule())
    }
}

/// Thông tin tóm tắt của mẫu để hiện nhãn và màu nền thẻ (tính một lần, lưu nhớ tạm).
struct PresetInfo {
    let top: Color
    let bottom: Color
    let hasSecondFX: Bool
    let hasFall: Bool
    let hasBackdrop: Bool

    private static let cache = LockedCache<String, PresetInfo>()

    static func of(_ p: FacePreset) -> PresetInfo {
        if let c = cache[p.id] { return c }
        let d = p.make()
        let info = PresetInfo(top: d.backgroundColor, bottom: d.useGradient ? d.backgroundColor2 : d.backgroundColor,
                              hasSecondFX: d.secondFX != .none, hasFall: d.animOn, hasBackdrop: !d.backdrop.isEmpty)
        cache[p.id] = info
        return info
    }
}

/// Ảnh xem trước của mẫu: hiện ảnh nhỏ (nếu đã có) ngay, dựng ảnh nét ở luồng nền rồi thay vào.
struct PresetThumbView: View {
    let preset: FacePreset
    @State private var image: UIImage? = nil

    var body: some View {
        ZStack {
            Circle().fill(Color.black.opacity(0.35))
            if let img = image {
                Image(uiImage: img).resizable().scaledToFit().clipShape(Circle())
                    .transition(.opacity)
            } else {
                ProgressView().scaleEffect(0.7)
            }
        }
        .overlay(Circle().stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.25), radius: 6, y: 3)
        .onAppear { load() }
    }

    private func load() {
        if let c = FacePresetThumbs.cached(preset, pixels: FacePresetThumbs.largePixels) {
            image = c
            return
        }
        let p = preset
        DispatchQueue.global(qos: .userInitiated).async {
            let img = FacePresetThumbs.image(p, pixels: FacePresetThumbs.largePixels)
            DispatchQueue.main.async { withAnimation(.easeIn(duration: 0.15)) { image = img } }
        }
    }
}
