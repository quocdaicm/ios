// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 61: CHỮ kỹ thuật số cho "Thứ", "Tên của bạn" và tên tình trạng thời tiết, đồng bộ với "Kiểu số chung" (`FaceDesign.dataStyle`).
// - Kiểu chấm ma trận / pixel (LED chấm, chấm vàng, pixel...): chữ được dựng thành lưới chấm (lấy mẫu từ hình chữ, nên có đủ dấu tiếng Việt).
// - Kiểu 7 đoạn, nét đơn neon, ống neon, kim loại...: chữ HOA dạng path của font kỹ thuật (DIN Alternate / Avenir Next Condensed),
//   tô bằng đúng bộ tô của số (`DigitalShapes.drawLabel`) nên cùng màu, quầng sáng, ống neon như chữ số.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Kiểu số chung đang áp cho chữ (null = không đồng bộ, dùng chữ thường / chữ vector `FaceTextFX`).
struct DigitalTextStyle {
    let def: DigitalShapes.Def
    let own: Bool
}

extension FaceDesign {
    /// Kiểu số chung dùng cho chữ; nil khi kiểu số chung là "Số thường".
    private var sharedDigitalText: DigitalTextStyle? {
        guard dataStyle != .classic, let def = dataStyle.def else { return nil }
        return DigitalTextStyle(def: def, own: dataOwnColors)
    }
    /// Thứ trong tuần theo kiểu số chung (khi bật `weekdaySync`).
    var weekdayDigital: DigitalTextStyle? { weekdaySync ? sharedDigitalText : nil }
    /// Tên của bạn theo kiểu số chung (khi bật `nameSync`).
    var nameDigital: DigitalTextStyle? { nameSync ? sharedDigitalText : nil }
}

enum DigitalText {
    /// Lề quanh chữ cho quầng sáng (giống ô chữ số).
    static func pad(_ d: DigitalShapes.Def) -> Int { d.paint.glows ? 7 : 3 }

    /// Kiểu lưới chấm (ma trận / pixel).
    static func isGrid(_ d: DigitalShapes.Def) -> Bool { d.geo == .matrix || d.geo == .pixel }

    /// Chữ kỹ thuật số luôn viết HOA cho gọn và dễ đọc (giữ nguyên dấu tiếng Việt).
    static func shown(_ s: String) -> String { s.uppercased() }

    /// Font kỹ thuật để lấy hình chữ: nét mảnh cho neon nét đơn, nét dày cho còn lại. Không có font thì dùng font đơn cách.
    static func font(_ d: DigitalShapes.Def, size: CGFloat) -> UIFont {
        let names: [String]
        if d.geo == .line && d.stroke <= 7 {
            names = ["AvenirNextCondensed-DemiBold", "AvenirNextCondensed-Medium", "HelveticaNeue-Medium"]
        } else {
            names = ["DINAlternate-Bold", "AvenirNextCondensed-Bold", "Menlo-Bold"]
        }
        for n in names {
            if let f = UIFont(name: n, size: size) { return f }
        }
        return UIFont.monospacedSystemFont(ofSize: size, weight: .bold)
    }

    /// Khoảng cách giữa hai chấm của lưới (điểm ảnh): cao chữ hoa = 7 chấm (ma trận) hoặc 5 chấm (pixel).
    static func pitch(_ d: DigitalShapes.Def, font: UIFont) -> CGFloat {
        let rows: CGFloat = d.geo == .pixel ? 5 : 7
        return max(2.2, font.capHeight / rows)
    }

    private static func rowsAbove(_ font: UIFont, _ pp: CGFloat) -> Int { Int(ceil(font.ascender * 1.1 / pp)) }
    private static func rowsBelow(_ font: UIFont, _ pp: CGFloat) -> Int { Int(ceil(-font.descender / pp)) + 1 }

    /// Chiều cao một dòng chữ (không kể lề `pad`).
    static func lineHeight(_ d: DigitalShapes.Def, font: UIFont) -> Int {
        if isGrid(d) {
            let pp = pitch(d, font: font)
            return Int(ceil(CGFloat(rowsAbove(font, pp) + rowsBelow(font, pp)) * pp))
        }
        return Int(ceil(font.lineHeight))
    }

    /// Bề rộng chữ (không kể lề `pad`).
    static func width(_ text: String, def d: DigitalShapes.Def, font: UIFont) -> Int {
        let t = shown(text)
        let w = (t as NSString).size(withAttributes: [.font: font]).width
        let extra: CGFloat = isGrid(d) ? 2 * pitch(d, font: font) : 0
        return Int(ceil(w + extra)) + 2
    }

    /// Vẽ `text` vào `rect` (ngữ cảnh UIKit hiện tại, gốc trên-trái). `centered` = căn giữa ô, ngược lại căn trái (sau lề `pad`).
    static func draw(_ text: String, def d: DigitalShapes.Def, own: Bool, font: UIFont, color: UIColor, centered: Bool, in rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), !text.isEmpty, rect.width > 0, rect.height > 0 else { return }
        let t = shown(text)
        guard let built = FaceTextFX.glyphPath(t, font: font) else { return }
        if isGrid(d) {
            drawGrid(ctx, built: built, def: d, own: own, font: font, color: color, centered: centered, in: rect)
            return
        }
        // Toạ độ glyph (y hướng lên) -> toạ độ ô: gốc ở đầu đường cơ sở, lật trục y.
        let p = CGFloat(pad(d))
        let x = centered ? rect.midX - built.width / 2 : rect.minX + p
        let baseline = rect.minY + p + 1 + font.ascender
        var place = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: x, ty: baseline)
        guard let path = built.path.copy(using: &place) else { return }
        var toCenter = CGAffineTransform(translationX: -rect.midX, y: -rect.midY)
        let centeredPath = path.copy(using: &toCenter) ?? path
        DigitalShapes.drawLabel(ctx, def: d, shape: centeredPath, scale: 1, in: rect, color: color, own: own)
    }

    /// Chữ dạng lưới chấm: vẽ hình chữ vào ảnh xám nhỏ (mỗi chấm = 3 x 3 điểm), chấm nào phủ đủ thì bật.
    private static func drawGrid(_ ctx: CGContext, built: (path: CGPath, width: CGFloat), def d: DigitalShapes.Def, own: Bool,
                                 font: UIFont, color: UIColor, centered: Bool, in rect: CGRect) {
        let pp = pitch(d, font: font)
        let above = rowsAbove(font, pp)
        let below = rowsBelow(font, pp)
        let rows = above + below
        let cols = max(1, Int(ceil(built.width / pp)) + 1)
        let sub = 3
        let bw = cols * sub
        let bh = rows * sub
        var buf = [UInt8](repeating: 0, count: bw * bh)
        let scale = CGFloat(sub) / pp
        let baseY = CGFloat(below) * pp
        buf.withUnsafeMutableBytes { raw in
            guard let g = CGContext(data: raw.baseAddress, width: bw, height: bh, bitsPerComponent: 8, bytesPerRow: bw,
                                    space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return }
            g.setAllowsAntialiasing(true)
            g.scaleBy(x: scale, y: scale)
            g.translateBy(x: 0, y: baseY)
            g.setFillColor(gray: 1, alpha: 1)
            g.addPath(built.path)
            g.fillPath()
        }
        // Hàng nhớ đầu tiên là hàng TRÊN CÙNG của ảnh.
        let on = CGMutablePath()
        let total = CGFloat(sub * sub) * 255
        let gridW = CGFloat(cols) * pp
        let gridH = CGFloat(rows) * pp
        let x0 = (centered ? rect.midX - gridW / 2 : rect.minX + CGFloat(pad(d))) - rect.midX
        let y0 = -gridH / 2
        for r in 0..<rows {
            for c in 0..<cols {
                var sum = 0
                for sy in 0..<sub {
                    let rowStart = (r * sub + sy) * bw + c * sub
                    for sx in 0..<sub { sum += Int(buf[rowStart + sx]) }
                }
                guard CGFloat(sum) >= total * 0.36 else { continue }
                let cx = x0 + (CGFloat(c) + 0.5) * pp
                let cy = y0 + (CGFloat(r) + 0.5) * pp
                on.addPath(dot(d, cx, cy, pp))
            }
        }
        DigitalShapes.drawLabel(ctx, def: d, shape: on, scale: 1, in: rect, color: color, own: own)
    }

    /// Một chấm của lưới theo hình chấm của kiểu (tròn / vuông / thoi; pixel = khối vuông bo góc).
    private static func dot(_ d: DigitalShapes.Def, _ cx: CGFloat, _ cy: CGFloat, _ p: CGFloat) -> CGPath {
        if d.geo == .pixel {
            let s = p * 0.9
            return CGPath(roundedRect: CGRect(x: cx - s / 2, y: cy - s / 2, width: s, height: s), cornerWidth: 0.8, cornerHeight: 0.8, transform: nil)
        }
        switch d.dot {
        case .round:
            let r = p * 0.42
            return CGPath(ellipseIn: CGRect(x: cx - r, y: cy - r, width: 2 * r, height: 2 * r), transform: nil)
        case .square:
            let s = p * 0.84
            return CGPath(roundedRect: CGRect(x: cx - s / 2, y: cy - s / 2, width: s, height: s), cornerWidth: 1, cornerHeight: 1, transform: nil)
        case .diamond:
            let q = p * 0.54
            let m = CGMutablePath()
            m.move(to: CGPoint(x: cx, y: cy - q))
            m.addLine(to: CGPoint(x: cx + q, y: cy))
            m.addLine(to: CGPoint(x: cx, y: cy + q))
            m.addLine(to: CGPoint(x: cx - q, y: cy))
            m.closeSubpath()
            return m
        }
    }
}
