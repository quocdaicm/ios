// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 61: bộ 16 mẫu "Chuyên nghiệp" - mỗi mẫu có nền, họa tiết, kiểu số giờ, kim, chuyển động theo giây, hạt rơi và AOD riêng.
// Chữ Thứ / tên thời tiết bật đồng bộ kiểu số chung (`weekdaySync`, `weatherSync`) nên cả mặt cùng một phong cách kỹ thuật số.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

private extension Color {
    init(wm hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255)
    }
}

enum FacePresetsPro {
    private typealias P = FacePresets

    /// Thứ, tên và tên thời tiết cùng kiểu số chung.
    private static func sync(_ d: inout FaceDesign) {
        d.weekdaySync = true
        d.nameSync = true
        d.weatherSync = true
        d.weatherFX = 0
    }

    private static func plate(_ d: inout FaceDesign, _ shape: Int, _ line: UInt32, opacity: Double = 0.85) {
        d.plates["digital"] = PlateStyle(shape: shape, fill: .black, line: Color(wm: line), opacity: opacity, outline: true)
    }

    private static func decor(_ d: inout FaceDesign, _ p: DecorPattern, _ c: UInt32, opacity: Double, scale: Double, spin: DecorSpin) {
        d.decor = [DecorLayer(pattern: p, color: Color(wm: c), opacity: opacity, scale: scale, spin: spin)]
    }

    static let list: [FacePreset] = [
        // 1. Chronograph thể thao đen - bạc
        FacePreset(id: "proChrono", title: "Chronograph đen bạc") {
            var d = P.base(0x050608, 0x1B1E26)
            d.marks = .numerals; d.numeralStyle = .sportSilver; d.numeralOwnColors = true
            P.vectorHands(&d, .chronograph, second: 0xFF3B30, cap: 0xE8ECF4)
            P.standardInfo(&d, text: 0xE8ECF4, accent: 0xE8ECF4, style: .silverTech)
            FacePresetsPro.decor(&d, .ring, 0x9AA3B5, opacity: 0.35, scale: 0.62, spin: .none)
            FacePresetsPro.plate(&d, 2, 0x9AA3B5)
            d.secondFX = .ticks; d.secondFXColor = Color(wm: 0xFF3B30)
            P.aodBackdrop(&d, "aodRings", hand: 0xB7BFCE, marks: 0x5A6070)
            FacePresetsPro.sync(&d)
            return d
        },
        // 2. Hoàng gia vàng - số La Mã
        FacePreset(id: "proRoyalGold", title: "Hoàng gia vàng") {
            var d = P.base(0x120A02, 0x3A2408)
            P.dayBackdrop(&d, "goldGeo")
            d.marks = .numerals; d.numeralStyle = .romanGold; d.numeralOwnColors = true
            P.vectorHands(&d, .dauphine, second: 0xFFE08A, cap: 0xD9A441)
            P.standardInfo(&d, text: 0xFBE9B8, accent: 0xF2C879, style: .goldHex)
            FacePresetsPro.plate(&d, 5, 0xD9A441)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFE08A)
            P.fall(&d, .snow, density: 0.12)
            P.aodBackdrop(&d, "aodGold", hand: 0xC7862E, marks: 0x7A5F2B)
            FacePresetsPro.sync(&d)
            return d
        },
        // 3. Phi công - số dạ quang xanh lục, giờ LCD
        FacePreset(id: "proPilot", title: "Phi công đêm") {
            var d = P.base(0x020503, 0x0B1A10)
            d.marks = .numerals; d.numeralStyle = .lumeGreen; d.numeralOwnColors = true
            P.vectorHands(&d, .luminousGreen, second: 0xFF8A00, cap: 0xB8FF9A)
            P.standardInfo(&d, text: 0xD8FFD0, accent: 0xA6FF7A, style: .ledGreen)
            FacePresetsPro.decor(&d, .compass, 0x3FB300, opacity: 0.28, scale: 0.9, spin: .none)
            FacePresetsPro.plate(&d, 11, 0x3FB300)
            d.secondFX = .radar; d.secondFXColor = Color(wm: 0x7CFF24)
            P.aodBackdrop(&d, "aodRings", hand: 0x3FB300, marks: 0x1C6600)
            FacePresetsPro.sync(&d)
            return d
        },
        // 4. Thợ lặn - biển sâu
        FacePreset(id: "proDiver", title: "Thợ lặn biển sâu") {
            var d = P.base(0x021626, 0x06527A)
            P.dayBackdrop(&d, "waves")
            d.marks = .numerals; d.numeralStyle = .lumeAqua; d.numeralOwnColors = true
            P.vectorHands(&d, .luminousAqua, second: 0xFFB020, cap: 0xFFB020)
            P.standardInfo(&d, text: 0xE6FBFF, accent: 0x6FE7FF, style: .futureBlue)
            FacePresetsPro.plate(&d, 3, 0x6FE7FF)
            d.secondFX = .pulse; d.secondFXColor = Color(wm: 0x6FE7FF)
            P.fall(&d, .snow, density: 0.18)
            P.aodBackdrop(&d, "aodWaves", hand: 0x4FC3E0, marks: 0x1F5F78)
            FacePresetsPro.sync(&d)
            return d
        },
        // 5. Đua xe carbon - đỏ
        FacePreset(id: "proRacing", title: "Đua xe carbon") {
            var d = P.base(0x0A0A0C, 0x24181A)
            d.marks = .ticks; d.marksColor = Color(wm: 0xFF2D2D)
            P.vectorHands(&d, .racing, second: 0xFFFFFF, cap: 0xFF2D2D)
            P.standardInfo(&d, text: 0xF2F2F2, accent: 0xFF3B30, style: .ledRed)
            FacePresetsPro.decor(&d, .hexGrid, 0xFF3B30, opacity: 0.22, scale: 0.9, spin: .none)
            FacePresetsPro.plate(&d, 9, 0xFF3B30)
            d.secondFX = .arc; d.secondFXColor = Color(wm: 0xFF3B30)
            P.aodBackdrop(&d, "aodDots", hand: 0xC0392B, marks: 0x5A1A1A)
            FacePresetsPro.sync(&d)
            return d
        },
        // 6. Holographic - tím xanh, hoa của sự sống quay
        FacePreset(id: "proHolo", title: "Holographic") {
            var d = P.base(0x0A0420, 0x2A0F5C)
            d.marks = .dots; d.marksColor = Color(wm: 0xB388FF)
            P.vectorHands(&d, .future, second: 0x40E0D0, cap: 0xB388FF)
            P.standardInfo(&d, text: 0xF1E9FF, accent: 0xC9A8FF, style: .neonPurple)
            FacePresetsPro.decor(&d, .flowerOfLife, 0xB388FF, opacity: 0.4, scale: 0.9, spin: .minute)
            FacePresetsPro.plate(&d, 18, 0xB388FF, opacity: 0.5)
            d.secondFX = .rainbow; d.secondFXColor = Color(wm: 0xB388FF)
            P.aodBackdrop(&d, "aodStars", hand: 0x9B7ADF, marks: 0x4A3A80)
            FacePresetsPro.sync(&d)
            return d
        },
        // 7. Anh đào đêm - hồng
        FacePreset(id: "proSakura", title: "Anh đào ánh trăng") {
            var d = P.base(0x1A0A1E, 0x4A1E4A)
            P.dayBackdrop(&d, "blossom")
            d.marks = .dots; d.marksColor = Color(wm: 0xFFC2DD)
            P.vectorHands(&d, .roseGold, second: 0xFFFFFF, cap: 0xFFC2DD)
            P.standardInfo(&d, text: 0xFFEAF4, accent: 0xFFB3D4, style: .roseLine)
            FacePresetsPro.plate(&d, 1, 0xFFB3D4, opacity: 0.6)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0xFFC2DD)
            P.fall(&d, .petals, density: 0.3)
            P.aodBackdrop(&d, "aodDots", hand: 0xE08FB5, marks: 0x6B3A55)
            FacePresetsPro.sync(&d)
            return d
        },
        // 8. Ngọc lục bảo
        FacePreset(id: "proEmerald", title: "Ngọc lục bảo") {
            var d = P.base(0x021A10, 0x0B4A2C)
            d.marks = .numerals; d.numeralStyle = .arabicGold; d.numeralOwnColors = true
            P.vectorHands(&d, .leafGold, second: 0xF2C879, cap: 0xF2C879)
            P.standardInfo(&d, text: 0xE8FFF0, accent: 0xF2C879, style: .goldSlant)
            FacePresetsPro.decor(&d, .laurel, 0xF2C879, opacity: 0.4, scale: 0.88, spin: .none)
            FacePresetsPro.plate(&d, 5, 0xF2C879)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xF2C879)
            P.aodBackdrop(&d, "aodGold", hand: 0xC7A24E, marks: 0x6B5A2B)
            FacePresetsPro.sync(&d)
            return d
        },
        // 9. Bắc cực - băng giá
        FacePreset(id: "proArctic", title: "Bắc cực băng giá") {
            var d = P.base(0x061426, 0x1E4B7A)
            P.dayBackdrop(&d, "seasonWinter")
            d.marks = .dots; d.marksColor = Color(wm: 0xD6F1FF)
            P.vectorHands(&d, .sapphire, second: 0x7FD8FF, cap: 0xD6F1FF)
            P.standardInfo(&d, text: 0xF0FAFF, accent: 0xBEE9FF, style: .ledIce)
            FacePresetsPro.plate(&d, 6, 0xBEE9FF, opacity: 0.6)
            d.secondFX = .comet; d.secondFXColor = Color(wm: 0xBEE9FF)
            P.fall(&d, .snow, density: 0.3)
            P.aodBackdrop(&d, "aodWinter", hand: 0x9CCBE8, marks: 0x4A6A80)
            FacePresetsPro.sync(&d)
            return d
        },
        // 10. Retro 80s - giờ số to hổ phách
        FacePreset(id: "proRetro", title: "Retro LED 80s") {
            var d = P.base(0x0A0200, 0x2A0F00)
            d.marks = .ticks; d.marksColor = Color(wm: 0xFF8A00)
            P.vectorHands(&d, .bar, second: 0xFFD27A, cap: 0xFF8A00)
            P.standardInfo(&d, text: 0xFFD9A0, accent: 0xFF9A1F, style: .ledAmber)
            P.bigBottomLayout(&d)
            FacePresetsPro.plate(&d, 2, 0xFF9A1F, opacity: 0.9)
            d.secondFX = .dotChase; d.secondFXColor = Color(wm: 0xFF9A1F)
            P.aodBackdrop(&d, "aodDots", hand: 0xB06A1A, marks: 0x5A3510)
            FacePresetsPro.sync(&d)
            return d
        },
        // 11. Trăng sao - La Mã bạc
        FacePreset(id: "proMoon", title: "Trăng sao bạc") {
            var d = P.base(0x050818, 0x16224A)
            P.dayBackdrop(&d, "starryNight")
            d.marks = .numerals; d.numeralStyle = .romanSilver; d.numeralOwnColors = true
            P.vectorHands(&d, .swordGold, second: 0xE8ECF4, cap: 0xE8ECF4)
            P.standardInfo(&d, text: 0xEEF2FF, accent: 0xD5DCF2, style: .silverPill)
            FacePresetsPro.decor(&d, .moonPhases, 0xD5DCF2, opacity: 0.45, scale: 0.55, spin: .none)
            FacePresetsPro.plate(&d, 14, 0xD5DCF2, opacity: 0.6)
            d.secondFX = .orbit; d.secondFXColor = Color(wm: 0xD5DCF2)
            P.aodBackdrop(&d, "aodMoon", hand: 0xB5BED8, marks: 0x555F80)
            FacePresetsPro.sync(&d)
            return d
        },
        // 12. Dung nham - ống neon đỏ
        FacePreset(id: "proLava", title: "Dung nham") {
            var d = P.base(0x180300, 0x601400)
            d.marks = .numerals; d.numeralStyle = .tubeRed; d.numeralOwnColors = true
            P.vectorHands(&d, .ruby, second: 0xFFD84A, cap: 0xFF5A1F)
            P.standardInfo(&d, text: 0xFFE3CC, accent: 0xFF6A2A, style: .tubeRed)
            FacePresetsPro.decor(&d, .sunburst, 0xFF5A1F, opacity: 0.3, scale: 0.9, spin: .hour)
            FacePresetsPro.plate(&d, 19, 0xFF5A1F, opacity: 0.5)
            d.secondFX = .sunburst; d.secondFXColor = Color(wm: 0xFFB020)
            P.aodBackdrop(&d, "aodRings", hand: 0xC0501F, marks: 0x5A2310)
            FacePresetsPro.sync(&d)
            return d
        },
        // 13. Thiền trúc
        FacePreset(id: "proZen", title: "Trúc xanh thiền") {
            var d = P.base(0x061A12, 0x1D4A32)
            P.dayBackdrop(&d, "bamboo")
            d.marks = .dots; d.marksColor = Color(wm: 0xDDF5D0)
            P.vectorHands(&d, .baton, second: 0xFFD27A, cap: 0xDDF5D0)
            P.standardInfo(&d, text: 0xEEFBE6, accent: 0xCDEFB8, style: .thinGold)
            FacePresetsPro.plate(&d, 14, 0xCDEFB8, opacity: 0.5)
            d.secondFX = .bloom; d.secondFXColor = Color(wm: 0xCDEFB8)
            P.fall(&d, .leaves, density: 0.25)
            P.aodBackdrop(&d, "aodBamboo", hand: 0x7FB58A, marks: 0x3A6045)
            FacePresetsPro.sync(&d)
            return d
        },
        // 14. Sa mạc la bàn
        FacePreset(id: "proDesert", title: "Sa mạc hoàng hôn") {
            var d = P.base(0x2A1206, 0x8A4A1E)
            P.dayBackdrop(&d, "dunes")
            d.marks = .ticks; d.marksColor = Color(wm: 0xFFE2B0)
            P.vectorHands(&d, .arrowGold, second: 0xFFFFFF, cap: 0xFFD27A)
            P.standardInfo(&d, text: 0xFFF1DC, accent: 0xFFD27A, style: .goldSlant)
            FacePresetsPro.decor(&d, .compass, 0xFFD27A, opacity: 0.3, scale: 0.9, spin: .none)
            FacePresetsPro.plate(&d, 8, 0xFFD27A, opacity: 0.7)
            d.secondFX = .sunburst; d.secondFXColor = Color(wm: 0xFFD27A)
            P.aodBackdrop(&d, "aodMountain", hand: 0xC9954A, marks: 0x6B4A22)
            FacePresetsPro.sync(&d)
            return d
        },
        // 15. Sapphire sang trọng
        FacePreset(id: "proSapphire", title: "Sapphire hoàng gia") {
            var d = P.base(0x040A24, 0x0F2C7A)
            d.marks = .numerals; d.numeralStyle = .gemBlue; d.numeralOwnColors = true
            P.vectorHands(&d, .blueSteel, second: 0xE8ECF4, cap: 0x9CC4FF)
            P.standardInfo(&d, text: 0xEAF2FF, accent: 0x9CC4FF, style: .bluePill)
            FacePresetsPro.decor(&d, .rosette, 0x4D8BFF, opacity: 0.3, scale: 0.88, spin: .none)
            FacePresetsPro.plate(&d, 4, 0x9CC4FF)
            d.secondFX = .sparkle; d.secondFXColor = Color(wm: 0x9CC4FF)
            P.aodBackdrop(&d, "aodStars", hand: 0x7AA6E8, marks: 0x34508A)
            FacePresetsPro.sync(&d)
            return d
        },
        // 16. LCD đơn sắc cổ điển (nền xanh lá nhạt, chữ tối)
        FacePreset(id: "proLCD", title: "LCD cổ điển") {
            var d = P.base(0xB9C79A, 0x9FB07F)
            d.marks = .ticks; d.marksColor = Color(wm: 0x1E2A14)
            P.vectorHands(&d, .minimalist, second: 0x1E2A14, cap: 0x1E2A14)
            d.handOwnColors = false
            d.hourColor = Color(wm: 0x1E2A14); d.minuteColor = Color(wm: 0x1E2A14)
            P.standardInfo(&d, text: 0x1E2A14, accent: 0x1E2A14, style: .lcd, plate: false)
            d.dataOwnColors = false
            d.secondFX = .ticks; d.secondFXColor = Color(wm: 0x1E2A14)
            P.aodBackdrop(&d, "aodDots", hand: 0x8A9A6A, marks: 0x4A5A3A)
            FacePresetsPro.sync(&d)
            return d
        }
    ]
}
