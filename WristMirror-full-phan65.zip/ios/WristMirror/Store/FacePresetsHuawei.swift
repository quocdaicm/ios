// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 64: bộ 27 mẫu "Kiểu Huawei" - tham khảo các mặt đồng hồ được ưa chuộng trên kho Huawei Watch Faces
// (vàng sang trọng Cloud White Eagle, hoa Pansy Glows, cơ khí Gentleman Machinery, bánh xe bạc xanh Silver Blue Wheel,
// sân vận động mùa hè, dạ quang phi công, neon phố đêm, tối giản trắng...). Mỗi mẫu có nền, họa tiết, kiểu số giờ,
// kim, khung số, chuyển động theo giây, hạt rơi và AOD riêng; Thứ / Tên / tên thời tiết đồng bộ kiểu số chung.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

private extension Color {
    init(wm hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255)
    }
}

enum FacePresetsHuawei {
    private typealias P = FacePresets

    /// Bố cục thông tin của mẫu.
    private enum Lay { case standard, ring(Double), columns, bigBottom }

    /// Mô tả gọn một mẫu; `build` dựng `FaceDesign` từ mô tả này để mọi mẫu dùng chung một quy trình.
    private struct Spec {
        var bg: (UInt32, UInt32)
        var backdrop: String? = nil
        var marks: FaceDesign.Marks = .ticks
        var marksColor: UInt32 = 0xFFFFFF
        var numerals: NumeralStyle? = nil
        var hand: FaceDesign.HandStyle
        var second: UInt32
        var cap: UInt32
        /// Kim màu đơn (mặt sáng): bỏ màu gốc của kiểu kim, dùng màu này cho kim giờ / phút.
        var plainHand: UInt32? = nil
        var text: UInt32
        var accent: UInt32
        var style: DigitalStyle
        /// Số theo màu riêng của kiểu; tắt cho mặt sáng để chữ lấy màu `text` / `accent`.
        var ownData = true
        var layout: Lay = .standard
        var plate: (shape: Int, line: UInt32, opacity: Double)? = nil
        var decor: (DecorPattern, UInt32, Double, Double, DecorSpin)? = nil
        var fx: SecondFX = .none
        var fxColor: UInt32 = 0xFFFFFF
        var fall: (AnimKind, Double)? = nil
        /// (số khung, ms mỗi khung) cho cảnh động chậm như cực quang, thủy triều; mặc định 24 khung x 52 ms.
        var fallTiming: (Int, Double)? = nil
        var aod: String
        var aodHand: UInt32
        var aodMarks: UInt32
    }

    private static func build(_ s: Spec) -> FaceDesign {
        var d = P.base(s.bg.0, s.bg.1)
        if let b = s.backdrop { P.dayBackdrop(&d, b) }
        d.marks = s.marks
        d.marksColor = Color(wm: s.marksColor)
        if let n = s.numerals { d.numeralStyle = n; d.numeralOwnColors = true }
        P.vectorHands(&d, s.hand, second: s.second, cap: s.cap)
        if let c = s.plainHand {
            d.handOwnColors = false
            d.hourColor = Color(wm: c); d.minuteColor = Color(wm: c)
        }
        P.standardInfo(&d, text: s.text, accent: s.accent, style: s.style, plate: false)
        d.dataOwnColors = s.ownData
        switch s.layout {
        case .standard: break
        case .ring(let grow): P.ringLayout(&d, spread: 1.0, grow: grow)
        case .columns: P.columnsLayout(&d)
        case .bigBottom: P.bigBottomLayout(&d)
        }
        if d.marks == .numerals { P.compactForNumerals(&d) }
        if let p = s.plate {
            d.plates["digital"] = PlateStyle(shape: p.shape, fill: .black, line: Color(wm: p.line), opacity: p.opacity, outline: true)
        }
        if let c = s.decor {
            d.decor = [DecorLayer(pattern: c.0, color: Color(wm: c.1), opacity: c.2, scale: c.3, spin: c.4)]
        }
        d.secondFX = s.fx
        d.secondFXColor = Color(wm: s.fxColor)
        if let f = s.fall { P.fall(&d, f.0, frames: s.fallTiming?.0 ?? 24, ms: s.fallTiming?.1 ?? 52, density: f.1) }
        P.aodBackdrop(&d, s.aod, hand: s.aodHand, marks: s.aodMarks)
        d.weekdaySync = true
        d.nameSync = true
        d.weatherSync = true
        d.weatherFX = 0
        return d
    }

    private static func item(_ id: String, _ title: String, _ s: Spec) -> FacePreset {
        FacePreset(id: id, title: title) { FacePresetsHuawei.build(s) }
    }

    static let list: [FacePreset] = [
        // 1. Đại bàng mây vàng (lấy ý từ Cloud White Eagle: vàng sang trọng, kim như cánh chim)
        item("hwEagle", "Đại bàng vàng", Spec(
            bg: (0x14100A, 0x3B2D14), backdrop: "goldGeo", marks: .numerals, numerals: .romanGold,
            hand: .featherGold, second: 0xFFE9B0, cap: 0xF2C879,
            text: 0xFFF3D6, accent: 0xF2C879, style: .goldHex,
            plate: (5, 0xD9A441, 0.85), decor: (.rosette, 0xF2C879, 0.25, 0.9, .none),
            fx: .sparkle, fxColor: 0xFFE9B0, aod: "aodGold", aodHand: 0xC7A24E, aodMarks: 0x6B5A2B)),
        // 2. Hoa păng-xê rực rỡ (Pansy Glows)
        item("hwPansy", "Păng-xê rực rỡ", Spec(
            bg: (0x14052A, 0x4A1470), marks: .dots, marksColor: 0xFF9AE6,
            hand: .roseGold, second: 0xFFFFFF, cap: 0xFF7AD9,
            text: 0xFFEAFB, accent: 0xFF9AE6, style: .neonPurple,
            plate: (18, 0xFF7AD9, 0.5), decor: (.chrysanthemum, 0xFF7AD9, 0.5, 0.9, .minute),
            fx: .bloom, fxColor: 0xFF9AE6, fall: (.petals, 0.2), aod: "aodDots", aodHand: 0xC77AB8, aodMarks: 0x5A2A6A)),
        // 3. Cơ khí quý ông (Gentleman Machinery)
        item("hwGentleman", "Cơ khí quý ông", Spec(
            bg: (0x1A1208, 0x3A2A14), marks: .numerals, numerals: .arabicGold,
            hand: .dauphine, second: 0xFF6B3A, cap: 0xC8A15A,
            text: 0xF4E2BC, accent: 0xE0B866, style: .goldSlant,
            plate: (21, 0xC8A15A, 0.8), decor: (.gear, 0xC8A15A, 0.45, 0.85, .minute),
            fx: .ticks, fxColor: 0xFF6B3A, aod: "aodRings", aodHand: 0xA8864A, aodMarks: 0x5A4824)),
        // 4. Bánh xe bạc xanh (Silver Blue Wheel)
        item("hwSilverBlue", "Bánh xe bạc xanh", Spec(
            bg: (0x06121F, 0x16385E), marks: .ticks, marksColor: 0xBFD8F5,
            hand: .dauphineSilver, second: 0x4DA3FF, cap: 0xBFD8F5,
            text: 0xE6F1FF, accent: 0xBFD8F5, style: .silverTech,
            plate: (2, 0x8FB8E8, 0.8), decor: (.dotRings, 0x8FB8E8, 0.4, 0.9, .hour),
            fx: .arc, fxColor: 0x4DA3FF, aod: "aodRings", aodHand: 0x8FB8E8, aodMarks: 0x3A5A80)),
        // 5. Sân vận động mùa hè (cỏ xanh, viền sân, bóng ở giữa)
        item("hwStadium", "Sân vận động", Spec(
            bg: (0x05340F, 0x0F7A2A), marks: .ticks, marksColor: 0xFFFFFF,
            hand: .sport, second: 0xFFD400, cap: 0xFFFFFF,
            text: 0xF2FFF2, accent: 0xFFFFFF, style: .boldWhite,
            layout: .ring(1.15), plate: (9, 0xFFFFFF, 0.6), decor: (.hexGrid, 0xFFFFFF, 0.18, 0.9, .none),
            fx: .arc, fxColor: 0xFFD400, aod: "aodDots", aodHand: 0x9FE0A8, aodMarks: 0x3A7A4A)),
        // 6. Vũ trụ hành tinh
        item("hwCosmos", "Vũ trụ hành tinh", Spec(
            bg: (0x050014, 0x1E0A4A), backdrop: "artPlanet", marks: .dots, marksColor: 0xA6B8FF,
            hand: .future, second: 0xFF7A59, cap: 0xA6B8FF,
            text: 0xE8EEFF, accent: 0x9CB4FF, style: .futureBlue,
            plate: (3, 0x9CB4FF, 0.6), decor: (.constellation, 0xA6B8FF, 0.4, 0.9, .none),
            fx: .orbit, fxColor: 0xFF7A59, fall: (.snow, 0.15), aod: "aodStars", aodHand: 0x8A9ADF, aodMarks: 0x3A4080)),
        // 7. Cực quang phương bắc
        item("hwAuroraPro", "Cực quang phương bắc", Spec(
            bg: (0x03121A, 0x0A4A4A), backdrop: "aurora", marks: .dots, marksColor: 0x9FFFE0,
            hand: .luminousAqua, second: 0xFFFFFF, cap: 0x9FFFE0,
            text: 0xE6FFF8, accent: 0x7CFFD8, style: .neonAqua,
            plate: (3, 0x7CFFD8, 0.5), fx: .rainbow, fxColor: 0x7CFFD8, fall: (.snow, 0.12),
            aod: "aodStars", aodHand: 0x4FC3A8, aodMarks: 0x1F5F58)),
        // 8. Siêu xe vàng chanh
        item("hwSuper", "Siêu xe vàng", Spec(
            bg: (0x0B0B0B, 0x1F1A00), marks: .ticks, marksColor: 0xFFC400,
            hand: .racing, second: 0xFFFFFF, cap: 0xFFC400,
            text: 0xFFF3C2, accent: 0xFFC400, style: .ledAmber,
            layout: .bigBottom, plate: (9, 0xFFC400, 0.85), decor: (.hexGrid, 0xFFC400, 0.2, 0.9, .none),
            fx: .arc, fxColor: 0xFFC400, aod: "aodDots", aodHand: 0xB08A1A, aodMarks: 0x5A4510)),
        // 9. Phi công cổ điển
        item("hwAviator", "Phi công cổ điển", Spec(
            bg: (0x1B1F14, 0x3A3F2A), marks: .numerals, numerals: .cardinalSilver,
            hand: .luminous, second: 0xFF5A1F, cap: 0xE8ECF4,
            text: 0xE9EDDC, accent: 0xD5DCC0, style: .silverLine,
            plate: (14, 0xD5DCC0, 0.6), decor: (.compass, 0xD5DCC0, 0.25, 0.9, .none),
            fx: .radar, fxColor: 0xFF5A1F, aod: "aodMountain", aodHand: 0x9AA37A, aodMarks: 0x4A5236)),
        // 10. Trắng tối giản (mặt sáng, chữ tối)
        item("hwPaper", "Giấy trắng tối giản", Spec(
            bg: (0xF4F4F0, 0xDADAD2), marks: .ticks, marksColor: 0x23262B,
            hand: .minimalist, second: 0xE5322D, cap: 0x23262B, plainHand: 0x23262B,
            text: 0x23262B, accent: 0x23262B, style: .thinLine, ownData: false,
            layout: .ring(1.15), fx: .ticks, fxColor: 0xE5322D,
            aod: "aodDots", aodHand: 0x8A8A84, aodMarks: 0x4A4A46)),
        // 11. Vàng hồng thanh lịch
        item("hwRoseGold", "Vàng hồng thanh lịch", Spec(
            bg: (0x2A1418, 0x5A2E36), marks: .numerals, numerals: .arabicRose,
            hand: .dauphineRose, second: 0xFFFFFF, cap: 0xF4B8B0,
            text: 0xFFEDEA, accent: 0xF4B8B0, style: .roseSlant,
            plate: (1, 0xF4B8B0, 0.6), decor: (.rosette, 0xF4B8B0, 0.28, 0.88, .none),
            fx: .sparkle, fxColor: 0xFFD6D0, aod: "aodDots", aodHand: 0xD79890, aodMarks: 0x6B3A3A)),
        // 12. Ma trận xanh
        item("hwMatrix", "Ma trận xanh", Spec(
            bg: (0x000A03, 0x002A0F), marks: .ticks, marksColor: 0x00FF66,
            hand: .future, second: 0xFFFFFF, cap: 0x00FF66,
            text: 0xC8FFDC, accent: 0x00FF66, style: .pixelGreen,
            layout: .columns, plate: (11, 0x00FF66, 0.7), decor: (.hexGrid, 0x00FF66, 0.2, 0.9, .none),
            fx: .dotChase, fxColor: 0x00FF66, aod: "aodDots", aodHand: 0x1FA050, aodMarks: 0x0F5A2A)),
        // 13. Bình minh trên núi
        item("hwSunrise", "Bình minh trên núi", Spec(
            bg: (0x2A0F2A, 0xFF7A3A), backdrop: "sunsetMountain", marks: .ticks, marksColor: 0xFFE0C0,
            hand: .leafGold, second: 0xFFFFFF, cap: 0xFFE0C0,
            text: 0xFFF3E6, accent: 0xFFD27A, style: .goldPill,
            plate: (6, 0xFFD27A, 0.65), fx: .sunburst, fxColor: 0xFFD27A,
            aod: "aodMountain", aodHand: 0xD9985A, aodMarks: 0x7A4A2A)),
        // 14. Sóng xanh ngọc
        item("hwJade", "Sóng xanh ngọc", Spec(
            bg: (0x021A2A, 0x0A6A78), backdrop: "moonSea", marks: .dots, marksColor: 0xB8F4FF,
            hand: .luminousBlue, second: 0xFFD27A, cap: 0xB8F4FF,
            text: 0xE8FCFF, accent: 0x9CEBFF, style: .bluePill,
            plate: (3, 0x9CEBFF, 0.6), fx: .pulse, fxColor: 0x9CEBFF,
            aod: "aodWaves", aodHand: 0x4FB8C8, aodMarks: 0x1F6A78)),
        // 15. Cá chép hồng
        item("hwKoi", "Cá chép hồng", Spec(
            bg: (0x0A1A2A, 0x14506A), backdrop: "artKoi", marks: .dots, marksColor: 0xFFB070,
            hand: .arrowGold, second: 0xFF6B4A, cap: 0xFFB070,
            text: 0xFFF1E4, accent: 0xFFB070, style: .dotAmber,
            plate: (22, 0xFFB070, 0.55), fx: .bloom, fxColor: 0xFFB070, fall: (.petals, 0.15),
            aod: "aodWaves", aodHand: 0xD9884A, aodMarks: 0x6A4A2A)),
        // 16. Thái cực đỏ đen
        item("hwSamurai", "Đỏ đen võ sĩ", Spec(
            bg: (0x0A0A0A, 0x2A0508), marks: .ticks, marksColor: 0xFF3040,
            hand: .sword, second: 0xFFFFFF, cap: 0xFF3040,
            text: 0xFFE4E6, accent: 0xFF3040, style: .outlineRuby,
            plate: (19, 0xFF3040, 0.6), decor: (.sunburst, 0xB01020, 0.35, 0.9, .none),
            fx: .ticks, fxColor: 0xFF3040, aod: "aodRings", aodHand: 0xB02A36, aodMarks: 0x5A1A20)),
        // 17. Kim cương băng
        item("hwDiamond", "Kim cương băng", Spec(
            bg: (0x080C18, 0x24305A), marks: .numerals, numerals: .diamondSilver,
            hand: .diamond, second: 0x9CD8FF, cap: 0xDDEBFF,
            text: 0xF0F6FF, accent: 0xDDEBFF, style: .silverPill,
            plate: (6, 0xDDEBFF, 0.6), decor: (.snowflake, 0xDDEBFF, 0.3, 0.8, .hour),
            fx: .sparkle, fxColor: 0xDDEBFF, fall: (.snow, 0.2), aod: "aodStars", aodHand: 0x9AA8CC, aodMarks: 0x3A4468)),
        // 18. Phố neon tím hồng
        item("hwNeonCity", "Phố neon tím hồng", Spec(
            bg: (0x12031F, 0x4A0A4A), backdrop: "cityNight", marks: .dots, marksColor: 0xFF4FD8,
            hand: .future, second: 0x40E0FF, cap: 0xFF4FD8,
            text: 0xFFE6FA, accent: 0xFF4FD8, style: .neonPink,
            plate: (17, 0xFF4FD8, 0.6), fx: .comet, fxColor: 0x40E0FF,
            aod: "aodDots", aodHand: 0xB03A98, aodMarks: 0x5A1A55)),
        // 19. Phúc lộc Tết
        item("hwTetFortune", "Phúc lộc Tết", Spec(
            bg: (0x4A0606, 0xA01010), marks: .numerals, numerals: .tetBadge,
            hand: .royal, second: 0xFFE08A, cap: 0xF2C879,
            text: 0xFFF1D0, accent: 0xF2C879, style: .ledTet,
            plate: (25, 0xF2C879, 0.7), decor: (.tetLantern, 0xF2C879, 0.4, 0.88, .none),
            fx: .firework, fxColor: 0xFFE08A, fall: (.mai, 0.25), aod: "aodMai", aodHand: 0xC79A3A, aodMarks: 0x6B4A1A)),
        // 20. Đêm Noel lấp lánh
        item("hwNoelPro", "Đêm Noel lấp lánh", Spec(
            bg: (0x04141C, 0x0A3A2A), backdrop: "noelNight", marks: .dots, marksColor: 0xE8F5FF,
            hand: .royal, second: 0xFF3B30, cap: 0xE8F5FF,
            text: 0xF2FAFF, accent: 0xFF5A5A, style: .silverTech,
            plate: (4, 0xFF5A5A, 0.7), decor: (.noelSnow, 0xE8F5FF, 0.35, 0.9, .none),
            fx: .sparkle, fxColor: 0xFFD84A, fall: (.snow, 0.35), aod: "aodNoel", aodHand: 0x9CCBE8, aodMarks: 0x4A6A80)),
        // 21. Hắc kim
        item("hwBlackGold", "Hắc kim", Spec(
            bg: (0x000000, 0x1A1405), marks: .ticks, marksColor: 0xD4AF37,
            hand: .luxury, second: 0xFFD700, cap: 0xD4AF37,
            text: 0xF5E6B0, accent: 0xD4AF37, style: .goldPill,
            layout: .ring(1.15), plate: (4, 0xD4AF37, 0.9), decor: (.sunburst, 0xD4AF37, 0.2, 0.9, .none),
            fx: .ticks, fxColor: 0xFFD700, aod: "aodGold", aodHand: 0xA88A2A, aodMarks: 0x5A4A18)),
        // 22. Pastel kẹo ngọt (mặt sáng)
        item("hwPastel", "Pastel kẹo ngọt", Spec(
            bg: (0xFFD9E8, 0xCFE8FF), marks: .dots, marksColor: 0xFF7AB0,
            hand: .baton, second: 0x5AA8FF, cap: 0xFF7AB0, plainHand: 0x5A3A6A,
            text: 0x5A3A6A, accent: 0xE0457F, style: .thinLine, ownData: false,
            layout: .ring(1.15), decor: (.cherry, 0xFF9AC8, 0.5, 0.9, .none),
            fx: .bloom, fxColor: 0xFF7AB0, fall: (.petals, 0.25), aod: "aodDots", aodHand: 0xB07AA0, aodMarks: 0x6A4A62)),
        // 23. Sấm sét điện
        item("hwThunder", "Sấm sét điện", Spec(
            bg: (0x04060F, 0x101A40), marks: .ticks, marksColor: 0xFFE14A,
            hand: .sport, second: 0xFFE14A, cap: 0x4D7CFF,
            text: 0xEAF0FF, accent: 0xFFE14A, style: .neonYellow,
            plate: (18, 0xFFE14A, 0.6), decor: (.sunburst, 0x4D7CFF, 0.25, 0.9, .minute),
            fx: .radar, fxColor: 0xFFE14A, aod: "aodRings", aodHand: 0xB0A030, aodMarks: 0x3A4468)),
        // 24. Nhịp xung (từ bản thiết kế web: vòng vạch giây sáng dần màu xanh ngọc, giờ số to màu hồng neon)
        item("hwPulse", "Nhịp xung", Spec(
            bg: (0x0A0612, 0x1B0A33), marks: .ticks, marksColor: 0x2EF2C8,
            hand: .future, second: 0xFF4FD8, cap: 0x2EF2C8,
            text: 0xFFFFFF, accent: 0xFF4FD8, style: .neonPink,
            layout: .bigBottom, plate: (18, 0xFF4FD8, 0.5),
            fx: .ticks, fxColor: 0x2EF2C8, aod: "aodRings", aodHand: 0x1FA088, aodMarks: 0x0F5A4C)),
        // 25-27. Ba mặt có cảnh động toàn mặt, dựng theo bản xem trước trên web (Phần 65)
        item("hwAuroraLive", "Cực quang động", Spec(
            bg: (0x030814, 0x07182E), marks: .dots, marksColor: 0xBFFFE6,
            hand: .luminousAqua, second: 0xFFFFFF, cap: 0x2CFF9A,
            text: 0xE8FFF4, accent: 0x2CFF9A, style: .neonGreen,
            layout: .ring(1.1), plate: (3, 0x2CFF9A, 0.35),
            fx: .ticks, fxColor: 0xFFFFFF, fall: (.aurora, 0.5), fallTiming: (24, 150),
            aod: "aodStars", aodHand: 0x3FB38A, aodMarks: 0x1F5F4A)),
        item("hwTideLive", "Thủy triều", Spec(
            bg: (0x041A2E, 0x06365A), marks: .ticks, marksColor: 0x9FE7FF,
            hand: .luminousBlue, second: 0xFFFFFF, cap: 0x9FE7FF,
            text: 0xFFFFFF, accent: 0xBFEFFF, style: .bluePill,
            layout: .ring(1.1), plate: (3, 0x9FE7FF, 0.45),
            fx: .arc, fxColor: 0x59C9FF, fall: (.tide, 0.5), fallTiming: (24, 120),
            aod: "aodWaves", aodHand: 0x4FB8C8, aodMarks: 0x1F6A78)),
        item("hwNeonRain", "Mưa neon", Spec(
            bg: (0x07040F, 0x14061F), marks: .dots, marksColor: 0xFF4FD8,
            hand: .future, second: 0x00E5FF, cap: 0xFF4FD8,
            text: 0xFFE6FA, accent: 0xFF4FD8, style: .neonPink,
            layout: .ring(1.1), plate: (17, 0xFF4FD8, 0.5),
            fx: .arc, fxColor: 0x00E5FF, fall: (.rain, 0.6),
            aod: "aodDots", aodHand: 0xB03A98, aodMarks: 0x5A1A55))
    ]
}
