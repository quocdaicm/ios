// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 39: biểu tượng và tên tình trạng thời tiết vẽ vector, đồng bộ với kiểu số của khối thời tiết.
// - Hai bộ biểu tượng mới (Đặc / Nét) cùng một lưới 100 x 100, cùng độ dày nét, cùng hình đám mây, tia nắng, hạt mưa.
//   Chỉ dùng tập con của `MiniSVG` (path M L C Q Z, circle). Hình sinh bằng script (cung tròn đổi thành cubic), không cần font hay ảnh.
// - "Đồng bộ với kiểu số": biểu tượng và tên tình trạng được tô bằng đúng kiểu của chữ số nhiệt độ (LED, neon, kim loại...).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Kiểu tô của chữ số vector (dùng để tô biểu tượng và tên tình trạng cho giống số nhiệt độ).
struct IconPaint {
    let def: DigitalShapes.Def
    let own: Bool
}

enum WeatherIconSets {
    /// 0 = bộ SVG cũ (`FaceSVGData.weather`), 1 = đặc, 2 = nét.
    static let titles = ["Bộ cũ", "Đặc", "Nét"]
    /// Tên các kiểu chữ của tên tình trạng: 0 = chữ vector theo font mục thời tiết (đồng bộ với số), 1... = `FaceTextFX`.
    static var nameFXTitles: [String] { ["Theo kiểu số"] + FaceTextFX.specs.map { $0.title } }

    /// SVG của tình trạng `index` (0...10, cùng thứ tự `FaceRenderer.weatherNames`) theo bộ `style`; nil nếu dùng bộ cũ.
    static func svg(style: Int, index: Int) -> String? {
        let set: [String]
        switch style {
        case 1: set = solid
        case 2: set = line
        default: return nil
        }
        guard index >= 0, index < set.count else { return nil }
        return set[index]
    }

    /// Màu trong SVG: sun / cloud / rain / snow / sand / gray (cùng bảng màu `weatherPalette`).
    static let solid: [String] = [
        ##"<path d="M 26.6 75.5 C 18.2 75.5 11.3 68.8 11 60.4 C 10.8 51.9 17.2 44.8 25.7 44.3 C 26.6 33.9 34.9 25.6 45.4 24.6 C 55.9 23.6 65.5 30.3 68.4 40.4 C 75 39.3 81.6 42 85.6 47.3 C 89.5 52.7 90.1 59.8 87.1 65.8 C 84.1 71.7 78 75.5 71.3 75.5 Z" fill="none" stroke="gray" stroke-width="6"/><path d="M 42 46 C 42 36 58 36 58 45 C 58 52 50 52 50 59" fill="none" stroke="gray" stroke-width="5"/><circle cx="50" cy="67.5" r="3.2" fill="gray"/>"##,
        ##"<circle cx="50" cy="50" r="18.5" fill="sun"/><path d="M 78.5 50 L 89.5 50 M 70.2 70.2 L 77.9 77.9 M 50 78.5 L 50 89.5 M 29.8 70.2 L 22.1 77.9 M 21.5 50 L 10.5 50 M 29.8 29.8 L 22.1 22.1 M 50 21.5 L 50 10.5 M 70.2 29.8 L 77.9 22.1" fill="none" stroke="sun" stroke-width="6"/>"##,
        ##"<path d="M 72.2 64.2 C 66.9 78.8 51.5 86.9 36.5 83 C 21.5 79.2 11.9 64.5 14.4 49.2 C 16.8 34 30.5 23.1 45.9 24.1 C 35.2 31.5 32.4 46 39.5 56.9 C 46.6 67.8 61.1 71.1 72.2 64.2 Z" fill="sun"/><path d="M 72 15 Q 74.6 25.4 85 28 Q 74.6 30.6 72 41 Q 69.4 30.6 59 28 Q 69.4 25.4 72 15 Z" fill="cloud" stroke="cloud" stroke-width="1.5"/><path d="M 84 45.5 Q 85.3 50.7 90.5 52 Q 85.3 53.3 84 58.5 Q 82.7 53.3 77.5 52 Q 82.7 50.7 84 45.5 Z" fill="cloud" stroke="cloud" stroke-width="1.2"/>"##,
        ##"<path d="M 79 32 C 79 38.6 73.6 44 67 44 C 60.4 44 55 38.6 55 32 C 55 25.4 60.4 20 67 20 C 73.6 20 79 25.4 79 32 Z" fill="sun"/><path d="M 87.5 32 L 96.5 32 M 81.5 46.5 L 87.9 52.9 M 46.5 32 L 37.5 32 M 52.5 17.5 L 46.1 11.1 M 67 11.5 L 67 2.5 M 81.5 17.5 L 87.9 11.1" fill="none" stroke="sun" stroke-width="6"/><path d="M 21.1 84.6 C 14.3 84.6 8.7 79.2 8.5 72.4 C 8.3 65.6 13.5 59.8 20.3 59.4 C 21.1 51 27.8 44.3 36.3 43.5 C 44.7 42.7 52.5 48.1 54.9 56.2 C 60.2 55.3 65.5 57.5 68.7 61.8 C 71.9 66.2 72.4 71.9 70 76.7 C 67.5 81.6 62.6 84.6 57.2 84.6 Z" fill="cloud"/>"##,
        ##"<path d="M 25.2 79 C 16.3 79 9 71.9 8.8 62.9 C 8.5 54 15.4 46.5 24.3 46 C 25.3 34.9 34.1 26.2 45.1 25.1 C 56.2 24.1 66.4 31.1 69.5 41.8 C 76.4 40.6 83.4 43.5 87.6 49.2 C 91.8 54.9 92.4 62.4 89.2 68.7 C 86.1 75 79.6 79 72.5 79 Z" fill="cloud"/>"##,
        ##"<path d="M 29.3 59.5 C 21.8 59.5 15.7 53.6 15.5 46.2 C 15.3 38.7 21 32.4 28.5 32 C 29.3 22.7 36.7 15.4 45.9 14.5 C 55.2 13.7 63.7 19.5 66.3 28.5 C 72.1 27.5 78 29.9 81.5 34.6 C 85 39.4 85.5 45.7 82.8 51 C 80.2 56.2 74.8 59.5 68.9 59.5 Z" fill="cloud"/><path d="M 34.5 71 L 29.5 86 M 52.5 71 L 47.5 86 M 70.5 71 L 65.5 86" fill="none" stroke="rain" stroke-width="6"/>"##,
        ##"<path d="M 29.3 58.5 C 21.8 58.5 15.7 52.6 15.5 45.2 C 15.3 37.7 21 31.4 28.5 31 C 29.3 21.7 36.7 14.4 45.9 13.5 C 55.2 12.7 63.7 18.5 66.3 27.5 C 72.1 26.5 78 28.9 81.5 33.6 C 85 38.4 85.5 44.7 82.8 50 C 80.2 55.2 74.8 58.5 68.9 58.5 Z" fill="cloud"/><path d="M 54.4 65 L 39.8 81.2 L 49.3 81.2 L 44.8 93 L 62.2 75.6 L 52.1 75.6 L 58.8 65 Z" fill="sun" stroke="sun" stroke-width="2.4"/><path d="M 28 70 L 24 82 M 76 70 L 72 82" fill="none" stroke="rain" stroke-width="6"/>"##,
        ##"<path d="M 29.3 59.5 C 21.8 59.5 15.7 53.6 15.5 46.2 C 15.3 38.7 21 32.4 28.5 32 C 29.3 22.7 36.7 15.4 45.9 14.5 C 55.2 13.7 63.7 19.5 66.3 28.5 C 72.1 27.5 78 29.9 81.5 34.6 C 85 39.4 85.5 45.7 82.8 51 C 80.2 56.2 74.8 59.5 68.9 59.5 Z" fill="cloud"/><circle cx="30" cy="75" r="4" fill="snow"/><circle cx="50" cy="75" r="4" fill="snow"/><circle cx="70" cy="75" r="4" fill="snow"/><circle cx="40" cy="87" r="4" fill="snow"/><circle cx="60" cy="87" r="4" fill="snow"/>"##,
        ##"<circle cx="50" cy="36" r="12.5" fill="sun"/><path d="M 28.5 36 L 19.5 36 M 34.8 20.8 L 28.4 14.4 M 50 14.5 L 50 5.5 M 65.2 20.8 L 71.6 14.4 M 71.5 36 L 80.5 36" fill="none" stroke="sun" stroke-width="6"/><path d="M 15 61 Q 22 55 29 61 Q 36 67 43 61 Q 50 55 57 61 Q 64 67 71 61 Q 78 55 85 61" fill="none" stroke="sand" stroke-width="6"/><path d="M 15 74 Q 22 68 29 74 Q 36 80 43 74 Q 50 68 57 74 Q 64 80 71 74 Q 78 68 85 74" fill="none" stroke="sand" stroke-width="6"/><path d="M 15 87 Q 22 81 29 87 Q 36 93 43 87 Q 50 81 57 87 Q 64 93 71 87 Q 78 81 85 87" fill="none" stroke="sand" stroke-width="6"/>"##,
        ##"<circle cx="50" cy="36" r="12.5" fill="sun"/><path d="M 28.5 36 L 19.5 36 M 34.8 20.8 L 28.4 14.4 M 50 14.5 L 50 5.5 M 65.2 20.8 L 71.6 14.4 M 71.5 36 L 80.5 36" fill="none" stroke="sun" stroke-width="6"/><path d="M 18 62 L 82 62" fill="none" stroke="gray" stroke-width="6"/><path d="M 26 74 L 74 74" fill="none" stroke="gray" stroke-width="6"/><path d="M 34 86 L 66 86" fill="none" stroke="gray" stroke-width="6"/>"##,
        ##"<path d="M 29.3 58.5 C 21.8 58.5 15.7 52.6 15.5 45.2 C 15.3 37.7 21 31.4 28.5 31 C 29.3 21.7 36.7 14.4 45.9 13.5 C 55.2 12.7 63.7 18.5 66.3 27.5 C 72.1 26.5 78 28.9 81.5 33.6 C 85 38.4 85.5 44.7 82.8 50 C 80.2 55.2 74.8 58.5 68.9 58.5 Z" fill="cloud"/><path d="M 18 71 L 82 71" fill="none" stroke="gray" stroke-width="6"/><path d="M 30 84 L 70 84" fill="none" stroke="gray" stroke-width="6"/>"##
    ]

    static let line: [String] = [
        ##"<path d="M 26.6 75.5 C 18.2 75.5 11.3 68.8 11 60.4 C 10.8 51.9 17.2 44.8 25.7 44.3 C 26.6 33.9 34.9 25.6 45.4 24.6 C 55.9 23.6 65.5 30.3 68.4 40.4 C 75 39.3 81.6 42 85.6 47.3 C 89.5 52.7 90.1 59.8 87.1 65.8 C 84.1 71.7 78 75.5 71.3 75.5 Z" fill="none" stroke="gray" stroke-width="6"/><path d="M 42 46 C 42 36 58 36 58 45 C 58 52 50 52 50 59" fill="none" stroke="gray" stroke-width="5"/><circle cx="50" cy="67.5" r="3.2" fill="gray"/>"##,
        ##"<circle cx="50" cy="50" r="16" fill="none" stroke="sun" stroke-width="6"/><path d="M 78.5 50 L 89.5 50 M 70.2 70.2 L 77.9 77.9 M 50 78.5 L 50 89.5 M 29.8 70.2 L 22.1 77.9 M 21.5 50 L 10.5 50 M 29.8 29.8 L 22.1 22.1 M 50 21.5 L 50 10.5 M 70.2 29.8 L 77.9 22.1" fill="none" stroke="sun" stroke-width="6"/>"##,
        ##"<path d="M 66.9 69.3 C 59.9 79.7 46.8 84.1 35 80 C 23.2 75.9 15.6 64.3 16.6 51.8 C 17.6 39.4 26.8 29.1 39.2 26.9 C 31.8 35.9 31.1 48.6 37.4 58.3 C 43.8 68 55.7 72.5 66.9 69.3 Z" fill="none" stroke="sun" stroke-width="6"/><path d="M 72 15 Q 74.6 25.4 85 28 Q 74.6 30.6 72 41 Q 69.4 30.6 59 28 Q 69.4 25.4 72 15 Z" fill="cloud" stroke="cloud" stroke-width="1.5"/><path d="M 84 45.5 Q 85.3 50.7 90.5 52 Q 85.3 53.3 84 58.5 Q 82.7 53.3 77.5 52 Q 82.7 50.7 84 45.5 Z" fill="cloud" stroke="cloud" stroke-width="1.2"/>"##,
        ##"<path d="M 76.5 32 C 76.5 37.2 72.2 41.5 67 41.5 C 61.8 41.5 57.5 37.2 57.5 32 C 57.5 26.8 61.8 22.5 67 22.5 C 72.2 22.5 76.5 26.8 76.5 32" fill="none" stroke="sun" stroke-width="6"/><path d="M 87.5 32 L 96.5 32 M 81.5 46.5 L 87.9 52.9 M 46.5 32 L 37.5 32 M 52.5 17.5 L 46.1 11.1 M 67 11.5 L 67 2.5 M 81.5 17.5 L 87.9 11.1" fill="none" stroke="sun" stroke-width="6"/><path d="M 21.1 84.6 C 14.3 84.6 8.7 79.2 8.5 72.4 C 8.3 65.6 13.5 59.8 20.3 59.4 C 21.1 51 27.8 44.3 36.3 43.5 C 44.7 42.7 52.5 48.1 54.9 56.2 C 60.2 55.3 65.5 57.5 68.7 61.8 C 71.9 66.2 72.4 71.9 70 76.7 C 67.5 81.6 62.6 84.6 57.2 84.6 Z" fill="none" stroke="cloud" stroke-width="6"/>"##,
        ##"<path d="M 25.2 79 C 16.3 79 9 71.9 8.8 62.9 C 8.5 54 15.4 46.5 24.3 46 C 25.3 34.9 34.1 26.2 45.1 25.1 C 56.2 24.1 66.4 31.1 69.5 41.8 C 76.4 40.6 83.4 43.5 87.6 49.2 C 91.8 54.9 92.4 62.4 89.2 68.7 C 86.1 75 79.6 79 72.5 79 Z" fill="none" stroke="cloud" stroke-width="6"/>"##,
        ##"<path d="M 29.3 59.5 C 21.8 59.5 15.7 53.6 15.5 46.2 C 15.3 38.7 21 32.4 28.5 32 C 29.3 22.7 36.7 15.4 45.9 14.5 C 55.2 13.7 63.7 19.5 66.3 28.5 C 72.1 27.5 78 29.9 81.5 34.6 C 85 39.4 85.5 45.7 82.8 51 C 80.2 56.2 74.8 59.5 68.9 59.5 Z" fill="none" stroke="cloud" stroke-width="6"/><path d="M 34.5 71 L 29.5 86 M 52.5 71 L 47.5 86 M 70.5 71 L 65.5 86" fill="none" stroke="rain" stroke-width="6"/>"##,
        ##"<path d="M 29.3 58.5 C 21.8 58.5 15.7 52.6 15.5 45.2 C 15.3 37.7 21 31.4 28.5 31 C 29.3 21.7 36.7 14.4 45.9 13.5 C 55.2 12.7 63.7 18.5 66.3 27.5 C 72.1 26.5 78 28.9 81.5 33.6 C 85 38.4 85.5 44.7 82.8 50 C 80.2 55.2 74.8 58.5 68.9 58.5 Z" fill="none" stroke="cloud" stroke-width="6"/><path d="M 54.4 65 L 39.8 81.2 L 49.3 81.2 L 44.8 93 L 62.2 75.6 L 52.1 75.6 L 58.8 65 Z" fill="sun" stroke="sun" stroke-width="2.4"/><path d="M 28 70 L 24 82 M 76 70 L 72 82" fill="none" stroke="rain" stroke-width="6"/>"##,
        ##"<path d="M 29.3 59.5 C 21.8 59.5 15.7 53.6 15.5 46.2 C 15.3 38.7 21 32.4 28.5 32 C 29.3 22.7 36.7 15.4 45.9 14.5 C 55.2 13.7 63.7 19.5 66.3 28.5 C 72.1 27.5 78 29.9 81.5 34.6 C 85 39.4 85.5 45.7 82.8 51 C 80.2 56.2 74.8 59.5 68.9 59.5 Z" fill="none" stroke="cloud" stroke-width="6"/><circle cx="30" cy="75" r="4" fill="snow"/><circle cx="50" cy="75" r="4" fill="snow"/><circle cx="70" cy="75" r="4" fill="snow"/><circle cx="40" cy="87" r="4" fill="snow"/><circle cx="60" cy="87" r="4" fill="snow"/>"##,
        ##"<circle cx="50" cy="36" r="10" fill="none" stroke="sun" stroke-width="6"/><path d="M 28.5 36 L 19.5 36 M 34.8 20.8 L 28.4 14.4 M 50 14.5 L 50 5.5 M 65.2 20.8 L 71.6 14.4 M 71.5 36 L 80.5 36" fill="none" stroke="sun" stroke-width="6"/><path d="M 15 61 Q 22 55 29 61 Q 36 67 43 61 Q 50 55 57 61 Q 64 67 71 61 Q 78 55 85 61" fill="none" stroke="sand" stroke-width="6"/><path d="M 15 74 Q 22 68 29 74 Q 36 80 43 74 Q 50 68 57 74 Q 64 80 71 74 Q 78 68 85 74" fill="none" stroke="sand" stroke-width="6"/><path d="M 15 87 Q 22 81 29 87 Q 36 93 43 87 Q 50 81 57 87 Q 64 93 71 87 Q 78 81 85 87" fill="none" stroke="sand" stroke-width="6"/>"##,
        ##"<circle cx="50" cy="36" r="10" fill="none" stroke="sun" stroke-width="6"/><path d="M 28.5 36 L 19.5 36 M 34.8 20.8 L 28.4 14.4 M 50 14.5 L 50 5.5 M 65.2 20.8 L 71.6 14.4 M 71.5 36 L 80.5 36" fill="none" stroke="sun" stroke-width="6"/><path d="M 18 62 L 82 62" fill="none" stroke="gray" stroke-width="6"/><path d="M 26 74 L 74 74" fill="none" stroke="gray" stroke-width="6"/><path d="M 34 86 L 66 86" fill="none" stroke="gray" stroke-width="6"/>"##,
        ##"<path d="M 29.3 58.5 C 21.8 58.5 15.7 52.6 15.5 45.2 C 15.3 37.7 21 31.4 28.5 31 C 29.3 21.7 36.7 14.4 45.9 13.5 C 55.2 12.7 63.7 18.5 66.3 27.5 C 72.1 26.5 78 28.9 81.5 33.6 C 85 38.4 85.5 44.7 82.8 50 C 80.2 55.2 74.8 58.5 68.9 58.5 Z" fill="none" stroke="cloud" stroke-width="6"/><path d="M 18 71 L 82 71" fill="none" stroke="gray" stroke-width="6"/><path d="M 30 84 L 70 84" fill="none" stroke="gray" stroke-width="6"/>"##
    ]
}

extension FaceRenderer {
    /// Tô biểu tượng SVG bằng kiểu của số vector: mỗi phần tử (vùng tô hoặc nét đã đổi thành vùng) vẽ qua `DigitalShapes.drawLabel`.
    /// `rect` là ô vuông của biểu tượng; hộp SVG 100 x 100 được co vừa ô.
    static func drawSyncedSVG(_ svg: String, in rect: CGRect, paint: IconPaint, color: UIColor) {
        guard let ctx = UIGraphicsGetCurrentContext(), rect.width > 0, rect.height > 0 else { return }
        let s = min(rect.width, rect.height) / 100
        var toCenter = CGAffineTransform(translationX: -50, y: -50)
        for p in MiniSVG.inkPaths(svg) {
            let centered = p.copy(using: &toCenter) ?? p
            DigitalShapes.drawLabel(ctx, def: paint.def, shape: centered, scale: s, in: rect, color: color, own: paint.own)
        }
    }

    /// Vẽ tên tình trạng `name` vào ô có góc trên-trái `o` (cao `L.textH`, ngữ cảnh UIKit hiện tại), căn trái như chữ thường.
    /// Ba chế độ: kiểu chữ vector `weatherFX` (như Thứ / Tên); tô theo kiểu của số vector khi đồng bộ; còn lại là chữ dạng path một màu
    /// (có viền tối mờ như `drawHaloText`).
    static func drawWeatherName(_ name: String, _ L: WeatherLayout, color: UIColor, origin o: CGPoint) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let text = (L.textFX?.caps ?? false) ? name.uppercased() : name
        guard !text.isEmpty else { return }
        if L.textSynced, let v = L.vec {
            let w = CGFloat(DigitalText.width(text, def: v.def, font: L.textFont) + 2 * L.textPadX)
            let box = CGRect(x: o.x, y: o.y, width: min(CGFloat(L.textW), w), height: CGFloat(L.textH))
            DigitalText.draw(text, def: v.def, own: v.own, font: L.textFont, color: color, centered: false, in: box)
            return
        }
        let own = CGFloat(dataTextWidth(text, L.textFont) + 2 * L.textPadX)
        let cell = CGRect(x: o.x, y: o.y, width: min(CGFloat(L.textW), own), height: CGFloat(L.textH))
        if let s = L.textFX {
            FaceTextFX.draw(text, spec: s, font: L.textFont, color: color, in: cell)
            return
        }
        guard let built = FaceTextFX.glyphPath(text, font: L.textFont) else { return }
        let font = L.textFont
        // Toạ độ glyph (y hướng lên) -> toạ độ ô: gốc ở đầu đường cơ sở, lật trục y.
        let baseline = cell.minY + CGFloat(L.textPadY) + 1 + font.ascender
        var place = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: cell.minX + CGFloat(L.textPadX), ty: baseline)
        guard let path = built.path.copy(using: &place) else { return }
        if L.textSynced, let v = L.vec {
            var toCenter = CGAffineTransform(translationX: -cell.midX, y: -cell.midY)
            let centered = path.copy(using: &toCenter) ?? path
            DigitalShapes.drawLabel(ctx, def: v.def, shape: centered, scale: 1, in: cell, color: color, own: v.own)
            return
        }
        if textOutlineOn {
            ctx.saveGState()
            ctx.addPath(path)
            ctx.setLineWidth(max(1.2, font.pointSize * 0.09))
            ctx.setLineJoin(.round)
            ctx.setStrokeColor(UIColor.black.withAlphaComponent(0.6).cgColor)
            ctx.strokePath()
            ctx.restoreGState()
        }
        ctx.addPath(path)
        ctx.setFillColor(color.withAlphaComponent(0.95).cgColor)
        ctx.fillPath()
    }
}
