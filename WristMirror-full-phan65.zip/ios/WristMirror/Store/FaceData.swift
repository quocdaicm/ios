// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Số liệu do đồng hồ cập nhật: pin, bước chân, nhịp tim, calo, thời tiết
//
// Cấu trúc lấy từ các file HWT thật (Kozmik Kule / Kristal / Ultimate, màn hình HWHD09):
// - Số (pin, bước chân, nhịp tim, calo, nhiệt độ) là lớp loại 3: 10 ảnh chữ số 0...9, ảnh dấu trừ, một ảnh đơn vị
//   ghép sau số (ví dụ "%", "bpm", "°") và mã loại số liệu (HwtDataType). Đồng hồ tự ghép chữ số và cập nhật.
// - Tình trạng thời tiết là dãy ảnh theo mã 53 (giá trị 0...10), dùng cho cả biểu tượng lẫn tên tình trạng.
// Xem trước dùng số liệu mẫu cố định; số thật do đồng hồ cập nhật.

/// Một mục số liệu: bật/tắt, màu, cỡ chữ, vị trí.
struct DataWidget {
    var show = false
    var color = Color.white
    var size = 1.0
    /// Vị trí ngang của MÉP TRÁI khối (tỉ lệ 0.1 ... 0.9 bề ngang mặt đồng hồ).
    var x = 0.5
    /// Vị trí dọc của tâm khối (tỉ lệ 0.1 ... 0.9).
    var y = 0.5
    /// Hiện đơn vị (%, bpm, kcal…) sau số.
    var unit = true
    /// Hiện biểu tượng (vẽ bằng vector SF Symbols) bên trái số; chỉ dùng cho pin, bước chân, nhịp tim, calo.
    var icon = false
    /// Biểu tượng một màu theo màu chữ thay vì màu riêng.
    var iconMono = false
    /// Kiểu số riêng của mục này (tắt = theo kiểu chung `FaceDesign.dataStyle`). `.classic` = số thường theo font.
    var customStyle = false
    var style: DigitalStyle = .classic
    /// Dùng màu gốc của kiểu số riêng (kim loại, LED, neon...).
    var ownColors = true
}

/// Các mục số đơn giản (một số + đơn vị).
enum DataKind: CaseIterable {
    case battery, steps, heart, calories

    var dataType: Int {
        switch self {
        case .battery: return HwtDataType.battery
        case .steps: return HwtDataType.steps
        case .heart: return HwtDataType.heartRate
        case .calories: return HwtDataType.calories
        }
    }

    /// Số chữ số tối đa dành chỗ (để khối không tràn khỏi mặt đồng hồ).
    var maxDigits: Int {
        switch self {
        case .battery: return 3
        case .steps: return 6
        case .heart: return 3
        case .calories: return 5
        }
    }

    /// Số liệu mẫu cho ảnh xem trước.
    var sample: Int {
        switch self {
        case .battery: return 86
        case .steps: return 8432
        case .heart: return 72
        case .calories: return 412
        }
    }

    /// Biểu tượng SF Symbols và màu riêng của từng mục.
    var iconSymbol: (name: String, color: UIColor) {
        switch self {
        case .battery: return ("battery.100percent", UIColor(red: 0.35, green: 0.85, blue: 0.45, alpha: 1))
        case .steps: return ("figure.walk", UIColor(red: 0.35, green: 0.78, blue: 1.0, alpha: 1))
        case .heart: return ("heart.fill", UIColor(red: 1.0, green: 0.30, blue: 0.35, alpha: 1))
        case .calories: return ("flame.fill", UIColor(red: 1.0, green: 0.60, blue: 0.20, alpha: 1))
        }
    }

    var suffix: String {
        switch self {
        case .battery: return "%"
        case .steps: return tr(" bước")
        case .heart: return " bpm"
        case .calories: return " kcal"
        }
    }
}

extension FaceDesign {
    func dataWidget(_ kind: DataKind) -> DataWidget {
        switch kind {
        case .battery: return battery
        case .steps: return steps
        case .heart: return heart
        case .calories: return calories
        }
    }
}

/// Bố cục một số + đơn vị (căn trái: (x, y) là góc trên-trái của chữ số đầu tiên).
struct DataNumberLayout {
    let font: UIFont
    let suffixFont: UIFont
    let digitW: Int
    let lineH: Int
    let suffix: String
    let suffixW: Int
    let x: Int
    let y: Int
    /// Bề rộng chỗ dành cho biểu tượng (0 nếu tắt) và cỡ biểu tượng.
    let iconW: Int
    let iconS: Int
    /// Kiểu số vector (nil = số thường theo font).
    var vec: DataVecInfo? = nil

    var numX: Int { x + iconW }
    var iconY: Int { y + (lineH - iconS) / 2 }
}

/// Bố cục khối thời tiết: biểu tượng + nhiệt độ (+ tên tình trạng, + cao/thấp).
struct WeatherLayout {
    let numFont: UIFont
    let degFont: UIFont
    let digitW: Int
    let lineH: Int
    let degW: Int
    let iconS: Int
    let gap: Int
    /// Nhiệt kế vector cạnh nhiệt độ (Phần 36): cỡ (0 = tắt) và bề rộng chỗ dành (gồm khoảng cách).
    let thermoS: Int
    let thermoW: Int
    let x: Int
    let y: Int
    let rowH: Int
    let showText: Bool
    let textFont: UIFont
    let textW: Int
    let textH: Int
    /// Phần 39: kiểu chữ vector của tên tình trạng (nil = chữ dạng path theo font mục thời tiết), phần đệm quanh chữ (đã tính vào
    /// `textW` / `textH`), và có đồng bộ biểu tượng + tên với kiểu số vector hay không (chỉ true khi số là kiểu vector).
    let textFX: TextFXSpec?
    let textPadX: Int
    let textPadY: Int
    let synced: Bool
    let showRange: Bool
    let rangeFont: UIFont
    let rangeDegFont: UIFont
    let rangeDigitW: Int
    let rangeLineH: Int
    let rangeDegW: Int
    let arrowW: Int
    let groupW: Int
    let rangeGap: Int
    /// Kiểu số vector của nhiệt độ hiện tại (kèm "°") và của nhiệt độ cao/thấp; nil = số thường theo font.
    let vec: DataVecInfo?
    let rangeVec: DataVecInfo?

    var iconY: Int { y + (rowH - iconS) / 2 }
    var thermoX: Int { x + iconS + gap }
    var thermoY: Int { y + (rowH - thermoS) / 2 }
    var numX: Int { x + iconS + gap + thermoW }
    var numY: Int { y + (rowH - lineH) / 2 }
    var textY: Int { y + rowH + 2 }
    /// Mép trái của ô tên tình trạng: lùi `textPadX` để chữ vẫn bắt đầu thẳng hàng với biểu tượng.
    var textX: Int { max(0, x - textPadX) }
    /// Tên tình trạng tô theo kiểu của số (chỉ khi không dùng kiểu chữ riêng `weatherFX`).
    var textSynced: Bool { synced && textFX == nil }
    /// Kiểu tô của số vector, dùng để tô biểu tượng khi đồng bộ.
    var paint: IconPaint? {
        guard synced, let v = vec else { return nil }
        return IconPaint(def: v.def, own: v.own)
    }
    var rangeY: Int { y + rowH + 2 + (showText ? textH + 2 : 0) }
    var loX: Int { x + groupW + rangeGap }

    init(_ d: FaceDesign) {
        let k = FaceRenderer.dataScale(d.weather.size)
        let tface = d.textFace("weather"), nface = d.numberFace("weather")
        let nf = nface.number(34 * k, .bold)
        let df = tface.text(30 * k, .bold)
        var dw = FaceFont.digitCell(nf)
        var lh = Int(ceil(nf.lineHeight)) + 2
        var degw = FaceRenderer.dataTextWidth("°", df)
        var mainVec: DataVecInfo? = nil
        let styled = d.dataVecStyle(d.weather)
        if let m = styled {
            let c = DigitalShapes.cells(m.def, scale: k, base: 28)
            let gh = c.lineH - 2 * c.pad
            let deg = FaceRenderer.vecSuffix("°", fontScale: 36 * k / 100, glyphH: gh, pad: c.pad, def: m.def,
                                             gap: 1, alignTop: true, sym: d.unitSymbol)
            dw = c.digitW
            lh = c.lineH
            degw = deg?.w ?? 0
            mainVec = DataVecInfo(def: m.def, own: m.own, pad: c.pad, glyphH: gh, key: m.key, suffix: deg)
        }
        let iS = d.weatherIcon ? Int((40 * k).rounded()) : 0
        let g = d.weatherIcon ? Int((6 * k).rounded()) : 0
        let tS = d.thermoStyle > 0 ? Int((34 * k).rounded()) : 0
        let tW = tS > 0 ? tS + Int((3 * k).rounded()) : 0
        let rh = max(iS, lh, tS)

        // Tên tình trạng: kiểu chữ vector (weatherFX), hoặc chữ dạng path (tô theo kiểu số khi đồng bộ, cần thêm đệm cho quầng sáng).
        let fx = FaceTextFX.spec(d.weatherFX)
        let isSynced = d.weatherSync && styled != nil
        // Phần 61: khi đồng bộ và không dùng kiểu chữ riêng, tên tình trạng là chữ kỹ thuật số (HOA, lưới chấm với kiểu chấm / pixel).
        let digText = (isSynced && fx == nil) ? styled?.def : nil
        let tf = fx.map { FaceTextFX.font($0, size: 17 * k) } ?? digText.map { DigitalText.font($0, size: 17 * k) } ?? tface.text(17 * k, .bold)
        var tpx = 0
        var tpy = 0
        if let s = fx {
            let p = FaceTextFX.padding(s, fontSize: tf.pointSize)
            tpx = p.x
            tpy = p.y
        } else if isSynced, let m = styled {
            tpx = DigitalText.pad(m.def)
            tpy = tpx
        }
        let nameList = FaceRenderer.weatherNames.map { ((fx?.caps ?? false) || digText != nil) ? $0.uppercased() : $0 }
        let tw = (nameList.map { n in digText.map { DigitalText.width(n, def: $0, font: tf) } ?? FaceRenderer.dataTextWidth(n, tf) }.max() ?? 80) + 2 * tpx
        let th = (digText.map { DigitalText.lineHeight($0, font: tf) } ?? Int(ceil(tf.lineHeight))) + 2 + 2 * tpy

        let rf = nface.number(20 * k, .semibold)
        let rdf = tface.text(18 * k, .semibold)
        var rdw = FaceFont.digitCell(rf)
        var rlh = Int(ceil(rf.lineHeight)) + 2
        var rdeg = FaceRenderer.dataTextWidth("°", rdf)
        var aw = FaceRenderer.dataTextWidth("↑", rf)
        var smallVec: DataVecInfo? = nil
        if let m = styled {
            let c = DigitalShapes.cells(m.def, scale: k, base: 18)
            let gh = c.lineH - 2 * c.pad
            let deg = FaceRenderer.vecSuffix("°", fontScale: 14 * k / 100, glyphH: gh, pad: c.pad, def: m.def,
                                             gap: 1, alignTop: true, sym: d.unitSymbol)
            rdw = c.digitW
            rlh = c.lineH
            rdeg = deg?.w ?? 0
            aw = Int((Double(gh) * 0.62).rounded()) + 4
            smallVec = DataVecInfo(def: m.def, own: m.own, pad: c.pad, glyphH: gh, key: m.key, suffix: deg)
        }
        let gw = aw + rdw * 2 + rdeg
        let rgap = rdw

        var bw = iS + g + tW + dw * 3 + degw
        var bh = rh
        if d.weatherText { bw = max(bw, tw); bh += th + 2 }
        if d.weatherRange { bw = max(bw, gw * 2 + rgap); bh += rlh + 2 }
        let side = Int(FaceRenderer.size)
        let left = max(0, min(side - bw, Int(FaceRenderer.size * FaceRenderer.dataUnit(d.weather.x))))
        let top = max(0, min(side - bh, Int(FaceRenderer.size * FaceRenderer.dataUnit(d.weather.y)) - bh / 2))

        numFont = nf
        degFont = df
        digitW = dw
        lineH = lh
        degW = degw
        iconS = iS
        gap = g
        thermoS = tS
        thermoW = tW
        x = left
        y = top
        rowH = rh
        showText = d.weatherText
        textFont = tf
        textW = tw
        textH = th
        textFX = fx
        textPadX = tpx
        textPadY = tpy
        synced = isSynced
        showRange = d.weatherRange
        rangeFont = rf
        rangeDegFont = rdf
        rangeDigitW = rdw
        rangeLineH = rlh
        rangeDegW = rdeg
        arrowW = aw
        groupW = gw
        rangeGap = rgap
        vec = mainVec
        rangeVec = smallVec
    }
}

extension FaceRenderer {
    /// Tên tình trạng thời tiết theo mã 0...10 (thứ tự như file HWT thật).
    static var weatherNames: [String] { ["Không có dữ liệu", "Nắng", "Trời quang", "Ít mây", "Nhiều mây", "Mưa",
                               "Dông", "Tuyết", "Bão cát", "Mù", "Sương mù"].map { tr($0) } }

    /// Biểu tượng SF Symbols và các màu (lớp chính trước) cho từng tình trạng 0...10.
    private static var weatherSymbols: [(name: String, colors: [UIColor])] {
        let white = UIColor.white
        let gray = UIColor(white: 0.72, alpha: 1)
        let yellow = UIColor(red: 1.0, green: 0.80, blue: 0.20, alpha: 1)
        let cyan = UIColor(red: 0.35, green: 0.78, blue: 1.0, alpha: 1)
        let sand = UIColor(red: 0.80, green: 0.62, blue: 0.38, alpha: 1)
        return [
            ("cloud.fill", [gray, gray]),
            ("sun.max.fill", [yellow, yellow]),
            ("moon.stars.fill", [yellow, white]),
            ("cloud.sun.fill", [white, yellow]),
            ("cloud.fill", [white, white]),
            ("cloud.rain.fill", [white, cyan]),
            ("cloud.bolt.rain.fill", [white, yellow, cyan]),
            ("cloud.snow.fill", [white, cyan]),
            ("sun.dust.fill", [yellow, sand]),
            ("sun.haze.fill", [yellow, gray]),
            ("cloud.fog.fill", [white, gray])
        ]
    }

    static func dataScale(_ s: Double) -> CGFloat { CGFloat(min(1.8, max(0.6, s))) }
    static func dataUnit(_ v: Double) -> CGFloat { CGFloat(min(0.9, max(0.1, v))) }

    static func dataTextWidth(_ t: String, _ f: UIFont) -> Int {
        Int(ceil((t as NSString).size(withAttributes: [.font: f]).width)) + 2
    }

    // MARK: Bố cục

    static func dataNumberLayout(_ kind: DataKind, _ w: DataWidget, _ d: FaceDesign) -> DataNumberLayout {
        let k = dataScale(w.size)
        let font = d.numberFace(kind.key).number(34 * k, .bold)
        let sfont = d.textFace(kind.key).text(17 * k, .bold)
        var digitW = FaceFont.digitCell(font)
        var lineH = Int(ceil(font.lineHeight)) + 2
        let suffix = w.unit ? kind.suffix : ""
        var suffixW = suffix.isEmpty ? 0 : dataTextWidth(suffix, sfont)
        var vecInfo: DataVecInfo? = nil
        if let vl = dataVecLayout(kind, w, d, k: k) {
            vecInfo = vl.v
            digitW = vl.digitW
            lineH = vl.lineH
            suffixW = vl.suffixW
        }
        let iconS = w.icon ? Int((28 * k).rounded()) : 0
        let iconW = w.icon ? iconS + Int((5 * k).rounded()) : 0
        let total = iconW + digitW * kind.maxDigits + suffixW
        let side = Int(size)
        let x = max(0, min(side - total, Int(size * dataUnit(w.x))))
        let y = max(0, min(side - lineH, Int(size * dataUnit(w.y)) - lineH / 2))
        return DataNumberLayout(font: font, suffixFont: sfont, digitW: digitW, lineH: lineH,
                                suffix: suffix, suffixW: suffixW, x: x, y: y, iconW: iconW, iconS: iconS, vec: vecInfo)
    }

    // MARK: Vẽ chữ

    /// Vẽ đơn vị cùng đường cơ sở với chữ số (ctx kiểu UIKit, gốc trên-trái).
    static func drawSuffixText(_ text: String, font: UIFont, numFont: UIFont, color: UIColor, in rect: CGRect, sym: Int = 0) {
        guard !text.isEmpty else { return }
        if sym > 0, UnitSymbols.shape(text, style: sym) != nil {
            UnitSymbols.drawFlat(text, style: sym, font: font, numFont: numFont, color: color, in: rect)
            return
        }
        let numTop = (rect.height - numFont.lineHeight) / 2
        let baseline = rect.minY + numTop + numFont.ascender
        drawHaloText(text, font: font, color: color, at: CGPoint(x: rect.minX + 1, y: baseline - font.ascender))
    }

    /// Vẽ chuỗi số căn trái, mỗi chữ số một ô rộng `digitW`. Trả về toạ độ x ngay sau chữ số cuối.
    @discardableResult
    static func drawNumberString(_ text: String, font: UIFont, digitW: Int, lineH: Int, x: Int, y: Int, color: UIColor) -> Int {
        var cx = x
        for ch in text {
            drawLunarText(String(ch), font: font, color: color, in: CGRect(x: cx, y: y, width: digitW, height: lineH))
            cx += digitW
        }
        return cx
    }

    static func drawWeatherSymbol(_ index: Int, in rect: CGRect, mono: UIColor? = nil) {
        let symbols = weatherSymbols
        guard index >= 0, index < symbols.count else { return }
        let s = symbols[index]
        let colors = mono.map { c in s.colors.map { _ in c } } ?? s.colors
        drawSymbol(s.name, colors: colors, in: rect)
    }

    /// Vẽ một biểu tượng SF Symbols (vector) vừa khung, nhiều lớp màu.
    static func drawSymbol(_ name: String, colors: [UIColor], in rect: CGRect) {
        let cfg = UIImage.SymbolConfiguration(pointSize: rect.height * 0.78, weight: .regular)
            .applying(UIImage.SymbolConfiguration(paletteColors: colors))
        let primary = UIImage(systemName: name, withConfiguration: cfg)
        let fallback = name == "battery.100percent" ? UIImage(systemName: "battery.100", withConfiguration: cfg) : nil
        guard let img = (primary ?? fallback)?.withRenderingMode(.alwaysOriginal) else { return }
        let sz = img.size
        guard sz.width > 0, sz.height > 0 else { return }
        let k = min(rect.width / sz.width, rect.height / sz.height)
        let w = sz.width * k, h = sz.height * k
        img.draw(in: CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h))
    }

    private static let rangeHighColor = UIColor(red: 1.0, green: 0.62, blue: 0.25, alpha: 1)
    private static let rangeLowColor = UIColor(red: 0.30, green: 0.85, blue: 0.85, alpha: 1)
    private static let sampleCondition = 3
    private static let sampleTemp = 18
    private static let sampleHigh = 21
    private static let sampleLow = 12

    // MARK: Xem trước

    static func drawDataPreview(_ ctx: CGContext, design d: FaceDesign) {
        UIGraphicsPushContext(ctx)
        for kind in DataKind.allCases {
            let w = d.dataWidget(kind)
            guard w.show else { continue }
            let L = dataNumberLayout(kind, w, d)
            let color = UIColor(w.color)
            if w.icon {
                let iconRect = CGRect(x: L.x, y: L.iconY, width: L.iconS, height: L.iconS)
                if kind == .battery, d.batteryLevelStyle > 0 {
                    // Biểu tượng đổi theo mức: xem trước ở mức của số liệu mẫu.
                    drawBatteryLevelIcon(style: d.batteryLevelStyle, level: FaceBatteryLevel.index(forPercent: kind.sample),
                                         in: iconRect, textColor: color, mono: w.iconMono)
                } else {
                    drawDataIcon(kind, in: iconRect, textColor: color, mono: w.iconMono, svg: d.iconSVG, batteryStyle: d.batteryIconStyle)
                }
            }
            if let v = L.vec {
                let end = drawVecNumber(ctx, String(kind.sample), v, digitW: L.digitW, lineH: L.lineH, x: L.numX, y: L.y, color: color)
                drawVecSuffix(ctx, v, color: color, x: CGFloat(end), y: CGFloat(L.y))
                continue
            }
            let end = drawNumberString(String(kind.sample), font: L.font, digitW: L.digitW, lineH: L.lineH, x: L.numX, y: L.y, color: color)
            drawSuffixText(L.suffix, font: L.suffixFont, numFont: L.font, color: color.withAlphaComponent(0.92),
                           in: CGRect(x: end, y: L.y, width: L.suffixW, height: L.lineH), sym: d.unitSymbol)
        }
        if d.weather.show { drawWeatherPreview(d) }
        UIGraphicsPopContext()
    }

    private static func drawWeatherPreview(_ d: FaceDesign) {
        let L = WeatherLayout(d)
        let color = UIColor(d.weather.color)
        if d.weatherIcon {
            drawWeatherIcon(sampleCondition, in: CGRect(x: L.x, y: L.iconY, width: L.iconS, height: L.iconS),
                            textColor: color, mono: d.weatherIconMono, svg: d.iconSVG,
                            style: d.weatherIconStyle, sync: L.paint)
        }
        if L.thermoS > 0 {
            drawThermoIcon(d.thermoStyle, in: CGRect(x: L.thermoX, y: L.thermoY, width: L.thermoS, height: L.thermoS),
                           textColor: color, mono: d.weatherIconMono)
        }
        if let v = L.vec, let ctx = UIGraphicsGetCurrentContext() {
            let end = drawVecNumber(ctx, String(sampleTemp), v, digitW: L.digitW, lineH: L.lineH, x: L.numX, y: L.numY, color: color)
            drawVecSuffix(ctx, v, color: color, x: CGFloat(end), y: CGFloat(L.numY))
        } else {
            let end = drawNumberString(String(sampleTemp), font: L.numFont, digitW: L.digitW, lineH: L.lineH, x: L.numX, y: L.numY, color: color)
            drawSuffixText("°", font: L.degFont, numFont: L.numFont, color: color,
                           in: CGRect(x: end, y: L.numY, width: L.degW, height: L.lineH), sym: d.unitSymbol)
        }
        if L.showText {
            drawWeatherName(weatherNames[sampleCondition], L, color: color, origin: CGPoint(x: L.textX, y: L.textY))
        }
        if L.showRange {
            func group(_ arrow: String, _ value: Int, _ gx: Int, _ tint: UIColor) {
                if let v = L.rangeVec, let ctx = UIGraphicsGetCurrentContext() {
                    drawVecArrow(ctx, up: arrow == "↑",
                                 in: CGRect(x: gx + 1, y: L.rangeY + v.pad, width: L.arrowW - 4, height: v.glyphH), color: tint)
                    let e = drawVecNumber(ctx, String(value), v, digitW: L.rangeDigitW, lineH: L.rangeLineH,
                                          x: gx + L.arrowW, y: L.rangeY, color: color)
                    drawVecSuffix(ctx, v, color: color, x: CGFloat(e), y: CGFloat(L.rangeY))
                    return
                }
                drawLunarText(arrow, font: L.rangeFont, color: tint, in: CGRect(x: gx, y: L.rangeY, width: L.arrowW, height: L.rangeLineH))
                let e = drawNumberString(String(value), font: L.rangeFont, digitW: L.rangeDigitW, lineH: L.rangeLineH,
                                         x: gx + L.arrowW, y: L.rangeY, color: color)
                drawSuffixText("°", font: L.rangeDegFont, numFont: L.rangeFont, color: color,
                               in: CGRect(x: e, y: L.rangeY, width: L.rangeDegW, height: L.rangeLineH), sym: d.unitSymbol)
            }
            group("↑", sampleHigh, L.x, rangeHighColor)
            group("↓", sampleLow, L.loX, rangeLowColor)
        }
    }

    // MARK: Lớp HWT

    /// Lớp HWT của tất cả mục số liệu đang bật. Bộ chữ số cùng cỡ và màu được dùng chung để tiết kiệm ảnh.
    static func dataLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        var layers = [HwtLayer]()
        var cache = [String: (digits: [Int], minus: Int)]()

        func digitSet(_ font: UIFont, _ digitW: Int, _ lineH: Int, _ color: UIColor,
                      _ vec: DataVecInfo? = nil) -> (digits: [Int], minus: Int) {
            let key = "\(font.pointSize)|\(digitW)|\(lineH)|\(color)|\(vec?.key ?? "-")|\(vec?.pad ?? 0)|\(vec?.glyphH ?? 0)"
            if let c = cache[key] { return c }
            var ids = [Int]()
            for n in 0...9 {
                if let v = vec {
                    ids.append(add(vecGlyphRaster(Character(String(n)), v, w: digitW, h: lineH, color: color)))
                } else {
                    ids.append(add(glyphRaster("\(n)", w: digitW, h: lineH, font: font, color: color)))
                }
            }
            let minus = add(vec.map { vecGlyphRaster("-", $0, w: digitW, h: lineH, color: color) }
                            ?? glyphRaster("-", w: digitW, h: lineH, font: font, color: color))
            let pair = (digits: ids, minus: minus)
            cache[key] = pair
            return pair
        }

        let sym = d.unitSymbol
        func suffixImage(_ text: String, _ font: UIFont, _ numFont: UIFont, _ w: Int, _ h: Int, _ color: UIColor) -> Int {
            if text.isEmpty || w <= 0 { return 0 }
            return add(drawRaster(width: w, height: h) { _ in
                drawSuffixText(text, font: font, numFont: numFont, color: color, in: CGRect(x: 0, y: 0, width: w, height: h), sym: sym)
            })
        }

        for kind in DataKind.allCases {
            let w = d.dataWidget(kind)
            guard w.show else { continue }
            let L = dataNumberLayout(kind, w, d)
            let color = UIColor(w.color)
            let set = digitSet(L.font, L.digitW, L.lineH, color, L.vec)
            let suffix: Int
            if let v = L.vec {
                suffix = v.suffix == nil ? 0 : add(vecSuffixRaster(v, w: L.suffixW, h: L.lineH, color: color))
            } else {
                suffix = suffixImage(L.suffix, L.suffixFont, L.font, L.suffixW, L.lineH, color.withAlphaComponent(0.92))
            }
            if w.icon {
                let s = L.iconS
                let mono = w.iconMono, useSVG = d.iconSVG, bStyle = d.batteryIconStyle
                if kind == .battery, d.batteryLevelStyle > 0 {
                    // Biểu tượng pin đổi theo mức: 11 ảnh (0%, 10% ... 100%), đồng hồ chọn ảnh theo mức pin (mã 54).
                    let levelStyle = d.batteryLevelStyle
                    var levelIDs = [Int]()
                    for level in 0..<FaceBatteryLevel.levelCount {
                        levelIDs.append(add(drawRaster(width: s, height: s) { _ in
                            drawBatteryLevelIcon(style: levelStyle, level: level, in: CGRect(x: 0, y: 0, width: s, height: s),
                                                 textColor: color, mono: mono)
                        }))
                    }
                    layers.append(.array(resources: levelIDs, x: L.x, y: L.iconY, valueType: HwtValueType.batteryLevel, ambient: false))
                } else {
                    let id = add(drawRaster(width: s, height: s) { _ in
                        drawDataIcon(kind, in: CGRect(x: 0, y: 0, width: s, height: s), textColor: color, mono: mono, svg: useSVG,
                                     batteryStyle: bStyle)
                    })
                    layers.append(.single(resource: id, x: L.x, y: L.iconY, ambient: false))
                }
            }
            layers.append(.number(digits: set.digits, minus: set.minus, suffix: suffix, x: L.numX, y: L.y,
                                  align: 0, dataType: kind.dataType, ambient: false))
        }

        guard d.weather.show else { return layers }
        let L = WeatherLayout(d)
        let color = UIColor(d.weather.color)

        // Biểu tượng tình trạng (mã 53, giá trị 0...10).
        if d.weatherIcon {
            var icons = [Int]()
            let mono = d.weatherIconMono, useSVG = d.iconSVG, iconStyle = d.weatherIconStyle, paint = L.paint
            for i in 0..<weatherNames.count {
                let s = L.iconS
                icons.append(add(drawRaster(width: s, height: s) { _ in
                    drawWeatherIcon(i, in: CGRect(x: 0, y: 0, width: s, height: s), textColor: color, mono: mono, svg: useSVG,
                                    style: iconStyle, sync: paint)
                }))
            }
            layers.append(.array(resources: icons, x: L.x, y: L.iconY, valueType: HwtValueType.weatherCondition, ambient: false))
        }

        // Nhiệt kế vector cạnh nhiệt độ (ảnh tĩnh).
        if L.thermoS > 0 {
            let s = L.thermoS, style = d.thermoStyle, mono = d.weatherIconMono
            let id = add(drawRaster(width: s, height: s) { _ in
                drawThermoIcon(style, in: CGRect(x: 0, y: 0, width: s, height: s), textColor: color, mono: mono)
            })
            layers.append(.single(resource: id, x: L.thermoX, y: L.thermoY, ambient: false))
        }

        // Nhiệt độ hiện tại + "°".
        let tempSet = digitSet(L.numFont, L.digitW, L.lineH, color, L.vec)
        let deg: Int
        if let v = L.vec {
            deg = v.suffix == nil ? 0 : add(vecSuffixRaster(v, w: L.degW, h: L.lineH, color: color))
        } else {
            deg = suffixImage("°", L.degFont, L.numFont, L.degW, L.lineH, color)
        }
        layers.append(.number(digits: tempSet.digits, minus: tempSet.minus, suffix: deg, x: L.numX, y: L.numY,
                              align: 0, dataType: HwtDataType.temperature, ambient: false))

        // Tên tình trạng (cùng mã 53).
        if L.showText {
            var names = [Int]()
            for name in weatherNames {
                let w = L.textW, h = L.textH
                names.append(add(drawRaster(width: w, height: h) { _ in
                    drawWeatherName(name, L, color: color, origin: .zero)
                }))
            }
            layers.append(.array(resources: names, x: L.textX, y: L.textY, valueType: HwtValueType.weatherCondition, ambient: false))
        }

        // Nhiệt độ cao nhất / thấp nhất.
        if L.showRange {
            let rangeSet = digitSet(L.rangeFont, L.rangeDigitW, L.rangeLineH, color, L.rangeVec)
            let rangeDeg: Int
            let up: Int
            let down: Int
            if let v = L.rangeVec {
                rangeDeg = v.suffix == nil ? 0 : add(vecSuffixRaster(v, w: L.rangeDegW, h: L.rangeLineH, color: color))
                func arrow(_ isUp: Bool, _ tint: UIColor) -> Int {
                    add(drawRaster(width: L.arrowW, height: L.rangeLineH) { ctx in
                        drawVecArrow(ctx, up: isUp, in: CGRect(x: 1, y: v.pad, width: L.arrowW - 4, height: v.glyphH), color: tint)
                    })
                }
                up = arrow(true, rangeHighColor)
                down = arrow(false, rangeLowColor)
            } else {
                rangeDeg = suffixImage("°", L.rangeDegFont, L.rangeFont, L.rangeDegW, L.rangeLineH, color)
                up = add(glyphRaster("↑", w: L.arrowW, h: L.rangeLineH, font: L.rangeFont, color: rangeHighColor))
                down = add(glyphRaster("↓", w: L.arrowW, h: L.rangeLineH, font: L.rangeFont, color: rangeLowColor))
            }
            layers.append(.single(resource: up, x: L.x, y: L.rangeY, ambient: false))
            layers.append(.number(digits: rangeSet.digits, minus: rangeSet.minus, suffix: rangeDeg, x: L.x + L.arrowW, y: L.rangeY,
                                  align: 0, dataType: HwtDataType.tempHigh, ambient: false))
            layers.append(.single(resource: down, x: L.loX, y: L.rangeY, ambient: false))
            layers.append(.number(digits: rangeSet.digits, minus: rangeSet.minus, suffix: rangeDeg, x: L.loX + L.arrowW, y: L.rangeY,
                                  align: 0, dataType: HwtDataType.tempLow, ambient: false))
        }
        return layers
    }
}
