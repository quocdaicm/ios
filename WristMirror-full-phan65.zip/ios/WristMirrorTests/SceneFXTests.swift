// Unit test cho cảnh động toàn mặt (mưa neon, cực quang, thủy triều).
import XCTest
@testable import WristMirror

final class SceneFXTests: XCTestCase {
    private func design(_ kind: AnimKind) -> FaceDesign {
        var d = FaceDesign()
        d.animOn = true
        d.animKind = kind
        d.animFallFrames = 24
        d.animDensity = 0.5
        return d
    }

    func testSceneKindsAreFall() {
        for k in [AnimKind.rain, .aurora, .tide] { XCTAssertTrue(k.isFall, k.rawValue) }
    }

    /// Mỗi cảnh ra 3 dải, đủ khung, và các khung không giống hệt nhau (có chuyển động).
    func testSceneFramesAnimate() {
        for k in [AnimKind.rain, .aurora, .tide] {
            let strips = FaceRenderer.fallStrips(design(k))
            XCTAssertEqual(strips.count, FaceRenderer.fallStripCount, k.rawValue)
            for s in strips {
                XCTAssertEqual(s.frames.count, 24, k.rawValue)
                XCTAssertNotEqual(s.frames[0], s.frames[6], k.rawValue)
            }
        }
    }

    func testScenePresetsUseSceneKinds() {
        let want: [String: AnimKind] = ["hwAuroraLive": .aurora, "hwTideLive": .tide, "hwNeonRain": .rain]
        for (id, kind) in want {
            let d = FacePresets.all.first { $0.id == id }!.make()
            XCTAssertTrue(d.animOn, id)
            XCTAssertEqual(d.animKind, kind, id)
        }
    }
}
