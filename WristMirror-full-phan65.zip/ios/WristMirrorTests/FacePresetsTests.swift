// Unit test cho các mẫu mặt đồng hồ có sẵn.
import XCTest
import SwiftUI
@testable import WristMirror

final class FacePresetsTests: XCTestCase {
    func testPresetIdsAreUnique() {
        let ids = FacePresets.all.map { $0.id }
        XCTAssertEqual(Set(ids).count, ids.count)
    }

    /// Nền SVG ban ngày / AOD mà mẫu dùng phải có thật trong thư viện nền.
    func testBackdropIdsResolve() {
        for p in FacePresets.all {
            let d = p.make()
            if !d.backdrop.isEmpty {
                XCTAssertNotNil(FaceBackdrops.day.first { $0.id == d.backdrop }, "\(p.id): nền ban ngày \(d.backdrop)")
            }
            if !d.aodBackdrop.isEmpty {
                XCTAssertNotNil(FaceBackdrops.aod.first { $0.id == d.aodBackdrop }, "\(p.id): nền AOD \(d.aodBackdrop)")
            }
        }
    }

    func testAnimationSettingsInRange() {
        for p in FacePresets.all {
            let d = p.make()
            guard d.animOn else { continue }
            XCTAssertTrue([24, 32, 48].contains(d.animFallFrames), p.id)
            XCTAssertTrue((0.1...1.0).contains(d.animDensity), p.id)
        }
    }

    /// Phần 61: bộ "Chuyên nghiệp" đủ 16 mẫu, có AOD riêng và đồng bộ chữ với kiểu số chung.
    func testProPresets() {
        XCTAssertEqual(FacePresetsPro.list.count, 16)
        for p in FacePresetsPro.list {
            let d = p.make()
            XCTAssertTrue(d.weekdaySync && d.nameSync && d.weatherSync, p.id)
            XCTAssertNotEqual(d.dataStyle, .classic, p.id)
            XCTAssertFalse(d.aodBackdrop.isEmpty, p.id)
            XCTAssertNotNil(FacePresets.all.first { $0.id == p.id }, p.id)
        }
    }

    /// Phần 64: bộ "Kiểu Huawei" đủ 27 mẫu, id không trùng bộ khác, có AOD riêng, đồng bộ chữ, có chuyển động giây.
    func testHuaweiPresets() {
        XCTAssertEqual(FacePresetsHuawei.list.count, 27)
        for p in FacePresetsHuawei.list {
            let d = p.make()
            XCTAssertTrue(d.weekdaySync && d.nameSync && d.weatherSync, p.id)
            XCTAssertFalse(d.aodBackdrop.isEmpty, p.id)
            XCTAssertNotEqual(d.secondFX, .none, p.id)
            XCTAssertNil(FacePresetsPro.list.first { $0.id == p.id }, p.id)
            XCTAssertNotNil(FacePresets.all.first { $0.id == p.id }, p.id)
            XCTAssertEqual(PresetCategory.of(p), .huawei, p.id)
        }
    }
}
