// Unit test cho Phần 61: chữ kỹ thuật số (Thứ, Tên, tên thời tiết) theo kiểu số chung.
import XCTest
import SwiftUI
@testable import WristMirror

final class DigitalTextTests: XCTestCase {
    private func design(_ st: DigitalStyle) -> FaceDesign {
        var d = FaceDesign()
        d.dataStyle = st
        d.showWeekday = true
        d.showName = true
        d.nameText = "Quốc Đại"
        d.weekdaySync = true
        d.nameSync = true
        return d
    }

    /// Mọi kiểu số vector đều vẽ được chữ ra điểm ảnh (lưới chấm, 7 đoạn, nét đơn, ống neon...).
    func testAllStylesDrawTextPixels() throws {
        for st in DigitalStyle.allCases where st != .classic {
            let d = design(st)
            let dg = try XCTUnwrap(d.weekdayDigital, st.rawValue)
            let L = FaceRenderer.weekdayLayout(d)
            XCTAssertGreaterThan(L.w, 20, st.rawValue)
            XCTAssertGreaterThan(L.h, 10, st.rawValue)
            let r = FaceRenderer.drawRaster(width: L.w, height: L.h) { _ in
                DigitalText.draw("Thứ bảy", def: dg.def, own: true, font: L.font, color: .white, centered: true,
                                 in: CGRect(x: 0, y: 0, width: L.w, height: L.h))
            }
            XCTAssertGreaterThan(r.argb.filter { ($0 >> 24) != 0 }.count, 30, st.rawValue)
        }
    }

    func testSyncOffKeepsOldBehavior() {
        var d = design(.dotAmber)
        d.weekdaySync = false
        d.nameSync = false
        XCTAssertNil(d.weekdayDigital)
        XCTAssertNil(d.nameDigital)
        d.dataStyle = .classic
        d.weekdaySync = true
        XCTAssertNil(d.weekdayDigital, "Số thường thì không có chữ kỹ thuật số")
    }

    func testNameLayoutFitsFace() throws {
        for st in [DigitalStyle.dotAmber, .neonPink, .tubeBlue, .ledRed, .pixel] {
            var d = design(st)
            d.nameText = "Nguyễn Hoàng Quốc Đại Việt Nam"
            let n = try XCTUnwrap(FaceRenderer.nameLayout(d), st.rawValue)
            XCTAssertLessThanOrEqual(n.line.w, FaceRenderer.maxNameWidth, st.rawValue)
        }
    }

    func testWeatherNameSyncedUsesDigitalFont() {
        var d = FaceDesign()
        d.dataStyle = .dotAmber
        d.weatherText = true
        d.weatherSync = true
        d.weatherFX = 0
        let L = WeatherLayout(d)
        XCTAssertTrue(L.textSynced)
        XCTAssertGreaterThan(L.textW, 20)
        XCTAssertGreaterThan(L.textH, 8)
    }

    func testDesignCodecKeepsSyncFlags() throws {
        var d = FaceDesign()
        d.weekdaySync = true
        d.nameSync = true
        let data = try FaceDesignCodec.encode(d)
        let back = try XCTUnwrap(FaceDesignCodec.decode(data))
        XCTAssertTrue(back.weekdaySync)
        XCTAssertTrue(back.nameSync)
    }
}
