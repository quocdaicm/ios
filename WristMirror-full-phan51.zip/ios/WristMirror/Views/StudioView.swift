// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import PhotosUI

/// Kết quả dựng xem trước (ban ngày + AOD).
struct StudioPreview {
    let day: LiveFaceAssets
    let aod: LiveFaceAssets
}

/// Giữ ảnh xem trước ở một đối tượng riêng (không nằm trong `StudioModel`): khi ảnh dựng xong chỉ khung xem trước được
/// vẽ lại, cả trang cuộn bên dưới không bị dựng lại (dựng lại lúc đó từng làm trang nhảy ngược lên).
final class StudioPreviewBox: ObservableObject {
    @Published fileprivate(set) var result: StudioPreview?
}

/// Quan sát `StudioPreviewBox` trong phạm vi riêng của nó.
private struct PreviewObserver<Content: View>: View {
    @ObservedObject var box: StudioPreviewBox
    let content: (StudioPreview?) -> Content
    var body: some View { content(box.result) }
}

/// Trạng thái màn hình "Tạo mặt đồng hồ": giữ thiết kế, vẽ lại ảnh xem trước mỗi khi thiết kế đổi.
/// Ảnh xem trước dựng ở luồng nền (tuần tự, bỏ qua các lần dựng đã cũ), nên chạm một tuỳ chọn không làm giao diện đứng.
final class StudioModel: ObservableObject {
    @Published var design = FaceDesign.themeDefault {
        didSet { refreshPreview() }
    }
    @Published private(set) var building = false
    let preview = StudioPreviewBox()

    private static let previewPixels = 320
    private let previewQueue = DispatchQueue(label: "site.quocdai.watchface.studio-preview", qos: .userInitiated)
    private let genLock = NSLock()
    private var latestGeneration = 0

    init(design initial: FaceDesign = FaceDesign.themeDefault) {
        design = initial
        // Lần đầu dựng ngay để khung xem trước không trống.
        preview.result = StudioModel.buildPreview(initial)
    }

    private static func buildPreview(_ d: FaceDesign) -> StudioPreview {
        StudioPreview(day: LiveFaceAssets.build(design: d, ambient: false, pixels: previewPixels),
                      aod: LiveFaceAssets.build(design: d, ambient: true, pixels: previewPixels))
    }

    private func currentGeneration() -> Int {
        genLock.lock(); defer { genLock.unlock() }
        return latestGeneration
    }

    private func refreshPreview() {
        let snapshot = design
        genLock.lock()
        latestGeneration += 1
        let gen = latestGeneration
        genLock.unlock()
        previewQueue.async { [weak self] in
            // Đã có thay đổi mới hơn thì bỏ lần dựng này (gộp nhiều lần chỉnh liên tiếp, ví dụ kéo thanh trượt).
            guard let self = self, self.currentGeneration() == gen else { return }
            let result = StudioModel.buildPreview(snapshot)
            DispatchQueue.main.async { [weak self] in
                guard let self = self, self.currentGeneration() == gen else { return }
                self.preview.result = result
            }
        }
    }

    func setAodPhoto(_ image: UIImage?) {
        var d = design
        d.aodPhoto = image.map { FaceRenderer.downscale($0, maxSide: 1600) }
        d.aodPhotoZoom = 1; d.aodPhotoPanX = 0; d.aodPhotoPanY = 0
        design = d
    }

    func setPhoto(_ image: UIImage?) {
        var d = design
        d.photo = image.map { FaceRenderer.downscale($0, maxSide: 1600) }
        d.photoZoom = 1; d.photoPanX = 0; d.photoPanY = 0
        design = d
    }

    /// Dựng file .hwt ở luồng nền rồi gọi `completion` trên main.
    func export(completion: @escaping (Result<URL, Error>) -> Void) {
        guard !building else { return }
        let snapshot = design
        building = true
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let result: Result<URL, Error>
            do {
                let bytes = try FaceBuilder.build(snapshot)
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("wm-studio-\(UUID().uuidString)", isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(FaceBuilder.fileName(snapshot.name))
                try Data(bytes).write(to: url, options: .atomic)
                result = .success(url)
            } catch {
                result = .failure(error)
            }
            DispatchQueue.main.async {
                self?.building = false
                completion(result)
            }
        }
    }
}

struct StudioView: View {
    @EnvironmentObject var vm: WatchViewModel
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: StudioModel
    /// Mục thư viện đang chỉnh sửa (nil = tạo mặt mới).
    private let editing: HwtLibraryItem?
    @State private var saveAsCopy = false
    @State private var pickerItem: PhotosPickerItem?
    @State private var aodPickerItem: PhotosPickerItem?
    @State private var errorText: String?
    @State private var showFall = true
    @State private var liveClock = true
    @State private var pulse = false

    /// `editing` + `library`: mở lại thiết kế đã lưu của một mặt trong Thư viện để chỉnh sửa.
    init(editing: HwtLibraryItem? = nil, library: HwtLibrary? = nil) {
        self.editing = editing
        _model = StateObject(wrappedValue: StudioModel(design: {
            if let item = editing, let lib = library, let saved = lib.loadDesign(id: item.id) { return saved }
            return FaceDesign.themeDefault
        }()))
    }

    private var busy: Bool { vm.ui.operation.active || model.building }

    var body: some View {
        VStack(spacing: 0) {
            // Khung xem trước cố định phía trên; phần bên dưới cuộn.
            previewCard
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 8)
            ScrollView {
            VStack(spacing: 16) {
                presetCard.staggerIn(1)
                nameCard.staggerIn(2)
                backgroundCard.staggerIn(3)
                decorCard.staggerIn(4)
                animCard.staggerIn(5)
                secondFXCard.staggerIn(6)
                sharedNumeralCard.staggerIn(7)
                lunarCard.staggerIn(8)
                marksCard.staggerIn(8)
                handsCard.staggerIn(8)
                aodCard.staggerIn(8)
                saveButton.staggerIn(8)
            }
            .padding(16)
            // Chỉnh tuỳ chọn làm dựng lại nội dung có thể kéo trang về đầu; giữ nguyên chỗ người dùng đang xem.
            .background(KeepScrollPosition())
            }
        }
        .background(AppBackground())
        .navigationTitle(tr(editing == nil ? tr("Tạo mặt đồng hồ") : tr("Chỉnh sửa mặt đồng hồ")))
        .navigationBarTitleDisplayMode(.inline)
        .alert(tr("Không tạo được mặt đồng hồ"), isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button(tr("Đóng"), role: .cancel) {}
        } message: {
            Text(tr(errorText ?? ""))
        }
    }

    // MARK: Xem trước

    private var previewCard: some View {
        VStack(spacing: 12) {
            PreviewObserver(box: model.preview) { r in
                HStack(spacing: 16) {
                    previewCircle(r?.day, fallback: nil,
                                  title: showFall && !fallPatterns.isEmpty ? tr("Ban ngày (hạt rơi chỉ để xem thử)") : tr("Ban ngày"),
                                  fall: showFall ? fallPatterns : [], glow: true)
                    previewCircle(r?.aod, fallback: nil, title: tr("AOD (màn hình tắt)"))
                }
            }
            .scaleEffect(pulse ? 0.94 : 1)

            Picker(tr("Giờ xem thử"), selection: $liveClock) {
                Text(tr("Giờ thật")).tag(true)
                Text("10:08:35").tag(false)
            }
            .pickerStyle(.segmented)
        }
        .frame(maxWidth: .infinity)
        .card()
    }

    /// Nhấp nhẹ bản xem trước khi áp một mẫu mới.
    private func pulsePreview() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        withAnimation(.easeOut(duration: 0.12)) { pulse = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.55)) { pulse = false }
        }
    }

    /// Các hiệu ứng mùa có hạt rơi trong thiết kế hiện tại.
    private var fallPatterns: [DecorPattern] {
        var seen = [DecorPattern]()
        for l in model.design.decor where l.pattern.isSeasonal && !SeasonArt.fallSprites(l.pattern).isEmpty {
            if !seen.contains(l.pattern) { seen.append(l.pattern) }
        }
        return seen
    }

    private func previewCircle(_ assets: LiveFaceAssets?, fallback: UIImage?, title: String,
                               fall: [DecorPattern] = [], glow: Bool = false) -> some View {
        VStack(spacing: 6) {
            ZStack {
                if glow { GlowRing().padding(-5) }
                Circle().fill(Color.black)
                if let assets = assets {
                    LiveFaceView(assets: assets,
                                 fixed: liveClock ? nil : LiveFaceTime(hour: 10, minute: 8, second: 35))
                        .clipShape(Circle())
                } else if let image = fallback {
                    Image(uiImage: image).resizable().scaledToFit().clipShape(Circle())
                }
                if !fall.isEmpty {
                    SeasonFallView(patterns: fall).clipShape(Circle())
                }
            }
            .frame(maxWidth: 130, maxHeight: 130)
            .aspectRatio(1, contentMode: .fit)
            // Cố định chiều cao dòng tiêu đề (1 hoặc 2 dòng) để khung xem trước không đổi cao, làm trang bên dưới nhảy.
            Text(tr(title)).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                .frame(minHeight: 34, alignment: .top)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Mẫu có sẵn

    private var presetCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(tr("Mẫu có sẵn")).font(.headline)
            Text(tr("Chạm để áp dụng một mẫu vector, rồi chỉnh tiếp bên dưới. Tên và tác giả của bạn được giữ nguyên."))
                .font(.footnote).foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(FacePresets.all) { preset in
                        Button {
                            pickerItem = nil
                            pulsePreview()
                            model.design = FacePresets.apply(preset, to: model.design)
                        } label: {
                            VStack(spacing: 4) {
                                Image(uiImage: FacePresetThumbs.image(preset))
                                    .resizable()
                                    .frame(width: 72, height: 72)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                                Text(tr(preset.title)).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .card()
    }

    // MARK: Tên

    private var nameCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(tr("Tên và tác giả")).font(.headline)
            TextField(tr("Tên mặt đồng hồ"), text: $model.design.name)
                .textFieldStyle(.roundedBorder)
            TextField(tr("Tác giả (không bắt buộc)"), text: $model.design.author)
                .textFieldStyle(.roundedBorder)
        }
        .card()
    }

    // MARK: Nền

    private var backgroundCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Nền")).font(.headline)

            PhotosPicker(selection: $pickerItem, matching: .images) {
                Label(tr(model.design.photo == nil ? tr("Chọn ảnh nền") : tr("Đổi ảnh nền")), systemImage: "photo")
            }
            .buttonStyle(SecondaryButtonStyle())
            .onChange(of: pickerItem) { item in
                guard let item = item else { return }
                _ = item.loadTransferable(type: Data.self) { result in
                    DispatchQueue.main.async {
                        if case .success(let data?) = result, let img = UIImage(data: data) {
                            model.setPhoto(img)
                        } else {
                            errorText = tr("Không đọc được ảnh đã chọn.")
                        }
                    }
                }
            }

            if model.design.photo != nil {
                slider(tr("Phóng to"), value: $model.design.photoZoom, range: 1...3, low: tr("Vừa khung"), high: tr("Gần nhất"))
                slider(tr("Dịch ngang"), value: $model.design.photoPanX, range: -1...1, low: tr("Trái"), high: tr("Phải"))
                slider(tr("Dịch dọc"), value: $model.design.photoPanY, range: -1...1, low: tr("Lên"), high: tr("Xuống"))
                slider(tr("Làm tối ảnh"), value: $model.design.photoDim, range: 0...0.8, low: tr("Không"), high: tr("Tối nhất"))
                Button(role: .destructive) {
                    pickerItem = nil
                    model.setPhoto(nil)
                } label: { Label(tr("Bỏ ảnh nền"), systemImage: "xmark.circle") }
                    .buttonStyle(SecondaryButtonStyle(color: Color.red))
            } else {
                Text(tr("Nền SVG có sẵn")).font(.caption).foregroundStyle(.secondary)
                backdropRow(FaceBackdrops.day, selected: model.design.backdrop) { b in
                    if let b = b {
                        model.design.backdrop = b.id
                        model.design.useGradient = true
                        model.design.backgroundColor = b.topColor
                        model.design.backgroundColor2 = b.bottomColor
                    } else {
                        model.design.backdrop = ""
                    }
                }
                ColorPicker(tr("Màu nền"), selection: $model.design.backgroundColor, supportsOpacity: false)
                Toggle(tr("Chuyển sắc"), isOn: $model.design.useGradient)
                if model.design.useGradient {
                    ColorPicker(tr("Màu nền thứ hai"), selection: $model.design.backgroundColor2, supportsOpacity: false)
                }
            }
        }
        .card()
    }

    /// Hàng chọn nền SVG: ô đầu là "Không", các ô sau là ảnh thu nhỏ của từng nền.
    private func backdropRow(_ list: [FaceBackdrop], selected: String, pick: @escaping (FaceBackdrop?) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                Button { pick(nil) } label: {
                    VStack(spacing: 3) {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(Color.primary.opacity(0.08))
                            .frame(width: 56, height: 56)
                            .overlay(Image(systemName: "nosign").foregroundStyle(.secondary))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(selected.isEmpty ? Color.accentColor : Color.clear, lineWidth: 2.5)
                            )
                        Text(tr("Không")).font(.caption2).foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(.plain)
                ForEach(list) { b in
                    Button { pick(b) } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: BackdropThumbs.image(b))
                                .resizable()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(selected == b.id ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(b.title)).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Lớp trang trí

    private var decorCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(tr("Lớp trang trí")).font(.headline)
            Text(tr("Chọn Giờ, Phút hoặc Giây để lớp quay theo kim tương ứng; Tĩnh là đứng yên."))
                .font(.footnote).foregroundStyle(.secondary)
            if !fallPatterns.isEmpty {
                Toggle(tr("Xem thử hoa/tuyết/lá rơi trên điện thoại"), isOn: $showFall)
                Text(tr("Chỉ để xem thử: trên đồng hồ, lớp hoa/tuyết/lá không rơi mà quay theo Giờ, Phút hoặc Giây."))
                    .font(.caption2).foregroundStyle(.secondary)
            }
            ForEach($model.design.decor) { $layer in
                decorEditor($layer, number: (model.design.decor.firstIndex { $0.id == layer.id } ?? 0) + 1)
            }
            if model.design.decor.count < FaceRenderer.maxDecor {
                Button {
                    model.design.decor.append(DecorLayer())
                } label: { Label(tr("Thêm lớp trang trí"), systemImage: "plus.circle") }
                    .buttonStyle(SecondaryButtonStyle())
            }
        }
        .card()
    }

    private func decorEditor(_ layer: Binding<DecorLayer>, number: Int) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(trf("Lớp %@", number)).font(.subheadline.weight(.semibold))
            Text(tr("Họa tiết")).font(.caption).foregroundStyle(.secondary)
            decorRow(DecorPattern.geometric, layer)
            Text(tr("Hiệu ứng mùa (nhiều màu)")).font(.caption).foregroundStyle(.secondary)
            decorRow(DecorPattern.seasonal, layer)
            if !layer.wrappedValue.pattern.isSeasonal {
                ColorPicker(tr("Màu"), selection: layer.color, supportsOpacity: false)
            }
            slider(tr("Độ đậm"), value: layer.opacity, range: 0.1...1, low: tr("Mờ"), high: tr("Đậm"))
            slider(tr("Kích thước"), value: layer.scale, range: 0.2...0.95, low: tr("Nhỏ"), high: tr("Lớn"))
            Picker(tr("Chuyển động"), selection: layer.spin) {
                ForEach(DecorSpin.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Button(role: .destructive) {
                let id = layer.wrappedValue.id
                model.design.decor.removeAll { $0.id == id }
            } label: { Label(tr("Xóa lớp này"), systemImage: "trash") }
                .buttonStyle(SecondaryButtonStyle(color: Color.red))
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.primary.opacity(0.05)))
    }

    private func decorRow(_ patterns: [DecorPattern], _ layer: Binding<DecorLayer>) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(patterns) { p in
                    Button {
                        layer.wrappedValue.pattern = p
                        // Hiệu ứng mùa cần đậm để thấy màu thật
                        if p.isSeasonal && layer.wrappedValue.opacity < 0.8 { layer.wrappedValue.opacity = 0.95 }
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: DecorThumbs.image(p))
                                .resizable()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(layer.wrappedValue.pattern == p ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(p.title)).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Âm lịch

    /// "Kiểu số chung cho tất cả": đặt ngay dưới "Lớp trang trí".
    private var sharedNumeralCard: some View {
        InfoSettingsView(design: $model.design, part: .sharedStyleOnly)
    }

    private var lunarCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Thông tin trên mặt đồng hồ")).font(.headline)
            Text(tr("Các mục này do đồng hồ tự cập nhật. Xem trước dùng ngày giờ hiện tại và số liệu mẫu."))
                .font(.footnote).foregroundStyle(.secondary)
            InfoSettingsView(design: $model.design, part: .withoutSharedStyle)
        }
    }

    // MARK: Vạch giờ

    private var marksCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Vạch giờ")).font(.headline)
            Picker(tr("Kiểu"), selection: $model.design.marks) {
                ForEach(FaceDesign.Marks.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.marks == .numerals { numeralStyleGrid }
            if model.design.marks != .none,
               !(model.design.marks == .numerals && model.design.numeralStyle.hasOwnPalette && model.design.numeralOwnColors) {
                ColorPicker(tr("Màu vạch giờ"), selection: $model.design.marksColor, supportsOpacity: false)
            }
        }
        .card()
    }

    private var numeralStyleGrid: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(trf("Kiểu số: %@", tr(model.design.numeralStyle.title))).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 66), spacing: 10)], spacing: 12) {
                ForEach(NumeralStyle.allCases) { st in
                    Button {
                        model.design.numeralStyle = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: NumeralThumbs.image(st))
                                .resizable()
                                .frame(width: 62, height: 62)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(model.design.numeralStyle == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(st.title)).font(.caption2).foregroundStyle(.secondary)
                                .lineLimit(2).minimumScaleFactor(0.75).multilineTextAlignment(.center)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            if model.design.numeralStyle.hasOwnPalette {
                Toggle(tr("Dùng màu gốc của kiểu số"), isOn: $model.design.numeralOwnColors)
            }
        }
    }

    // MARK: Chuyển động theo giây

    private var secondFXCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Chuyển động theo giây")).font(.headline)
            Text(tr("Hiệu ứng đổi ảnh mỗi giây trên đồng hồ. Chỉ hiện ban ngày."))
                .font(.footnote).foregroundStyle(.secondary)
            Picker(tr("Kiểu"), selection: $model.design.secondFX) {
                ForEach(SecondFX.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.secondFX != .none {
                ColorPicker(tr("Màu hiệu ứng"), selection: $model.design.secondFXColor, supportsOpacity: false)
                Text(String(format: tr("Ảnh thô khoảng %.1f MB trên đồng hồ. Nếu tắt kim giây, app tự thêm một kim giây vô hình để đồng hồ cập nhật mỗi giây."),
                            FaceRenderer.secondFXRawMegabytes(model.design)))
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .card()
    }

    // MARK: Hoạt ảnh xoay liên tục (thử nghiệm)

    private var animCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Hoạt ảnh nền (thử nghiệm)")).font(.headline)
            Text(tr("Họa tiết xoay hoặc tuyết/lá/hoa rơi liên tục trên nền. Chưa thử trên đồng hồ thật, nên hãy cài lên một ô mặt đồng hồ dự phòng trước."))
                .font(.footnote).foregroundStyle(.secondary)
            Toggle(tr("Bật hoạt ảnh"), isOn: $model.design.animOn)
            if model.design.animOn {
                Picker(tr("Kiểu"), selection: Binding(
                    get: { model.design.animKind },
                    set: { k in
                        model.design.animKind = k
                        model.design.animInterval = k.isFall ? 90 : 50
                    })) {
                    ForEach(AnimKind.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.menu)
                Picker(tr("Kiểu lặp (thử)"), selection: $model.design.animLoopMode) {
                    Text("A").tag(0); Text("B").tag(1); Text("C").tag(2); Text("D").tag(3)
                }
                .pickerStyle(.segmented)
                Text(tr("Nếu hoạt ảnh chỉ chạy một lần rồi nghỉ vài giây, hãy thử lần lượt kiểu B, C, D."))
                    .font(.caption2).foregroundStyle(.secondary)
                if model.design.animKind.isFall {
                    slider(tr("Mật độ hạt"), value: $model.design.animDensity, range: 0.1...1, low: tr("Ít"), high: tr("Nhiều"))
                    Picker(tr("Số khung"), selection: $model.design.animFallFrames) {
                        ForEach(FaceRenderer.fallFrameChoices, id: \.self) { Text("\($0)").tag($0) }
                    }
                    .pickerStyle(.segmented)
                    slider(tr("Chu kỳ mỗi khung (nhỏ = rơi nhanh)"),
                           value: $model.design.animInterval,
                           range: Double(AnimFX.minInterval)...Double(AnimFX.maxInterval),
                           low: tr("Nhanh"), high: tr("Chậm"), step: 1, valueText: { "\(Int($0)) ms" })
                    Text(String(format: tr("Ảnh thô khoảng %.0f MB trên đồng hồ. Nhiều khung = mượt hơn nhưng nặng hơn; nếu đồng hồ báo lỗi hoặc giật, hãy giảm số khung hoặc mật độ."),
                                FaceRenderer.fallRawMegabytes(model.design)))
                        .font(.caption2).foregroundStyle(.secondary)
                } else {
                    Picker(tr("Họa tiết"), selection: $model.design.animPattern) {
                        ForEach(DecorPattern.allCases) { Text($0.title).tag($0) }
                    }
                    if !model.design.animPattern.isSeasonal {
                        ColorPicker(tr("Màu"), selection: $model.design.animColor, supportsOpacity: false)
                    }
                    slider(tr("Kích thước"), value: $model.design.animSize, range: 0.2...0.5, low: tr("Nhỏ"), high: tr("Lớn"))
                    Text(String(format: tr("Ảnh thô khoảng %.1f MB trên đồng hồ. Càng to càng dễ giật hoặc đứng hình; nên để nhỏ."),
                                FaceRenderer.animSpinRawMegabytes(model.design)))
                        .font(.caption2).foregroundStyle(.secondary)
                    slider(tr("Vị trí ngang"), value: $model.design.animX, range: 0...1, low: tr("Trái"), high: tr("Phải"))
                    slider(tr("Vị trí dọc"), value: $model.design.animY, range: 0...1, low: tr("Trên"), high: tr("Dưới"))
                    slider(tr("Chu kỳ mỗi khung (nhỏ = quay nhanh)"),
                           value: $model.design.animInterval,
                           range: Double(AnimFX.minInterval)...Double(AnimFX.maxInterval),
                           low: tr("Nhanh"), high: tr("Chậm"), step: 1, valueText: { "\(Int($0)) ms" })
                    Toggle(tr("Quay ngược chiều"), isOn: $model.design.animReverse)
                }
            }
        }
        .card()
    }

    // MARK: Kim

    private var handsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Kim").font(.headline)
            Text(trf("Kiểu kim: %@", model.design.handStyle.title)).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 66), spacing: 10)], spacing: 12) {
                ForEach(FaceDesign.HandStyle.allCases) { st in
                    Button {
                        model.design.handStyle = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: HandThumbs.image(st))
                                .resizable()
                                .frame(width: 58, height: 58)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(model.design.handStyle == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(st.title)).font(.caption2).foregroundStyle(.secondary)
                                .lineLimit(2).minimumScaleFactor(0.75).multilineTextAlignment(.center)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            if model.design.handStyle.isVector {
                Toggle(tr("Dùng màu gốc của kiểu kim"), isOn: $model.design.handOwnColors)
            }
            if !(model.design.handStyle.isVector && model.design.handOwnColors) {
                ColorPicker(tr("Kim giờ"), selection: $model.design.hourColor, supportsOpacity: false)
                ColorPicker(tr("Kim phút"), selection: $model.design.minuteColor, supportsOpacity: false)
            }
            Toggle(tr("Hiện kim giây"), isOn: $model.design.showSecond)
            if model.design.showSecond {
                ColorPicker(tr("Kim giây"), selection: $model.design.secondColor, supportsOpacity: false)
            }
            ColorPicker(tr("Núm giữa"), selection: $model.design.capColor, supportsOpacity: false)
            slider(tr("Độ dày kim"), value: $model.design.handWidth, range: 0.6...1.8, low: tr("Mảnh"), high: tr("Dày"))
            Toggle(tr("Viền tối quanh kim"), isOn: $model.design.handOutline)
        }
        .card()
    }

    // MARK: AOD

    private var aodCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("AOD (màn hình tắt)")).font(.headline)
            Text(tr("Nền đen và ít điểm sáng sẽ tiết kiệm pin hơn."))
                .font(.footnote).foregroundStyle(.secondary)
            Picker(tr("Nền AOD"), selection: $model.design.aodBackground) {
                ForEach(FaceDesign.AodBackground.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            if model.design.aodBackground == .dimmed {
                slider(tr("Độ sáng nền"), value: $model.design.aodBrightness, range: 0.05...0.6, low: tr("Tối"), high: tr("Sáng"))
            }
            if model.design.aodBackground == .custom { aodCustomControls }
            ColorPicker(tr("Màu kim AOD"), selection: $model.design.aodHandColor, supportsOpacity: false)
            Toggle(tr("Hiện vạch giờ"), isOn: $model.design.aodShowMarks)
            if model.design.aodShowMarks && model.design.marks != .none {
                ColorPicker(tr("Màu vạch giờ AOD"), selection: $model.design.aodMarksColor, supportsOpacity: false)
            }
            Toggle(tr("Hiện giờ số, thứ, ngày, số liệu, tên"), isOn: $model.design.aodShowInfo)
            if model.design.aodShowInfo {
                Text(tr("Dùng lại đúng ảnh của mặt ban ngày (cùng màu, không làm mờ riêng) nên không tốn thêm dung lượng, nhưng AOD sáng hơn và tốn pin hơn. Chưa thử trên đồng hồ thật."))
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Text(tr("AOD đồng hồ chỉ cập nhật mỗi phút nên hiệu ứng quay, hiệu ứng giây và hạt rơi không có ở AOD."))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .card()
    }

    /// Nền riêng của AOD: ảnh, màu có sẵn hoặc tự chọn.
    private var aodCustomControls: some View {
        VStack(alignment: .leading, spacing: 12) {
            PhotosPicker(selection: $aodPickerItem, matching: .images) {
                Label(tr(model.design.aodPhoto == nil ? tr("Chọn ảnh nền AOD") : tr("Đổi ảnh nền AOD")), systemImage: "photo")
            }
            .buttonStyle(SecondaryButtonStyle())
            .onChange(of: aodPickerItem) { item in
                guard let item = item else { return }
                _ = item.loadTransferable(type: Data.self) { result in
                    DispatchQueue.main.async {
                        if case .success(let data?) = result, let img = UIImage(data: data) {
                            model.setAodPhoto(img)
                        } else {
                            errorText = tr("Không đọc được ảnh đã chọn.")
                        }
                    }
                }
            }
            if model.design.aodPhoto != nil {
                slider(tr("Phóng to"), value: $model.design.aodPhotoZoom, range: 1...3, low: tr("Vừa khung"), high: tr("Gần nhất"))
                slider(tr("Dịch ngang"), value: $model.design.aodPhotoPanX, range: -1...1, low: tr("Trái"), high: tr("Phải"))
                slider(tr("Dịch dọc"), value: $model.design.aodPhotoPanY, range: -1...1, low: tr("Lên"), high: tr("Xuống"))
                slider(tr("Làm tối ảnh (nên tối để tiết kiệm pin)"), value: $model.design.aodPhotoDim, range: 0...0.9, low: tr("Không"), high: tr("Tối nhất"))
                Button(role: .destructive) {
                    aodPickerItem = nil
                    model.setAodPhoto(nil)
                } label: { Label(tr("Bỏ ảnh nền AOD"), systemImage: "xmark.circle") }
                    .buttonStyle(SecondaryButtonStyle(color: Color.red))
            } else {
                Text(tr("Nền SVG nét mảnh (tiết kiệm pin)")).font(.caption).foregroundStyle(.secondary)
                backdropRow(FaceBackdrops.aod, selected: model.design.aodBackdrop) { b in
                    if let b = b {
                        model.design.aodBackdrop = b.id
                        model.design.aodUseGradient = true
                        model.design.aodColor = b.topColor
                        model.design.aodColor2 = b.bottomColor
                    } else {
                        model.design.aodBackdrop = ""
                    }
                }
                Text(tr("Nền có sẵn")).font(.caption).foregroundStyle(.secondary)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(FaceDesign.aodPalettes) { p in
                            Button {
                                model.design.aodUseGradient = true
                                model.design.aodColor = p.top
                                model.design.aodColor2 = p.bottom
                            } label: {
                                VStack(spacing: 3) {
                                    Circle()
                                        .fill(LinearGradient(colors: [p.top, p.bottom], startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 48, height: 48)
                                        .overlay(Circle().stroke(Color.primary.opacity(0.2), lineWidth: 1))
                                    Text(tr(p.title)).font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                ColorPicker(tr("Màu nền"), selection: $model.design.aodColor, supportsOpacity: false)
                Toggle(tr("Chuyển sắc"), isOn: $model.design.aodUseGradient)
                if model.design.aodUseGradient {
                    ColorPicker(tr("Màu nền thứ hai"), selection: $model.design.aodColor2, supportsOpacity: false)
                }
            }
            Toggle(tr("Hiện lớp trang trí tĩnh (không quay)"), isOn: $model.design.aodShowDecor)
        }
    }

    // MARK: Lưu

    private var saveButton: some View {
        VStack(spacing: 8) {
            Button {
                model.export { result in
                    switch result {
                    case .success(let url):
                        let design = model.design
                        let library = vm.library
                        // Ghi đè mặt đang sửa (giữ id nên lịch nhắc vẫn đúng) trừ khi chọn "Lưu thành bản mới".
                        let replaceId = saveAsCopy ? nil : editing?.id
                        vm.importHwt(url, displayName: url.lastPathComponent, onLibrary: { item, isNew in
                            library.saveDesign(id: item.id, design: design)
                            if let old = replaceId, isNew { library.absorb(newId: item.id, into: old) }
                        })
                        dismiss()
                    case .failure(let error):
                        errorText = trf("Mã lỗi: %@", WMCore.code(error))
                    }
                }
            } label: {
                if model.building {
                    HStack(spacing: 8) { ProgressView(); Text(tr("Đang tạo file HWT")) }
                } else {
                    if editing == nil {
                        Label(tr("Tạo và thêm vào thư viện"), systemImage: "wand.and.stars")
                    } else {
                        Label(tr(saveAsCopy ? tr("Lưu thành bản mới") : tr("Lưu thay đổi")), systemImage: "checkmark.circle")
                    }
                }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)
            if editing != nil {
                Toggle(tr("Lưu thành bản mới (giữ nguyên bản cũ)"), isOn: $saveAsCopy)
                    .font(.footnote)
            }
            Text(editing == nil
                 ? tr("File được lưu vào Thư viện cùng thiết kế; sau này bạn có thể mở lại để chỉnh sửa, hoặc gửi lên đồng hồ như mọi file HWT khác.")
                 : tr("Sau khi lưu, nhớ gửi lại file lên đồng hồ để thấy thay đổi."))
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
    }

    /// Thanh kéo có số % và mốc hai đầu; `low`/`high` là chữ mốc (Trái/Phải, Nhỏ/Lớn…).
    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>,
                        low: String? = nil, high: String? = nil,
                        step: Double = 0.01, valueText: ((Double) -> String)? = nil) -> some View {
        PercentSlider(title: title, value: value, range: range, lowLabel: low, highLabel: high,
                      step: step, valueText: valueText)
    }
}
