// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Phần 36: ký hiệu "%" và "°" vẽ bằng vector (7 kiểu), 8 biểu tượng pin và 6 biểu tượng nhiệt kế vector mới.
// Ký hiệu là path dựng bằng code (không cần font) nên dùng được cho cả số thường lẫn 48 kiểu số vector; biểu tượng là SVG nhỏ
// đúng tập con của `MiniSVG` (path M L C Q Z, circle, ellipse, rect).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Ký hiệu % và ° vector

enum UnitSymbols {
    /// 0 = chữ theo font như cũ; 1... = ký hiệu vector.
    static let titles = ["Theo font", "Tròn", "Mảnh", "Đậm", "Vuông", "Thoi", "Chấm đặc", "Đôi"]

    private enum Kind { case round, square, diamond, dot, double }

    private struct Spec {
        let kind: Kind
        /// Độ dày nét vòng, bán kính ngoài (đơn vị: cỡ chữ 100), độ dày và kiểu đầu nét của dấu gạch chéo.
        let t: CGFloat
        let r: CGFloat
        let slash: CGFloat
        let cap: CGLineCap
    }

    private static let specs: [Spec] = [
        Spec(kind: .round, t: 8, r: 17, slash: 7, cap: .round),
        Spec(kind: .round, t: 4.5, r: 17.5, slash: 4.5, cap: .round),
        Spec(kind: .round, t: 12, r: 18, slash: 10, cap: .round),
        Spec(kind: .square, t: 8, r: 16, slash: 7, cap: .butt),
        Spec(kind: .diamond, t: 8, r: 21, slash: 7, cap: .butt),
        Spec(kind: .dot, t: 0, r: 15, slash: 7, cap: .round),
        Spec(kind: .double, t: 5, r: 18, slash: 6, cap: .round)
    ]

    private static var cache = [String: DateLabelShape]()
    private static let lock = NSLock()

    /// Khung dành cho dấu "%" (đơn vị chữ cỡ 100).
    private static let pctW: CGFloat = 84
    private static let pctH: CGFloat = 72

    /// Ký hiệu vector của chuỗi `text` (đã cắt khoảng trắng): chỉ "%" và "°"; nil nếu `style` = 0 hoặc là chuỗi khác.
    static func shape(_ text: String, style: Int) -> DateLabelShape? {
        guard style > 0, style <= specs.count else { return nil }
        let t = text.trimmingCharacters(in: .whitespaces)
        guard t == "%" || t == "°" else { return nil }
        let key = "\(style)|\(t)"
        lock.lock()
        defer { lock.unlock() }
        if let c = cache[key] { return c }
        let spec = specs[style - 1]
        let raw = CGMutablePath()
        if t == "°" {
            raw.addPath(ring(.zero, spec))
        } else {
            let tl = CGPoint(x: -pctW / 2 + spec.r, y: -pctH / 2 + spec.r)
            let br = CGPoint(x: pctW / 2 - spec.r, y: pctH / 2 - spec.r)
            raw.addPath(ring(tl, spec))
            raw.addPath(ring(br, spec))
            let line = CGMutablePath()
            line.move(to: CGPoint(x: -pctW / 2 + 8, y: pctH / 2))
            line.addLine(to: CGPoint(x: pctW / 2 - 8, y: -pctH / 2))
            raw.addPath(line.copy(strokingWithWidth: spec.slash, lineCap: spec.cap, lineJoin: .round, miterLimit: 10))
        }
        let b = raw.boundingBox
        var shift = CGAffineTransform(translationX: -b.midX, y: -b.midY)
        let path = raw.copy(using: &shift) ?? raw
        let s = DateLabelShape(path: path, w: b.width, h: b.height)
        cache[key] = s
        return s
    }

    /// Một vòng/ô đặc (vùng đã tô được bằng nonzero) tâm `c`.
    private static func ring(_ c: CGPoint, _ s: Spec) -> CGPath {
        let out = CGMutablePath()
        switch s.kind {
        case .round:
            out.addPath(strokedRing(c, s.r - s.t / 2, s.t))
        case .square:
            let h = s.r - s.t / 2
            let p = CGPath(roundedRect: CGRect(x: c.x - h, y: c.y - h, width: 2 * h, height: 2 * h),
                           cornerWidth: 4, cornerHeight: 4, transform: nil)
            out.addPath(p.copy(strokingWithWidth: s.t, lineCap: .butt, lineJoin: .round, miterLimit: 10))
        case .diamond:
            let h = s.r - s.t * 0.707
            let p = CGMutablePath()
            p.move(to: CGPoint(x: c.x, y: c.y - h))
            p.addLine(to: CGPoint(x: c.x + h, y: c.y))
            p.addLine(to: CGPoint(x: c.x, y: c.y + h))
            p.addLine(to: CGPoint(x: c.x - h, y: c.y))
            p.closeSubpath()
            out.addPath(p.copy(strokingWithWidth: s.t, lineCap: .butt, lineJoin: .miter, miterLimit: 10))
        case .dot:
            out.addEllipse(in: CGRect(x: c.x - s.r, y: c.y - s.r, width: 2 * s.r, height: 2 * s.r))
        case .double:
            out.addPath(strokedRing(c, s.r - s.t / 2, s.t))
            let inner = s.r - s.t - 5
            out.addEllipse(in: CGRect(x: c.x - inner, y: c.y - inner, width: 2 * inner, height: 2 * inner))
        }
        return out
    }

    private static func strokedRing(_ c: CGPoint, _ r: CGFloat, _ t: CGFloat) -> CGPath {
        CGPath(ellipseIn: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r), transform: nil)
            .copy(strokingWithWidth: t, lineCap: .butt, lineJoin: .round, miterLimit: 10)
    }

    /// Vẽ ký hiệu một màu thay cho chữ "%" / "°" của font (chế độ số thường). Căn như `drawSuffixText`:
    /// "%" nằm trên đường cơ sở của số, "°" căn mép trên của số. `rect` là ô đơn vị (cao bằng ô số).
    static func drawFlat(_ text: String, style: Int, font: UIFont, numFont: UIFont, color: UIColor, in rect: CGRect) {
        guard let s = shape(text, style: style), let ctx = UIGraphicsGetCurrentContext() else { return }
        let k = font.pointSize / 100
        let numTop = (rect.height - numFont.lineHeight) / 2
        let baseline = rect.minY + numTop + numFont.ascender
        let digitTop = baseline - numFont.capHeight
        let isDeg = text.trimmingCharacters(in: .whitespaces) == "°"
        let cy = isDeg ? digitTop + s.h * k / 2 + 1 : baseline - s.h * k / 2
        let cx = rect.minX + 1 + s.w * k / 2
        ctx.saveGState()
        ctx.translateBy(x: cx, y: cy)
        ctx.scaleBy(x: k, y: k)
        ctx.addPath(s.path)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()
        ctx.restoreGState()
    }
}

/// Hình dạng chữ/ký hiệu: path (tâm ở gốc, y hướng xuống) và hộp bao. Cùng cấu trúc với `DateLabelShapes.Shape`.
typealias DateLabelShape = DateLabelShapes.Shape

// MARK: - Biểu tượng pin và nhiệt kế vector (viewBox 100 x 100)

enum FaceSVGIcons {
    static let batteryTitles = ["Pin dọc sét", "Pin 4 vạch", "Pin mờ sét", "Viên thuốc", "Vòng sét", "Phích sạc", "Viền kép", "Pin lá"]
    /// Màu trong SVG: accent (màu chính), currentColor (nét phụ).
    static let battery: [String] = [
        ##"<rect x="27" y="14" width="46" height="80" rx="10" fill="none" stroke="accent" stroke-width="7"/><rect x="40" y="4" width="20" height="9" rx="3" fill="accent"/><path d="M54 30 L38 56 L48 56 L44 80 L62 50 L51 50 Z" fill="accent"/>"##,
        ##"<rect x="5" y="28" width="82" height="44" rx="9" fill="none" stroke="accent" stroke-width="6"/><rect x="91" y="42" width="6" height="16" rx="3" fill="accent"/><rect x="14" y="37" width="14" height="26" rx="3" fill="accent"/><rect x="31" y="37" width="14" height="26" rx="3" fill="accent"/><rect x="48" y="37" width="14" height="26" rx="3" fill="accent"/><rect x="65" y="37" width="14" height="26" rx="3" fill="accent"/>"##,
        ##"<rect x="27" y="14" width="46" height="80" rx="10" fill="accent" opacity="0.28" stroke="accent" stroke-width="6"/><rect x="40" y="4" width="20" height="9" rx="3" fill="accent"/><path d="M54 28 L36 57 L48 57 L44 82 L64 49 L51 49 Z" fill="accent"/>"##,
        ##"<rect x="4" y="30" width="84" height="40" rx="20" fill="none" stroke="accent" stroke-width="6"/><rect x="13" y="39" width="66" height="22" rx="11" fill="accent"/><rect x="91" y="43" width="6" height="14" rx="3" fill="accent"/>"##,
        ##"<circle cx="50" cy="50" r="40" fill="none" stroke="accent" stroke-width="8"/><path d="M56 22 L34 54 L48 54 L43 78 L68 44 L53 44 Z" fill="accent"/>"##,
        ##"<rect x="22" y="26" width="56" height="68" rx="10" fill="none" stroke="accent" stroke-width="7"/><rect x="34" y="4" width="9" height="20" rx="3" fill="accent"/><rect x="57" y="4" width="9" height="20" rx="3" fill="accent"/><path d="M53 42 L38 64 L48 64 L45 82 L63 58 L52 58 Z" fill="accent"/>"##,
        ##"<rect x="4" y="26" width="84" height="48" rx="12" fill="none" stroke="accent" stroke-width="3.5"/><rect x="11" y="33" width="70" height="34" rx="7" fill="accent"/><rect x="91" y="41" width="6" height="18" rx="3" fill="accent"/>"##,
        ##"<rect x="22" y="12" width="56" height="82" rx="11" fill="none" stroke="accent" stroke-width="7"/><rect x="40" y="3" width="20" height="8" rx="3" fill="accent"/><path d="M50 80 Q30 66 34 38 Q58 40 68 58 Q66 72 50 80 Z" fill="accent"/>"##
    ]

    static let thermoTitles = ["Cổ điển", "Đặc", "Vạch chia", "Có độ", "Nóng - lạnh", "Đồng hồ đo"]
    /// Màu trong SVG: currentColor (ống), accent (thuỷ ngân nóng), cold (thuỷ ngân lạnh).
    static let thermo: [String] = [
        ##"<rect x="38" y="6" width="24" height="72" rx="12" fill="none" stroke="currentColor" stroke-width="6"/><circle cx="50" cy="78" r="17" fill="accent"/><rect x="45.5" y="30" width="9" height="46" rx="4.5" fill="accent"/>"##,
        ##"<rect x="38" y="6" width="24" height="68" rx="12" fill="accent"/><circle cx="50" cy="78" r="18" fill="accent"/><rect x="46" y="22" width="8" height="52" rx="4" fill="#000" opacity="0.4"/><circle cx="50" cy="78" r="9" fill="#000" opacity="0.4"/>"##,
        ##"<rect x="30" y="6" width="24" height="72" rx="12" fill="none" stroke="currentColor" stroke-width="6"/><circle cx="42" cy="78" r="17" fill="accent"/><rect x="37.5" y="30" width="9" height="46" rx="4.5" fill="accent"/><rect x="62" y="14" width="16" height="4" rx="2" fill="currentColor"/><rect x="62" y="26" width="10" height="4" rx="2" fill="currentColor"/><rect x="62" y="38" width="16" height="4" rx="2" fill="currentColor"/><rect x="62" y="50" width="10" height="4" rx="2" fill="currentColor"/>"##,
        ##"<rect x="22" y="6" width="24" height="72" rx="12" fill="none" stroke="currentColor" stroke-width="6"/><circle cx="34" cy="78" r="17" fill="accent"/><rect x="29.5" y="30" width="9" height="46" rx="4.5" fill="accent"/><circle cx="72" cy="22" r="10" fill="none" stroke="accent" stroke-width="5"/>"##,
        ##"<rect x="13" y="6" width="22" height="70" rx="11" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="24" cy="78" r="15" fill="accent"/><rect x="20" y="20" width="8" height="56" rx="4" fill="accent"/><rect x="63" y="6" width="22" height="70" rx="11" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="74" cy="78" r="15" fill="cold"/><rect x="70" y="46" width="8" height="30" rx="4" fill="cold"/>"##,
        ##"<circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" stroke-width="6"/><rect x="47" y="14" width="6" height="10" rx="3" fill="currentColor"/><rect x="14" y="47" width="10" height="6" rx="3" fill="currentColor"/><rect x="76" y="47" width="10" height="6" rx="3" fill="currentColor"/><path d="M50 52 L68 30" fill="none" stroke="accent" stroke-width="6"/><circle cx="50" cy="52" r="8" fill="accent"/>"##
    ]

    static func batteryPalette(accent: UIColor, mono: Bool, text: UIColor) -> [String: UIColor] {
        ["accent": accent, "currentColor": mono ? text : .white]
    }

    static func thermoPalette(mono: UIColor?) -> [String: UIColor] {
        if let m = mono { return ["currentColor": m, "accent": m, "cold": m] }
        return ["currentColor": UIColor(white: 0.95, alpha: 1),
                "accent": UIColor(red: 1.0, green: 0.36, blue: 0.30, alpha: 1),
                "cold": UIColor(red: 0.35, green: 0.78, blue: 1.0, alpha: 1)]
    }
}

extension FaceRenderer {
    /// Biểu tượng pin vector mới (kiểu 1...8). Màu chính theo màu riêng của pin hoặc màu chữ khi `mono`.
    static func drawBatteryIconStyle(_ style: Int, in rect: CGRect, textColor: UIColor, mono: Bool) {
        guard style >= 1, style <= FaceSVGIcons.battery.count else { return }
        let accent = mono ? textColor : DataKind.battery.iconSymbol.color
        MiniSVG.draw(FaceSVGIcons.battery[style - 1], box: CGSize(width: 100, height: 100), in: rect,
                     palette: FaceSVGIcons.batteryPalette(accent: accent, mono: mono, text: textColor))
    }

    /// Biểu tượng nhiệt kế vector (kiểu 1...6).
    static func drawThermoIcon(_ style: Int, in rect: CGRect, textColor: UIColor, mono: Bool) {
        guard style >= 1, style <= FaceSVGIcons.thermo.count else { return }
        MiniSVG.draw(FaceSVGIcons.thermo[style - 1], box: CGSize(width: 100, height: 100), in: rect,
                     palette: FaceSVGIcons.thermoPalette(mono: mono ? textColor : nil))
    }
}

// MARK: - Hình thu nhỏ trong bộ chọn

enum UnitIconThumbs {
    private static var cache = [String: UIImage]()
    private static let lock = NSLock()

    private static func render(_ key: String, size: CGSize, _ draw: (CGContext) -> Void) -> UIImage {
        lock.lock()
        if let c = cache[key] { lock.unlock(); return c }
        lock.unlock()
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(origin: .zero, size: size))
            draw(c.cgContext)
        }
        lock.lock()
        cache[key] = img
        lock.unlock()
        return img
    }

    static let symbolSize = CGSize(width: 240, height: 84)
    static let iconSize = CGSize(width: 84, height: 84)

    /// Hình "86%  18°" theo kiểu ký hiệu `style` (0 = font).
    static func symbol(_ style: Int) -> UIImage {
        render("sym\(style)", size: symbolSize) { ctx in
            UIGraphicsPushContext(ctx)
            let numFont = UIFont.monospacedDigitSystemFont(ofSize: 40, weight: .bold)
            let unitFont = UIFont.systemFont(ofSize: 24, weight: .bold)
            let attrs: [NSAttributedString.Key: Any] = [.font: numFont, .foregroundColor: UIColor.white]
            let uattrs: [NSAttributedString.Key: Any] = [.font: unitFont, .foregroundColor: UIColor.white]
            let top = (symbolSize.height - numFont.lineHeight) / 2
            var x: CGFloat = 20
            for (num, unit) in [("86", "%"), ("18", "°")] {
                let w = (num as NSString).size(withAttributes: attrs).width
                (num as NSString).draw(at: CGPoint(x: x, y: top), withAttributes: attrs)
                let rect = CGRect(x: x + w, y: top, width: 40, height: numFont.lineHeight)
                if style > 0 {
                    UnitSymbols.drawFlat(unit, style: style, font: unitFont, numFont: numFont, color: .white, in: rect)
                } else {
                    let baseline = top + numFont.ascender
                    (unit as NSString).draw(at: CGPoint(x: rect.minX + 1, y: baseline - unitFont.ascender), withAttributes: uattrs)
                }
                x += w + 62
            }
            UIGraphicsPopContext()
        }
    }

    static func battery(_ style: Int) -> UIImage {
        render("bat\(style)", size: iconSize) { ctx in
            UIGraphicsPushContext(ctx)
            let r = CGRect(x: 10, y: 10, width: 64, height: 64)
            if style == 0 {
                FaceRenderer.drawDataIcon(.battery, in: r, textColor: .white, mono: false, svg: true)
            } else {
                FaceRenderer.drawBatteryIconStyle(style, in: r, textColor: .white, mono: false)
            }
            UIGraphicsPopContext()
        }
    }

    /// Pin đổi theo mức (Phần 37): 0 = "Không" (vòng tròn gạch chéo), 1...6 = kiểu, vẽ ở mức 7 (khoảng 70%).
    static func batteryLevel(_ style: Int) -> UIImage {
        render("lvl\(style)", size: iconSize) { ctx in
            UIGraphicsPushContext(ctx)
            let r = CGRect(x: 10, y: 10, width: 64, height: 64)
            if style == 0 {
                ctx.setStrokeColor(UIColor(white: 0.6, alpha: 1).cgColor)
                ctx.setLineWidth(4)
                ctx.strokeEllipse(in: r.insetBy(dx: 12, dy: 12))
                ctx.move(to: CGPoint(x: r.minX + 18, y: r.maxY - 18))
                ctx.addLine(to: CGPoint(x: r.maxX - 18, y: r.minY + 18))
                ctx.strokePath()
            } else {
                FaceRenderer.drawBatteryLevelIcon(style: style, level: 7, in: r, textColor: .white, mono: false)
            }
            UIGraphicsPopContext()
        }
    }

    /// Hình mẫu bộ biểu tượng thời tiết (Phần 39): nắng, ít mây, mưa, trời quang. `style` 0 = bộ cũ.
    static func weather(_ style: Int) -> UIImage {
        render("wx\(style)", size: symbolSize) { ctx in
            UIGraphicsPushContext(ctx)
            let s: CGFloat = 48
            let gap: CGFloat = 12
            let x0 = (symbolSize.width - (s * 4 + gap * 3)) / 2
            let y0 = (symbolSize.height - s) / 2
            for (n, cond) in [1, 3, 5, 2].enumerated() {
                let r = CGRect(x: x0 + CGFloat(n) * (s + gap), y: y0, width: s, height: s)
                FaceRenderer.drawWeatherIcon(cond, in: r, textColor: .white, mono: false, svg: true, style: style)
            }
            UIGraphicsPopContext()
        }
    }

    static func thermo(_ style: Int) -> UIImage {
        render("thm\(style)", size: iconSize) { ctx in
            UIGraphicsPushContext(ctx)
            let r = CGRect(x: 10, y: 10, width: 64, height: 64)
            if style == 0 {
                // "Không": vòng tròn gạch chéo.
                ctx.setStrokeColor(UIColor(white: 0.6, alpha: 1).cgColor)
                ctx.setLineWidth(4)
                ctx.strokeEllipse(in: r.insetBy(dx: 12, dy: 12))
                ctx.move(to: CGPoint(x: r.minX + 18, y: r.maxY - 18))
                ctx.addLine(to: CGPoint(x: r.maxX - 18, y: r.minY + 18))
                ctx.strokePath()
            } else {
                FaceRenderer.drawThermoIcon(style, in: r, textColor: .white, mono: false)
            }
            UIGraphicsPopContext()
        }
    }
}
