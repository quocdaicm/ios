// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Giữ vị trí cuộn của `ScrollView` chứa nó: nếu không phải do người dùng kéo mà vị trí bỗng nhảy một mạch về đầu trang
/// (ví dụ khi nội dung bị dựng lại lúc chỉnh tuỳ chọn), đưa lại về chỗ người dùng đang xem.
/// Dùng: `.background(KeepScrollPosition())` trên nội dung bên trong `ScrollView`.
struct KeepScrollPosition: UIViewRepresentable {
    func makeUIView(context: Context) -> Probe {
        let v = Probe()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        return v
    }

    func updateUIView(_ uiView: Probe, context: Context) {}

    final class Probe: UIView {
        private weak var scroll: UIScrollView?
        private var offsetObs: NSKeyValueObservation?
        private var sizeObs: NSKeyValueObservation?
        /// Vị trí người dùng đang xem (cập nhật khi họ kéo).
        private var wanted: CGFloat = 0
        private var lastY: CGFloat = 0
        private var pending = false
        private var restoring = false

        override func didMoveToWindow() {
            super.didMoveToWindow()
            guard window != nil, scroll == nil else { return }
            var v: UIView? = superview
            while let s = v, !(s is UIScrollView) { v = s.superview }
            guard let sv = v as? UIScrollView else { return }
            scroll = sv
            lastY = sv.contentOffset.y
            wanted = lastY
            offsetObs = sv.observe(\.contentOffset, options: [.new]) { [weak self] s, _ in self?.offsetChanged(s) }
            sizeObs = sv.observe(\.contentSize, options: [.new]) { [weak self] s, _ in self?.sizeChanged(s) }
        }

        private func userDriven(_ s: UIScrollView) -> Bool { s.isTracking || s.isDragging || s.isDecelerating }

        private func offsetChanged(_ s: UIScrollView) {
            if restoring { return }
            let y = s.contentOffset.y
            let prev = lastY
            lastY = y
            if userDriven(s) {
                wanted = y
                pending = false
                return
            }
            let top = -s.adjustedContentInset.top
            // Nhảy một mạch về đầu trang mà không do người dùng kéo.
            if prev > top + 120, y <= top + 1, prev - y > 120 {
                wanted = prev
                pending = true
                DispatchQueue.main.async { [weak self, weak s] in
                    if let s = s { self?.restore(s) }
                }
            }
        }

        private func sizeChanged(_ s: UIScrollView) {
            guard pending, !restoring, !userDriven(s) else { return }
            DispatchQueue.main.async { [weak self, weak s] in
                if let s = s { self?.restore(s) }
            }
        }

        private func restore(_ s: UIScrollView) {
            guard pending, !userDriven(s) else { return }
            let top = -s.adjustedContentInset.top
            let maxY = max(top, s.contentSize.height - s.bounds.height + s.adjustedContentInset.bottom)
            let target = min(wanted, maxY)
            restoring = true
            s.setContentOffset(CGPoint(x: s.contentOffset.x, y: target), animated: false)
            restoring = false
            lastY = s.contentOffset.y
            // Nội dung đang co lại tạm thời thì còn chờ lần đổi kích thước sau.
            if target >= wanted - 0.5 { pending = false }
        }
    }
}
