// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Thứ trong tuần, giờ số, tên hiển thị + gom các mục thông tin

/// Bố cục một dòng chữ đơn (thứ, tên).
struct TextLineLayout {
    let font: UIFont
    let w: Int
    let h: Int
    let x: Int
    let y: Int
}

/// Bố cục giờ số `HH:MM`: `[chục giờ][giờ] : [chục phút][phút]`.
struct DigitalLayout {
    let font: UIFont
    let digitW: Int
    let colonW: Int
    let lineH: Int
    let x0: Int
    let y: Int
    /// Kiểu số vector (`.classic` = vẽ bằng `font`) và lề quanh hình số (điểm ảnh).
    var style: DigitalStyle = .classic
    var pad = 0
    var hourTensX: Int { x0 }
    var hourOnesX: Int { x0 + digitW }
    var colonX: Int { x0 + digitW * 2 }
    var minTensX: Int { x0 + digitW * 2 + colonW }
    var minOnesX: Int { x0 + digitW * 3 + colonW }
}

extension FaceRenderer {
    static var weekdayNames: [String] { ["Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy", "Chủ nhật"].map { tr($0) } }
    static var nameStyleTitles: [String] { ["Đậm", "Mảnh", "Nghiêng"].map { tr($0) } }
    static let maxNameChars = 24
    static let maxNameWidth = 440

    private static func clampUnit(_ v: Double) -> CGFloat { CGFloat(min(0.9, max(0.1, v))) }

    private static func textWidth(_ t: String, _ f: UIFont) -> Int {
        Int(ceil((t as NSString).size(withAttributes: [.font: f]).width)) + 2
    }

    // MARK: Thứ

    static func weekdayLayout(_ d: FaceDesign) -> TextLineLayout {
        let k = CGFloat(min(1.8, max(0.6, d.weekdaySize)))
        let font = d.textFace("weekday").text(28 * k, .bold)
        let w = min(Int(size), weekdayNames.map { textWidth($0, font) }.max() ?? 100)
        let h = Int(ceil(font.lineHeight)) + 2
        let x = max(0, min(Int(size) - w, Int(size * clampUnit(d.weekdayX)) - w / 2))
        let y = max(0, min(Int(size) - h, Int(size * clampUnit(d.weekdayY)) - h / 2))
        return TextLineLayout(font: font, w: w, h: h, x: x, y: y)
    }

    /// Thứ hôm nay: 0 = thứ hai ... 6 = chủ nhật (chỉ để xem trước).
    static func weekdayToday() -> Int {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh") ?? TimeZone.current
        let w = cal.component(.weekday, from: Date()) // 1 = chủ nhật
        return (w + 5) % 7
    }

    static func drawWeekdayPreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showWeekday else { return }
        let L = weekdayLayout(d)
        UIGraphicsPushContext(ctx)
        drawLunarText(weekdayNames[weekdayToday()], font: L.font, color: UIColor(d.weekdayColor),
                      in: CGRect(x: L.x, y: L.y, width: L.w, height: L.h))
        UIGraphicsPopContext()
    }

    /// Dãy 8 ảnh theo mã 52: mục 0 là mục đệm (lặp "Thứ hai"), mục 1...7 = thứ hai ... chủ nhật (như file thật).
    static func weekdayLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        let L = weekdayLayout(d)
        let color = UIColor(d.weekdayColor)
        let ids = weekdayNames.map { add(glyphRaster($0, w: L.w, h: L.h, font: L.font, color: color)) }
        return [.array(resources: [ids[0]] + ids, x: L.x, y: L.y, valueType: HwtValueType.weekday, ambient: false)]
    }

    // MARK: Giờ số

    static func digitalLayout(_ d: FaceDesign) -> DigitalLayout {
        let k = CGFloat(min(1.8, max(0.6, d.digitalSize)))
        if d.digitalStyle != .classic, let def = d.digitalStyle.def {
            let c = DigitalShapes.cells(def, scale: k)
            let total = c.digitW * 4 + c.colonW
            let x0 = max(0, min(Int(size) - total, Int(size * clampUnit(d.digitalX)) - total / 2))
            let y = max(0, min(Int(size) - c.lineH, Int(size * clampUnit(d.digitalY)) - c.lineH / 2))
            return DigitalLayout(font: d.numberFace("digital").number(44 * k, .bold), digitW: c.digitW, colonW: c.colonW,
                                 lineH: c.lineH, x0: x0, y: y, style: d.digitalStyle, pad: c.pad)
        }
        let font = d.numberFace("digital").number(44 * k, .bold)
        let digitW = FaceFont.digitCell(font)
        let colonW = textWidth(":", font)
        let lineH = Int(ceil(font.lineHeight)) + 2
        let total = digitW * 4 + colonW
        let x0 = max(0, min(Int(size) - total, Int(size * clampUnit(d.digitalX)) - total / 2))
        let y = max(0, min(Int(size) - lineH, Int(size * clampUnit(d.digitalY)) - lineH / 2))
        return DigitalLayout(font: font, digitW: digitW, colonW: colonW, lineH: lineH, x0: x0, y: y)
    }

    static func drawDigitalPreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showDigital else { return }
        let L = digitalLayout(d)
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh") ?? TimeZone.current
        let c = cal.dateComponents([.hour, .minute], from: Date())
        let h = c.hour ?? 0, m = c.minute ?? 0
        let color = UIColor(d.digitalColor)
        if L.style != .classic, let def = L.style.def {
            func vec(_ ch: Character, _ x: Int, _ w: Int) {
                DigitalShapes.draw(ctx, def: def, char: ch, in: CGRect(x: x, y: L.y, width: w, height: L.lineH),
                                   pad: CGFloat(L.pad), color: color, own: d.digitalOwnColors)
            }
            vec(Character(String(h / 10)), L.hourTensX, L.digitW)
            vec(Character(String(h % 10)), L.hourOnesX, L.digitW)
            vec(":", L.colonX, L.colonW)
            vec(Character(String(m / 10)), L.minTensX, L.digitW)
            vec(Character(String(m % 10)), L.minOnesX, L.digitW)
            return
        }
        UIGraphicsPushContext(ctx)
        func cell(_ t: String, _ x: Int, _ w: Int) {
            drawLunarText(t, font: L.font, color: color, in: CGRect(x: x, y: L.y, width: w, height: L.lineH))
        }
        cell("\(h / 10)", L.hourTensX, L.digitW)
        cell("\(h % 10)", L.hourOnesX, L.digitW)
        cell(":", L.colonX, L.colonW)
        cell("\(m / 10)", L.minTensX, L.digitW)
        cell("\(m % 10)", L.minOnesX, L.digitW)
        UIGraphicsPopContext()
    }

    /// Giờ số 24 giờ: chục giờ (0...2), giờ (0...9), chục phút (0...5), phút (0...9) — số mục khớp file thật.
    static func digitalLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        let L = digitalLayout(d)
        let color = UIColor(d.digitalColor)
        if L.style != .classic, let def = L.style.def {
            let own = d.digitalOwnColors
            func vec(_ ch: Character, _ w: Int) -> Int {
                add(drawRaster(width: w, height: L.lineH) { ctx in
                    DigitalShapes.draw(ctx, def: def, char: ch, in: CGRect(x: 0, y: 0, width: w, height: L.lineH),
                                       pad: CGFloat(L.pad), color: color, own: own)
                })
            }
            let digits = (0...9).map { vec(Character(String($0)), L.digitW) }
            let colon = vec(":", L.colonW)
            return [
                .array(resources: Array(digits[0...2]), x: L.hourTensX, y: L.y, valueType: HwtValueType.hourTens, ambient: false),
                .array(resources: digits, x: L.hourOnesX, y: L.y, valueType: HwtValueType.hourOnes, ambient: false),
                .single(resource: colon, x: L.colonX, y: L.y, ambient: false),
                .array(resources: Array(digits[0...5]), x: L.minTensX, y: L.y, valueType: HwtValueType.minuteTens, ambient: false),
                .array(resources: digits, x: L.minOnesX, y: L.y, valueType: HwtValueType.minuteOnes, ambient: false)
            ]
        }
        func digit(_ n: Int) -> Int { add(glyphRaster("\(n)", w: L.digitW, h: L.lineH, font: L.font, color: color)) }
        let digits = (0...9).map { digit($0) }
        let colon = add(glyphRaster(":", w: L.colonW, h: L.lineH, font: L.font, color: color))
        return [
            .array(resources: Array(digits[0...2]), x: L.hourTensX, y: L.y, valueType: HwtValueType.hourTens, ambient: false),
            .array(resources: digits, x: L.hourOnesX, y: L.y, valueType: HwtValueType.hourOnes, ambient: false),
            .single(resource: colon, x: L.colonX, y: L.y, ambient: false),
            .array(resources: Array(digits[0...5]), x: L.minTensX, y: L.y, valueType: HwtValueType.minuteTens, ambient: false),
            .array(resources: digits, x: L.minOnesX, y: L.y, valueType: HwtValueType.minuteOnes, ambient: false)
        ]
    }

    // MARK: Tên

    static func cleanName(_ s: String) -> String {
        String(HwtLibrary.cleanName(s).prefix(maxNameChars))
    }

    private static func nameFont(style: Int, pointSize: CGFloat, face: FaceFont) -> UIFont {
        switch style {
        case 1:
            return face.text(pointSize, .light)
        case 2:
            // Nghiêng: font hệ thống thì dùng chữ có chân nghiêng như trước; font khác thì nghiêng chính font đó.
            let base = (face == .system ? FaceFont.serif : face).text(pointSize, .semibold)
            if let dsc = base.fontDescriptor.withSymbolicTraits(.traitItalic) {
                return UIFont(descriptor: dsc, size: pointSize)
            }
            return base
        default:
            return face.text(pointSize, .bold)
        }
    }

    static func nameLayout(_ d: FaceDesign) -> (line: TextLineLayout, text: String)? {
        let text = cleanName(d.nameText)
        guard !text.isEmpty else { return nil }
        var fs = 30 * CGFloat(min(1.8, max(0.6, d.nameSize)))
        let face = d.textFace("name")
        var font = nameFont(style: d.nameStyle, pointSize: fs, face: face)
        // Thu nhỏ cho vừa bề ngang mặt đồng hồ.
        while textWidth(text, font) + 4 > maxNameWidth && fs > 10 {
            fs -= 1
            font = nameFont(style: d.nameStyle, pointSize: fs, face: face)
        }
        let w = min(maxNameWidth, textWidth(text, font) + 4)
        let h = Int(ceil(font.lineHeight)) + 4
        let x = max(0, min(Int(size) - w, Int(size * clampUnit(d.nameX)) - w / 2))
        let y = max(0, min(Int(size) - h, Int(size * clampUnit(d.nameY)) - h / 2))
        return (TextLineLayout(font: font, w: w, h: h, x: x, y: y), text)
    }

    static func drawNamePreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showName, let n = nameLayout(d) else { return }
        UIGraphicsPushContext(ctx)
        drawLunarText(n.text, font: n.line.font, color: UIColor(d.nameColor),
                      in: CGRect(x: n.line.x, y: n.line.y, width: n.line.w, height: n.line.h))
        UIGraphicsPopContext()
    }

    static func nameLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        guard let n = nameLayout(d) else { return [] }
        let id = add(glyphRaster(n.text, w: n.line.w, h: n.line.h, font: n.line.font, color: UIColor(d.nameColor)))
        return [.single(resource: id, x: n.line.x, y: n.line.y, ambient: false)]
    }

    // MARK: Gom tất cả

    /// Có mục thông tin nào được bật không.
    static func infoActive(_ d: FaceDesign) -> Bool {
        d.showLunar || d.showSolar || d.showWeekday || d.showDigital || (d.showName && !cleanName(d.nameText).isEmpty)
            || d.battery.show || d.steps.show || d.heart.show || d.calories.show || d.weather.show
    }

    /// Các mã dữ liệu (valueType) mà các mục đang bật sẽ dùng — để phát hiện file đã có sẵn mục đó.
    static func infoValueTypes(_ d: FaceDesign) -> Set<Int> {
        var s = Set<Int>()
        if d.showLunar { s.formUnion([HwtValueType.lunarMonth, HwtValueType.lunarDayTens, HwtValueType.lunarDayOnes]) }
        if d.showSolar { s.formUnion([HwtValueType.solarMonth, HwtValueType.solarDayTens, HwtValueType.solarDayOnes]) }
        if d.showWeekday { s.insert(HwtValueType.weekday) }
        if d.showDigital {
            s.formUnion([HwtValueType.hourTens, HwtValueType.hourOnes, HwtValueType.minuteTens, HwtValueType.minuteOnes])
        }
        if d.weather.show { s.insert(HwtValueType.weatherCondition) }
        return s
    }

    /// Xem trước tất cả mục đang bật (không vẽ ở AOD).
    static func drawInfoPreview(_ ctx: CGContext, design source: FaceDesign) {
        textOutlineOn = source.textOutline
        let d = resolvedLayout(source)
        drawPlatesPreview(ctx, design: d)
        drawSolarPreview(ctx, design: d)
        drawLunarPreview(ctx, design: d)
        drawWeekdayPreview(ctx, design: d)
        drawDigitalPreview(ctx, design: d)
        drawDataPreview(ctx, design: d)
        drawNamePreview(ctx, design: d)
    }

    /// Các lớp HWT của tất cả mục đang bật.
    static func infoLayers(_ source: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        textOutlineOn = source.textOutline
        let d = resolvedLayout(source)
        var layers = plateLayers(d, add: add)
        if d.showSolar { layers += solarLayers(d, add: add) }
        if d.showLunar { layers += lunarLayers(d, add: add) }
        if d.showWeekday { layers += weekdayLayers(d, add: add) }
        if d.showDigital { layers += digitalLayers(d, add: add) }
        layers += dataLayers(d, add: add)
        if d.showName { layers += nameLayers(d, add: add) }
        return layers
    }
}
