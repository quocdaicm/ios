// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Cài đặt các mục thông tin: dương lịch, âm lịch, thứ, giờ số, pin, bước chân, nhịp tim, calo, thời tiết, tên. Dùng chung cho Studio và "Thêm thông tin vào HWT".
struct InfoSettingsView: View {
    @Binding var design: FaceDesign

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Toggle(tr("Tự sắp xếp, không cho chữ chồng nhau hoặc đè lên số giờ"), isOn: $design.autoLayout)
                Toggle(tr("Viền chữ mờ phía sau cho dễ đọc"), isOn: $design.textOutline)
                Toggle(tr("Biểu tượng SVG riêng (tắt = biểu tượng iOS)"), isOn: $design.iconSVG)
                Picker(tr("Font chữ"), selection: $design.textFontIndex) {
                    ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
                }
                .pickerStyle(.menu)
                Picker(tr("Font số"), selection: $design.numberFontIndex) {
                    ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
                }
                .pickerStyle(.menu)
            }
            .card()
            ElementStyleView(design: $design)
            block(tr("Dương lịch"), isOn: $design.showSolar) {
                ColorPicker(tr("Màu chữ"), selection: $design.solarColor, supportsOpacity: false)
                pos(size: $design.solarSize, x: $design.solarX, y: $design.solarY)
                Toggle(tr("Hiện chữ D. LỊCH"), isOn: $design.solarLabel)
                plateControls("solar")
            }
            block(tr("Âm lịch"), isOn: $design.showLunar) {
                ColorPicker(tr("Màu chữ"), selection: $design.lunarColor, supportsOpacity: false)
                pos(size: $design.lunarSize, x: $design.lunarX, y: $design.lunarY)
                Toggle(tr("Hiện chữ ÂL"), isOn: $design.lunarLabel)
                plateControls("lunar")
            }
            block(tr("Thứ trong tuần"), isOn: $design.showWeekday) {
                ColorPicker(tr("Màu chữ"), selection: $design.weekdayColor, supportsOpacity: false)
                pos(size: $design.weekdaySize, x: $design.weekdayX, y: $design.weekdayY)
                plateControls("weekday")
            }
            block(tr("Giờ số (HH:MM)"), isOn: $design.showDigital) {
                digitalStyleGrid
                if design.digitalStyle.hasOwnPalette {
                    Toggle(tr("Dùng màu gốc của kiểu số"), isOn: $design.digitalOwnColors)
                }
                if !(design.digitalStyle.hasOwnPalette && design.digitalOwnColors) {
                    ColorPicker(tr("Màu chữ"), selection: $design.digitalColor, supportsOpacity: false)
                }
                pos(size: $design.digitalSize, x: $design.digitalX, y: $design.digitalY)
                plateControls("digital")
            }
            dataBlock("Pin", $design.battery, key: "battery", unitTitle: tr("Hiện %"))
            dataBlock(tr("Bước chân"), $design.steps, key: "steps", unitTitle: tr("Hiện chữ \"bước\""))
            dataBlock(tr("Nhịp tim"), $design.heart, key: "heart", unitTitle: tr("Hiện chữ \"bpm\""))
            dataBlock("Calo", $design.calories, key: "calories", unitTitle: tr("Hiện chữ \"kcal\""))
            block(tr("Thời tiết"), isOn: $design.weather.show) {
                ColorPicker(tr("Màu chữ"), selection: $design.weather.color, supportsOpacity: false)
                pos(size: $design.weather.size, x: $design.weather.x, y: $design.weather.y, xTitle: tr("Vị trí ngang (mép trái khối)"))
                Toggle(tr("Hiện biểu tượng thời tiết"), isOn: $design.weatherIcon)
                if design.weatherIcon {
                    Toggle(tr("Biểu tượng một màu (theo màu chữ)"), isOn: $design.weatherIconMono)
                }
                Toggle(tr("Hiện tên tình trạng (nắng, mưa…)"), isOn: $design.weatherText)
                Toggle(tr("Hiện nhiệt độ cao / thấp"), isOn: $design.weatherRange)
                plateControls("weather")
            }
            block(tr("Tên của bạn"), isOn: $design.showName) {
                TextField(tr("Nhập tên hiển thị"), text: $design.nameText)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: design.nameText) { v in
                        let c = FaceRenderer.cleanName(v)
                        if c != v && v.count > FaceRenderer.maxNameChars { design.nameText = c }
                    }
                Picker(tr("Kiểu chữ"), selection: $design.nameStyle) {
                    ForEach(0..<FaceRenderer.nameStyleTitles.count, id: \.self) { Text(tr(FaceRenderer.nameStyleTitles[$0])).tag($0) }
                }
                .pickerStyle(.segmented)
                ColorPicker(tr("Màu chữ"), selection: $design.nameColor, supportsOpacity: false)
                pos(size: $design.nameSize, x: $design.nameX, y: $design.nameY)
                plateControls("name")
            }
        }
    }

    /// Lưới chọn kiểu số giờ số (hình thu nhỏ "13:00").
    private var digitalStyleGrid: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(trf("Kiểu số: %@", tr(design.digitalStyle.title))).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 104), spacing: 10)], spacing: 12) {
                ForEach(DigitalStyle.allCases) { st in
                    Button {
                        design.digitalStyle = st
                    } label: {
                        VStack(spacing: 3) {
                            Image(uiImage: DigitalThumbs.image(st))
                                .resizable()
                                .aspectRatio(240.0 / 84.0, contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .stroke(design.digitalStyle == st ? Color.accentColor : Color.clear, lineWidth: 2.5)
                                )
                            Text(tr(st.title)).font(.caption2).foregroundStyle(.secondary)
                                .lineLimit(2).minimumScaleFactor(0.75).multilineTextAlignment(.center)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func block<C: View>(_ title: String, isOn: Binding<Bool>, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: isOn) { Text(tr(title)).font(.headline) }
            if isOn.wrappedValue { content() }
        }
        .card()
    }

    /// Mục số liệu do đồng hồ cập nhật (pin, bước chân, nhịp tim, calo).
    private func dataBlock(_ title: String, _ w: Binding<DataWidget>, key: String, unitTitle: String) -> some View {
        block(title, isOn: w.show) {
            ColorPicker(tr("Màu chữ"), selection: w.color, supportsOpacity: false)
            pos(size: w.size, x: w.x, y: w.y, xTitle: tr("Vị trí ngang (mép trái số)"))
            Toggle(tr(unitTitle), isOn: w.unit)
            Toggle(tr("Hiện biểu tượng"), isOn: w.icon)
            if w.icon.wrappedValue {
                Toggle(tr("Biểu tượng một màu (theo màu chữ)"), isOn: w.iconMono)
            }
            plateControls(key)
        }
    }

    /// Khung nền SVG phía sau một mục (viên thuốc, lục giác, viền đôi…).
    private func plateControls(_ key: String) -> some View {
        let b = Binding<PlateStyle>(get: { design.plates[key] ?? PlateStyle() }, set: { design.plates[key] = $0 })
        return VStack(alignment: .leading, spacing: 8) {
            Picker(tr("Khung nền SVG"), selection: b.shape) {
                ForEach(0..<FacePlate.titles.count, id: \.self) { Text(tr(FacePlate.titles[$0])).tag($0) }
            }
            .pickerStyle(.menu)
            if b.wrappedValue.shape > 0 {
                ColorPicker(tr("Màu nền khung"), selection: b.fill, supportsOpacity: false)
                ColorPicker(tr("Màu viền khung"), selection: b.line, supportsOpacity: false)
                labeled(tr("Độ đậm nền khung")) { Slider(value: b.opacity, in: 0.1...1) }
                Toggle(tr("Viền khung"), isOn: b.outline)
            }
        }
    }

    private func pos(size: Binding<Double>, x: Binding<Double>, y: Binding<Double>, xTitle: String = tr("Vị trí ngang")) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            labeled(tr("Cỡ chữ")) { Slider(value: size, in: 0.6...1.8) }
            labeled(xTitle) { Slider(value: x, in: 0.1...0.9) }
            labeled(tr("Vị trí dọc")) { Slider(value: y, in: 0.1...0.9) }
        }
    }

    private func labeled<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(tr(title)).font(.footnote).foregroundStyle(.secondary)
            content()
        }
    }
}
