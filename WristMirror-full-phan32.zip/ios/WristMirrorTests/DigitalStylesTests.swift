// Unit test cho bộ kiểu số giờ kỹ thuật số vector.
import XCTest
import SwiftUI
@testable import WristMirror

final class DigitalStylesTests: XCTestCase {
    func testEveryStyleHasDefinitionAndTitle() {
        for st in DigitalStyle.allCases where st != .classic {
            XCTAssertNotNil(DigitalShapes.table[st.rawValue], st.rawValue)
            XCTAssertNotNil(DigitalShapes.titles[st.rawValue], st.rawValue)
        }
        XCTAssertEqual(DigitalShapes.table.count, 17)
        XCTAssertEqual(DigitalStyle.allCases.count, 18)
    }

    func testEveryGlyphHasGeometry() throws {
        for st in DigitalStyle.allCases where st != .classic {
            let def = try XCTUnwrap(st.def)
            for ch in "0123456789:" {
                let g = DigitalShapes.glyph(def, ch)
                XCTAssertFalse(g.on.isEmpty, "\(st.rawValue) \(ch)")
            }
        }
    }

    func testCellsGrowWithScale() throws {
        let def = try XCTUnwrap(DigitalStyle.lcd.def)
        let small = DigitalShapes.cells(def, scale: 0.6)
        let big = DigitalShapes.cells(def, scale: 1.8)
        XCTAssertLessThan(small.lineH, big.lineH)
        XCTAssertLessThan(small.digitW, big.digitW)
    }

    func testLayoutUsesVectorCells() {
        var d = FaceDesign()
        d.showDigital = true
        d.digitalStyle = .ledRed
        let L = FaceRenderer.digitalLayout(d)
        XCTAssertEqual(L.style, .ledRed)
        XCTAssertGreaterThan(L.pad, 0)
        XCTAssertGreaterThan(L.digitW, L.colonW)
    }

    func testCodecRoundTrip() throws {
        var d = FaceDesign()
        d.digitalStyle = .neonAqua
        d.digitalOwnColors = false
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.digitalStyle, .neonAqua)
        XCTAssertFalse(back.digitalOwnColors)
    }
}
