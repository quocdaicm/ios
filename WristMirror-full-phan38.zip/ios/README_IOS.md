# Huawei watch face (iOS) – bản viết lại từ WristMirror bằng Swift/SwiftUI

Build không cần Mac: đẩy thư mục này lên GitHub → tab Actions → "Build IPA" → tải artifact `Huawei-watch-face-ipa` (file `Huawei-watch-face.ipa`) (IPA chưa ký, cần tự ký/cài bằng Sideloadly, AltStore...).

> Người/AI làm tiếp: đọc **HANDOFF.md** trước.

## Các phần
1. Khung dự án, FrameCodec, GattChannel (CoreBluetooth)  ✅
2. Core, TlvView, Wire, DeviceInfo, MiniJson  ✅
3. Mật mã (AES-GCM/CBC, HMAC, HKDF), CryptoSession, LiteAuth, LinkCapabilities, AuthReplyJson  ✅
4. IsoAuth + IsoReplyHandler (xác thực HiChain ISO)  ✅
5. WatchConnection + WatchScanner + WristInitialization + DeviceTelemetry + SafeLog + Keychain store  ✅
6. FacePolicy/VersionPolicy + WireNames + các lớp *State + HwtSource (+ZipArchive) + FileTransfer (giao thức 0x28)  ✅ (chưa biên dịch)
7. WatchfaceManager (thay/xoá/bật mặt đồng hồ) + AppRuntime + Models + SavedWatchStore  ✅ (chưa biên dịch)
8. WatchViewModel + giao diện SwiftUI + đăng nhập Huawei ID (WKWebView)  ✅ (chưa biên dịch)
9. Build GitHub Actions lần đầu, sửa lỗi biên dịch, thử trên đồng hồ thật  ← tiếp theo

## Giấy phép
Apache-2.0 (xem `LICENSE`, `NOTICE`). Tác phẩm phái sinh của WristMirror (Escosis). Chi tiết ghi công: `THIRD_PARTY_NOTICES.md`.

## Giao diện (v11)
- Tên hiển thị app: **Huawei watch face** (`CFBundleDisplayName`); tên target/module nội bộ vẫn là `WristMirror`.
- Nền, logo, vòng mặt số vẽ bằng vector (SwiftUI Canvas, `Views/Theme.swift`); bản SVG gốc ở `design/` (`app-icon.svg`, `logo-mark.svg`, `background-dark.svg`, `background-light.svg`).
- Icon app 1024×1024 và ảnh launch (`LaunchLogo`) được xuất từ SVG trong `design/`.

- Tạo mặt đồng hồ mới: tab Mặt đồng hồ → "Tạo mặt đồng hồ mới" (đổi tên, ảnh nền, màu, kiểu kim, vạch giờ, AOD; thông tin trên mặt: ngày, giờ số, pin, bước chân, nhịp tim, calo, thời tiết).

- Kiểu kim: 26 kiểu (chọn bằng lưới hình trong Tạo mặt đồng hồ). Hiệu ứng mùa: hoa đào, hoa mai, anh đào, tuyết, lá thu, tia nắng, vòng hoa (lớp quay theo kim; xem thử hạt rơi trong ứng dụng).

- Xem trước động trong Tạo mặt đồng hồ: kim chạy giờ thật hoặc cố định 10:08:35, lớp quay chạy thật, hạt rơi, thẻ xuất hiện mượt (chỉ là xem trước; xem HANDOFF mục 14).

## Vùng chạm và font riêng từng mục (phần 28)

- `Store/FaceTap.swift`: hành động chạm (`TapAction`), font riêng (`FaceDesign.textFace/numberFace`), tính vùng chạm (`FaceRenderer.tapZones`).
- `HwtBuilder.layoutBytes` ghi thêm phần tử số 3 chứa các vùng chạm `{1: số thứ tự, 2: 0, 5: {x, y, rộng, cao}, 8: mã hành động}` (cấu trúc đọc từ Kozmik Sporcu / BetaFinal).
- Mã hành động đối chiếu với ảnh xem trước: 10 bước chân, 11 nhịp tim, 12 calo, 17 pin, 21 thời tiết, 24 quãng đường, 25 giấc ngủ, 16 căng thẳng; 9 (mặt trời mọc/lặn) chưa kiểm chứng.
- `Views/ElementStyleView.swift`: chọn font, cỡ chữ (pt) và hành động chạm cho từng mục, nằm trong `InfoSettingsView`.
- Chưa biên dịch/thử trên thiết bị khi viết: cần chạy `TapZoneTests` và thử cài một mặt có vùng chạm lên đồng hồ thật.

### Phần 29

- Vùng chạm ở mép mặt đồng hồ (`TapEdge`: trên, trái, dưới, phải) chọn trong `ElementStyleView`, lưu ở `FaceDesign.edgeTaps`.
- "Thêm thông tin vào HWT" (`HwtLunarPatch.patchBin`) ghi vùng chạm vào file có sẵn nếu file chưa có phần tử số 3 (chèn trước các trường tiêu đề); file đã có phần tử số 3 thì giữ nguyên, không thêm.
