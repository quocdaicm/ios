// Unit test cho kiểu số vector của các mục số liệu (pin, bước chân, nhịp tim, calo, thời tiết).
import XCTest
import SwiftUI
@testable import WristMirror

final class DataStylesTests: XCTestCase {
    func testClassicByDefault() {
        let d = FaceDesign()
        for kind in DataKind.allCases {
            XCTAssertNil(d.dataVecStyle(d.dataWidget(kind)), "\(kind)")
        }
        XCTAssertNil(d.dataVecStyle(d.weather))
    }

    func testSharedStyleAppliesToAll() {
        var d = FaceDesign()
        d.dataStyle = .ledGreen
        for kind in DataKind.allCases {
            XCTAssertNotNil(d.dataVecStyle(d.dataWidget(kind)), "\(kind)")
        }
        XCTAssertNotNil(d.dataVecStyle(d.weather))
    }

    func testCustomStyleOverridesShared() throws {
        var d = FaceDesign()
        d.dataStyle = .ledGreen
        d.heart.customStyle = true
        d.heart.style = .neonRuby
        d.battery.customStyle = true
        d.battery.style = .classic
        let heart = try XCTUnwrap(d.dataVecStyle(d.heart))
        XCTAssertTrue(heart.key.hasPrefix("neonRuby"))
        XCTAssertNil(d.dataVecStyle(d.battery), "kiểu riêng .classic phải thắng kiểu chung")
        XCTAssertTrue(try XCTUnwrap(d.dataVecStyle(d.steps)).key.hasPrefix("ledGreen"))
    }

    func testVectorLayoutHasGeometry() {
        var d = FaceDesign()
        d.dataStyle = .goldHex
        for kind in DataKind.allCases {
            var w = d.dataWidget(kind)
            w.show = true
            let L = FaceRenderer.dataNumberLayout(kind, w, d)
            XCTAssertNotNil(L.vec, "\(kind)")
            XCTAssertGreaterThan(L.digitW, 4)
            XCTAssertGreaterThan(L.lineH, 8)
            XCTAssertGreaterThan(L.suffixW, 0, "\(kind) có đơn vị")
        }
    }

    func testUnitOffRemovesSuffix() {
        var d = FaceDesign()
        d.dataStyle = .pixel
        d.heart.unit = false
        let L = FaceRenderer.dataNumberLayout(.heart, d.heart, d)
        XCTAssertEqual(L.suffixW, 0)
    }

    func testWeatherVectorLayout() {
        var d = FaceDesign()
        d.weather.show = true
        d.weatherRange = true
        XCTAssertNil(WeatherLayout(d).vec)
        d.dataStyle = .neonAqua
        let L = WeatherLayout(d)
        XCTAssertNotNil(L.vec)
        XCTAssertNotNil(L.rangeVec)
        XCTAssertGreaterThan(L.degW, 0)
        XCTAssertGreaterThan(L.arrowW, 4)
    }

    func testAllStylesProduceUnitsAndRasters() throws {
        for st in DigitalStyle.allCases where st != .classic {
            let def = try XCTUnwrap(st.def)
            let c = DigitalShapes.cells(def, scale: 1.0, base: 28)
            let gh = c.lineH - 2 * c.pad
            let suf = try XCTUnwrap(FaceRenderer.vecSuffix(" kcal", fontScale: 0.17, glyphH: gh, pad: c.pad, def: def, gap: 4), st.rawValue)
            XCTAssertGreaterThan(suf.w, 8, st.rawValue)
            let v = DataVecInfo(def: def, own: true, pad: c.pad, glyphH: gh, key: st.rawValue, suffix: suf)
            let r = FaceRenderer.vecGlyphRaster("-", v, w: c.digitW, h: c.lineH, color: .white)
            XCTAssertEqual(r.width, c.digitW)
        }
    }

    func testCodecRoundTrip() throws {
        var d = FaceDesign()
        d.dataStyle = .dotAmber
        d.dataOwnColors = false
        d.weather.customStyle = true
        d.weather.style = .pixelIce
        d.weather.ownColors = false
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.dataStyle, .dotAmber)
        XCTAssertFalse(back.dataOwnColors)
        XCTAssertTrue(back.weather.customStyle)
        XCTAssertEqual(back.weather.style, .pixelIce)
        XCTAssertFalse(back.weather.ownColors)
        XCTAssertFalse(back.battery.customStyle)
    }

    func testSharedStyleSyncsTimeAndDates() {
        var d = FaceDesign()
        d.showDigital = true
        d.showSolar = true
        d.showLunar = true
        d.dataStyle = .ledRed
        XCTAssertEqual(FaceRenderer.digitalLayout(d).style, .ledRed)
        XCTAssertEqual(FaceRenderer.solarLayout(d).style, .ledRed)
        XCTAssertEqual(FaceRenderer.lunarLayout(d).style, .ledRed)
        // Kiểu riêng của một mục thắng kiểu chung, các mục còn lại vẫn theo kiểu chung.
        d.solarCustom = true
        d.solarStyle = .pixel
        XCTAssertEqual(FaceRenderer.solarLayout(d).style, .pixel)
        XCTAssertEqual(FaceRenderer.digitalLayout(d).style, .ledRed)
        XCTAssertEqual(FaceRenderer.lunarLayout(d).style, .ledRed)
    }

    func testOldDesignWithOwnTimeStyleStaysCustom() throws {
        var d = FaceDesign()
        d.digitalCustom = true
        d.digitalStyle = .goldHex
        var data = try FaceDesignCodec.encode(d)
        // Giả lập file cũ: không có khoá "digitalCustom".
        var root = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        var dict = try XCTUnwrap(root["design"] as? [String: Any])
        dict.removeValue(forKey: "digitalCustom")
        root["design"] = dict
        data = try JSONSerialization.data(withJSONObject: root)
        let back = try XCTUnwrap(FaceDesignCodec.decode(data))
        XCTAssertTrue(back.digitalCustom)
        XCTAssertEqual(back.digitalStyleEff, .goldHex)
    }
}
