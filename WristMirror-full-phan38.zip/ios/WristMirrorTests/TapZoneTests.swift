// Unit test cho vùng chạm (phần tử số 3) và font riêng từng mục.
import XCTest
import SwiftUI
@testable import WristMirror

final class TapZoneTests: XCTestCase {
    private func hex(_ b: [UInt8]) -> String { b.map { String(format: "%02x", $0) }.joined() }

    /// Vùng chạm ghi đúng dạng của file thật (Kozmik BetaFinal): {1: số thứ tự, 2: 0, 5: hình chữ nhật, 8: mã hành động}.
    func testTapZoneBytes() {
        var spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [], images: [])
        spec.tapZones = [HwtTapZone(rect: HwtRect(x: 1, y: 2, w: 3, h: 4), action: 10)]
        let expected = "0a18" + "0803" + "1000" + "2200" + "4210" + "0800" + "1000" + "2a08" + "0801100218032004" + "400a"
            + "120178" + "1a0178"
        XCTAssertEqual(hex(HwtBuilder.layoutBytes(spec)), expected)
    }

    func testNoZonesLeavesLayoutUnchanged() {
        let spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [], images: [])
        XCTAssertEqual(hex(HwtBuilder.layoutBytes(spec)), "120178" + "1a0178")
    }

    func testDefaultTapActions() {
        let d = FaceDesign()
        XCTAssertEqual(d.tapAction("heart"), .heart)
        XCTAssertEqual(d.tapAction("weather"), .weather)
        XCTAssertEqual(d.tapAction("digital"), .none)
    }

    func testZonesOnlyForShownItems() {
        var d = FaceDesign()
        d.heart.show = true
        d.heart.x = 0.3
        d.heart.y = 0.8
        var zones = FaceRenderer.tapZones(d)
        XCTAssertEqual(zones.map { $0.action }, [11])
        let r = zones[0].rect
        XCTAssertTrue(r.w >= 64 && r.h >= 48 && r.x >= 0 && r.y >= 0 && r.x + r.w <= 466 && r.y + r.h <= 466)
        d.taps["heart"] = 0
        zones = FaceRenderer.tapZones(d)
        XCTAssertTrue(zones.isEmpty)
        d.taps["heart"] = TapAction.sleep.rawValue
        d.tapsOn = false
        XCTAssertTrue(FaceRenderer.tapZones(d).isEmpty)
    }

    func testElementFontOverride() {
        var d = FaceDesign()
        d.textFontIndex = FaceFont.serif.rawValue
        d.elementFonts["name"] = FaceFont.mono.rawValue
        XCTAssertEqual(d.textFace("name"), .mono)
        XCTAssertEqual(d.textFace("weekday"), .serif)
    }

    func testCodecRoundTrip() throws {
        var d = FaceDesign()
        d.elementFonts = ["digital": FaceFont.rounded.rawValue]
        d.taps = ["steps": TapAction.sleep.rawValue, "weather": 0]
        d.tapsOn = false
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.elementFonts, d.elementFonts)
        XCTAssertEqual(back.taps, d.taps)
        XCTAssertFalse(back.tapsOn)
    }

    func testValidateRejectsBadZone() {
        var spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [], images: [HwtRaster(width: 1, height: 1)])
        spec.tapZones = [HwtTapZone(rect: HwtRect(x: 460, y: 0, w: 64, h: 48), action: 10)]
        XCTAssertThrowsError(try HwtBuilder.validate(spec, pngs: [[0]]))
    }

    func testEdgeZones() {
        var d = FaceDesign()
        d.edgeTaps = ["top": TapAction.battery.rawValue, "right": TapAction.calories.rawValue, "left": 0]
        let zones = FaceRenderer.tapZones(d)
        XCTAssertEqual(zones.map { $0.action }, [17, 12])
        XCTAssertEqual(zones[0].rect, HwtRect(x: 173, y: 0, w: 120, h: 38))
        XCTAssertEqual(zones[1].rect, HwtRect(x: 428, y: 173, w: 38, h: 120))
        d.tapsOn = false
        XCTAssertTrue(FaceRenderer.tapZones(d).isEmpty)
    }
}
