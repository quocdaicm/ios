// Unit test cho kiểu số + nhãn vector của khối ngày/tháng (Dương lịch / Âm lịch).
import XCTest
import SwiftUI
@testable import WristMirror

final class DateStylesTests: XCTestCase {
    func testLabelTexts() {
        XCTAssertEqual(FaceRenderer.dateLabelString(lunar: false, lang: 1), "D lịch")
        XCTAssertEqual(FaceRenderer.dateLabelString(lunar: true, lang: 1), "Â lịch")
        XCTAssertEqual(FaceRenderer.dateLabelString(lunar: false, lang: 2), "Solar")
        XCTAssertEqual(FaceRenderer.dateLabelString(lunar: true, lang: 2), "Lunar")
        XCTAssertEqual(FaceRenderer.dateSepString(0), "/")
        XCTAssertEqual(FaceRenderer.dateSepString(1), "-")
    }

    func testVectorLabelsHaveGeometry() {
        for t in DateLabelShapes.allLabels {
            let s = DateLabelShapes.shape(t)
            XCTAssertFalse(s.path.isEmpty, t)
            XCTAssertGreaterThan(s.w, 10, t)
            XCTAssertGreaterThan(s.h, 10, t)
        }
    }

    func testLabelFontsAllProduceGeometry() {
        for i in 0..<DateLabelShapes.fontTitles.count {
            let s = DateLabelShapes.shape("Â lịch", font: i)
            XCTAssertFalse(s.path.isEmpty, "font \(i)")
        }
    }

    func testSeparatorWidthsAndGlyphs() throws {
        for st in DigitalStyle.allCases where st != .classic {
            let def = try XCTUnwrap(st.def)
            XCTAssertGreaterThan(DigitalShapes.sepWidth(def), 10, st.rawValue)
            let c = DigitalShapes.cells(def, scale: 1.0, base: 26)
            XCTAssertGreaterThan(c.sepW, 0, st.rawValue)
            XCTAssertEqual(DigitalShapes.charWidth(def, "-"), DigitalShapes.sepWidth(def))
        }
    }

    func testLayoutSeparatorAndLabel() {
        var d = FaceDesign()
        d.showSolar = true
        d.solarSep = 1
        d.solarLabelLang = 2
        d.solarCustom = true
        d.solarStyle = .ledRed
        let L = FaceRenderer.solarLayout(d)
        XCTAssertEqual(L.sep, "-")
        XCTAssertEqual(L.labelText, "Solar")
        XCTAssertEqual(L.style, .ledRed)
        XCTAssertNotNil(L.labelPath)
        XCTAssertGreaterThan(L.pad, 0)
    }

    func testClassicLayoutKeepsFontMode() {
        var d = FaceDesign()
        d.showLunar = true
        d.lunarLabelLang = 1
        let L = FaceRenderer.lunarLayout(d)
        XCTAssertEqual(L.style, .classic)
        XCTAssertNil(L.labelPath)
        XCTAssertEqual(L.labelText, "Â lịch")
        XCTAssertEqual(L.sep, "/")
    }

    func testLayersKeepImageCountsForVectorAndClassic() {
        for style in [DigitalStyle.classic, .lcd, .dotMatrix] {
            var d = FaceDesign()
            d.showLunar = true
            d.lunarCustom = true
            d.lunarStyle = style
            var n = 0
            let layers = FaceRenderer.lunarLayers(d) { _ in n += 1; return n }
            // 4 ảnh chục (trống,1,2,3) + 10 đơn vị + 12 tháng + dấu ngăn + nhãn; mục đệm của tháng dùng lại ảnh có sẵn
            XCTAssertEqual(layers.count, 5, "\(style)")
            XCTAssertEqual(n, 4 + 10 + 1 + 12 + 1, "\(style)")
        }
    }

    func testCodecRoundTrip() throws {
        var d = FaceDesign()
        d.solarCustom = true
        d.solarStyle = .neonAqua
        d.solarOwnColors = false
        d.solarSep = 1
        d.solarLabelLang = 2
        d.lunarCustom = true
        d.lunarStyle = .roseGold
        d.lunarSep = 1
        d.lunarLabelLang = 1
        d.solarLabelFont = 3
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.solarStyle, .neonAqua)
        XCTAssertFalse(back.solarOwnColors)
        XCTAssertEqual(back.solarSep, 1)
        XCTAssertEqual(back.solarLabelLang, 2)
        XCTAssertEqual(back.lunarStyle, .roseGold)
        XCTAssertEqual(back.lunarSep, 1)
        XCTAssertEqual(back.lunarLabelLang, 1)
        XCTAssertEqual(back.solarLabelFont, 3)
    }
}
