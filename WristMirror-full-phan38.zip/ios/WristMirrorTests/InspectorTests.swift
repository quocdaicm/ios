// Unit test cho HwtInspector (đọc thông tin file HWT, chỉ đọc).
// Cấu hình mẫu là watch_face_config.xml thật từ một file HWT; giá trị kỳ vọng tính độc lập bằng Python (ElementTree).
import XCTest
@testable import WristMirror

final class HwtInspectorTests: XCTestCase {
    static let config = #"""
<?xml version="1.0" encoding="utf-8"?>
<watchface>
    <element label="background" is_support_option="false" res_preview="A100_003.png">
        <layer index="1" draw_type="single_res" ambient_mode="1" res_name="A100_002.png" res_position="0,0"/>
    </element>
    <element label="widget">
        <container index="1" data_type="41" res_preview="A100_003.png" rect="0,0,496,496" is_support_option="false">
            <layer index="1" draw_type="selected_res" value_type="99" ambient_mode="0" res_name="A100_004.png,A100_004.png,A100_004.png,A100_005.png,A100_005.png,A100_005.png,A100_006.png,A100_006.png,A100_006.png,A100_004.png,A100_004.png,A100_004.png" res_position="0,0"/>
            <layer index="2" draw_type="single_res" ambient_mode="0" res_name="A100_007.png" res_position="83,183"/>
            <layer index="3" draw_type="single_res" ambient_mode="0" res_name="A100_008.png" res_position="0,0"/>
        </container>
        <container index="2" data_type="11" res_preview="A100_003.png" rect="183,340,100,50" is_support_option="false">
            <layer index="1" draw_type="text" text_color="#FFFFF7D9" text_font="100" text_size="20" text_align="center" value_type="2" ambient_mode="0" text_rect="183,340,100,23"/>
        </container>
        <container index="3" data_type="10" res_preview="A100_003.png" rect="183,280,100,60" is_support_option="false">
            <layer index="1" draw_type="text" text_color="#FFFFF7D9" text_font="100" text_size="26" text_align="center" value_type="0" ambient_mode="0" text_rect="183,306,100,32"/>
        </container>
        <container index="4" data_type="21" res_preview="A100_003.png" rect="56,250,100,60" is_support_option="false">
            <layer index="1" draw_type="selected_res" value_type="248" ambient_mode="0" res_name="A100_009.png,A100_010.png,A100_011.png,A100_012.png,A100_013.png,A100_014.png,A100_015.png,A100_016.png,A100_017.png,A100_018.png,A100_019.png,A100_020.png,A100_021.png,A100_022.png,A100_023.png,A100_024.png,A100_025.png,A100_026.png,A100_027.png,A100_028.png,A100_029.png,A100_030.png,A100_031.png,A100_032.png,A100_033.png,A100_034.png,A100_035.png,A100_036.png" res_position="58,254"/>
            <layer index="2" draw_type="text" text_color="#FFFFF7D9" text_font="100" text_size="20" text_align="right" value_type="4" ambient_mode="0" text_rect="78,258,35,24"/>
            <layer index="3" draw_type="selected_res" value_type="73" ambient_mode="0" res_name="A100_037.png,A100_038.png" res_position="118,264"/>
        </container>
        <container index="5" data_type="17" res_preview="A100_003.png" rect="0,0,1,1" is_support_option="false">
            <layer index="1" draw_type="text2_res" text_color="#FFFFF7D9" text_font="100" text_size="20" text_align="left" connect_type="5" value_type_one="9" value_type_two="255" ambient_mode="0" text_rect="370,187,37,24"/>
        </container>
        <container index="6" data_type="25" res_preview="A100_003.png" rect="160,110,50,50" is_support_option="false">
            <layer index="1" draw_type="single_res" ambient_mode="0" res_name="A100_003.png" res_position="160,110"/>
        </container>
    </element>
    <element label="date" is_support_option="false" res_preview="A100_003.png">
        <layer index="1" draw_type="selected_res" value_type="52" ambient_mode="0" res_name="A100_039.png,A100_039.png,A100_040.png,A100_041.png,A100_042.png,A100_043.png,A100_044.png,A100_045.png" res_position="59,220"/>
        <layer index="2" draw_type="selected_res" value_type="70" ambient_mode="0" res_name="A100_046.png,A100_047.png,A100_048.png,A100_049.png" res_position="102,226"/>
        <layer index="3" draw_type="selected_res" value_type="71" ambient_mode="0" res_name="A100_046.png,A100_047.png,A100_048.png,A100_049.png,A100_050.png,A100_051.png,A100_052.png,A100_053.png,A100_054.png,A100_055.png" res_position="113,226"/>
        <layer index="4" draw_type="selected_res" value_type="51" ambient_mode="0" res_name="A100_056.png,A100_056.png,A100_057.png,A100_058.png,A100_059.png,A100_060.png,A100_061.png,A100_062.png,A100_063.png,A100_064.png,A100_065.png,A100_066.png,A100_067.png" res_position="133,226"/>
        <layer index="5" draw_type="selected_res" value_type="94" ambient_mode="0" res_name="A100_065.png,A100_056.png,A100_057.png,A100_058.png,A100_059.png,A100_060.png,A100_061.png,A100_062.png,A100_063.png,A100_064.png" res_position="315,226"/>
        <layer index="6" draw_type="selected_res" value_type="93" ambient_mode="0" res_name="A100_068.png,A100_069.png,A100_070.png,A100_071.png,A100_070.png" res_position="315,226"/>
        <layer index="7" draw_type="selected_res" value_type="92" ambient_mode="0" res_name="A100_056.png,A100_056.png,A100_057.png,A100_058.png,A100_059.png,A100_060.png,A100_061.png,A100_062.png,A100_063.png,A100_064.png,A100_065.png,A100_066.png,A100_067.png" res_position="346,226"/>
        <layer index="8" draw_type="selected_res" value_type="52" ambient_mode="1" res_name="A100_039.png,A100_039.png,A100_040.png,A100_041.png,A100_042.png,A100_043.png,A100_044.png,A100_045.png" res_position="65,220"/>
        <layer index="9" draw_type="text2_res" text_color="#FFFFF7D9" text_font="110" text_size="20" text_align="left" connect_type="2" value_type_one="17" value_type_two="253" ambient_mode="1" text_rect="112,222,58,24"/>
    </element>
    <element label="time" is_support_option="false" res_preview="A100_003.png">
        <layer index="1" draw_type="selected_res" value_type="59" ambient_mode="0" res_name="A100_072.png,A100_073.png,A100_074.png" res_position="54,186"/>
        <layer index="2" draw_type="selected_res" value_type="60" ambient_mode="0" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png,A100_078.png,A100_079.png,A100_080.png,A100_081.png" res_position="69,186"/>
        <layer index="3" draw_type="selected_res" value_type="61" ambient_mode="0" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png" res_position="90,186"/>
        <layer index="4" draw_type="selected_res" value_type="62" ambient_mode="0" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png,A100_078.png,A100_079.png,A100_080.png,A100_081.png" res_position="105,186"/>
        <layer index="5" draw_type="hand_res" value_type="150" ambient_mode="0" res_left="A100_082.png" rotate_start_angel="0" rotate_end_angel="360" rotate_point_hand="25,147" rotate_rect="86,86,294,294"/>
        <layer index="6" draw_type="hand_res" value_type="153" ambient_mode="0" res_left="A100_083.png" rotate_start_angel="0" rotate_end_angel="360" rotate_point_hand="27,192" rotate_rect="41,41,384,384"/>
        <layer index="7" draw_type="hand_res" value_type="154" ambient_mode="0" res_left="A100_084.png" rotate_start_angel="0" rotate_end_angel="360" rotate_point_hand="27,230" rotate_rect="3,3,460,460"/>
        <layer index="8" draw_type="selected_res" value_type="59" ambient_mode="1" res_name="A100_085.png,A100_086.png,A100_087.png" res_position="300,222"/>
        <layer index="9" draw_type="selected_res" value_type="60" ambient_mode="1" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png,A100_078.png,A100_079.png,A100_080.png,A100_081.png" res_position="315,222"/>
        <layer index="10" draw_type="selected_res" value_type="61" ambient_mode="1" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png" res_position="344,222"/>
        <layer index="11" draw_type="selected_res" value_type="62" ambient_mode="1" res_name="A100_072.png,A100_073.png,A100_074.png,A100_075.png,A100_076.png,A100_077.png,A100_078.png,A100_079.png,A100_080.png,A100_081.png" res_position="359,222"/>
        <layer index="12" draw_type="hand_res" value_type="150" ambient_mode="1" res_left="A100_082.png" rotate_start_angel="0" rotate_end_angel="360" rotate_point_hand="25,147" rotate_rect="86,86,294,294"/>
        <layer index="13" draw_type="hand_res" value_type="153" ambient_mode="1" res_left="A100_088.png" rotate_start_angel="0" rotate_end_angel="360" rotate_point_hand="27,192" rotate_rect="41,41,384,384"/>
    </element>
</watchface>
"""#

    func testParseConfigRealSample() {
        let s = HwtInspector.parseConfig(Array(HwtInspectorTests.config.utf8))
        XCTAssertEqual(s.elementLabels, ["background", "widget", "date", "time"])
        XCTAssertEqual(s.layerCount, 33)
        XCTAssertEqual(s.backgroundResource, "A100_002.png")
        XCTAssertEqual(s.textStyles.count, 2)
        XCTAssertEqual(s.textStyles.first { $0.size == 20 }?.count, 4)
        XCTAssertEqual(s.textStyles.first { $0.size == 26 }?.count, 1)
        XCTAssertTrue(s.textStyles.allSatisfy { $0.color == "#FFFFF7D9" })
    }

    func testParseConfigGarbageDoesNotCrash() {
        let s = HwtInspector.parseConfig(Array("không phải xml <<<".utf8))
        XCTAssertEqual(s.layerCount, 0)
        XCTAssertTrue(s.textStyles.isEmpty)
    }

    func testParseDescription() {
        let xml = """
        <?xml version="1.0" encoding="UTF-8"?>
        <HwTheme>
          <title>p0228Long</title>
          <title-cn>Long</title-cn>
          <author>jd</author>
          <designer>jd</designer>
          <screen>HWHD09</screen>
          <version>2.1.1</version>
          <font>Default</font>
          <briefinfo>{"en_US":"xxx"}</briefinfo>
        </HwTheme>
        """
        let d = HwtInspector.parseDescription(Array(xml.utf8))
        XCTAssertEqual(d["title"], "p0228Long")
        XCTAssertEqual(d["screen"], "HWHD09")
        XCTAssertEqual(d["version"], "2.1.1")
        XCTAssertEqual(d["author"], "jd")
        XCTAssertNil(d["font"])
        XCTAssertNil(d["briefinfo"])
    }

    func testParseColor() throws {
        let a = try XCTUnwrap(HwtInspector.parseColor("#FFFFF7D9"))
        XCTAssertEqual([a.a, a.r, a.g, a.b], [255, 255, 247, 217])
        let b = try XCTUnwrap(HwtInspector.parseColor("#00FF00"))
        XCTAssertEqual([b.a, b.r, b.g, b.b], [255, 0, 255, 0])
        XCTAssertNil(HwtInspector.parseColor("red"))
        XCTAssertNil(HwtInspector.parseColor("#12345"))
    }

    func testPngSize() {
        // PNG tối thiểu: chữ ký + IHDR 466×300
        var b: [UInt8] = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52]
        b += [0, 0, 0x01, 0xd2, 0, 0, 0x01, 0x2c]
        let s = HwtInspector.pngSize(b)
        XCTAssertEqual(s?.width, 466)
        XCTAssertEqual(s?.height, 300)
        XCTAssertNil(HwtInspector.pngSize([1, 2, 3]))
        var zero = b; zero[19] = 0; zero[18] = 0; zero[17] = 0; zero[16] = 0
        XCTAssertNil(HwtInspector.pngSize(zero))
    }
}
