// Unit test cho bộ 40 kiểu kim vector.
import XCTest
import SwiftUI
@testable import WristMirror

final class HandShapesTests: XCTestCase {
    func testEveryVectorStyleHasDefinitionAndTitle() {
        let basic: Set<String> = ["bar", "pointed", "classic"]
        for st in FaceDesign.HandStyle.allCases where !basic.contains(st.rawValue) {
            XCTAssertNotNil(HandShapes.table[st.rawValue], st.rawValue)
            XCTAssertNotNil(HandShapes.titles[st.rawValue], st.rawValue)
        }
        XCTAssertEqual(HandShapes.table.count, 40)
        XCTAssertEqual(FaceDesign.HandStyle.allCases.count, 43)
    }

    func testEveryStyleDrawsOpaquePixelsInBothHands() {
        for st in FaceDesign.HandStyle.allCases {
            var d = FaceDesign()
            d.handStyle = st
            for kind in [FaceRenderer.HandKind.hour, .minute] {
                let img = FaceRenderer.handImage(kind, ambient: false, design: d)
                XCTAssertTrue(img.raster.argb.contains { ($0 >> 24) > 128 }, "\(st.rawValue) \(kind)")
            }
        }
    }

    func testOwnColorsFlagRoundTrips() throws {
        var d = FaceDesign()
        d.handStyle = .royal
        d.handOwnColors = false
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.handStyle, .royal)
        XCTAssertFalse(back.handOwnColors)
    }
}
