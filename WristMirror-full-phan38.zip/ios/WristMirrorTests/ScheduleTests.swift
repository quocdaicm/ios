// Unit test cho lịch nhắc đổi mặt đồng hồ (FaceSchedule).
import XCTest
import UserNotifications
@testable import WristMirror

final class FaceScheduleTests: XCTestCase {
    private var suite: String!
    private var defaults: UserDefaults!

    override func setUp() {
        suite = "wm-test-\(UUID().uuidString)"
        defaults = UserDefaults(suiteName: suite)
        addTeardownBlock { [suite] in UserDefaults().removePersistentDomain(forName: suite!) }
    }

    private func make(applied: @escaping ([UNNotificationRequest]) -> Void = { _ in }) -> FaceSchedule {
        let s = FaceSchedule(defaults: defaults, key: "k", apply: applied)
        s.nameProvider = { id in id == "gone" ? nil : "Mặt \(id)" }
        return s
    }

    func testNormalizeClampsAndDefaultsToEveryDay() {
        let e = ScheduleEntry(itemId: "a", hour: 99, minute: -5, weekdays: [9, 0]).normalized()
        XCTAssertEqual(e.hour, 23)
        XCTAssertEqual(e.minute, 0)
        XCTAssertEqual(e.weekdays, [1, 2, 3, 4, 5, 6, 7])
        let f = ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: [4, 2, 2]).normalized()
        XCTAssertEqual(f.weekdays, [2, 4])
    }

    func testTexts() {
        XCTAssertEqual(ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: []).normalized().timeText, "07:05")
        XCTAssertEqual(ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: []).normalized().daysText, "Mỗi ngày")
        XCTAssertEqual(ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: [2, 3, 4, 5, 6]).daysText, "Thứ 2 – Thứ 6")
        XCTAssertEqual(ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: [1, 7]).daysText, "Cuối tuần")
        XCTAssertEqual(ScheduleEntry(itemId: "a", hour: 7, minute: 5, weekdays: [1, 4, 2]).daysText, "T2, T4, CN")
    }

    func testRequestsOnePerWeekdayWithTriggerAndUserInfo() throws {
        let e = ScheduleEntry(id: "e1", itemId: "face1", hour: 6, minute: 30, weekdays: [2, 4])
        let reqs = FaceSchedule.requests(for: [e], nameFor: { "Tên \($0)" })
        XCTAssertEqual(reqs.count, 2)
        XCTAssertEqual(Set(reqs.map { $0.identifier }), ["wm.schedule.e1.2", "wm.schedule.e1.4"])
        let r = try XCTUnwrap(reqs.first { $0.identifier.hasSuffix(".4") })
        let trig = try XCTUnwrap(r.trigger as? UNCalendarNotificationTrigger)
        XCTAssertTrue(trig.repeats)
        XCTAssertEqual(trig.dateComponents.hour, 6)
        XCTAssertEqual(trig.dateComponents.minute, 30)
        XCTAssertEqual(trig.dateComponents.weekday, 4)
        XCTAssertEqual(r.content.userInfo[FaceSchedule.itemKey] as? String, "face1")
        XCTAssertTrue(r.content.body.contains("Tên face1"))
    }

    func testDisabledAndOrphanEntriesProduceNoRequests() {
        var off = ScheduleEntry(itemId: "a", hour: 1, minute: 1, weekdays: [])
        off.enabled = false
        let orphan = ScheduleEntry(itemId: "gone", hour: 1, minute: 1, weekdays: [])
        let reqs = FaceSchedule.requests(for: [off, orphan], nameFor: { $0 == "gone" ? nil : "x" })
        XCTAssertTrue(reqs.isEmpty)
    }

    func testUpsertDeleteToggleAndApplyCalled() {
        var lastCount = -1
        let s = make { lastCount = $0.count }
        let e = ScheduleEntry(itemId: "a", hour: 8, minute: 0, weekdays: [2])
        XCTAssertTrue(s.upsert(e))
        XCTAssertEqual(lastCount, 1)
        var edited = e; edited.weekdays = [2, 3]
        XCTAssertTrue(s.upsert(edited))
        XCTAssertEqual(s.entries.count, 1)
        XCTAssertEqual(lastCount, 2)
        s.setEnabled(id: e.id, false)
        XCTAssertEqual(lastCount, 0)
        s.delete(id: e.id)
        XCTAssertTrue(s.entries.isEmpty)
    }

    func testMaxEntries() {
        let s = make()
        for i in 0..<FaceSchedule.maxEntries {
            XCTAssertTrue(s.upsert(ScheduleEntry(itemId: "a", hour: i, minute: 0, weekdays: [])))
        }
        XCTAssertFalse(s.upsert(ScheduleEntry(itemId: "a", hour: 1, minute: 1, weekdays: [])))
        XCTAssertEqual(s.entries.count, FaceSchedule.maxEntries)
        // 8 lịch × 7 ngày = 56, dưới giới hạn 64 thông báo của iOS
        XCTAssertLessThanOrEqual(FaceSchedule.requests(for: s.entries, nameFor: { _ in "x" }).count, 64)
    }

    func testPersistence() {
        let s = make()
        let e = ScheduleEntry(itemId: "keep", hour: 21, minute: 15, weekdays: [1, 7])
        s.upsert(e)
        let again = make()
        XCTAssertEqual(again.entries, [e.normalized()])
    }
}
