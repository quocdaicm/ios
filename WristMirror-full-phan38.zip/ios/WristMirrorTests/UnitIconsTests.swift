// Unit test Phần 36: ký hiệu % và ° vector, biểu tượng pin / nhiệt kế vector, khung nền mới.
import XCTest
import SwiftUI
@testable import WristMirror

final class UnitIconsTests: XCTestCase {
    /// Số điểm ảnh có độ trong suốt khác 0 của ảnh `s` x `s` do `draw` vẽ.
    private func inkCount(_ s: Int, _ draw: @escaping () -> Void) -> Int {
        let r = FaceRenderer.drawRaster(width: s, height: s) { _ in draw() }
        return r.argb.filter { ($0 >> 24) != 0 }.count
    }

    func testTitleCountsMatchData() {
        XCTAssertEqual(FaceSVGIcons.batteryTitles.count, FaceSVGIcons.battery.count)
        XCTAssertEqual(FaceSVGIcons.thermoTitles.count, FaceSVGIcons.thermo.count)
        XCTAssertEqual(UnitSymbols.titles.count, 8, "0 = theo font + 7 kiểu vector")
        XCTAssertEqual(FacePlate.titles.count, 17, "0 = không + 16 khung")
    }

    func testSymbolShapesExistForAllStyles() throws {
        for st in 1..<UnitSymbols.titles.count {
            let pct = try XCTUnwrap(UnitSymbols.shape("%", style: st), "% kiểu \(st)")
            let deg = try XCTUnwrap(UnitSymbols.shape("°", style: st), "° kiểu \(st)")
            XCTAssertGreaterThan(pct.w, 20)
            XCTAssertGreaterThan(pct.h, 20)
            XCTAssertGreaterThan(deg.w, 10)
            XCTAssertLessThan(deg.w, pct.w, "° nhỏ hơn %")
            XCTAssertFalse(pct.path.boundingBox.isNull)
            // Path đã căn tâm ở gốc.
            XCTAssertEqual(pct.path.boundingBox.midX, 0, accuracy: 0.5)
            XCTAssertEqual(pct.path.boundingBox.midY, 0, accuracy: 0.5)
        }
    }

    func testSymbolOnlyForPercentAndDegree() {
        XCTAssertNil(UnitSymbols.shape("%", style: 0))
        XCTAssertNil(UnitSymbols.shape("%", style: 99))
        XCTAssertNil(UnitSymbols.shape(" bpm", style: 1))
        XCTAssertNotNil(UnitSymbols.shape(" % ", style: 1), "khoảng trắng hai đầu được bỏ")
    }

    func testVecSuffixUsesSymbolWhenSet() throws {
        let def = try XCTUnwrap(DigitalStyle.ledGreen.def)
        let font = try XCTUnwrap(FaceRenderer.vecSuffix("%", fontScale: 0.17, glyphH: 28, pad: 4, def: def, gap: 4))
        let sym = try XCTUnwrap(FaceRenderer.vecSuffix("%", fontScale: 0.17, glyphH: 28, pad: 4, def: def, gap: 4, sym: 3))
        XCTAssertNotEqual(font.labelW, sym.labelW, "ký hiệu vector khác hình chữ của font")
        let other = try XCTUnwrap(FaceRenderer.vecSuffix(" kcal", fontScale: 0.17, glyphH: 28, pad: 4, def: def, gap: 4, sym: 3))
        let base = try XCTUnwrap(FaceRenderer.vecSuffix(" kcal", fontScale: 0.17, glyphH: 28, pad: 4, def: def, gap: 4))
        XCTAssertEqual(other.labelW, base.labelW, "đơn vị khác % và ° không đổi")
    }

    func testFlatSymbolDrawsInk() {
        let numFont = UIFont.systemFont(ofSize: 34, weight: .bold)
        let unitFont = UIFont.systemFont(ofSize: 17, weight: .bold)
        for st in 1..<UnitSymbols.titles.count {
            let n = inkCount(40) {
                UnitSymbols.drawFlat("%", style: st, font: unitFont, numFont: numFont, color: .white,
                                     in: CGRect(x: 0, y: 0, width: 30, height: 40))
            }
            XCTAssertGreaterThan(n, 20, "% kiểu \(st) phải có nét")
        }
    }

    func testBatteryAndThermoIconsDrawInk() {
        for st in 1...FaceSVGIcons.battery.count {
            let n = inkCount(48) {
                FaceRenderer.drawBatteryIconStyle(st, in: CGRect(x: 0, y: 0, width: 48, height: 48), textColor: .white, mono: false)
            }
            XCTAssertGreaterThan(n, 100, "pin kiểu \(st)")
        }
        for st in 1...FaceSVGIcons.thermo.count {
            let n = inkCount(48) {
                FaceRenderer.drawThermoIcon(st, in: CGRect(x: 0, y: 0, width: 48, height: 48), textColor: .white, mono: true)
            }
            XCTAssertGreaterThan(n, 100, "nhiệt kế kiểu \(st)")
        }
    }

    func testBatteryStyleRoutedThroughDataIcon() {
        let defaultInk = inkCount(48) {
            FaceRenderer.drawDataIcon(.battery, in: CGRect(x: 0, y: 0, width: 48, height: 48), textColor: .white, mono: true, svg: true)
        }
        let styled = inkCount(48) {
            FaceRenderer.drawDataIcon(.battery, in: CGRect(x: 0, y: 0, width: 48, height: 48), textColor: .white, mono: true, svg: true,
                                      batteryStyle: 5)
        }
        XCTAssertGreaterThan(defaultInk, 0)
        XCTAssertGreaterThan(styled, 0)
        XCTAssertNotEqual(defaultInk, styled)
    }

    func testPlatesProduceMarkup() {
        for shape in 1..<FacePlate.titles.count {
            for outline in [true, false] {
                let s = FacePlate.svg(shape: shape, w: 150, h: 44, outline: outline)
                XCTAssertTrue(s.contains("<"), "khung \(shape)")
                XCTAssertFalse(s.contains("nan"), "khung \(shape) có toạ độ nan")
            }
        }
        XCTAssertEqual(FacePlate.svg(shape: 99, w: 150, h: 44, outline: true), "")
    }

    func testThermoWidensWeatherLayout() {
        var d = FaceDesign()
        d.weather.show = true
        let off = WeatherLayout(d)
        d.thermoStyle = 2
        let on = WeatherLayout(d)
        XCTAssertEqual(off.thermoS, 0)
        XCTAssertEqual(off.thermoW, 0)
        XCTAssertGreaterThan(on.thermoS, 0)
        XCTAssertGreaterThan(on.thermoW, on.thermoS)
        XCTAssertEqual(on.numX - off.numX, on.thermoW, "số nhiệt độ dời sang phải đúng bề rộng nhiệt kế")
    }

    func testCodecKeepsPhase36Fields() throws {
        var d = FaceDesign()
        d.unitSymbol = 4
        d.batteryIconStyle = 6
        d.thermoStyle = 3
        d.plates["battery"] = PlateStyle(shape: 15)
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.unitSymbol, 4)
        XCTAssertEqual(back.batteryIconStyle, 6)
        XCTAssertEqual(back.thermoStyle, 3)
        XCTAssertEqual(back.plates["battery"]?.shape, 15)
        XCTAssertEqual(FaceDesign().unitSymbol, 0, "mặc định giữ nguyên cách cũ")
        XCTAssertEqual(FaceDesign().thermoStyle, 0)
    }

    // MARK: Phần 37 – pin đổi theo mức, mã mới đọc từ 11 file HWT

    /// Tổng độ đục (alpha) của ảnh `s` x `s` do `draw` vẽ: tăng khi vẽ thêm phần đầy của pin.
    private func alphaSum(_ s: Int, _ draw: @escaping () -> Void) -> Int {
        let r = FaceRenderer.drawRaster(width: s, height: s) { _ in draw() }
        return r.argb.reduce(0) { $0 + Int($1 >> 24) }
    }

    func testPhase37CodesMatchRealFiles() {
        XCTAssertEqual(HwtValueType.batteryLevel, 54)
        XCTAssertEqual(HwtValueType.hourOfDay, 12)
        XCTAssertEqual(HwtValueType.moonPhase, 116)
        XCTAssertEqual(HwtValueType.stressLevel, 117)
        XCTAssertEqual(HwtValueType.unreadMessage, 72)
        XCTAssertEqual(HwtDataType.standHours, 15)
        XCTAssertEqual(HwtDataType.heartHigh, 18)
        XCTAssertEqual(HwtDataType.heartLow, 19)
        XCTAssertEqual(HwtDataType.stress, 26)
        XCTAssertEqual(HwtProgressCode.battery, 163)
        XCTAssertEqual(HwtProgressCode.steps, 161)
    }

    func testBatteryLevelIndexRounding() {
        XCTAssertEqual(FaceBatteryLevel.levelCount, 11)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 0), 0)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 4), 0)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 5), 1)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 78), 8, "Kozmik Beta: pin 78% hiện ảnh 8")
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 100), 10)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: 250), 10)
        XCTAssertEqual(FaceBatteryLevel.index(forPercent: -7), 0)
    }

    func testArcPathSegments() {
        func curves(_ p: String) -> Int { p.filter { $0 == "C" }.count }
        XCTAssertEqual(FaceBatteryLevel.arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 0), "")
        let a = FaceBatteryLevel.arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 36)
        XCTAssertTrue(a.hasPrefix("M50.00 10.00 "), a)
        XCTAssertEqual(curves(a), 1)
        XCTAssertEqual(curves(FaceBatteryLevel.arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 180)), 2)
        XCTAssertEqual(curves(FaceBatteryLevel.arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 324)), 4)
        let q = FaceBatteryLevel.arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 90)
        XCTAssertTrue(q.hasSuffix("90.00 50.00 "), "cung 90° kết thúc bên phải tâm: \(q)")
        XCTAssertFalse(q.contains("nan"))
    }

    func testBatteryLevelSVGForAllStylesAndLevels() {
        for style in 1...FaceBatteryLevel.titles.count {
            for level in 0...10 {
                let s = FaceBatteryLevel.svg(style: style, level: level)
                XCTAssertTrue(s.contains("<"), "kiểu \(style) mức \(level)")
                XCTAssertFalse(s.contains("nan"), "kiểu \(style) mức \(level) có toạ độ nan")
            }
        }
        XCTAssertEqual(FaceBatteryLevel.svg(style: 0, level: 5), "")
        XCTAssertEqual(FaceBatteryLevel.svg(style: 99, level: 5), "")
    }

    func testBatteryLevelIconGrowsWithLevel() {
        let box = CGRect(x: 0, y: 0, width: 64, height: 64)
        for style in 1...FaceBatteryLevel.titles.count {
            var last = -1
            for level in [0, 5, 10] {
                let n = alphaSum(64) {
                    FaceRenderer.drawBatteryLevelIcon(style: style, level: level, in: box, textColor: .white, mono: true)
                }
                XCTAssertGreaterThan(n, last, "kiểu \(style): mức \(level) phải đậm hơn mức trước")
                last = n
            }
        }
    }

    func testBatteryLevelBuildsElevenImageArray() {
        var d = FaceDesign()
        d.battery.show = true
        d.battery.icon = true
        d.batteryLevelStyle = 4
        var counter = 0
        let layers = FaceRenderer.dataLayers(d) { _ in
            counter += 1
            return counter
        }
        var found = 0
        for layer in layers {
            if case let .array(resources, _, _, valueType, _) = layer, valueType == HwtValueType.batteryLevel {
                found += 1
                XCTAssertEqual(resources.count, 11)
                XCTAssertEqual(Set(resources).count, 11, "11 ảnh khác nhau")
            }
        }
        XCTAssertEqual(found, 1)

        d.batteryLevelStyle = 0
        let plain = FaceRenderer.dataLayers(d) { _ in 1 }
        for layer in plain {
            if case let .array(_, _, _, valueType, _) = layer {
                XCTAssertNotEqual(valueType, HwtValueType.batteryLevel, "tắt thì dùng biểu tượng cố định như cũ")
            }
        }
        XCTAssertTrue(FaceRenderer.infoValueTypes({ var x = d; x.batteryLevelStyle = 2; return x }()).contains(HwtValueType.batteryLevel))
        XCTAssertFalse(FaceRenderer.infoValueTypes(d).contains(HwtValueType.batteryLevel))
    }

    func testCodecKeepsBatteryLevelStyle() throws {
        var d = FaceDesign()
        d.batteryLevelStyle = 5
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.batteryLevelStyle, 5)
        XCTAssertEqual(FaceDesign().batteryLevelStyle, 0, "mặc định giữ nguyên cách cũ")
    }

    // MARK: Phần 38 – chữ vector cho thứ và tên

    func testTextFXSpecsAndTitles() {
        XCTAssertEqual(FaceTextFX.specs.count, 24)
        XCTAssertEqual(FaceTextFX.titles.count, 25)
        XCTAssertEqual(Set(FaceTextFX.titles).count, 25, "tên kiểu không trùng")
        XCTAssertNil(FaceTextFX.spec(0))
        XCTAssertNil(FaceTextFX.spec(25))
        XCTAssertNotNil(FaceTextFX.spec(24))
        XCTAssertTrue(FaceTextFX.usesUserColor(0))
        XCTAssertFalse(FaceTextFX.usesUserColor(1))
    }

    func testTextFXDrawsEveryStyle() {
        for i in 1...FaceTextFX.specs.count {
            let s = FaceTextFX.specs[i - 1]
            let font = FaceTextFX.font(s, size: 28)
            let pad = FaceTextFX.padding(s, fontSize: 28)
            let w = 200 + 2 * pad.x
            let h = Int(ceil(font.lineHeight)) + 2 * pad.y
            let r = FaceRenderer.drawRaster(width: w, height: h) { _ in
                FaceTextFX.draw("Thứ hai", spec: s, font: font, color: .cyan, in: CGRect(x: 0, y: 0, width: w, height: h))
            }
            XCTAssertTrue(r.argb.contains { ($0 >> 24) != 0 }, "kiểu \(i) (\(s.title)) phải vẽ ra điểm ảnh")
            XCTAssertEqual(FaceTextFX.thumb(i).size, FaceTextFX.thumbSize)
        }
    }

    func testWeekdayAndNameFXLayers() {
        var d = FaceDesign()
        d.showWeekday = true
        d.showName = true
        d.nameText = "Quốc Đại"
        d.weekdayFX = 1
        d.nameFX = 4
        var count = 0
        let layers = FaceRenderer.weekdayLayers(d) { _ in count += 1; return count }
        XCTAssertEqual(count, 7)
        XCTAssertEqual(layers.count, 1)
        let L = FaceRenderer.weekdayLayout(d)
        var plain = d
        plain.weekdayFX = 0
        XCTAssertGreaterThan(L.h, FaceRenderer.weekdayLayout(plain).h, "kiểu có hoa văn cần thêm phần đệm")
        let n = FaceRenderer.nameLayout(d)
        XCTAssertNotNil(n)
        if let n = n { XCTAssertLessThanOrEqual(n.line.w, FaceRenderer.maxNameWidth) }
        count = 0
        let nl = FaceRenderer.nameLayers(d) { _ in count += 1; return count }
        XCTAssertEqual(nl.count, 1)
        XCTAssertEqual(count, 1)
    }

    func testCodecKeepsTextFX() throws {
        var d = FaceDesign()
        d.weekdayFX = 7
        d.nameFX = 13
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.weekdayFX, 7)
        XCTAssertEqual(back.nameFX, 13)
        XCTAssertEqual(FaceDesign().weekdayFX, 0)
    }
}
