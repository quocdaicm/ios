// Unit test cho phần giao thức (FrameCodec, HuaweiCrypto, ZipArchive).
// Test vector được sinh độc lập bằng Python (hashlib/hmac/cryptography/zlib), không phải từ chính code Swift.
import XCTest
@testable import WristMirror

private func hex(_ s: String) -> [UInt8] {
    var out: [UInt8] = []
    var i = s.startIndex
    while i < s.endIndex {
        let j = s.index(i, offsetBy: 2)
        out.append(UInt8(s[i..<j], radix: 16)!)
        i = j
    }
    return out
}
private func utf8(_ s: String) -> [UInt8] { Array(s.utf8) }

final class FrameCodecTests: XCTestCase {
    func testCrc16Xmodem() {
        let d = utf8("123456789")
        XCTAssertEqual(FrameCodec.crc16(d, 0, d.count), 0x31c3)
    }

    func testEncodeSingleFrameKnownBytes() throws {
        let frames = try FrameCodec.encode(service: 1, command: 5, body: [1, 2, 3], maxFrameBytes: 256)
        XCTAssertEqual(frames.count, 1)
        XCTAssertEqual(frames[0], hex("5a000600010501020335bf"))
    }

    func testDecodeSingleFrame() throws {
        let dec = FrameCodec.Decoder()
        let packets = try dec.receive(hex("5a000600010501020335bf"), now: 0)
        XCTAssertEqual(packets.count, 1)
        XCTAssertEqual(packets[0].service, 1)
        XCTAssertEqual(packets[0].command, 5)
        XCTAssertEqual(packets[0].body, [1, 2, 3])
    }

    func testSlicedRoundTripAndByteByByte() throws {
        let body = (0..<300).map { UInt8($0 & 0xff) }
        let frames = try FrameCodec.encode(service: 0x28, command: 0x02, body: body, maxFrameBytes: 64)
        XCTAssertGreaterThan(frames.count, 1)
        // Nhận cả khung một lần
        let d1 = FrameCodec.Decoder()
        var got: [FrameCodec.Packet] = []
        for f in frames { got += try d1.receive(f, now: 0) }
        XCTAssertEqual(got.count, 1)
        XCTAssertEqual(got[0].body, body)
        // Nhận từng byte một (BLE có thể cắt gói bất kỳ)
        let d2 = FrameCodec.Decoder()
        var got2: [FrameCodec.Packet] = []
        for b in frames.flatMap({ $0 }) { got2 += try d2.receive([b], now: 0) }
        XCTAssertEqual(got2.count, 1)
        XCTAssertEqual(got2[0].service, 0x28)
        XCTAssertEqual(got2[0].body, body)
        XCTAssertEqual(d2.errors, 0)
    }

    func testCorruptCrcIsRejected() throws {
        var f = hex("5a000600010501020335bf")
        f[6] ^= 0xff
        let dec = FrameCodec.Decoder()
        let packets = try dec.receive(f, now: 0)
        XCTAssertTrue(packets.isEmpty)
        XCTAssertGreaterThan(dec.errors, 0)
    }

    func testGarbageBeforeFrameResyncs() throws {
        let dec = FrameCodec.Decoder()
        let packets = try dec.receive([0x00, 0x11, 0x22] + hex("5a000600010501020335bf"), now: 0)
        XCTAssertEqual(packets.count, 1)
        XCTAssertEqual(packets[0].body, [1, 2, 3])
    }

    func testInvalidArgumentsThrow() {
        XCTAssertThrowsError(try FrameCodec.encode(service: 300, command: 1, body: [], maxFrameBytes: 64))
        XCTAssertThrowsError(try FrameCodec.encode(service: 1, command: 1, body: [], maxFrameBytes: 8))
    }
}

final class HuaweiCryptoTests: XCTestCase {
    let key32 = hex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
    let iv16 = hex("000102030405060708090a0b0c0d0e0f")
    let plain = utf8("Hello Huawei watch face 0123456789")

    func testSha256() throws {
        XCTAssertEqual(try HuaweiCrypto.sha256(utf8("abc")),
                       hex("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"))
    }

    func testHmac() throws {
        XCTAssertEqual(try HuaweiCrypto.hmac(utf8("key"), utf8("The quick brown fox jumps over the lazy dog")),
                       hex("f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"))
        // Khoá rỗng được thay bằng 1 byte 0
        XCTAssertEqual(try HuaweiCrypto.hmac([], utf8("abc")),
                       hex("fd7adb152c05ef80dccf50a1fa4c05d5a3ec6da95575fc312ae7c5d091836351"))
    }

    func testHkdf32() throws {
        // RFC 5869 test case 1 (32 byte đầu của OKM)
        let ikm = [UInt8](repeating: 0x0b, count: 22)
        let salt = hex("000102030405060708090a0b0c")
        let info = hex("f0f1f2f3f4f5f6f7f8f9")
        XCTAssertEqual(try HuaweiCrypto.hkdf32(ikm, salt, info),
                       hex("3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf"))
        // Không salt, không info
        XCTAssertEqual(try HuaweiCrypto.hkdf32(ikm, nil, nil),
                       hex("8da4e775a563c18f715f802a063c5a31b8a11f5c5ee1879ec3454e5f3c738d2d"))
    }

    func testGcm256Iv16WithAad() throws {
        let want = hex("2f09cc1a56c4025dfc88be4075d34dc737db4bc706eeb663740f7fe6baccfafd5046319b85e576d175daa152d47994c93c8c")
        let sealed = try HuaweiCrypto.aesGcmEncrypt(key32, iv16, plain, utf8("huawei-aad"))
        XCTAssertEqual(sealed, want)
        XCTAssertEqual(try HuaweiCrypto.aesGcmDecrypt(key32, iv16, want, utf8("huawei-aad")), plain)
    }

    func testGcmNoAad() throws {
        let want = hex("2f09cc1a56c4025dfc88be4075d34dc737db4bc706eeb663740f7fe6baccfafd50461d9d18598426ea4729cc31a9cfe2767c")
        XCTAssertEqual(try HuaweiCrypto.aesGcmEncrypt(key32, iv16, plain, nil), want)
    }

    func testGcm128Iv12() throws {
        let k = hex("000102030405060708090a0b0c0d0e0f")
        let iv = hex("000102030405060708090a0b")
        let want = hex("db09cba2093bbf212aa504e316d4117cd04e3a80328e98d6d610c31e2071945bbd9d4dd0747b6b2eae57e287a064e28673d4")
        XCTAssertEqual(try HuaweiCrypto.aesGcmEncrypt(k, iv, plain, utf8("huawei-aad")), want)
    }

    func testGcmEmptyPlaintext() throws {
        XCTAssertEqual(try HuaweiCrypto.aesGcmEncrypt(key32, iv16, [], nil), hex("1fe22185668c52bcacfdff70749c67b9"))
    }

    func testGcmRejectsTamperedTagAndWrongAad() throws {
        var sealed = try HuaweiCrypto.aesGcmEncrypt(key32, iv16, plain, utf8("a"))
        XCTAssertThrowsError(try HuaweiCrypto.aesGcmDecrypt(key32, iv16, sealed, utf8("b"))) { e in
            XCTAssertEqual(WMCore.code(e), "GCM_AUTHENTICATION_FAILED")
        }
        sealed[sealed.count - 1] ^= 1
        XCTAssertThrowsError(try HuaweiCrypto.aesGcmDecrypt(key32, iv16, sealed, utf8("a"))) { e in
            XCTAssertEqual(WMCore.code(e), "GCM_AUTHENTICATION_FAILED")
        }
    }

    func testCbcKnownVectorAndRoundTrip() throws {
        let want = hex("e2d2362480254806be52a59096137700c5dfd3ac9bbd7ceb328b88fabc5011f8a7986ecdb3d51f456ad0b614a9b874f6")
        XCTAssertEqual(try HuaweiCrypto.aesCbcEncrypt(key32, iv16, plain), want)
        XCTAssertEqual(try HuaweiCrypto.aesCbcDecrypt(key32, iv16, want), plain)
    }

    func testInvalidKeyLengthThrows() {
        XCTAssertThrowsError(try HuaweiCrypto.aesGcmEncrypt([UInt8](repeating: 1, count: 15), iv16, plain, nil))
    }

    func testConstantTimeEquals() {
        XCTAssertTrue(HuaweiCrypto.constantTimeEquals([1, 2, 3], [1, 2, 3]))
        XCTAssertFalse(HuaweiCrypto.constantTimeEquals([1, 2, 3], [1, 2, 4]))
        XCTAssertFalse(HuaweiCrypto.constantTimeEquals([1, 2], [1, 2, 3]))
        XCTAssertFalse(HuaweiCrypto.constantTimeEquals(nil, [1]))
    }
}

final class ZipArchiveTests: XCTestCase {
    // ZIP tạo bằng Python zipfile: "watchface.bin" (deflate, 7000 byte) + "stored.txt" (stored)
    static let zipB64 = "UEsDBBQAAAAIAAAAIQA0pbDrMQAAAFgbAAANAAAAd2F0Y2hmYWNlLmJpbu3HMQ0AIAwAMEWIGAsEHi6S+XeCASS0Xyturhk5Wt+nlZmZmZmZmZmZmZmZmZl99gBQSwMEFAAAAAAAAAAhAAhmAvQRAAAAEQAAAAoAAABzdG9yZWQudHh0cGxhaW4gc3RvcmVkIGRhdGFQSwECFAMUAAAACAAAACEANKWw6zEAAABYGwAADQAAAAAAAAAAAAAAgAEAAAAAd2F0Y2hmYWNlLmJpblBLAQIUAxQAAAAAAAAAIQAIZgL0EQAAABEAAAAKAAAAAAAAAAAAAACAAVwAAABzdG9yZWQudHh0UEsFBgAAAAACAAIAcwAAAJUAAAAAAA=="

    private func writeTemp(_ data: Data) throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("wm-test-\(UUID().uuidString).zip")
        try data.write(to: url)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }

    func testCrc32KnownValue() {
        var c = CRC32()
        c.update(utf8("123456789"))
        XCTAssertEqual(c.checksum, 0xcbf43926)
    }

    func testReadDeflateAndStored() throws {
        let url = try writeTemp(Data(base64Encoded: ZipArchiveTests.zipB64)!)
        let zip = try ZipArchive(url: url)
        XCTAssertEqual(Set(zip.entries.keys), ["watchface.bin", "stored.txt"])

        let bin = try XCTUnwrap(zip.entries["watchface.bin"])
        XCTAssertEqual(bin.method, 8)
        XCTAssertEqual(bin.size, 7000)
        XCTAssertEqual(bin.crc, 0xebb0a534)
        let binData = try zip.read(bin, max: 100_000)
        XCTAssertEqual(binData, Array(String(repeating: "WATCHFACE-BIN-", count: 500).utf8))

        let txt = try XCTUnwrap(zip.entries["stored.txt"])
        XCTAssertEqual(txt.method, 0)
        XCTAssertEqual(txt.crc, 0xf4026608)
        XCTAssertEqual(try zip.read(txt, max: 100), utf8("plain stored data"))
    }

    func testSizeLimitIsEnforced() throws {
        let url = try writeTemp(Data(base64Encoded: ZipArchiveTests.zipB64)!)
        let zip = try ZipArchive(url: url)
        let bin = try XCTUnwrap(zip.entries["watchface.bin"])
        XCTAssertThrowsError(try zip.read(bin, max: 1000))
    }

    func testExtractToFile() throws {
        let url = try writeTemp(Data(base64Encoded: ZipArchiveTests.zipB64)!)
        let zip = try ZipArchive(url: url)
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("wm-out-\(UUID().uuidString).bin")
        addTeardownBlock { try? FileManager.default.removeItem(at: out) }
        try zip.extract(try XCTUnwrap(zip.entries["stored.txt"]), to: out, maxBytes: 100)
        XCTAssertEqual(try Data(contentsOf: out), Data("plain stored data".utf8))
    }

    func testGarbageIsNotAZip() throws {
        let url = try writeTemp(Data(repeating: 0x41, count: 200))
        XCTAssertThrowsError(try ZipArchive(url: url))
    }

    func testCorruptedDataFailsCrc() throws {
        var bytes = [UInt8](Data(base64Encoded: ZipArchiveTests.zipB64)!)
        // Sửa 1 byte trong dữ liệu stored ("plain stored data"): tìm chuỗi rồi đổi ký tự đầu
        let needle = utf8("plain stored data")
        let at = try XCTUnwrap((0..<(bytes.count - needle.count)).first { Array(bytes[$0..<($0 + needle.count)]) == needle })
        bytes[at] = UInt8(ascii: "P")
        let url = try writeTemp(Data(bytes))
        let zip = try ZipArchive(url: url)
        XCTAssertThrowsError(try zip.read(try XCTUnwrap(zip.entries["stored.txt"]), max: 100)) { e in
            XCTAssertEqual(WMCore.code(e), "ZIP_CRC")
        }
    }
}
