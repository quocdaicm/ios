// Unit test cho thư viện HWT (HwtLibrary).
import XCTest
@testable import WristMirror

final class HwtLibraryTests: XCTestCase {
    private var root: URL!
    private var scratch: URL!

    override func setUpWithError() throws {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("wm-lib-\(UUID().uuidString)")
        root = base.appendingPathComponent("lib")
        scratch = base.appendingPathComponent("src")
        try FileManager.default.createDirectory(at: scratch, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: base) }
    }

    private func makeFile(_ name: String, _ content: String) throws -> URL {
        let u = scratch.appendingPathComponent(name)
        try Data(content.utf8).write(to: u)
        return u
    }

    private func add(_ lib: HwtLibrary, hash: String, title: String = "Face", preview: Bool = false) throws -> HwtLibraryItem? {
        let f = try makeFile("\(hash).hwt", "data-\(hash)")
        let p: URL? = preview ? try makeFile("\(hash).png", "png-\(hash)") : nil
        return lib.add(original: f, preview: p, sourceHash: hash, title: title, fileName: "\(hash).hwt", xmlVersion: "1.0")
    }

    func testAddStoresFileAndPreview() throws {
        let lib = HwtLibrary(root: root)
        let item = try XCTUnwrap(add(lib, hash: "aaa", title: "Mặt số A", preview: true))
        XCTAssertEqual(item.name, "Mặt số A")
        XCTAssertTrue(item.hasPreview)
        XCTAssertEqual(item.bytes, Int64("data-aaa".utf8.count))
        XCTAssertEqual(try Data(contentsOf: XCTUnwrap(lib.fileURL(item))), Data("data-aaa".utf8))
        XCTAssertNotNil(lib.previewURL(item))
        XCTAssertEqual(lib.all().count, 1)
    }

    func testDuplicateHashReturnsExisting() throws {
        let lib = HwtLibrary(root: root)
        let a = try XCTUnwrap(add(lib, hash: "same"))
        let b = try XCTUnwrap(add(lib, hash: "same", title: "Khác"))
        XCTAssertEqual(a.id, b.id)
        XCTAssertEqual(lib.all().count, 1)
    }

    func testNewestFirstAndNoPreview() throws {
        let lib = HwtLibrary(root: root)
        _ = try add(lib, hash: "one")
        let two = try XCTUnwrap(add(lib, hash: "two"))
        XCTAssertEqual(lib.all().first?.id, two.id)
        XCTAssertFalse(two.hasPreview)
        XCTAssertNil(lib.previewURL(two))
    }

    func testRenameCleansAndIgnoresEmpty() throws {
        let lib = HwtLibrary(root: root)
        let item = try XCTUnwrap(add(lib, hash: "r"))
        lib.rename(id: item.id, to: "  Tên\nmới   hay  ")
        XCTAssertEqual(lib.item(id: item.id)?.name, "Tên mới hay")
        lib.rename(id: item.id, to: "   \n ")
        XCTAssertEqual(lib.item(id: item.id)?.name, "Tên mới hay")
        lib.rename(id: item.id, to: String(repeating: "x", count: 200))
        XCTAssertEqual(lib.item(id: item.id)?.name.count, HwtLibrary.maxNameLength)
    }

    func testDeleteRemovesFiles() throws {
        let lib = HwtLibrary(root: root)
        let item = try XCTUnwrap(add(lib, hash: "d", preview: true))
        let file = try XCTUnwrap(lib.fileURL(item))
        lib.delete(id: item.id)
        XCTAssertTrue(lib.all().isEmpty)
        XCTAssertFalse(FileManager.default.fileExists(atPath: file.path))
    }

    func testPersistsAcrossReloadAndDropsMissingFiles() throws {
        let lib = HwtLibrary(root: root)
        let keep = try XCTUnwrap(add(lib, hash: "keep"))
        let gone = try XCTUnwrap(add(lib, hash: "gone"))
        lib.rename(id: keep.id, to: "Giữ lại")
        try FileManager.default.removeItem(at: XCTUnwrap(lib.fileURL(gone)))

        let reloaded = HwtLibrary(root: root)
        XCTAssertEqual(reloaded.all().map { $0.id }, [keep.id])
        XCTAssertEqual(reloaded.all().first?.name, "Giữ lại")
    }

    func testCleanName() {
        XCTAssertEqual(HwtLibrary.cleanName("a\tb\u{0}c"), "a b c")
        XCTAssertEqual(HwtLibrary.cleanName(""), "")
    }
}
