import XCTest
import SwiftUI
@testable import WristMirror

final class DesignCodecTests: XCTestCase {
    func testRoundTrip() throws {
        var d = FaceDesign()
        d.name = "Thử"
        d.showLunar = true
        d.lunarY = 0.31
        d.marks = .dots
        d.handStyle = .sword
        d.backgroundColor = Color(red: 0.2, green: 0.4, blue: 0.6)
        d.battery.show = true
        d.battery.x = 0.7
        d.decor = [DecorLayer(pattern: .gear, color: .white, opacity: 0.6, scale: 0.5, spin: .hour)]
        d.plates["steps"] = PlateStyle(shape: 2)
        let back = try XCTUnwrap(FaceDesignCodec.decode(try FaceDesignCodec.encode(d)))
        XCTAssertEqual(back.name, "Thử")
        XCTAssertTrue(back.showLunar)
        XCTAssertEqual(back.lunarY, 0.31, accuracy: 1e-9)
        XCTAssertEqual(back.marks, .dots)
        XCTAssertEqual(back.handStyle, .sword)
        XCTAssertTrue(back.battery.show)
        XCTAssertEqual(back.battery.x, 0.7, accuracy: 1e-9)
        XCTAssertEqual(back.decor.count, 1)
        XCTAssertEqual(back.decor[0].pattern, .gear)
        XCTAssertEqual(back.decor[0].spin, .hour)
        XCTAssertEqual(back.plates["steps"]?.shape, 2)
    }

    func testMissingFieldsKeepDefaults() throws {
        let json = #"{"version":1,"design":{"name":"A","marks":"khong-co-kieu-nay"}}"#
        let d = try XCTUnwrap(FaceDesignCodec.decode(Data(json.utf8)))
        XCTAssertEqual(d.name, "A")
        XCTAssertEqual(d.marks, FaceDesign().marks)
    }
}
