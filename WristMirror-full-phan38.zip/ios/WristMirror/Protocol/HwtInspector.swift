// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Báo cáo CHỈ ĐỌC về một file HWT. Không sửa file, không gửi gì tới đồng hồ.
struct HwtReport: Equatable {
    struct Image: Equatable { let name: String; let width: Int; let height: Int; let bytes: Int64 }
    struct TextStyle: Equatable, Identifiable {
        let color: String; let size: Int; let count: Int
        var id: String { "\(color)/\(size)" }
    }
    var info: [String: String] = [:]          // title, title-cn, author, designer, screen, version
    var hasBin = false
    var binBytes: Int64 = 0
    var hasConfig = false
    var elementLabels: [String] = []
    var layerCount = 0
    var textStyles: [TextStyle] = []
    var images: [Image] = []
    var backgroundResource: String?
    var canvas: (width: Int, height: Int)?
    var warnings: [String] = []

    static func == (a: HwtReport, b: HwtReport) -> Bool {
        a.info == b.info && a.hasBin == b.hasBin && a.binBytes == b.binBytes && a.hasConfig == b.hasConfig
            && a.elementLabels == b.elementLabels && a.layerCount == b.layerCount && a.textStyles == b.textStyles
            && a.images == b.images && a.backgroundResource == b.backgroundResource
            && a.canvas?.width == b.canvas?.width && a.canvas?.height == b.canvas?.height && a.warnings == b.warnings
    }
}

enum HwtInspector {
    static let maxConfigBytes = 1 * 1024 * 1024
    static let maxImages = 400
    static let maxImageBytes = 4 * 1024 * 1024
    static let maxTotalImageBytes = 48 * 1024 * 1024

    // MARK: Đọc file

    static func inspect(url: URL) throws -> HwtReport {
        var report = HwtReport()
        let outer = try ZipArchive(url: url)
        let prefix = outer.entries["com.huawei.watchface"] != nil ? "" : "watchFace/"

        if let d = outer.entries[prefix + "description.xml"], !d.isDirectory, d.size <= 64 * 1024,
           let bytes = try? outer.read(d, max: 64 * 1024) {
            report.info = parseDescription(bytes)
        } else {
            report.warnings.append(tr("Không có description.xml"))
        }

        guard let res = outer.entries[prefix + "com.huawei.watchface"], !res.isDirectory, res.size > 0,
              res.size <= WMCore.maxMember else {
            report.warnings.append(tr("Không có gói com.huawei.watchface"))
            return report
        }
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("wm-inspect-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: tmp) }
        try outer.extract(res, to: tmp, maxBytes: WMCore.maxMember)
        let inner = try ZipArchive(url: tmp)

        if let bin = inner.entries["watchface.bin"], !bin.isDirectory {
            report.hasBin = bin.size > 0
            report.binBytes = bin.size
        }
        if !report.hasBin { report.warnings.append(tr("Thiếu watchface.bin: app không thể thay file này lên đồng hồ")) }

        if let c = inner.entries["watchface/watch_face_config.xml"], !c.isDirectory, c.size <= Int64(maxConfigBytes),
           let bytes = try? inner.read(c, max: maxConfigBytes) {
            report.hasConfig = true
            let summary = parseConfig(bytes)
            report.elementLabels = summary.elementLabels
            report.layerCount = summary.layerCount
            report.textStyles = summary.textStyles
            report.backgroundResource = summary.backgroundResource
        }

        var total: Int64 = 0
        let names = inner.entries.keys
            .filter { $0.hasPrefix("watchface/res/") && $0.lowercased().hasSuffix(".png") }
            .sorted()
            .prefix(maxImages)
        for name in names {
            guard let e = inner.entries[name], !e.isDirectory, e.size > 0, e.size <= Int64(maxImageBytes),
                  total + e.size <= Int64(maxTotalImageBytes),
                  let bytes = try? inner.read(e, max: maxImageBytes), let size = pngSize(bytes) else { continue }
            total += e.size
            report.images.append(.init(name: (name as NSString).lastPathComponent, width: size.width, height: size.height, bytes: e.size))
        }
        if let bg = report.backgroundResource, let img = report.images.first(where: { $0.name == bg }) {
            report.canvas = (img.width, img.height)
        }
        if report.hasBin && !report.hasConfig {
            report.warnings.append(tr("Không có watch_face_config.xml (không đọc được màu chữ/bố cục)"))
        }
        return report
    }

    // MARK: PNG

    /// Đọc rộng/cao từ khối IHDR của PNG.
    static func pngSize(_ b: [UInt8]) -> (width: Int, height: Int)? {
        let sig: [UInt8] = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
        guard b.count >= 24, Array(b[0..<8]) == sig, Array(b[12..<16]) == [0x49, 0x48, 0x44, 0x52] else { return nil }
        func be(_ o: Int) -> Int { Int(b[o]) << 24 | Int(b[o + 1]) << 16 | Int(b[o + 2]) << 8 | Int(b[o + 3]) }
        let w = be(16), h = be(20)
        guard w > 0, h > 0, w <= 16384, h <= 16384 else { return nil }
        return (w, h)
    }

    // MARK: Màu

    /// "#AARRGGBB" hoặc "#RRGGBB" → (a, r, g, b) 0–255.
    static func parseColor(_ s: String) -> (a: Int, r: Int, g: Int, b: Int)? {
        var t = s.trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("#") { t.removeFirst() }
        guard t.count == 8 || t.count == 6, let v = UInt32(t, radix: 16) else { return nil }
        if t.count == 8 {
            return (Int(v >> 24 & 255), Int(v >> 16 & 255), Int(v >> 8 & 255), Int(v & 255))
        }
        return (255, Int(v >> 16 & 255), Int(v >> 8 & 255), Int(v & 255))
    }

    // MARK: XML

    private final class DescriptionParser: NSObject, XMLParserDelegate {
        var fields: [String: String] = [:]
        private var depth = 0
        private var current: String?
        private var text = ""
        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String] = [:]) {
            depth += 1
            if depth == 2 { current = name; text = "" }
        }
        func parser(_ parser: XMLParser, foundCharacters string: String) { if depth == 2 { text += string } }
        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
            if depth == 2, let c = current { fields[c] = text.trimmingCharacters(in: .whitespacesAndNewlines) }
            depth -= 1
        }
    }

    static func parseDescription(_ bytes: [UInt8]) -> [String: String] {
        let p = XMLParser(data: Data(bytes))
        p.shouldResolveExternalEntities = false
        let d = DescriptionParser()
        p.delegate = d
        _ = p.parse()
        let wanted: Set<String> = ["title", "title-cn", "author", "designer", "screen", "version"]
        return d.fields.filter { wanted.contains($0.key) }
    }

    struct ConfigSummary: Equatable {
        var elementLabels: [String] = []
        var layerCount = 0
        var textStyles: [HwtReport.TextStyle] = []
        var backgroundResource: String?
    }

    private final class ConfigParser: NSObject, XMLParserDelegate {
        var summary = ConfigSummary()
        private var currentLabel = ""
        private var styles: [String: (color: String, size: Int, count: Int)] = [:]
        private var order: [String] = []
        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes a: [String: String] = [:]) {
            switch name {
            case "element":
                currentLabel = a["label"] ?? ""
                if !currentLabel.isEmpty { summary.elementLabels.append(currentLabel) }
            case "layer":
                summary.layerCount += 1
                if let color = a["text_color"], !color.isEmpty {
                    let size = Int(a["text_size"] ?? "") ?? 0
                    let key = "\(color.uppercased())/\(size)"
                    if styles[key] == nil { styles[key] = (color.uppercased(), size, 0); order.append(key) }
                    styles[key]!.count += 1
                }
                if currentLabel == "background", summary.backgroundResource == nil,
                   let r = a["res_name"], !r.isEmpty {
                    summary.backgroundResource = r.split(separator: ",").first.map { String($0) }
                }
            default: break
            }
        }
        func finish() -> ConfigSummary {
            var s = summary
            s.textStyles = order.compactMap { styles[$0] }.map { HwtReport.TextStyle(color: $0.color, size: $0.size, count: $0.count) }
            return s
        }
    }

    static func parseConfig(_ bytes: [UInt8]) -> ConfigSummary {
        let p = XMLParser(data: Data(bytes))
        p.shouldResolveExternalEntities = false
        let d = ConfigParser()
        p.delegate = d
        _ = p.parse()
        return d.finish()
    }
}
