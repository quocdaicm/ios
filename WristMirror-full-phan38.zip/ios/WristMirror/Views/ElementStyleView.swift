// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Chỉnh từng mục đang bật: font riêng, cỡ chữ (pt) và hành động khi chạm trên đồng hồ.
struct ElementStyleView: View {
    @Binding var design: FaceDesign

    private var shown: [FaceElementInfo] { FaceElementInfo.all.filter { $0.show(design) } }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Font, cỡ chữ và chạm cho từng mục")).font(.headline)
            Toggle(tr("Bật vùng chạm (chạm vào mục để mở trên đồng hồ)"), isOn: $design.tapsOn)
            if shown.isEmpty {
                Text(tr("Bật một mục thông tin bên dưới để chỉnh font, cỡ chữ và chạm."))
                    .font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(shown) { info in
                row(info)
                if info.id != shown.last?.id { Divider() }
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(tr("Chạm ở mép mặt đồng hồ")).font(.subheadline.weight(.semibold))
                ForEach(TapEdge.allCases) { edge in
                    Picker(edge.title, selection: Binding<Int>(
                        get: { design.edgeAction(edge).rawValue },
                        set: { design.edgeTaps[edge.rawValue] = $0 }
                    )) {
                        ForEach(TapAction.allCases) { Text($0.title).tag($0.rawValue) }
                    }
                    .pickerStyle(.menu)
                    .disabled(!design.tapsOn)
                }
            }
            Text(tr("Vùng chạm ghi theo đúng vị trí của mục (tối thiểu 64×48 điểm). Mã hành động đối chiếu từ các file HWT thật; cần thử trên đồng hồ."))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .card()
    }

    private func row(_ info: FaceElementInfo) -> some View {
        let fontBinding = Binding<Int>(
            get: { design.elementFonts[info.key] ?? -1 },
            set: { design.elementFonts[info.key] = $0 < 0 ? nil : $0 }
        )
        let tapBinding = Binding<Int>(
            get: { design.tapAction(info.key).rawValue },
            set: { design.taps[info.key] = $0 }
        )
        let sizeBinding = Binding<Double>(
            get: { design[keyPath: info.size] },
            set: { design[keyPath: info.size] = $0 }
        )
        let points = Int((info.basePoints * Double(FaceRenderer.dataScale(sizeBinding.wrappedValue))).rounded())
        return VStack(alignment: .leading, spacing: 8) {
            Text(info.title).font(.subheadline.weight(.semibold))
            Picker(tr("Font"), selection: fontBinding) {
                Text(tr("Theo font chung")).tag(-1)
                ForEach(FaceFont.allCases) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            VStack(alignment: .leading, spacing: 2) {
                Text("\(tr("Cỡ chữ")): \(points) pt").font(.footnote).foregroundStyle(.secondary)
                Slider(value: sizeBinding, in: 0.6...1.8)
            }
            Picker(tr("Khi chạm"), selection: tapBinding) {
                ForEach(TapAction.allCases) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            .disabled(!design.tapsOn)
        }
    }
}
