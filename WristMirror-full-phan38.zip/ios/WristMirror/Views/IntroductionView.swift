// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Nội dung giới thiệu lần đầu – tương đương IntroductionContent/IntroductionDialog của Android (đã dịch).
struct IntroductionSection: Identifiable {
    let title: String
    let items: [String]
    var id: String { title }
}

enum IntroductionContent {
    static let sections: [IntroductionSection] = [
        IntroductionSection(title: "Giới thiệu dự án", items: [
            "Dùng phương pháp thay thế để cài mặt đồng hồ HWT bên thứ ba lên đồng hồ Huawei, hỗ trợ các thiết bị GT, FIT… dùng giao thức mặt đồng hồ tương thích, và cung cấp đường thay thế tài nguyên có sẵn cho firmware HarmonyOS mới khi truyền trực tiếp không hoạt động."
        ]),
        IntroductionSection(title: "Khuyến nghị sử dụng", items: [
            "App không thể kết nối đồng hồ cùng lúc với Huawei Health (Sức khoẻ). Hãy tắt hẳn Huawei Health chạy nền trước khi dùng app này. Nếu không, việc thay thế có thể thất bại!",
            "App có sẵn chức năng lấy Huawei ID bằng một chạm, nên dùng. Lưu ý: nhập sai ID sẽ khiến đồng hồ hỏi có xoá dữ liệu hay không – TUYỆT ĐỐI không bấm xác nhận!",
            "Phương pháp thay thế tương đương việc xoá mặt đồng hồ gốc, hãy tải trước mặt đồng hồ miễn phí từ Huawei Health hoặc chọn mặt đồng hồ không dùng để thay. Mặt đồng hồ bị thay có thể tải lại từ cửa hàng.",
            "App có thể không hỗ trợ chế độ toàn năng của dòng WATCH hoặc điện thoại HarmonyOS; nếu gặp vấn đề có thể dùng Gadgetbridge hoặc các công cụ tương tự để cài mặt đồng hồ bên thứ ba.",
        ]),
    ]
}

struct IntroductionView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    BrandHeader(logoSize: 96, subtitle: tr("Cài mặt đồng hồ HWT cho đồng hồ Huawei"))
                    ForEach(IntroductionContent.sections) { section in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(tr(section.title)).font(.headline).foregroundStyle(Theme.accent)
                            ForEach(section.items, id: \.self) { item in
                                HStack(alignment: .top, spacing: 8) {
                                    Text("•")
                                    Text(tr(item)).fixedSize(horizontal: false, vertical: true)
                                }
                                .font(.subheadline)
                            }
                        }
                        .card()
                    }
                    Text(tr("Đây là nội dung giới thiệu cục bộ, không phải sự chấp thuận của hãng. Tính tương thích nêu trên là lý thuyết, không phải cam kết đã kiểm chứng trên máy thật."))
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle(tr("Giới thiệu"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) { LanguageMenuButton() }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    _ = vm.acknowledgeIntroduction()
                } label: {
                    Text(tr("Tôi đã đọc"))
                }
                .buttonStyle(PrimaryButtonStyle())
                .padding()
                .background(.ultraThinMaterial)
            }
        }
        .interactiveDismissDisabled(true)
    }
}
