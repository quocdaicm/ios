// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Nút lá cờ ở góc trên: hiện cờ của ngôn ngữ đang dùng, chạm để chọn Tiếng Việt / English.
struct LanguageMenuButton: View {
    @ObservedObject private var store = LangStore.shared

    var body: some View {
        Menu {
            ForEach(AppLang.allCases) { l in
                Button {
                    store.lang = l
                } label: {
                    if store.lang == l {
                        Label(l.flag + "  " + l.name, systemImage: "checkmark")
                    } else {
                        Text(l.flag + "  " + l.name)
                    }
                }
            }
        } label: {
            Text(store.lang.flag)
                .font(.title2)
                .frame(width: 42, height: 42)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().stroke(Color.primary.opacity(0.12), lineWidth: 1))
        }
        .accessibilityLabel("Language")
    }
}

/// Dòng chọn ngôn ngữ trong Cài đặt.
struct LanguagePickerRow: View {
    @ObservedObject private var store = LangStore.shared

    var body: some View {
        Picker(selection: Binding(get: { store.lang }, set: { store.lang = $0 })) {
            ForEach(AppLang.allCases) { l in
                Text(l.flag + "  " + l.name).tag(l)
            }
        } label: {
            HStack(spacing: 12) {
                IconBadge(systemName: "globe")
                Text(tr("Ngôn ngữ"))
            }
        }
    }
}
