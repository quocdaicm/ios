// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Tài nguyên vẽ sẵn

/// Các lớp đã vẽ sẵn thành ảnh để xoay trực tiếp (không vẽ lại cả mặt đồng hồ mỗi khung hình).
/// Dựng lại mỗi khi thiết kế đổi (xem `StudioModel.refreshPreview`).
final class LiveFaceAssets {
    enum Kind: Equatable {
        case spin(DecorSpin)   // lớp trang trí quay theo kim
        case hour, minute, second
        case cap               // nắp trục kim (không quay)
        case anim(cx: CGFloat, cy: CGFloat, period: Double, reverse: Bool)  // hoạt ảnh xoay liên tục
    }

    struct Part {
        let image: UIImage
        /// Trục xoay, tính bằng điểm ảnh của `image`.
        let pivot: CGPoint
        /// Số điểm ảnh của `image` trên một đơn vị toạ độ mặt đồng hồ (466 đơn vị).
        let unit: CGFloat
        let kind: Kind
    }

    let ambient: Bool
    /// Nền + vạch + thông tin (không có kim). Đã cắt tròn, ngoài vòng là đen.
    let base: UIImage
    /// 10 khung hiệu ứng theo giây (rỗng nếu không dùng), vẽ trên nền và dưới kim.
    let fxFrames: [UIImage]
    let parts: [Part]
    /// Các dải hạt rơi (tuyết/lá/hoa), vẽ trên nền và dưới kim.
    let fall: [FallPreview]

    struct FallPreview {
        let frames: [UIImage]
        let x: CGFloat
        let width: CGFloat
        let period: Double
    }

    private init(ambient: Bool, base: UIImage, fxFrames: [UIImage], parts: [Part], fall: [FallPreview]) {
        self.ambient = ambient
        self.base = base
        self.fxFrames = fxFrames
        self.parts = parts
        self.fall = fall
    }

    static func build(design d: FaceDesign, ambient: Bool, pixels: Int) -> LiveFaceAssets {
        let size = FaceRenderer.size
        let s = CGFloat(pixels) / size
        let rect = CGRect(x: 0, y: 0, width: pixels, height: pixels)

        let opaqueFmt = UIGraphicsImageRendererFormat.default()
        opaqueFmt.scale = 1
        opaqueFmt.opaque = true
        let base = UIGraphicsImageRenderer(size: rect.size, format: opaqueFmt).image { c in
            UIColor.black.setFill()
            c.fill(rect)
            let ctx = c.cgContext
            ctx.saveGState()
            ctx.scaleBy(x: s, y: s)
            ctx.addEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            ctx.clip()
            FaceRenderer.drawBackground(ctx, design: d, ambient: ambient)
            if !ambient || d.aodShowInfo { FaceRenderer.drawInfoPreview(ctx, design: d) }
            ctx.restoreGState()
        }

        var fx = [UIImage]()
        if !ambient && d.secondFX != .none {
            let clear = UIGraphicsImageRendererFormat.default()
            clear.scale = 1
            clear.opaque = false
            let color = UIColor(d.secondFXColor)
            for f in 0..<SecondFX.frameCount {
                fx.append(UIGraphicsImageRenderer(size: rect.size, format: clear).image { c in
                    c.cgContext.scaleBy(x: s, y: s)
                    FaceRenderer.drawSecondFX(c.cgContext, style: d.secondFX, color: color, frame: f)
                })
            }
        }

        var parts = [Part]()

        // Lớp trang trí quay (chỉ ban ngày), vẽ dưới kim như `drawComposite`.
        if !ambient {
            let clearFmt = UIGraphicsImageRendererFormat.default()
            clearFmt.scale = 1
            clearFmt.opaque = false
            for l in d.decor where l.spin != .none {
                let img = UIGraphicsImageRenderer(size: rect.size, format: clearFmt).image { c in
                    let ctx = c.cgContext
                    ctx.scaleBy(x: s, y: s)
                    ctx.translateBy(x: FaceRenderer.center, y: FaceRenderer.center)
                    FaceRenderer.drawDecorLayer(ctx, l)
                }
                parts.append(Part(image: img, pivot: CGPoint(x: CGFloat(pixels) / 2, y: CGFloat(pixels) / 2),
                                  unit: s, kind: .spin(l.spin)))
            }
        }

        // Hạt rơi: phát lần lượt các khung đã vẽ, đúng như đồng hồ sẽ phát.
        var fall = [FallPreview]()
        if !ambient && d.animOn && d.animKind.isFall {
            let ms = min(AnimFX.maxInterval, max(AnimFX.minInterval, Int(d.animInterval.rounded())))
            for strip in FaceRenderer.fallStrips(d) {
                let imgs: [UIImage] = strip.frames.compactMap { r in
                    FaceRenderer.cgImage(r).map { UIImage(cgImage: $0, scale: 1, orientation: .up) }
                }
                if imgs.count == strip.frames.count {
                    fall.append(FallPreview(frames: imgs, x: CGFloat(strip.x), width: CGFloat(strip.width),
                                            period: Double(ms * imgs.count) / 1000))
                }
            }
        }

        // Hoạt ảnh xoay liên tục: vẽ khung 0 rồi xoay theo thời gian (24 nấc như trên đồng hồ).
        if !ambient && d.animOn && !d.animKind.isFall {
            let pl = FaceRenderer.animPlacement(d)
            if let cg = FaceRenderer.cgImage(FaceRenderer.animFrame(d, 0)) {
                let ms = min(AnimFX.maxInterval, max(AnimFX.minInterval, Int(d.animInterval.rounded())))
                parts.append(Part(image: UIImage(cgImage: cg, scale: 1, orientation: .up),
                                  pivot: CGPoint(x: CGFloat(pl.side) / 2, y: CGFloat(pl.side) / 2), unit: 1,
                                  kind: .anim(cx: CGFloat(pl.x + pl.side / 2), cy: CGFloat(pl.y + pl.side / 2),
                                              period: Double(ms * AnimFX.frameCount) / 1000, reverse: d.animReverse)))
            }
        }

        func hand(_ kind: FaceRenderer.HandKind, _ k: Kind) {
            let h = FaceRenderer.handImage(kind, ambient: ambient, design: d)
            guard let cg = FaceRenderer.cgImage(h.raster) else { return }
            parts.append(Part(image: UIImage(cgImage: cg, scale: 1, orientation: .up),
                              pivot: CGPoint(x: CGFloat(h.pivotX), y: CGFloat(h.pivotY)), unit: 1, kind: k))
        }
        hand(.hour, .hour)
        hand(.minute, .minute)
        if !ambient {
            if d.showSecond { hand(.second, .second) }
            if let cg = FaceRenderer.cgImage(FaceRenderer.capImage(design: d)) {
                parts.append(Part(image: UIImage(cgImage: cg, scale: 1, orientation: .up),
                                  pivot: CGPoint(x: 12, y: 12), unit: 1, kind: .cap))
            }
        }
        return LiveFaceAssets(ambient: ambient, base: base, fxFrames: fx, parts: parts, fall: fall)
    }
}

// MARK: - Mặt đồng hồ chạy trực tiếp

struct LiveFaceTime: Equatable {
    var hour: Int
    var minute: Int
    var second: Double
}

/// Vẽ mặt đồng hồ đang chạy: kim và lớp quay xoay theo giờ thật (hoặc giờ cố định).
/// Kim giây quét mượt; bản AOD chỉ cập nhật mỗi giây và không có kim giây.
struct LiveFaceView: View {
    let assets: LiveFaceAssets
    /// nil = giờ thật của điện thoại.
    var fixed: LiveFaceTime?

    private func current(_ date: Date) -> LiveFaceTime {
        if let f = fixed { return f }
        let c = Calendar.current.dateComponents([.hour, .minute, .second, .nanosecond], from: date)
        let sec = Double(c.second ?? 0) + Double(c.nanosecond ?? 0) / 1_000_000_000
        return LiveFaceTime(hour: c.hour ?? 0, minute: c.minute ?? 0, second: sec)
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: assets.ambient ? 1.0 : 1.0 / 30.0)) { tl in
            Canvas { gc, size in
                let t = current(tl.date)
                let k = size.width / FaceRenderer.size
                gc.draw(Image(uiImage: assets.base), in: CGRect(origin: .zero, size: size))
                if !assets.fxFrames.isEmpty {
                    let idx = Int(t.second) % assets.fxFrames.count
                    gc.draw(Image(uiImage: assets.fxFrames[idx]), in: CGRect(origin: .zero, size: size))
                }

                let nowRef = tl.date.timeIntervalSinceReferenceDate
                for f in assets.fall where !f.frames.isEmpty {
                    let phase = (nowRef / f.period).truncatingRemainder(dividingBy: 1)
                    let idx = min(f.frames.count - 1, Int(phase * Double(f.frames.count)))
                    gc.draw(Image(uiImage: f.frames[idx]),
                            in: CGRect(x: f.x * k, y: 0, width: f.width * k, height: FaceRenderer.size * k))
                }

                let sec = assets.ambient ? Double(Int(t.second)) : t.second
                let hAngle = (Double(t.hour % 12) + Double(t.minute) / 60) * Double.pi / 6
                let mAngle = (Double(t.minute) + sec / 60) * Double.pi / 30
                let sAngle = sec * Double.pi / 30

                for p in assets.parts {
                    let angle: Double
                    switch p.kind {
                    case .hour: angle = hAngle
                    case .minute: angle = mAngle
                    case .second: angle = sAngle
                    case .cap: angle = 0
                    case let .anim(_, _, period, reverse):
                        let ref = tl.date.timeIntervalSinceReferenceDate
                        let step = floor((ref / period).truncatingRemainder(dividingBy: 1) * Double(AnimFX.frameCount))
                        angle = step * 2 * Double.pi / Double(AnimFX.frameCount) * (reverse ? -1 : 1)
                    case let .spin(which):
                        switch which {
                        case .hour: angle = hAngle
                        case .minute: angle = mAngle
                        default: angle = sAngle
                        }
                    }
                    let w = p.image.size.width / p.unit * k
                    let h = p.image.size.height / p.unit * k
                    let px = p.pivot.x / p.unit * k
                    let py = p.pivot.y / p.unit * k
                    var c = gc
                    if case let .anim(cx, cy, _, _) = p.kind {
                        c.translateBy(x: cx * k, y: cy * k)
                    } else {
                        c.translateBy(x: size.width / 2, y: size.height / 2)
                    }
                    c.rotate(by: Angle.radians(angle))
                    c.draw(Image(uiImage: p.image), in: CGRect(x: -px, y: -py, width: w, height: h))
                }
            }
        }
        .aspectRatio(1, contentMode: .fit)
        .allowsHitTesting(false)
    }
}

// MARK: - Vòng sáng quay quanh bản xem trước

struct GlowRing: View {
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { tl in
            let t = tl.date.timeIntervalSinceReferenceDate
            Circle()
                .strokeBorder(
                    AngularGradient(colors: [Theme.cyan, Theme.accent, Theme.accent2, Theme.cyan],
                                    center: .center, angle: Angle.degrees(t * 45)),
                    lineWidth: 3)
                .opacity(0.85)
                .blur(radius: 0.6)
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Hiệu ứng xuất hiện lần lượt của các thẻ

struct StaggerIn: ViewModifier {
    let index: Int
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 18)
            .onAppear {
                guard !shown else { return }
                withAnimation(.spring(response: 0.5, dampingFraction: 0.82).delay(Double(min(index, 8)) * 0.06)) {
                    shown = true
                }
            }
    }
}

extension View {
    /// Thẻ trượt lên và hiện dần theo thứ tự `index`.
    func staggerIn(_ index: Int) -> some View { modifier(StaggerIn(index: index)) }
}
