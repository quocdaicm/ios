// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Gốc giao diện: 4 tab + các hộp thoại dùng chung (xác nhận, mã PIN, tiến độ thao tác).
struct RootView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var notice = ""
    @State private var tab = 0
    @ObservedObject private var langStore = LangStore.shared

    var body: some View {
        TabView(selection: $tab) {
            HomeView()
                .id(langStore.lang)
                .tabItem { Label(tr("Trang chủ"), systemImage: "house.fill") }
                .tag(0)
            DeviceView(onOpenFaces: { tab = 2 })
                .id(langStore.lang)
                .tabItem { Label(tr("Thiết bị"), systemImage: "applewatch") }
                .tag(1)
            FacesView()
                .id(langStore.lang)
                .tabItem { Label(tr("Mặt đồng hồ"), systemImage: "square.grid.2x2") }
                .tag(2)
            SettingsView()
                .id(langStore.lang)
                .tabItem { Label(tr("Cài đặt"), systemImage: "gearshape") }
                .tag(3)
        }
        .onAppear {
            vm.connectAtStartup()
            ScheduleNotificationRouter.shared.handler = { id in
                tab = 2
                vm.openScheduled(itemId: id)
            }
        }
        .fullScreenCover(isPresented: Binding(get: { vm.ui.introductionPending }, set: { _ in })) {
            IntroductionView()
                .id(langStore.lang)
        }
        .alert(tr(vm.ui.prompt?.title ?? ""), isPresented: Binding(get: { vm.ui.prompt != nil }, set: { _ in }), presenting: vm.ui.prompt) { p in
            Button(tr(p.positiveLabel), role: p.destructive ? .destructive : nil) { vm.confirmAction(token: p.token) }
            Button(tr(p.negativeLabel), role: .cancel) { vm.dismissAction(token: p.token) }
        } message: { p in
            Text(tr(p.message))
        }
        .sheet(isPresented: Binding(get: { vm.ui.needsPin }, set: { _ in })) {
            PinSheet()
                .id(langStore.lang)
                .interactiveDismissDisabled(true)
        }
        .sheet(isPresented: Binding(get: { vm.ui.operationDialog != nil }, set: { _ in })) {
            OperationSheet()
                .id(langStore.lang)
                .interactiveDismissDisabled(true)
        }
        .overlay(alignment: .top) {
            if !notice.isEmpty {
                Text(tr(notice))
                    .font(.footnote)
                    .padding(10)
                    .frame(maxWidth: .infinity)
                    .background(.ultraThinMaterial)
                    .transition(.move(edge: .top))
            }
        }
        .onChange(of: vm.ui.noticeSerial) { serial in
            withAnimation { notice = vm.ui.noticeMessage }
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                if vm.ui.noticeSerial == serial { withAnimation { notice = "" } }
            }
        }
    }
}

struct PinSheet: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var pin = ""

    var body: some View {
        NavigationStack {
            Form {
                Section { Text(tr(vm.ui.pinMessage)) }
.glassRows()
                Section(tr("Mã ghép nối")) {
                    TextField(tr("Nhập mã"), text: $pin)
                        .keyboardType(.numberPad)
                        .textContentType(.oneTimeCode)
                }
.glassRows()
                Section {
                    Button(tr("Gửi mã")) { vm.submitPin(expectedEpoch: vm.ui.connectionEpoch, pin: pin); pin = "" }
                        .disabled(pin.trimmingCharacters(in: .whitespaces).isEmpty)
                    Button(tr("Huỷ kết nối"), role: .cancel) { vm.cancelPin(expectedEpoch: vm.ui.connectionEpoch); pin = "" }
                }
.glassRows()
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle(tr("Mã ghép nối"))
        }
    }
}

/// Tiến độ/kết quả thay – xoá – bật. Đang chạy: không đóng được (trừ "Ngắt" cho thay thế).
struct OperationSheet: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        NavigationStack {
            if let d = vm.ui.operationDialog {
                List {
                    Section {
                        Text(tr(d.title)).font(.headline)
                        if !d.fileName.isEmpty { Label(tr(d.fileName), systemImage: "doc") }
                        Text(trf("ID %@ · phiên bản %@", d.targetId, d.targetVersion)).font(.footnote).foregroundStyle(.secondary)
                    }
.glassRows()
                    Section(tr("Trạng thái")) {
                        if d.operation.active {
                            if let p = d.operation.progress {
                                ProgressView(value: Double(max(0, min(100, p))), total: 100)
                                Text("\(p)%").font(.footnote).foregroundStyle(.secondary)
                            } else {
                                ProgressView()
                            }
                        }
                        Text(tr(d.operation.detail))
                            .foregroundStyle(d.operation.failed ? Color.red : Color.primary)
                    }
.glassRows()
                    Section {
                        if d.operation.active {
                            if d.operation.kind == "replacement" {
                                Button(tr("Ngắt thao tác"), role: .destructive) { vm.interruptReplacement(token: d.token) }
                                    .disabled(d.interruptRequested)
                            }
                            Text(tr("Hãy giữ app mở và đồng hồ ở gần cho tới khi xong."))
                                .font(.footnote).foregroundStyle(.secondary)
                        } else {
                            Button(tr("Đóng")) { dismiss(d) }
                        }
                    }
.glassRows()
                }
                .scrollContentBackground(.hidden)
                .background(AppBackground())
                .navigationTitle(tr(title(for: d.operation.kind)))
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }

    private func title(for kind: String) -> String {
        switch kind {
        case "deletion": return tr("Xoá mặt đồng hồ")
        case "activation": return tr("Bật mặt đồng hồ")
        default: return tr("Thay mặt đồng hồ")
        }
    }

    private func dismiss(_ d: ReplacementDialogInfo) {
        switch d.operation.kind {
        case "deletion": vm.dismissDeletionResult(token: d.token)
        case "activation": vm.dismissActivationResult(token: d.token)
        default: vm.dismissReplacementResult(token: d.token)
        }
    }
}
