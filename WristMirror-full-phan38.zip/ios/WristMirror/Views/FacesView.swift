// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UniformTypeIdentifiers

/// Tab "Mặt đồng hồ" – thẻ file HWT, nút thao tác, danh sách mặt đồng hồ dạng thẻ.
struct FacesView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var importing = false
    @State private var showSource = false
    @State private var expandedId: String?

    private var busy: Bool { vm.ui.operation.active }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 16) {
                    sourceCard
                    actions
                    LibrarySection(library: vm.library)
                    facesSection
                }
                .padding(16)
            }
            .background(AppBackground())
            .navigationTitle(tr("Mặt đồng hồ"))
            // Ẩn thanh tiêu đề của tab gốc để nội dung full màn (màn con vẫn có nút quay lại).
            .toolbar(.hidden, for: .navigationBar)
            // Dùng UIDocumentPickerViewController (asCopy) thay cho .fileImporter của SwiftUI:
            // nhận mọi loại file (.item) và nhận bản sao trong thư mục tạm, không cần quyền security-scoped.
            .sheet(isPresented: $importing) {
                HwtDocumentPicker(
                    onPick: { url in
                        importing = false
                        vm.logPick("RESULT ext=\(url.pathExtension.lowercased())")
                        vm.importHwt(url)
                    },
                    onCancel: {
                        importing = false
                        vm.logPick("CANCELLED")
                        vm.cancelHwtPick()
                    }
                )
                .ignoresSafeArea()
            }
        }
    }

    // MARK: Nút thao tác

    private var actions: some View {
        VStack(spacing: 10) {
            Button {
                vm.logPick("BUTTON_TAPPED")
                importing = true
            } label: {
                Label(tr("Chọn file HWT"), systemImage: "doc.badge.plus")
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)

            NavigationLink {
                StudioView()
            } label: {
                Label(tr("Tạo mặt đồng hồ mới"), systemImage: "wand.and.stars")
            }
            .buttonStyle(SecondaryButtonStyle())
            .disabled(busy)

            HStack(spacing: 10) {
                Button { vm.refreshFaces() } label: {
                    Label(tr(vm.ui.listRefreshing ? tr("Đang làm mới") : tr("Làm mới")), systemImage: "arrow.clockwise")
                }
                .buttonStyle(SecondaryButtonStyle())
                .disabled(!vm.ui.connected || vm.ui.listRefreshing || busy)

                Button { vm.clearCache() } label: { Label(tr("Xoá bộ nhớ đệm"), systemImage: "trash") }
                    .buttonStyle(SecondaryButtonStyle())
                    .disabled(busy)
            }
        }
    }

    // MARK: Danh sách mặt đồng hồ

    private var facesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(tr("Mặt đồng hồ trên đồng hồ")).font(.headline).padding(.leading, 4)
            if !vm.ui.connected {
                placeholder(tr("Chưa kết nối đồng hồ"), tr("Hãy kết nối đồng hồ ở tab Thiết bị."))
            } else if vm.ui.listRefreshing {
                HStack(spacing: 10) { ProgressView(); Text(tr("Đang đọc mặt đồng hồ")) }.card()
            } else if !vm.ui.listReady {
                placeholder(tr("Đang chờ đọc mặt đồng hồ"), tr("Chạm làm mới và chờ đồng hồ trả về danh sách."))
            } else if vm.ui.faces.isEmpty {
                placeholder(tr("Đồng hồ trả về danh sách rỗng"), tr("Chạm làm mới để thử lại."))
            }
            if vm.ui.quarantine {
                Text(tr("Thao tác thiết bị đã tạm dừng, hãy ngắt rồi kết nối lại."))
                    .foregroundStyle(Color.orange).card()
            }
            ForEach(vm.ui.faces) { face in
                FaceCard(face: face,
                         expanded: expandedId == face.id,
                         toggle: { withAnimation { expandedId = (expandedId == face.id) ? nil : face.id } })
            }
        }
    }

    private func placeholder(_ title: String, _ message: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(tr(title))
            Text(tr(message)).font(.footnote).foregroundStyle(.secondary)
        }
        .card()
    }

    // MARK: Thẻ file HWT

    private var sourceCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("File HWT").font(.headline)
            if let s = vm.ui.source {
                if let p = s.previewPath, let img = UIImage(contentsOfFile: p) {
                    Image(uiImage: img)
                        .resizable().scaledToFit()
                        .frame(maxHeight: 180)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .frame(maxWidth: .infinity)
                }
                Button {
                    withAnimation { showSource.toggle() }
                } label: {
                    HStack {
                        Image(systemName: "doc.zipper").foregroundStyle(Theme.accent)
                        Text(tr(s.fileName)).lineLimit(1).truncationMode(.middle)
                        Spacer()
                        Image(systemName: showSource ? "chevron.up" : "chevron.down").font(.footnote)
                    }
                }
                .foregroundStyle(.primary)
                if showSource {
                    InfoRow(label: tr("Tên mặt đồng hồ"), value: s.title)
                    InfoRow(label: tr("Dung lượng file gốc"), value: ByteCountFormatter.string(fromByteCount: s.sourceBytes, countStyle: .file))
                    InfoRow(label: tr("Nội dung sẽ truyền"), value: ByteCountFormatter.string(fromByteCount: Int64(s.payloadBytes), countStyle: .file))
                    InfoRow(label: tr("Phiên bản file"), value: s.xmlVersion.isEmpty ? tr("Không có") : s.xmlVersion)
                }
            } else {
                HStack(spacing: 10) {
                    Image(systemName: "tray").foregroundStyle(.secondary)
                    Text(tr("Chưa chọn file HWT")).foregroundStyle(.secondary)
                }
            }
            if vm.ui.operation.kind == "source" && vm.ui.operation.active {
                HStack { ProgressView(); Text(tr(vm.ui.operation.detail)) }
            }
        }
        .card()
    }
}

/// Thẻ mặt đồng hồ mở rộng được (FaceCard + FaceCardActions của Android).
struct FaceCard: View {
    @EnvironmentObject var vm: WatchViewModel
    let face: FaceItem
    let expanded: Bool
    let toggle: () -> Void

    private var locked: Bool {
        !vm.ui.connected || !vm.ui.listReady || vm.ui.listRefreshing || vm.ui.quarantine || vm.ui.operation.active
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button(action: toggle) {
                HStack(spacing: 12) {
                    Image(systemName: face.current ? "checkmark.circle.fill" : "clock")
                        .font(.title3)
                        .foregroundStyle(face.current ? Theme.accent : Color.secondary)
                    Text(tr(face.title)).font(.headline).lineLimit(1)
                    Spacer()
                    if face.current {
                        Text(tr("Đang dùng"))
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(Theme.accent.opacity(0.14))
                            .foregroundStyle(Theme.accent)
                            .clipShape(Capsule())
                    }
                    Image(systemName: expanded ? "chevron.up" : "chevron.down").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .foregroundStyle(.primary)
            if expanded {
                VStack(spacing: 6) {
                    InfoRow(label: tr("Phiên bản"), value: face.version.isEmpty ? tr("Đồng hồ không cung cấp") : face.version)
                    InfoRow(label: "ID", value: face.id)
                    InfoRow(label: tr("Loại"), value: face.kind)
                }
                HStack(spacing: 8) {
                    Button(tr("Thay thế")) { vm.requestReplacement(face: face, epoch: vm.ui.connectionEpoch) }
                        .buttonStyle(PrimaryButtonStyle())
                        .disabled(!face.selectable || vm.ui.source == nil)
                    Button(tr("Bật")) { vm.requestActivation(face: face, epoch: vm.ui.connectionEpoch) }
                        .buttonStyle(SecondaryButtonStyle())
                        .disabled(!face.activatable || face.current)
                    Button(tr("Xoá")) { vm.requestDeletion(face: face, epoch: vm.ui.connectionEpoch) }
                        .buttonStyle(SecondaryButtonStyle(color: Color.red))
                        .disabled(!face.selectable)
                }
                .disabled(locked)
            }
        }
        .card()
        .overlay(
            RoundedRectangle(cornerRadius: Theme.cardRadius, style: .continuous)
                .stroke(face.current ? Theme.accent : Color.clear, lineWidth: 2)
        )
    }
}

/// Bộ chọn file của hệ thống (UIKit), nhận mọi loại file.
struct HwtDocumentPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.item], asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void
        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let u = urls.first { onPick(u) } else { onCancel() }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}
