// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Màn xem thông tin file HWT (chỉ đọc).
struct HwtInfoView: View {
    let url: URL
    @State private var report: HwtReport?
    @State private var failure: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let r = report {
                    content(r)
                } else if let f = failure {
                    Text(trf("Không đọc được file: %@", f)).foregroundStyle(Color.orange).card()
                } else {
                    HStack(spacing: 10) { ProgressView(); Text(tr("Đang đọc file")) }.card()
                }
            }
            .padding(16)
        }
        .background(AppBackground())
        .navigationTitle(tr("Thông tin file"))
        .navigationBarTitleDisplayMode(.inline)
        .task {
            let u = url
            do {
                report = try await Task.detached(priority: .utility) { try HwtInspector.inspect(url: u) }.value
            } catch {
                failure = WMCore.code(error)
            }
        }
    }

    @ViewBuilder private func content(_ r: HwtReport) -> some View {
        VStack(spacing: 6) {
            InfoRow(label: tr("Tên"), value: r.info["title"] ?? tr("Không có"))
            if let cn = r.info["title-cn"], !cn.isEmpty { InfoRow(label: tr("Tên (CN)"), value: cn) }
            InfoRow(label: tr("Tác giả"), value: r.info["author"] ?? tr("Không có"))
            InfoRow(label: tr("Nhà thiết kế"), value: r.info["designer"] ?? tr("Không có"))
            InfoRow(label: tr("Mã màn hình"), value: r.info["screen"] ?? tr("Không có"))
            InfoRow(label: tr("Phiên bản"), value: r.info["version"] ?? tr("Không có"))
        }
        .card()

        VStack(alignment: .leading, spacing: 8) {
            Text(tr("Kiểm tra")).font(.headline)
            check(r.hasBin, tr("watchface.bin (phần app gửi lên đồng hồ)"),
                  r.hasBin ? ByteCountFormatter.string(fromByteCount: r.binBytes, countStyle: .file) : tr("thiếu"))
            check(r.hasConfig, tr("Bản thiết kế watch_face_config.xml"), r.hasConfig ? trf("%@ lớp", r.layerCount) : tr("không có"))
            if let c = r.canvas {
                check(true, tr("Kích thước ảnh nền"), "\(c.width) × \(c.height) px")
            }
            ForEach(r.warnings, id: \.self) { w in
                Label(tr(w), systemImage: "exclamationmark.triangle.fill").font(.footnote).foregroundStyle(Color.orange)
            }
        }
        .card()

        if !r.textStyles.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text(tr("Chữ")).font(.headline)
                ForEach(r.textStyles) { s in
                    HStack(spacing: 10) {
                        swatch(s.color)
                        Text(tr(s.color)).font(.system(.footnote, design: .monospaced))
                        Spacer()
                        Text(trf("cỡ %@ · %@ chỗ", s.size, s.count)).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .card()
        }

        if !r.images.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                let total = r.images.reduce(Int64(0)) { $0 + $1.bytes }
                Text(trf("Ảnh (%@ · %@)", r.images.count, ByteCountFormatter.string(fromByteCount: total, countStyle: .file))).font(.headline)
                ForEach(Array(r.images.sorted { $0.bytes > $1.bytes }.prefix(12)), id: \.name) { i in
                    HStack {
                        Text(tr(i.name)).font(.system(.footnote, design: .monospaced))
                        Spacer()
                        Text("\(i.width)×\(i.height) · \(ByteCountFormatter.string(fromByteCount: i.bytes, countStyle: .file))")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                if r.images.count > 12 { Text(trf("… và %@ ảnh nhỏ hơn", r.images.count - 12)).font(.footnote).foregroundStyle(.secondary) }
            }
            .card()
        }

        Text(tr("Chỉ để xem. Đồng hồ chỉ đọc watchface.bin; ảnh và màu ở đây là bản thiết kế nguồn, sửa chúng không làm đổi mặt đồng hồ thật."))
            .font(.footnote).foregroundStyle(.secondary).padding(.horizontal, 4)
    }

    private func check(_ ok: Bool, _ title: String, _ detail: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "xmark.circle.fill").foregroundStyle(ok ? Color.green : Color.red)
            Text(tr(title)).font(.subheadline)
            Spacer()
            Text(tr(detail)).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func swatch(_ hex: String) -> some View {
        let c = HwtInspector.parseColor(hex)
        let color = c.map { Color(.sRGB, red: Double($0.r) / 255, green: Double($0.g) / 255, blue: Double($0.b) / 255, opacity: Double($0.a) / 255) } ?? Color.gray
        return RoundedRectangle(cornerRadius: 6, style: .continuous)
            .fill(color)
            .frame(width: 26, height: 26)
            .overlay(RoundedRectangle(cornerRadius: 6, style: .continuous).stroke(Color.secondary.opacity(0.4), lineWidth: 1))
    }
}
