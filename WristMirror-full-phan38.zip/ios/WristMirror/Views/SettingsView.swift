// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Tương đương SettingsScreen.kt: tự kết nối, chủ đề, nhật ký, giới thiệu.
struct SettingsView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    BrandHeader()
                }
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
                Section {
                    Toggle(isOn: Binding(get: { vm.ui.autoConnect }, set: { vm.setAutoConnect($0) })) {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "bolt.horizontal.fill")
                            Text(tr("Tự kết nối khi mở app"))
                        }
                    }
                } footer: {
                    Text(tr("Khi mở app, tự kết nối với đồng hồ đã kết nối thành công gần nhất."))
                }
.glassRows()
                Section {
                    NavigationLink {
                        NotificationsView()
                    } label: {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "bell.badge.fill")
                            Text(tr("Thông báo & đồng bộ giờ"))
                        }
                    }
                } footer: {
                    Text(tr("Chuyển tin nhắn, cuộc gọi, thông báo iPhone lên đồng hồ (ANCS, thử nghiệm) và đồng bộ giờ."))
                }
.glassRows()
                Section {
                    LanguagePickerRow()
                } footer: {
                    Text(tr("Chọn ngôn ngữ của app."))
                }
.glassRows()
                Section {
                    Picker(selection: Binding(get: { vm.ui.theme }, set: { vm.setTheme($0) })) {
                        Text(tr("Theo hệ thống")).tag(ThemeMode.system)
                        Text(tr("Sáng")).tag(ThemeMode.light)
                        Text(tr("Tối")).tag(ThemeMode.dark)
                    } label: {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "circle.lefthalf.filled")
                            Text(tr("Chủ đề"))
                        }
                    }
                } footer: {
                    Text(tr("Chọn giao diện của app."))
                }
.glassRows()
                Section {
                    NavigationLink {
                        LogsView()
                    } label: {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "doc.text")
                            Text(tr("Nhật ký hoạt động"))
                        }
                    }
                    NavigationLink {
                        AboutView()
                    } label: {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "info.circle")
                            Text(tr("Giới thiệu"))
                        }
                    }
                }
.glassRows()
                Section {
                    Button { vm.clearCache() } label: {
                        HStack(spacing: 12) {
                            IconBadge(systemName: "trash")
                            Text(tr("Xoá bộ nhớ đệm HWT đã nhập"))
                        }
                    }
                } footer: {
                    Text(tr("Huỷ ghép nối: Cài đặt iOS > Bluetooth > (i) > Forget This Device."))
                }
.glassRows()
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle(tr("Cài đặt"))
            // Ẩn thanh tiêu đề của tab gốc để nội dung full màn (màn con vẫn có nút quay lại).
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}
