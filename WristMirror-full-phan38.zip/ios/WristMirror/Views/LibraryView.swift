// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import ImageIO

/// Tải ảnh thu nhỏ từ file (không nạp ảnh gốc vào bộ nhớ).
enum Thumbnail {
    static func load(url: URL, maxPixel: CGFloat) -> UIImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }
}

struct ThumbnailView: View {
    let url: URL?
    let maxPixel: CGFloat
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let image = image {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                Image(systemName: "clock").font(.largeTitle).foregroundStyle(.secondary)
            }
        }
        .task(id: url) {
            guard let u = url else { image = nil; return }
            let px = maxPixel
            image = await Task.detached(priority: .utility) { Thumbnail.load(url: u, maxPixel: px) }.value
        }
    }
}

/// Mục "Thư viện" trong tab Mặt đồng hồ.
struct LibrarySection: View {
    @EnvironmentObject var vm: WatchViewModel
    @ObservedObject var library: HwtLibrary
    @State private var selected: HwtLibraryItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(tr("Thư viện")).font(.headline)
                Spacer()
                NavigationLink {
                    ScheduleView(library: library, schedule: vm.schedule)
                } label: {
                    Label(tr("Lịch nhắc"), systemImage: "bell")
                        .font(.caption.weight(.semibold))
                }
                if !library.items.isEmpty {
                    Text(trf("%@ mặt · %@", library.items.count, ByteCountFormatter.string(fromByteCount: library.totalBytes, countStyle: .file)))
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.leading, 4)

            if library.items.isEmpty {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr("Thư viện còn trống"))
                    Text(tr("Mỗi file HWT bạn chọn sẽ tự được lưu ở đây để dùng lại."))
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .card()
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 12)], spacing: 12) {
                    ForEach(library.items) { item in
                        Button { selected = item } label: { tile(item) }
                            .buttonStyle(.plain)
                    }
                }
            }
        }
        .sheet(item: $selected) { item in
            LibraryDetailView(library: library, itemId: item.id)
                .environmentObject(vm)
        }
    }

    private func tile(_ item: HwtLibraryItem) -> some View {
        VStack(spacing: 8) {
            ThumbnailView(url: library.previewURL(item), maxPixel: 360)
                .id(item.sourceHash)
                .frame(height: 110)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(alignment: .topTrailing) {
                    if library.hasDesign(item) {
                        Image(systemName: "slider.horizontal.3")
                            .font(.caption2.weight(.bold))
                            .padding(5)
                            .background(.ultraThinMaterial, in: Circle())
                            .padding(5)
                    }
                }
            Text(tr(item.name)).font(.subheadline.weight(.semibold)).lineLimit(1)
            Text(tr(ByteCountFormatter.string(fromByteCount: item.bytes, countStyle: .file)))
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .card()
    }
}

/// Chi tiết một mục thư viện: xem ảnh lớn, đổi tên, dùng, chia sẻ, xoá.
struct LibraryDetailView: View {
    @EnvironmentObject var vm: WatchViewModel
    @ObservedObject var library: HwtLibrary
    let itemId: String
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var loaded = false
    @State private var confirmDelete = false
    @State private var lunarItem: HwtLibraryItem?

    private var item: HwtLibraryItem? { library.items.first { $0.id == itemId } }
    private var busy: Bool { vm.ui.operation.active || vm.ui.pickingHwt }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if let item = item {
                        ThumbnailView(url: library.previewURL(item), maxPixel: 900)
                            .id(item.sourceHash)
                            .frame(maxHeight: 280)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                        VStack(alignment: .leading, spacing: 8) {
                            Text(tr("Tên")).font(.footnote).foregroundStyle(.secondary)
                            TextField(tr("Tên mặt đồng hồ"), text: $name)
                                .textFieldStyle(.roundedBorder)
                                .submitLabel(.done)
                                .onSubmit { library.rename(id: itemId, to: name) }
                        }
                        .card()

                        VStack(spacing: 6) {
                            InfoRow(label: tr("Tên trong file"), value: item.title)
                            InfoRow(label: tr("File gốc"), value: item.fileName)
                            InfoRow(label: tr("Dung lượng"), value: ByteCountFormatter.string(fromByteCount: item.bytes, countStyle: .file))
                            InfoRow(label: tr("Phiên bản file"), value: item.xmlVersion.isEmpty ? tr("Không có") : item.xmlVersion)
                            InfoRow(label: tr("Ngày thêm"), value: item.addedAt.formatted(date: .abbreviated, time: .shortened))
                        }
                        .card()

                        if let url = library.fileURL(item) {
                            NavigationLink {
                                HwtInfoView(url: url)
                            } label: { Label(tr("Xem thông tin file"), systemImage: "info.circle") }
                                .buttonStyle(SecondaryButtonStyle())
                        }

                        if library.hasDesign(item) {
                            NavigationLink {
                                StudioView(editing: item, library: library)
                            } label: { Label(tr("Chỉnh sửa thiết kế"), systemImage: "slider.horizontal.3") }
                                .buttonStyle(SecondaryButtonStyle())
                            Text(tr("Mở lại Studio với đúng thiết kế đã tạo. Thêm âm lịch bằng nút bên dưới sẽ tạo mặt mới và không còn chỉnh sửa được."))
                                .font(.caption2).foregroundStyle(.secondary)
                        }

                        if library.fileURL(item) != nil {
                            Button { lunarItem = item } label: { Label(tr("Thêm âm lịch"), systemImage: "calendar.badge.plus") }
                                .buttonStyle(SecondaryButtonStyle())
                        }

                        Button {
                            library.rename(id: itemId, to: name)
                            vm.useFromLibrary(item)
                            dismiss()
                        } label: { Label(tr("Dùng file này"), systemImage: "checkmark.circle") }
                            .buttonStyle(PrimaryButtonStyle())
                            .disabled(busy || library.fileURL(item) == nil)

                        HStack(spacing: 10) {
                            if let url = library.fileURL(item) {
                                ShareLink(item: url) { Label(tr("Chia sẻ"), systemImage: "square.and.arrow.up") }
                                    .buttonStyle(SecondaryButtonStyle())
                            }
                            Button { confirmDelete = true } label: { Label(tr("Xoá"), systemImage: "trash") }
                                .buttonStyle(SecondaryButtonStyle(color: Color.red))
                        }
                    } else {
                        Text(tr("Mục này đã bị xoá.")).foregroundStyle(.secondary).card()
                    }
                }
                .padding(16)
            }
            .background(AppBackground())
            .navigationTitle(tr("Thư viện"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { library.rename(id: itemId, to: name); dismiss() }
                }
            }
            .confirmationDialog(tr("Xoá khỏi thư viện?"), isPresented: $confirmDelete, titleVisibility: .visible) {
                Button(tr("Xoá"), role: .destructive) { library.delete(id: itemId); dismiss() }
                Button(tr("Huỷ"), role: .cancel) {}
            } message: {
                Text(tr("Chỉ xoá bản lưu trong app, không ảnh hưởng đồng hồ."))
            }
            .sheet(item: $lunarItem) { it in
                LunarPatchView(library: library, item: it)
            }
            .onAppear {
                if !loaded, let i = item { name = i.name; loaded = true }
            }
        }
    }
}
