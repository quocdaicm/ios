// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Khối ngày/tháng (âm lịch hoặc dương lịch)

/// Bố cục khối ngày/tháng: `[chục][đơn vị] / [tháng]` và một dòng nhãn nhỏ ("Â lịch" / "D lịch" hoặc "Lunar" / "Solar").
/// Cấu trúc lấy từ các file HWT thật: ngày = 2 dãy ảnh (chục, đơn vị), tháng = 1 dãy ảnh (1...12),
/// dấu "/" và nhãn là ảnh tĩnh. Số được vẽ vector đúng cỡ điểm ảnh của đồng hồ nên nét sắc ở mọi cỡ chữ.
struct LunarLayout {
    let font: UIFont
    let labelFont: UIFont
    let digitW: Int
    let lineH: Int
    let slashW: Int
    let labelW: Int
    let labelH: Int
    let x0: Int
    /// Hàng chữ số (toạ độ y của hàng ngày/tháng).
    let numY: Int
    let labelY: Int
    /// Tâm ngang của khối.
    let cx: Int
    let showLabel: Bool
    let labelText: String
    /// Dấu ngăn ngày/tháng ("/" hoặc "-").
    var sep = "/"
    /// Kiểu số vector (`.classic` = vẽ bằng `font`), lề quanh hình số, có dùng màu gốc của kiểu không.
    var style: DigitalStyle = .classic
    var pad = 0
    var own = true
    /// Nhãn vector: path chữ (cỡ 100, tâm ở gốc), tỉ lệ sang điểm ảnh. Rỗng khi kiểu số thường.
    var labelPath: CGPath? = nil
    var labelScale: CGFloat = 1

    var tensX: Int { x0 }
    var onesX: Int { x0 + digitW }
    var slashX: Int { x0 + digitW * 2 }
    var monthX: Int { x0 + digitW * 2 + slashW }
    var labelX: Int { max(0, cx - labelW / 2) }
}

/// Mã dữ liệu (valueType) của một khối ngày/tháng, đọc từ các file HWT thật.
struct DateValueTypes {
    let tens: Int
    let ones: Int
    let month: Int
    /// Số mục của dãy "chục ngày" (âm lịch: 5 mục theo file thật, dương lịch: 4 mục 0...3).
    let tensCount: Int

    static let lunar = DateValueTypes(tens: HwtValueType.lunarDayTens, ones: HwtValueType.lunarDayOnes,
                                      month: HwtValueType.lunarMonth, tensCount: 5)
    static let solar = DateValueTypes(tens: HwtValueType.solarDayTens, ones: HwtValueType.solarDayOnes,
                                      month: HwtValueType.solarMonth, tensCount: 4)
}

extension FaceRenderer {
    /// Chữ nhãn: lang 0 = theo ngôn ngữ app, 1 = Tiếng Việt ("Â lịch" / "D lịch"), 2 = English ("Lunar" / "Solar").
    static func dateLabelString(lunar: Bool, lang: Int) -> String {
        let en = lang == 2 || (lang == 0 && Lang.current == .en)
        if lunar { return en ? "Lunar" : "Â lịch" }
        return en ? "Solar" : "D lịch"
    }

    static func dateSepString(_ i: Int) -> String { i == 1 ? "-" : "/" }

    static func dateLayout(size sz: Double, x: Double, y: Double, label: Bool, labelText: String, labelAbove: Bool,
                           sep: String = "/", style: DigitalStyle = .classic, own: Bool = true, labelFontIdx: Int = 0,
                           textFont tf: FaceFont = .system, numberFont nf: FaceFont = .system) -> LunarLayout {
        let k = CGFloat(min(1.8, max(0.6, sz)))
        let fs = 30 * k
        let font = nf.number(fs, .bold)
        let labelFont = tf.text(fs * 0.6, .bold)
        func width(_ t: String, _ f: UIFont) -> Int { Int(ceil((t as NSString).size(withAttributes: [.font: f]).width)) + 2 }
        var digitW = FaceFont.digitCell(font)
        var lineH = Int(ceil(font.lineHeight)) + 2
        var slashW = width(sep, font)
        var labelW = width(labelText, labelFont)
        var labelH = Int(ceil(labelFont.lineHeight)) + 2
        var pad = 0
        var labelPath: CGPath? = nil
        var labelScale: CGFloat = 1
        var useStyle = DigitalStyle.classic
        if style != .classic, let def = style.def {
            // Số vector: ô theo hình học của kiểu, nhãn là path chữ tô cùng kiểu.
            useStyle = style
            let c = DigitalShapes.cells(def, scale: k, base: 26)
            digitW = c.digitW
            lineH = c.lineH
            slashW = c.sepW
            pad = c.pad
            let shape = DateLabelShapes.shape(labelText, font: labelFontIdx)
            labelScale = 17 * k / 100
            let lpad = def.paint == .glow ? 6 : 3
            labelW = Int(ceil(shape.w * labelScale)) + 2 * lpad
            labelH = Int(ceil(shape.h * labelScale)) + 2 * lpad
            labelPath = shape.path
        }
        let total = digitW * 4 + slashW
        let cxPx = Int(size * CGFloat(min(0.9, max(0.1, x))))
        let x0 = max(0, min(Int(size) - total, cxPx - total / 2))
        let blockH = lineH + (label ? labelH : 0)
        let cy = Int(size * CGFloat(min(0.9, max(0.1, y))))
        let top = max(0, min(Int(size) - blockH, cy - blockH / 2))
        let numY = (label && labelAbove) ? top + labelH : top
        let labelY = labelAbove ? top : top + lineH
        return LunarLayout(font: font, labelFont: labelFont, digitW: digitW, lineH: lineH, slashW: slashW,
                           labelW: labelW, labelH: labelH, x0: x0, numY: numY, labelY: labelY,
                           cx: x0 + total / 2, showLabel: label, labelText: labelText,
                           sep: sep, style: useStyle, pad: pad, own: own, labelPath: labelPath, labelScale: labelScale)
    }

    static func lunarLayout(_ d: FaceDesign) -> LunarLayout {
        dateLayout(size: d.lunarSize, x: d.lunarX, y: d.lunarY, label: d.lunarLabel,
                   labelText: dateLabelString(lunar: true, lang: d.lunarLabelLang), labelAbove: false,
                   sep: dateSepString(d.lunarSep), style: d.lunarStyleEff, own: d.lunarOwnEff, labelFontIdx: d.lunarLabelFont,
                   textFont: d.textFace("lunar"), numberFont: d.numberFace("lunar"))
    }

    static func solarLayout(_ d: FaceDesign) -> LunarLayout {
        dateLayout(size: d.solarSize, x: d.solarX, y: d.solarY, label: d.solarLabel,
                   labelText: dateLabelString(lunar: false, lang: d.solarLabelLang), labelAbove: true,
                   sep: dateSepString(d.solarSep), style: d.solarStyleEff, own: d.solarOwnEff, labelFontIdx: d.solarLabelFont,
                   textFont: d.textFace("solar"), numberFont: d.numberFace("solar"))
    }

    /// Vẽ chữ ở giữa hình chữ nhật (gốc trên-trái, ctx kiểu UIKit).
    static func drawLunarText(_ text: String, font: UIFont, color: UIColor, in rect: CGRect) {
        guard !text.isEmpty else { return }
        let sz = (text as NSString).size(withAttributes: [.font: font])
        drawHaloText(text, font: font, color: color,
                     at: CGPoint(x: rect.minX + (rect.width - sz.width) / 2, y: rect.minY + (rect.height - sz.height) / 2))
    }

    /// Ngày âm hôm nay (chỉ để xem trước; đồng hồ tự tính ngày âm thật).
    static func lunarToday() -> (day: Int, month: Int) {
        var cal = Calendar(identifier: .chinese)
        cal.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh") ?? TimeZone.current
        let c = cal.dateComponents([.day, .month], from: Date())
        return (min(30, max(1, c.day ?? 1)), min(12, max(1, c.month ?? 1)))
    }

    /// Ngày dương hôm nay (chỉ để xem trước).
    static func solarToday() -> (day: Int, month: Int) {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh") ?? TimeZone.current
        let c = cal.dateComponents([.day, .month], from: Date())
        return (min(31, max(1, c.day ?? 1)), min(12, max(1, c.month ?? 1)))
    }

    /// Vẽ một khối ngày/tháng vào ctx (toạ độ 466×466, gốc trên-trái).
    static func drawDatePreview(_ ctx: CGContext, layout L: LunarLayout, color: UIColor, value v: (day: Int, month: Int)) {
        if L.style != .classic, let def = L.style.def {
            func vec(_ ch: Character, _ x: Int, _ w: Int) {
                DigitalShapes.draw(ctx, def: def, char: ch, in: CGRect(x: x, y: L.numY, width: w, height: L.lineH),
                                   pad: CGFloat(L.pad), color: color, own: L.own)
            }
            if v.day >= 10 { vec(Character(String(v.day / 10)), L.tensX, L.digitW) }
            vec(Character(String(v.day % 10)), L.onesX, L.digitW)
            vec(Character(L.sep), L.slashX, L.slashW)
            vec(Character(String(v.month / 10)), L.monthX, L.digitW)
            vec(Character(String(v.month % 10)), L.monthX + L.digitW, L.digitW)
            if L.showLabel, let lp = L.labelPath {
                DigitalShapes.drawLabel(ctx, def: def, shape: lp, scale: L.labelScale,
                                        in: CGRect(x: L.labelX, y: L.labelY, width: L.labelW, height: L.labelH),
                                        color: color, own: L.own)
            }
            return
        }
        UIGraphicsPushContext(ctx)
        func cell(_ t: String, _ x: Int, _ w: Int, _ y: Int, _ h: Int, _ f: UIFont) {
            drawLunarText(t, font: f, color: color, in: CGRect(x: x, y: y, width: w, height: h))
        }
        cell(v.day >= 10 ? "\(v.day / 10)" : "", L.tensX, L.digitW, L.numY, L.lineH, L.font)
        cell("\(v.day % 10)", L.onesX, L.digitW, L.numY, L.lineH, L.font)
        cell(L.sep, L.slashX, L.slashW, L.numY, L.lineH, L.font)
        cell(String(format: "%02d", v.month), L.monthX, L.digitW * 2, L.numY, L.lineH, L.font)
        if L.showLabel { cell(L.labelText, L.labelX, L.labelW, L.labelY, L.labelH, L.labelFont) }
        UIGraphicsPopContext()
    }

    /// Xem trước âm lịch (giữ tên cũ).
    static func drawLunarPreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showLunar else { return }
        drawDatePreview(ctx, layout: lunarLayout(d), color: UIColor(d.lunarColor), value: lunarToday())
    }

    /// Xem trước dương lịch.
    static func drawSolarPreview(_ ctx: CGContext, design d: FaceDesign) {
        guard d.showSolar else { return }
        drawDatePreview(ctx, layout: solarLayout(d), color: UIColor(d.solarColor), value: solarToday())
    }

    /// Ảnh của một ô chữ (vẽ đúng cỡ điểm ảnh).
    static func glyphRaster(_ t: String, w: Int, h: Int, font: UIFont, color: UIColor) -> HwtRaster {
        drawRaster(width: w, height: h) { ctx in
            drawLunarText(t, font: font, color: color, in: CGRect(x: 0, y: 0, width: w, height: h))
        }
    }

    /// Các lớp của một khối ngày/tháng: thêm ảnh qua `add` (trả về số ảnh, bắt đầu từ 1).
    static func dateLayers(_ L: LunarLayout, color: UIColor, types: DateValueTypes, add: (HwtRaster) -> Int) -> [HwtLayer] {
        let vecDef: DigitalShapes.Def? = L.style == .classic ? nil : L.style.def
        func glyph(_ t: String, w: Int, h: Int, font: UIFont) -> Int {
            add(glyphRaster(t, w: w, h: h, font: font, color: color))
        }
        /// Một ô số vector (hoặc ô trống khi `ch` rỗng); `w` = rộng ô, vẽ lần lượt các ký tự trong `chars` mỗi ký tự một ô `cw`.
        func vecCell(_ chars: [Character], w: Int, cw: Int) -> Int {
            add(drawRaster(width: w, height: L.lineH) { ctx in
                guard let def = vecDef else { return }
                for (i, ch) in chars.enumerated() {
                    DigitalShapes.draw(ctx, def: def, char: ch, in: CGRect(x: CGFloat(i * cw), y: 0, width: CGFloat(cw), height: CGFloat(L.lineH)),
                                       pad: CGFloat(L.pad), color: color, own: L.own)
                }
            })
        }
        func digit(_ t: String) -> Int {
            if vecDef != nil { return vecCell(Array(t), w: L.digitW, cw: L.digitW) }
            return glyph(t, w: L.digitW, h: L.lineH, font: L.font)
        }
        func monthImg(_ m: Int) -> Int {
            if vecDef != nil { return vecCell(Array(String(format: "%02d", m)), w: L.digitW * 2, cw: L.digitW) }
            return glyph(String(format: "%02d", m), w: L.digitW * 2, h: L.lineH, font: L.font)
        }

        // Chục ngày: mục 0 để trống (ngày 1...9 không hiện số 0 đầu).
        let blank = digit("")
        let t1 = digit("1"), t2 = digit("2"), t3 = digit("3")
        let tens = types.tensCount == 5 ? [blank, t1, t2, t3, t2] : [blank, t1, t2, t3]
        // Đơn vị ngày (giá trị 0...9)
        let ones = (0...9).map { digit("\($0)") }
        // Tháng (giá trị 1...12); mục 0 là mục đệm giống file thật
        let months = (1...12).map { monthImg($0) }
        let slash: Int
        if vecDef != nil {
            slash = vecCell(Array(L.sep), w: L.slashW, cw: L.slashW)
        } else {
            slash = glyph(L.sep, w: L.slashW, h: L.lineH, font: L.font)
        }

        var layers: [HwtLayer] = [
            .array(resources: tens, x: L.tensX, y: L.numY, valueType: types.tens, ambient: false),
            .array(resources: ones, x: L.onesX, y: L.numY, valueType: types.ones, ambient: false),
            .single(resource: slash, x: L.slashX, y: L.numY, ambient: false),
            .array(resources: [months[0]] + months, x: L.monthX, y: L.numY, valueType: types.month, ambient: false)
        ]
        if L.showLabel {
            let label: Int
            if let def = vecDef, let lp = L.labelPath {
                label = add(drawRaster(width: L.labelW, height: L.labelH) { ctx in
                    DigitalShapes.drawLabel(ctx, def: def, shape: lp, scale: L.labelScale,
                                            in: CGRect(x: 0, y: 0, width: L.labelW, height: L.labelH), color: color, own: L.own)
                })
            } else {
                label = glyph(L.labelText, w: L.labelW, h: L.labelH, font: L.labelFont)
            }
            layers.append(.single(resource: label, x: L.labelX, y: L.labelY, ambient: false))
        }
        return layers
    }

    /// Các lớp âm lịch (giữ tên cũ).
    static func lunarLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        dateLayers(lunarLayout(d), color: UIColor(d.lunarColor), types: .lunar, add: add)
    }

    static func solarLayers(_ d: FaceDesign, add: (HwtRaster) -> Int) -> [HwtLayer] {
        dateLayers(solarLayout(d), color: UIColor(d.solarColor), types: .solar, add: add)
    }
}
