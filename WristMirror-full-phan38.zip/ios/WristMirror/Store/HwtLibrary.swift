// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import UIKit

/// Một mặt đồng hồ (file .hwt) đã lưu trong thư viện.
struct HwtLibraryItem: Codable, Identifiable, Equatable {
    let id: String
    var name: String
    let fileName: String
    let title: String
    let bytes: Int64
    let sourceHash: String
    let xmlVersion: String
    let addedAt: Date
    let hasPreview: Bool
}

/// Thư viện file HWT: mỗi mục là một thư mục `<id>/` gồm `face.hwt` (bản sao nguyên văn file gốc)
/// và `preview.image` (nếu HWT có ảnh xem trước), cộng `index.json`.
/// Chống trùng theo SHA-256 của file gốc. An toàn đa luồng (khoá nội bộ); `items` chỉ cập nhật trên main.
final class HwtLibrary: ObservableObject {
    static let maxItems = 200
    static let maxNameLength = 60

    @Published private(set) var items: [HwtLibraryItem] = []
    /// Gọi trên main sau mỗi lần thư viện thay đổi (thêm/đổi tên/xoá).
    var onChange: (() -> Void)?

    private let root: URL
    private let lock = NSLock()
    private var store: [HwtLibraryItem] = []

    init(root: URL? = nil) {
        if let r = root {
            self.root = r
        } else {
            let base = (try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                                     appropriateFor: nil, create: true))
                ?? FileManager.default.temporaryDirectory
            self.root = base.appendingPathComponent("hwt-library", isDirectory: true)
        }
        try? FileManager.default.createDirectory(at: self.root, withIntermediateDirectories: true)
        store = loadIndex()
        items = store
    }

    // MARK: Đường dẫn

    private var indexURL: URL { root.appendingPathComponent("index.json") }
    private func directory(_ id: String) -> URL { root.appendingPathComponent(id, isDirectory: true) }

    func fileURL(_ item: HwtLibraryItem) -> URL? {
        let u = directory(item.id).appendingPathComponent("face.hwt")
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    func previewURL(_ item: HwtLibraryItem) -> URL? {
        guard item.hasPreview else { return nil }
        let u = directory(item.id).appendingPathComponent("preview.image")
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    // MARK: Đọc

    func all() -> [HwtLibraryItem] {
        lock.lock(); defer { lock.unlock() }
        return store
    }

    func item(id: String) -> HwtLibraryItem? { all().first { $0.id == id } }

    var totalBytes: Int64 { all().reduce(0) { $0 + $1.bytes } }

    // MARK: Ghi

    /// Thêm một file HWT. Trả về mục đã có nếu trùng SHA-256; `nil` nếu thư viện đầy hoặc lỗi ghi file.
    @discardableResult
    func add(original: URL, preview: URL?, sourceHash: String, title: String,
             fileName: String, xmlVersion: String) -> HwtLibraryItem? {
        lock.lock(); defer { lock.unlock() }
        if let existing = store.first(where: { $0.sourceHash == sourceHash }) { return existing }
        guard store.count < HwtLibrary.maxItems else { return nil }
        let fm = FileManager.default
        let id = UUID().uuidString.lowercased()
        let dir = directory(id)
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            try fm.copyItem(at: original, to: dir.appendingPathComponent("face.hwt"))
            var hasPreview = false
            if let p = preview, (try? fm.copyItem(at: p, to: dir.appendingPathComponent("preview.image"))) != nil {
                hasPreview = true
            }
            let size = (try? fm.attributesOfItem(atPath: dir.appendingPathComponent("face.hwt").path)[.size] as? NSNumber)?.int64Value ?? 0
            let baseName = (fileName as NSString).deletingPathExtension
            let initial = HwtLibrary.cleanName(title).isEmpty ? HwtLibrary.cleanName(baseName) : HwtLibrary.cleanName(title)
            let item = HwtLibraryItem(id: id, name: initial.isEmpty ? "Mặt đồng hồ" : initial, fileName: fileName,
                                      title: title, bytes: size, sourceHash: sourceHash, xmlVersion: xmlVersion,
                                      addedAt: Date(), hasPreview: hasPreview)
            store.insert(item, at: 0)
            saveIndexLocked()
            publish()
            return item
        } catch {
            try? fm.removeItem(at: dir)
            return nil
        }
    }

    // MARK: Thiết kế (để mở lại chỉnh sửa mặt đồng hồ tạo từ Studio)

    /// File thiết kế `design.json` của mục (có khi mặt được tạo bằng Studio).
    func designURL(_ item: HwtLibraryItem) -> URL? {
        let u = directory(item.id).appendingPathComponent("design.json")
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    func hasDesign(_ item: HwtLibraryItem) -> Bool { designURL(item) != nil }

    /// Lưu thiết kế (JSON + ảnh nền nếu có) cạnh file HWT của mục. Trả về false nếu mục không còn hoặc lỗi ghi.
    @discardableResult
    func saveDesign(id: String, design: FaceDesign) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard store.contains(where: { $0.id == id }) else { return false }
        let dir = directory(id)
        let fm = FileManager.default
        do {
            try FaceDesignCodec.encode(design).write(to: dir.appendingPathComponent("design.json"), options: .atomic)
            let photoURL = dir.appendingPathComponent("photo.jpg")
            if let photo = design.photo, let data = photo.jpegData(compressionQuality: 0.92) {
                try data.write(to: photoURL, options: .atomic)
            } else {
                try? fm.removeItem(at: photoURL)
            }
            let aodURL = dir.appendingPathComponent("aodphoto.jpg")
            if let photo = design.aodPhoto, let data = photo.jpegData(compressionQuality: 0.92) {
                try data.write(to: aodURL, options: .atomic)
            } else {
                try? fm.removeItem(at: aodURL)
            }
            return true
        } catch {
            return false
        }
    }

    /// Đọc lại thiết kế đã lưu; nil nếu mục không có thiết kế hoặc file hỏng.
    func loadDesign(id: String) -> FaceDesign? {
        let dir = directory(id)
        guard let data = try? Data(contentsOf: dir.appendingPathComponent("design.json")),
              var design = FaceDesignCodec.decode(data) else { return nil }
        if let photoData = try? Data(contentsOf: dir.appendingPathComponent("photo.jpg")) {
            design.photo = UIImage(data: photoData)
        }
        if let aodData = try? Data(contentsOf: dir.appendingPathComponent("aodphoto.jpg")) {
            design.aodPhoto = UIImage(data: aodData)
        }
        return design
    }

    /// Dùng nội dung của mục mới `newId` (vừa tạo từ Studio) thay cho mục cũ `oldId`, giữ nguyên id cũ
    /// (nên lịch nhắc trỏ tới mục cũ vẫn đúng) và ngày thêm. Mục mới bị gộp và xoá.
    @discardableResult
    func absorb(newId: String, into oldId: String) -> HwtLibraryItem? {
        lock.lock(); defer { lock.unlock() }
        guard newId != oldId,
              let ni = store.firstIndex(where: { $0.id == newId }),
              let oi = store.firstIndex(where: { $0.id == oldId }) else { return nil }
        let fm = FileManager.default
        let newItem = store[ni], oldItem = store[oi]
        let nd = directory(newId), od = directory(oldId)
        for name in ["face.hwt", "preview.image", "design.json", "photo.jpg", "aodphoto.jpg"] {
            let target = od.appendingPathComponent(name)
            try? fm.removeItem(at: target)
            let source = nd.appendingPathComponent(name)
            if fm.fileExists(atPath: source.path) { try? fm.moveItem(at: source, to: target) }
        }
        // Giữ tên do người dùng tự đặt trong thư viện (khác tên trong file); nếu không thì lấy tên mới.
        let renamedByUser = oldItem.name != HwtLibrary.cleanName(oldItem.title)
        let merged = HwtLibraryItem(id: oldId, name: renamedByUser ? oldItem.name : newItem.name,
                                    fileName: newItem.fileName, title: newItem.title, bytes: newItem.bytes,
                                    sourceHash: newItem.sourceHash, xmlVersion: newItem.xmlVersion,
                                    addedAt: oldItem.addedAt, hasPreview: newItem.hasPreview)
        store[oi] = merged
        store.remove(at: ni)
        try? fm.removeItem(at: nd)
        saveIndexLocked()
        publish()
        return merged
    }

    func rename(id: String, to newName: String) {
        let cleaned = HwtLibrary.cleanName(newName)
        guard !cleaned.isEmpty else { return }
        lock.lock(); defer { lock.unlock() }
        guard let i = store.firstIndex(where: { $0.id == id }), store[i].name != cleaned else { return }
        store[i].name = cleaned
        saveIndexLocked()
        publish()
    }

    func delete(id: String) {
        lock.lock(); defer { lock.unlock() }
        guard let i = store.firstIndex(where: { $0.id == id }) else { return }
        store.remove(at: i)
        try? FileManager.default.removeItem(at: directory(id))
        saveIndexLocked()
        publish()
    }

    /// Bỏ ký tự điều khiển/xuống dòng, gọn khoảng trắng, cắt tối đa `maxNameLength` ký tự.
    static func cleanName(_ s: String) -> String {
        let filtered = s.unicodeScalars.map { CharacterSet.controlCharacters.contains($0) ? " " : String($0) }.joined()
        let collapsed = filtered.split(whereSeparator: { $0 == " " }).joined(separator: " ")
        return String(collapsed.prefix(maxNameLength))
    }

    // MARK: Lưu chỉ mục

    private func loadIndex() -> [HwtLibraryItem] {
        guard let data = try? Data(contentsOf: indexURL) else { return [] }
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        guard let list = try? dec.decode([HwtLibraryItem].self, from: data) else { return [] }
        // Bỏ mục mà file đã mất.
        return list.filter {
            FileManager.default.fileExists(atPath: directory($0.id).appendingPathComponent("face.hwt").path)
        }
    }

    private func saveIndexLocked() {
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        if let data = try? enc.encode(store) { try? data.write(to: indexURL, options: .atomic) }
    }

    private func publish() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.items = self.all()
            self.onChange?()
        }
    }
}
