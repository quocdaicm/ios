// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import UIKit

// MARK: - Biểu tượng pin đổi theo mức (Phần 37)
//
// Cơ sở: file Kozmik Beta có dãy ảnh mã 54 gồm 11 ảnh (0...10) đặt cạnh số pin (dataType 9): đồng hồ chọn ảnh thứ
// "mức pin / 10" (78% hiện ảnh 8). App dùng lại đúng cơ chế đó cho biểu tượng pin: dựng 11 ảnh biểu tượng, mỗi ảnh đầy
// thêm 10%, ghi thành lớp dãy ảnh mã `HwtValueType.batteryLevel`.
// CHƯA thử trên máy thật: chưa rõ firmware làm tròn hay lấy cận trên khi chọn ảnh (cả hai cho cùng kết quả ở 78%).

enum FaceBatteryLevel {
    /// Tên các kiểu (chỉ số kiểu = vị trí + 1; 0 = tắt, biểu tượng pin cố định như cũ).
    static let titles = ["Pin ngang", "Pin 4 vạch", "Pin dọc", "Viên thuốc", "Vòng tròn", "Viền kép"]
    /// Số ảnh trong dãy (mức 0...10).
    static let levelCount = 11
    /// Từ mức này trở xuống (pin dưới khoảng 25%) biểu tượng chuyển sang màu đỏ (trừ khi bật "Biểu tượng một màu").
    static let lowLevel = 2

    /// Chỉ số ảnh (0...10) ứng với phần trăm pin.
    static func index(forPercent percent: Int) -> Int {
        let p = min(max(percent, 0), 100)
        return min(max((p + 5) / 10, 0), levelCount - 1)
    }

    private static func n(_ v: Double) -> String { String(format: "%.2f", v) }

    /// Cung tròn bắt đầu từ đỉnh, đi theo chiều kim đồng hồ, bằng đường cong Bézier bậc ba (MiniSVG không có lệnh cung "A").
    static func arcPath(cx: Double, cy: Double, r: Double, sweepDegrees: Double) -> String {
        guard sweepDegrees > 0 else { return "" }
        let total = min(sweepDegrees, 359.9) * Double.pi / 180
        // Trừ 1e-9 để cung đúng 90° / 180° không bị chia thừa một đoạn do sai số số thực.
        let segments = max(1, Int((total / (Double.pi / 2) - 1e-9).rounded(.up)))
        let step = total / Double(segments)
        let k = 4.0 / 3.0 * tan(step / 4)
        var a0 = -Double.pi / 2
        var d = ""
        for i in 0..<segments {
            let a1 = a0 + step
            let p0x = cx + r * cos(a0), p0y = cy + r * sin(a0)
            let p3x = cx + r * cos(a1), p3y = cy + r * sin(a1)
            let c1x = p0x - k * r * sin(a0), c1y = p0y + k * r * cos(a0)
            let c2x = p3x + k * r * sin(a1), c2y = p3y - k * r * cos(a1)
            if i == 0 { d += "M\(n(p0x)) \(n(p0y)) " }
            d += "C\(n(c1x)) \(n(c1y)) \(n(c2x)) \(n(c2y)) \(n(p3x)) \(n(p3y)) "
            a0 = a1
        }
        return d
    }

    /// SVG (viewBox 100) của biểu tượng ở mức `level` (0...10). Màu: accent. Kiểu sai → chuỗi rỗng.
    static func svg(style: Int, level rawLevel: Int) -> String {
        let level = min(max(rawLevel, 0), levelCount - 1)
        let frac = Double(level) / 10.0
        switch style {
        case 1:
            var s = "<rect x=\"5\" y=\"28\" width=\"82\" height=\"44\" rx=\"9\" fill=\"none\" stroke=\"accent\" stroke-width=\"6\"/>"
            s += "<rect x=\"91\" y=\"42\" width=\"6\" height=\"16\" rx=\"3\" fill=\"accent\"/>"
            s += "<rect x=\"14\" y=\"37\" width=\"66\" height=\"26\" rx=\"4\" fill=\"accent\" opacity=\"0.16\"/>"
            if level > 0 {
                s += "<rect x=\"14\" y=\"37\" width=\"\(n(66 * frac))\" height=\"26\" rx=\"4\" fill=\"accent\"/>"
            }
            return s
        case 2:
            var s = "<rect x=\"5\" y=\"28\" width=\"82\" height=\"44\" rx=\"9\" fill=\"none\" stroke=\"accent\" stroke-width=\"6\"/>"
            s += "<rect x=\"91\" y=\"42\" width=\"6\" height=\"16\" rx=\"3\" fill=\"accent\"/>"
            let bars = Int((Double(level) * 4.0 / 10.0).rounded(.up))
            for i in 0..<4 {
                let x = 14 + 17 * i
                let opacity = i < bars ? "1" : "0.16"
                s += "<rect x=\"\(x)\" y=\"37\" width=\"14\" height=\"26\" rx=\"3\" fill=\"accent\" opacity=\"\(opacity)\"/>"
            }
            return s
        case 3:
            var s = "<rect x=\"27\" y=\"14\" width=\"46\" height=\"80\" rx=\"10\" fill=\"none\" stroke=\"accent\" stroke-width=\"7\"/>"
            s += "<rect x=\"40\" y=\"4\" width=\"20\" height=\"9\" rx=\"3\" fill=\"accent\"/>"
            s += "<rect x=\"35\" y=\"22\" width=\"30\" height=\"64\" rx=\"4\" fill=\"accent\" opacity=\"0.16\"/>"
            if level > 0 {
                let h = 64 * frac
                s += "<rect x=\"35\" y=\"\(n(86 - h))\" width=\"30\" height=\"\(n(h))\" rx=\"4\" fill=\"accent\"/>"
            }
            return s
        case 4:
            var s = "<rect x=\"4\" y=\"30\" width=\"84\" height=\"40\" rx=\"20\" fill=\"none\" stroke=\"accent\" stroke-width=\"6\"/>"
            s += "<rect x=\"91\" y=\"43\" width=\"6\" height=\"14\" rx=\"3\" fill=\"accent\"/>"
            s += "<rect x=\"13\" y=\"39\" width=\"66\" height=\"22\" rx=\"11\" fill=\"accent\" opacity=\"0.16\"/>"
            if level > 0 {
                s += "<rect x=\"13\" y=\"39\" width=\"\(n(66 * frac))\" height=\"22\" rx=\"11\" fill=\"accent\"/>"
            }
            return s
        case 5:
            var s = "<circle cx=\"50\" cy=\"50\" r=\"40\" fill=\"none\" stroke=\"accent\" stroke-width=\"9\" opacity=\"0.2\"/>"
            if level >= levelCount - 1 {
                s += "<circle cx=\"50\" cy=\"50\" r=\"40\" fill=\"none\" stroke=\"accent\" stroke-width=\"9\"/>"
            } else if level > 0 {
                s += "<path d=\"\(arcPath(cx: 50, cy: 50, r: 40, sweepDegrees: 360 * frac))\" fill=\"none\" stroke=\"accent\" stroke-width=\"9\"/>"
            }
            return s
        case 6:
            var s = "<rect x=\"4\" y=\"26\" width=\"84\" height=\"48\" rx=\"12\" fill=\"none\" stroke=\"accent\" stroke-width=\"3.5\"/>"
            s += "<rect x=\"91\" y=\"41\" width=\"6\" height=\"18\" rx=\"3\" fill=\"accent\"/>"
            s += "<rect x=\"11\" y=\"33\" width=\"70\" height=\"34\" rx=\"7\" fill=\"accent\" opacity=\"0.16\"/>"
            if level > 0 {
                s += "<rect x=\"11\" y=\"33\" width=\"\(n(70 * frac))\" height=\"34\" rx=\"7\" fill=\"accent\"/>"
            }
            return s
        default:
            return ""
        }
    }

    /// Màu chính của biểu tượng ở mức `level`: màu chữ khi một màu, đỏ khi pin yếu, còn lại màu xanh riêng của pin.
    static func accent(level: Int, textColor: UIColor, mono: Bool) -> UIColor {
        if mono { return textColor }
        if level <= lowLevel { return UIColor(red: 1.0, green: 0.30, blue: 0.30, alpha: 1) }
        return DataKind.battery.iconSymbol.color
    }
}

extension FaceRenderer {
    /// Vẽ biểu tượng pin kiểu `style` (1...6) ở mức `level` (0...10) vừa khung `rect`.
    static func drawBatteryLevelIcon(style: Int, level: Int, in rect: CGRect, textColor: UIColor, mono: Bool) {
        let svg = FaceBatteryLevel.svg(style: style, level: level)
        guard !svg.isEmpty else { return }
        let accent = FaceBatteryLevel.accent(level: level, textColor: textColor, mono: mono)
        MiniSVG.draw(svg, box: CGSize(width: 100, height: 100), in: rect,
                     palette: ["accent": accent, "currentColor": mono ? textColor : .white])
    }
}
