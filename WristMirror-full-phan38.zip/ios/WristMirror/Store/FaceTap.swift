// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Hành động khi chạm vào một mục trên mặt đồng hồ + font riêng từng mục
//
// Cấu trúc lấy từ các file HWT thật (Kozmik Sporcu / Kule / BetaFinal, màn hình HWHD09): phần tử số 3 chứa các "vùng chạm",
// mỗi vùng là một hình chữ nhật (x, y, rộng, cao) và một mã hành động. Mã được đối chiếu với ảnh xem trước của từng file:
// 10 = bước chân, 11 = nhịp tim, 12 = calo, 17 = pin, 21 = thời tiết, 24 = quãng đường, 25 = giấc ngủ, 16 = căng thẳng.
// Mã 9 (khung mặt trời mọc / lặn) suy ra từ vị trí vùng, chưa kiểm chứng trên đồng hồ thật.

enum TapAction: Int, CaseIterable, Identifiable {
    case none = 0
    case steps = 10
    case heart = 11
    case calories = 12
    case battery = 17
    case weather = 21
    case distance = 24
    case sleep = 25
    case stress = 16
    case sun = 9

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .none: return tr("Không làm gì")
        case .steps: return tr("Mở Bước chân")
        case .heart: return tr("Mở Nhịp tim")
        case .calories: return tr("Mở Calo")
        case .battery: return tr("Mở Pin")
        case .weather: return tr("Mở Thời tiết")
        case .distance: return tr("Mở Quãng đường")
        case .sleep: return tr("Mở Giấc ngủ")
        case .stress: return tr("Mở Căng thẳng")
        case .sun: return tr("Mở Mặt trời mọc/lặn (chưa kiểm chứng)")
        }
    }

    static func from(_ code: Int) -> TapAction { TapAction(rawValue: code) ?? .none }
}

extension DataKind {
    /// Khoá của mục trong `FaceDesign.taps` / `elementFonts`.
    var key: String {
        switch self {
        case .battery: return "battery"
        case .steps: return "steps"
        case .heart: return "heart"
        case .calories: return "calories"
        }
    }
}

/// Một mục có thể chỉnh font, cỡ chữ và hành động chạm.
struct FaceElementInfo: Identifiable {
    let key: String
    let title: String
    /// Cỡ chữ gốc (pt) khi hệ số cỡ = 1.
    let basePoints: Double
    let size: WritableKeyPath<FaceDesign, Double>
    let show: (FaceDesign) -> Bool
    let item: FaceRenderer.InfoItem
    var id: String { key }

    static var all: [FaceElementInfo] { [
        FaceElementInfo(key: "digital", title: tr("Giờ số (HH:MM)"), basePoints: 44, size: \.digitalSize, show: { $0.showDigital }, item: .digital),
        FaceElementInfo(key: "weekday", title: tr("Thứ trong tuần"), basePoints: 28, size: \.weekdaySize, show: { $0.showWeekday }, item: .weekday),
        FaceElementInfo(key: "solar", title: tr("Dương lịch"), basePoints: 30, size: \.solarSize, show: { $0.showSolar }, item: .solar),
        FaceElementInfo(key: "lunar", title: tr("Âm lịch"), basePoints: 30, size: \.lunarSize, show: { $0.showLunar }, item: .lunar),
        FaceElementInfo(key: "name", title: tr("Tên hiển thị"), basePoints: 30, size: \.nameSize, show: { $0.showName }, item: .name),
        FaceElementInfo(key: "battery", title: "Pin", basePoints: 34, size: \.battery.size, show: { $0.battery.show }, item: .data(.battery)),
        FaceElementInfo(key: "steps", title: tr("Bước chân"), basePoints: 34, size: \.steps.size, show: { $0.steps.show }, item: .data(.steps)),
        FaceElementInfo(key: "heart", title: tr("Nhịp tim"), basePoints: 34, size: \.heart.size, show: { $0.heart.show }, item: .data(.heart)),
        FaceElementInfo(key: "calories", title: "Calo", basePoints: 34, size: \.calories.size, show: { $0.calories.show }, item: .data(.calories)),
        FaceElementInfo(key: "weather", title: tr("Thời tiết"), basePoints: 34, size: \.weather.size, show: { $0.weather.show }, item: .weather)
    ] }
}

extension FaceDesign {
    /// Font chữ của một mục: font riêng nếu có, không thì font chung.
    func textFace(_ key: String) -> FaceFont { FaceFont.from(elementFonts[key] ?? textFontIndex) }

    /// Font số của một mục: font riêng nếu có, không thì font số chung.
    func numberFace(_ key: String) -> FaceFont { FaceFont.from(elementFonts[key] ?? numberFontIndex) }

    /// Hành động chạm của một mục: giá trị người dùng chọn, không thì hành động tự nhiên (pin, bước chân, nhịp tim, calo, thời tiết).
    func tapAction(_ key: String) -> TapAction {
        if let code = taps[key] { return TapAction.from(code) }
        switch key {
        case "battery": return .battery
        case "steps": return .steps
        case "heart": return .heart
        case "calories": return .calories
        case "weather": return .weather
        default: return .none
        }
    }
}

/// Vùng chạm ở mép mặt đồng hồ (như các theme Kozmik: dải 120×38 ở giữa mỗi cạnh).
enum TapEdge: String, CaseIterable, Identifiable {
    case top, left, bottom, right
    var id: String { rawValue }

    var title: String {
        switch self {
        case .top: return tr("Mép trên")
        case .left: return tr("Mép trái")
        case .bottom: return tr("Mép dưới")
        case .right: return tr("Mép phải")
        }
    }

    /// Hình chữ nhật trên mặt 466×466 (đọc từ Kozmik BetaFinal).
    var rect: HwtRect {
        switch self {
        case .top: return HwtRect(x: 173, y: 0, w: 120, h: 38)
        case .left: return HwtRect(x: 0, y: 173, w: 38, h: 120)
        case .bottom: return HwtRect(x: 173, y: 428, w: 120, h: 38)
        case .right: return HwtRect(x: 428, y: 173, w: 38, h: 120)
        }
    }
}

extension FaceDesign {
    func edgeAction(_ edge: TapEdge) -> TapAction { TapAction.from(edgeTaps[edge.rawValue] ?? 0) }
}

/// Vùng chạm ghi vào HWT (toạ độ điểm ảnh trên mặt 466×466).
struct HwtTapZone: Equatable {
    var rect: HwtRect
    var action: Int
}

extension FaceRenderer {
    /// Mở rộng vùng chạm cho dễ bấm (tối thiểu 64×48, cộng viền 6 điểm) và giữ trong mặt đồng hồ.
    static func touchRect(_ r: CGRect) -> HwtRect {
        let side = Int(size)
        let w = min(side, max(Int(r.width.rounded(.up)) + 12, 64))
        let h = min(side, max(Int(r.height.rounded(.up)) + 12, 48))
        let x = max(0, min(side - w, Int(r.midX) - w / 2))
        let y = max(0, min(side - h, Int(r.midY) - h / 2))
        return HwtRect(x: x, y: y, w: w, h: h)
    }

    /// Các vùng chạm của mọi mục đang bật và có hành động (dùng cùng bố cục với ảnh đã vẽ, kể cả khi tự sắp xếp).
    static func tapZones(_ source: FaceDesign) -> [HwtTapZone] {
        guard source.tapsOn else { return [] }
        let d = resolvedLayout(source)
        var zones = [HwtTapZone]()
        for info in FaceElementInfo.all {
            guard isShown(info.item, d) else { continue }
            let action = d.tapAction(info.key)
            guard action != .none else { continue }
            let r = itemRect(info.item, d)
            guard r.width > 0, r.height > 0 else { continue }
            zones.append(HwtTapZone(rect: touchRect(r), action: action.rawValue))
        }
        for edge in TapEdge.allCases {
            let action = source.edgeAction(edge)
            if action != .none { zones.append(HwtTapZone(rect: edge.rect, action: action.rawValue)) }
        }
        return zones
    }
}
