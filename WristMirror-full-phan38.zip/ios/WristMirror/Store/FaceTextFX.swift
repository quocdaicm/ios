// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import UIKit
import CoreText

// MARK: - Kiểu chữ vector cho "Thứ trong tuần" và "Tên của bạn" (Phần 38)
//
// Chữ được lấy ra thành ĐƯỜNG NÉT (CGPath) từ font có sẵn trên iOS rồi tô bằng gradient, viền, phát sáng, khối 3D, chấm LED,
// hoa văn và nét trang trí vẽ bằng code (vương miện, đường uốn, trái tim, khung HUD, tia sét, lấp lánh...). Không dùng ảnh,
// không cần font ngoài. Kiểu 0 = chữ thường như trước. Xem hai bảng mẫu của chủ app (Hoàng Gia 3D, Kim Loại Bạc, ...).
// CHƯA biên dịch/chưa thử máy thật.

struct TextFXSpec {
    enum Decor { case none, crown, swoosh, heartSwoosh, ornament, speed, frame, lightning, sparkles, sparkle, line }
    enum Pattern { case none, carbon, dots, slits }

    var title: String
    /// Tên PostScript của font, thử lần lượt; không có thì dùng font hệ thống (`fallbackWeight`, nghiêng nếu `italic`).
    var fonts: [String]
    var fallbackWeight: UIFont.Weight = .heavy
    var italic = true
    var caps = false
    /// Độ xô nghiêng thêm (0 = không).
    var skew: CGFloat = 0
    /// Màu tô từ trên xuống dưới (hoặc trái sang phải nếu `horizontal`); một màu = tô phẳng.
    var fill: [UIColor]
    var horizontal = false
    var stroke: UIColor? = nil
    /// Các độ dày dưới đây tính theo tỉ lệ cỡ chữ.
    var strokeW: CGFloat = 0
    var extrude: UIColor? = nil
    var extrudeD: CGFloat = 0
    var glow: UIColor? = nil
    var glowR: CGFloat = 0
    var pattern: Pattern = .none
    var decor: Decor = .none
    var decorColor: UIColor? = nil
    /// true: màu lấy theo màu chữ người dùng chọn (viền, phát sáng, trang trí cùng màu đó).
    var tint = false
    /// true: chỉ vẽ viền (neon viền), không tô.
    var outlineOnly = false
    var padX: CGFloat = 0.1
    var padY: CGFloat = 0.1
}

enum FaceTextFX {
    private static func c(_ hex: UInt32, _ a: CGFloat = 1) -> UIColor {
        UIColor(red: CGFloat((hex >> 16) & 255) / 255, green: CGFloat((hex >> 8) & 255) / 255,
                blue: CGFloat(hex & 255) / 255, alpha: a)
    }

    private static func S(_ title: String, _ fonts: [String], _ fill: [UIColor],
                          _ cfg: (inout TextFXSpec) -> Void = { _ in }) -> TextFXSpec {
        var s = TextFXSpec(title: title, fonts: fonts, fill: fill)
        cfg(&s)
        return s
    }

    private static var silver: [UIColor] { [c(0xFFFFFF), c(0xC9CED8), c(0x7D8492), c(0xEEF1F7), c(0xA4ABB8)] }
    private static var gold: [UIColor] { [c(0xFFF3B0), c(0xF7C948), c(0xB7791F), c(0xFFE08A), c(0xD4A017)] }

    /// Các kiểu (chỉ số kiểu = vị trí + 1; 0 = chữ thường).
    static let specs: [TextFXSpec] = {
        var l = [TextFXSpec]()
        l.append(S("Hoàng Gia 3D", ["Baskerville-BoldItalic", "Georgia-BoldItalic"], gold) {
            $0.extrude = c(0x6B4A12); $0.extrudeD = 0.07; $0.glow = c(0xFFC933, 0.6); $0.glowR = 0.18
            $0.stroke = c(0x5A3A08); $0.strokeW = 0.02; $0.decor = .crown; $0.decorColor = c(0xF7C948)
            $0.padX = 0.2; $0.padY = 0.6
        })
        l.append(S("Kim Loại Bạc", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"], silver) {
            $0.stroke = c(0x2F343F); $0.strokeW = 0.03; $0.glow = c(0xDDE6FF, 0.55); $0.glowR = 0.14
            $0.extrude = c(0x3A404C); $0.extrudeD = 0.04
        })
        l.append(S("Vàng Sang Trọng", ["Georgia-BoldItalic", "Baskerville-BoldItalic"], gold) {
            $0.glow = c(0xFFB300, 0.55); $0.glowR = 0.16; $0.stroke = c(0x6B4A12); $0.strokeW = 0.02
            $0.decor = .swoosh; $0.decorColor = c(0xF7C948); $0.padY = 0.5
        })
        l.append(S("Băng Giá", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFFFFFF), c(0xA8ECFF), c(0x39B0F5), c(0x1565C0)]) {
            $0.stroke = c(0x0A3D91); $0.strokeW = 0.03; $0.glow = c(0x5CC8FF, 0.9); $0.glowR = 0.28; $0.padX = 0.25; $0.padY = 0.25
        })
        l.append(S("Lửa Nhiệt", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFFF176), c(0xFFB300), c(0xFF5A00), c(0xB71C1C)]) {
            $0.stroke = c(0x8A1A00); $0.strokeW = 0.025; $0.glow = c(0xFF6A00, 0.95); $0.glowR = 0.32; $0.padX = 0.28; $0.padY = 0.3
        })
        l.append(S("Neon Phát Sáng", ["AvenirNext-BoldItalic", "HelveticaNeue-BoldItalic"], [.white]) {
            $0.tint = true; $0.glow = .white; $0.glowR = 0.38; $0.stroke = .white; $0.strokeW = 0.012; $0.padX = 0.3; $0.padY = 0.3
        })
        l.append(S("Điện Sét", ["AvenirNext-DemiBoldItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFFFFFF), c(0xB8F0FF), c(0x55B8FF)]) {
            $0.glow = c(0x2D6BFF, 0.95); $0.glowR = 0.3; $0.stroke = c(0x1B3FBF); $0.strokeW = 0.02
            $0.decor = .lightning; $0.decorColor = c(0xCFF4FF); $0.padX = 0.35; $0.padY = 0.45
        })
        l.append(S("Thư Pháp Vàng", ["SnellRoundhand-Black", "SnellRoundhand-Bold", "Georgia-BoldItalic"], gold) {
            $0.italic = true; $0.stroke = c(0x5A3A00); $0.strokeW = 0.035; $0.glow = c(0xFFB300, 0.5); $0.glowR = 0.14
            $0.padX = 0.2; $0.padY = 0.3
        })
        l.append(S("Thư Pháp Bạc", ["SnellRoundhand-Black", "SnellRoundhand-Bold", "Georgia-BoldItalic"], silver) {
            $0.stroke = c(0x2F343F); $0.strokeW = 0.035; $0.glow = c(0xDDE6FF, 0.5); $0.glowR = 0.14
            $0.padX = 0.2; $0.padY = 0.3
        })
        l.append(S("Chữ Ký Tay", ["SnellRoundhand", "SnellRoundhand-Bold", "Georgia-Italic"],
                   [c(0xFFE9A0), c(0xF2C14E), c(0xC8922A)]) {
            $0.fallbackWeight = .regular; $0.glow = c(0xFFC933, 0.45); $0.glowR = 0.1
            $0.decor = .heartSwoosh; $0.decorColor = c(0xF2C14E); $0.padX = 0.25; $0.padY = 0.5
        })
        l.append(S("Thể Thao Tốc Độ", ["AvenirNextCondensed-HeavyItalic", "AvenirNext-HeavyItalic"], silver) {
            $0.stroke = c(0x2B2F38); $0.strokeW = 0.035; $0.decor = .speed; $0.decorColor = c(0xE53935)
            $0.extrude = c(0x2B2F38); $0.extrudeD = 0.05; $0.padX = 0.2; $0.padY = 0.4
        })
        l.append(S("Carbon Fiber", ["AvenirNextCondensed-HeavyItalic", "AvenirNext-HeavyItalic"],
                   [c(0x555B65), c(0x1B1D21)]) {
            $0.pattern = .carbon; $0.stroke = c(0xD7DCE6); $0.strokeW = 0.035; $0.decor = .speed; $0.decorColor = c(0xE53935)
            $0.padX = 0.2; $0.padY = 0.4
        })
        l.append(S("Công Nghệ HUD", ["AvenirNextCondensed-Bold", "AvenirNext-Bold"],
                   [c(0xFFFFFF), c(0xB8F3FF), c(0x4FD8FF)]) {
            $0.caps = true; $0.italic = false; $0.stroke = c(0x0B4F7A); $0.strokeW = 0.025
            $0.glow = c(0x27C6FF, 0.7); $0.glowR = 0.18; $0.decor = .frame; $0.decorColor = c(0x4FD8FF)
            $0.padX = 0.5; $0.padY = 0.4
        })
        l.append(S("LED Pixel", ["AvenirNext-Heavy", "Futura-CondensedExtraBold"], [.white]) {
            $0.italic = false; $0.tint = true; $0.pattern = .dots; $0.glow = .white; $0.glowR = 0.2
            $0.padX = 0.2; $0.padY = 0.2
        })
        l.append(S("Gradient Neon", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"],
                   [c(0x29B6F6), c(0x7C4DFF), c(0xE040FB)]) {
            $0.horizontal = true; $0.glow = c(0x7C4DFF, 0.8); $0.glowR = 0.25; $0.stroke = c(0xFFFFFF, 0.9); $0.strokeW = 0.012
            $0.decor = .swoosh; $0.decorColor = c(0x7C4DFF); $0.padX = 0.25; $0.padY = 0.5
        })
        l.append(S("Serif Sang Trọng", ["Didot", "Baskerville", "Georgia"], gold) {
            $0.italic = false; $0.fallbackWeight = .regular; $0.decor = .ornament; $0.decorColor = c(0xD4A017)
            $0.padX = 0.2; $0.padY = 0.55
        })
        l.append(S("Tối Giản", ["AvenirNext-UltraLight", "HelveticaNeue-Light"], [.white]) {
            $0.italic = false; $0.fallbackWeight = .ultraLight; $0.tint = true; $0.decor = .line; $0.padX = 0.15; $0.padY = 0.35
        })
        l.append(S("Neon Viền", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"], [.white]) {
            $0.tint = true; $0.outlineOnly = true; $0.stroke = .white; $0.strokeW = 0.05; $0.glow = .white; $0.glowR = 0.3
            $0.padX = 0.3; $0.padY = 0.3
        })
        l.append(S("Retro 80s", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFFE45E), c(0xFF6EC7), c(0x8A2BE2)]) {
            $0.stroke = c(0x00E5FF); $0.strokeW = 0.03; $0.glow = c(0xFF3DCB, 0.7); $0.glowR = 0.2; $0.pattern = .slits
            $0.padX = 0.25; $0.padY = 0.25
        })
        l.append(S("Thiên Nhiên", ["AvenirNext-DemiBoldItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xDFFF8A), c(0x7BE04A), c(0x1B8F2A)]) {
            $0.stroke = c(0x0B4D12); $0.strokeW = 0.03; $0.glow = c(0x4CFF4C, 0.7); $0.glowR = 0.2
            $0.padX = 0.2; $0.padY = 0.2
        })
        l.append(S("Vũ Trụ", ["Georgia-BoldItalic", "Baskerville-BoldItalic"],
                   [c(0xF3E5F5), c(0xB388FF), c(0x7C4DFF)]) {
            $0.horizontal = true; $0.glow = c(0x9C6BFF, 0.9); $0.glowR = 0.28; $0.stroke = c(0x311B92); $0.strokeW = 0.02
            $0.decor = .sparkles; $0.decorColor = .white; $0.padX = 0.3; $0.padY = 0.4
        })
        l.append(S("Kính Trong Suốt", ["AvenirNext-DemiBoldItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFFFFFF, 0.9), c(0xBFE8FF, 0.55), c(0x7FC8FF, 0.45)]) {
            $0.stroke = c(0xFFFFFF, 0.95); $0.strokeW = 0.012; $0.glow = c(0x7FD0FF, 0.85); $0.glowR = 0.22
            $0.padX = 0.2; $0.padY = 0.2
        })
        l.append(S("Sơn Màu", ["AvenirNext-HeavyItalic", "HelveticaNeue-BoldItalic"],
                   [c(0xFF1744), c(0xFF9100), c(0xFFEA00), c(0x00E676), c(0x00B0FF), c(0xD500F9)]) {
            $0.horizontal = true; $0.stroke = c(0xFFFFFF); $0.strokeW = 0.03; $0.glow = c(0xFFFFFF, 0.35); $0.glowR = 0.1
        })
        l.append(S("Kim Cương", ["Didot", "Baskerville", "Georgia"], [c(0xFFFFFF), c(0xDDEBFF), c(0x9EB8D9)]) {
            $0.italic = false; $0.fallbackWeight = .regular; $0.stroke = c(0x5F7694); $0.strokeW = 0.025
            $0.glow = c(0xFFFFFF, 0.7); $0.glowR = 0.2; $0.decor = .sparkle; $0.decorColor = .white
            $0.padX = 0.3; $0.padY = 0.4
        })
        return l
    }()

    /// Tên các kiểu kể cả kiểu 0 (chữ thường), dùng cho lưới chọn.
    static var titles: [String] { ["Thường"] + specs.map { $0.title } }

    static func spec(_ index: Int) -> TextFXSpec? {
        guard index >= 1 && index <= specs.count else { return nil }
        return specs[index - 1]
    }

    /// Có dùng màu chữ người dùng chọn không (kiểu 0 và các kiểu `tint`); các kiểu còn lại có bảng màu riêng.
    static func usesUserColor(_ index: Int) -> Bool {
        guard let s = spec(index) else { return true }
        return s.tint
    }

    static func font(_ spec: TextFXSpec, size: CGFloat) -> UIFont {
        for n in spec.fonts {
            if let f = UIFont(name: n, size: size) { return f }
        }
        var f = UIFont.systemFont(ofSize: size, weight: spec.fallbackWeight)
        if spec.italic, let d = f.fontDescriptor.withSymbolicTraits(.traitItalic) {
            f = UIFont(descriptor: d, size: size)
        }
        return f
    }

    /// Phần đệm quanh chữ (điểm ảnh) để chứa viền, phát sáng, khối 3D và nét trang trí.
    static func padding(_ spec: TextFXSpec, fontSize fs: CGFloat) -> (x: Int, y: Int) {
        let extra = spec.glowR * 1.2 + spec.strokeW + spec.extrudeD
        return (Int(ceil((spec.padX + extra) * fs)), Int(ceil((spec.padY + extra) * fs)))
    }

    // MARK: Đường nét chữ

    /// Đường nét của chuỗi (toạ độ glyph: gốc ở đầu đường cơ sở, trục y hướng lên) và bề rộng chữ.
    private static func glyphPath(_ text: String, font: UIFont) -> (path: CGPath, width: CGFloat)? {
        let attr = NSAttributedString(string: text, attributes: [.font: font])
        let line = CTLineCreateWithAttributedString(attr)
        let width = CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
        guard let runs = CTLineGetGlyphRuns(line) as? [CTRun] else { return nil }
        let path = CGMutablePath()
        for run in runs {
            let count = CTRunGetGlyphCount(run)
            if count == 0 { continue }
            let attrs = CTRunGetAttributes(run) as NSDictionary
            guard let raw = attrs[kCTFontAttributeName as String] else { continue }
            let runFont = raw as! CTFont
            var glyphs = [CGGlyph](repeating: 0, count: count)
            var positions = [CGPoint](repeating: .zero, count: count)
            CTRunGetGlyphs(run, CFRangeMake(0, 0), &glyphs)
            CTRunGetPositions(run, CFRangeMake(0, 0), &positions)
            for i in 0..<count {
                if let gp = CTFontCreatePathForGlyph(runFont, glyphs[i], nil) {
                    path.addPath(gp, transform: CGAffineTransform(translationX: positions[i].x, y: positions[i].y))
                }
            }
        }
        return (path, width)
    }

    private static func mix(_ a: UIColor, _ b: UIColor, _ t: CGFloat) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        a.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        b.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        return UIColor(red: r1 + (r2 - r1) * t, green: g1 + (g2 - g1) * t, blue: b1 + (b2 - b1) * t, alpha: a1 + (a2 - a1) * t)
    }

    // MARK: Vẽ

    /// Vẽ `text` kiểu `spec` vào `rect` ở ngữ cảnh hiện tại (toạ độ kiểu UIKit, gốc trên-trái). `font` lấy từ `font(_:size:)`.
    static func draw(_ rawText: String, spec: TextFXSpec, font: UIFont, color: UIColor, in rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let text = spec.caps ? rawText.uppercased() : rawText
        guard !text.isEmpty, let built = glyphPath(text, font: font) else { return }
        let fs = font.pointSize
        let left = rect.midX - built.width / 2
        let right = left + built.width
        let baseline = rect.minY + (rect.height - font.lineHeight) / 2 + font.ascender
        let cap = font.capHeight
        let top = baseline - cap
        var t = CGAffineTransform(a: 1, b: 0, c: spec.skew, d: -1, tx: left, ty: baseline)
        guard let path = built.path.copy(using: &t) else { return }

        let fillCols: [UIColor] = spec.tint ? [mix(color, .white, 0.55), color] : spec.fill
        let glowCol: UIColor? = spec.glow == nil ? nil : (spec.tint ? color : spec.glow)
        let strokeCol: UIColor? = spec.stroke == nil ? nil : (spec.tint ? color : spec.stroke)
        let decCol: UIColor = spec.tint ? color : (spec.decorColor ?? spec.fill.first ?? .white)
        let gTop = baseline - cap * 1.1
        let gBottom = baseline + cap * 0.15

        // 1. Phát sáng.
        if let g = glowCol, spec.glowR > 0 {
            for _ in 0..<2 {
                ctx.saveGState()
                ctx.setShadow(offset: .zero, blur: spec.glowR * fs, color: g.cgColor)
                if spec.outlineOnly {
                    ctx.setStrokeColor(g.cgColor)
                    ctx.setLineWidth(max(1.2, spec.strokeW * fs))
                    ctx.setLineJoin(.round)
                    ctx.addPath(path)
                    ctx.strokePath()
                } else {
                    ctx.setFillColor(g.cgColor)
                    ctx.addPath(path)
                    ctx.fillPath()
                }
                ctx.restoreGState()
            }
        }

        // 2. Khối 3D.
        if let e = spec.extrude, spec.extrudeD > 0, !spec.outlineOnly {
            let steps = max(2, Int((spec.extrudeD * fs).rounded()))
            ctx.setFillColor(e.cgColor)
            for i in stride(from: steps, through: 1, by: -1) {
                var shift = CGAffineTransform(translationX: CGFloat(i) * 0.75, y: CGFloat(i))
                if let p = path.copy(using: &shift) {
                    ctx.addPath(p)
                    ctx.fillPath()
                }
            }
        }

        // 3. Viền ngoài (vẽ nét dày rồi tô đè lên, chỉ phần ngoài còn thấy).
        if let s = strokeCol, spec.strokeW > 0, !spec.outlineOnly {
            ctx.saveGState()
            ctx.setStrokeColor(s.cgColor)
            ctx.setLineWidth(spec.strokeW * fs * 2)
            ctx.setLineJoin(.round)
            ctx.addPath(path)
            ctx.strokePath()
            ctx.restoreGState()
        }

        // 4. Tô.
        if spec.outlineOnly {
            let w = max(1.2, spec.strokeW * fs)
            ctx.saveGState()
            ctx.setLineJoin(.round)
            ctx.setStrokeColor((strokeCol ?? color).cgColor)
            ctx.setLineWidth(w)
            ctx.addPath(path)
            ctx.strokePath()
            ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.9).cgColor)
            ctx.setLineWidth(max(0.8, w * 0.35))
            ctx.addPath(path)
            ctx.strokePath()
            ctx.restoreGState()
        } else if spec.pattern == .dots {
            drawDots(ctx, path: path, fs: fs, cols: fillCols, glow: glowCol, glowR: spec.glowR, top: gTop, bottom: gBottom)
        } else {
            fillGradient(ctx, path, colors: fillCols, horizontal: spec.horizontal, top: gTop, bottom: gBottom, left: left, right: right)
            if spec.pattern == .carbon { drawCarbon(ctx, path: path) }
            if spec.pattern == .slits { drawSlits(ctx, path: path, from: baseline - cap * 0.45, to: baseline) }
        }

        // 5. Nét trang trí.
        drawDecor(ctx, spec: spec, color: decCol, glow: glowCol, rect: rect, left: left, right: right, top: top,
                  baseline: baseline, fs: fs, cap: cap)
    }

    private static func fillGradient(_ ctx: CGContext, _ path: CGPath, colors: [UIColor], horizontal: Bool,
                                     top: CGFloat, bottom: CGFloat, left: CGFloat, right: CGFloat) {
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        if colors.count <= 1 {
            ctx.setFillColor((colors.first ?? .white).cgColor)
            ctx.fill(path.boundingBoxOfPath.insetBy(dx: -2, dy: -2))
        } else if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: colors.map { $0.cgColor } as CFArray, locations: nil) {
            let s = horizontal ? CGPoint(x: left, y: 0) : CGPoint(x: 0, y: top)
            let e = horizontal ? CGPoint(x: right, y: 0) : CGPoint(x: 0, y: bottom)
            ctx.drawLinearGradient(g, start: s, end: e, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
        }
        ctx.restoreGState()
    }

    /// Hoa văn sợi carbon: hai hướng đường chéo mảnh, chỉ trong nét chữ.
    private static func drawCarbon(_ ctx: CGContext, path: CGPath) {
        let bb = path.boundingBoxOfPath
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        ctx.setLineWidth(1)
        ctx.setStrokeColor(UIColor(white: 1, alpha: 0.22).cgColor)
        var x = bb.minX - bb.height
        while x < bb.maxX {
            ctx.move(to: CGPoint(x: x, y: bb.maxY))
            ctx.addLine(to: CGPoint(x: x + bb.height, y: bb.minY))
            x += 3
        }
        ctx.strokePath()
        ctx.setStrokeColor(UIColor(white: 0, alpha: 0.35).cgColor)
        x = bb.minX
        while x < bb.maxX + bb.height {
            ctx.move(to: CGPoint(x: x, y: bb.maxY))
            ctx.addLine(to: CGPoint(x: x - bb.height, y: bb.minY))
            x += 3
        }
        ctx.strokePath()
        ctx.restoreGState()
    }

    /// Các khe ngang tối ở nửa dưới chữ (kiểu retro 80s).
    private static func drawSlits(_ ctx: CGContext, path: CGPath, from y0: CGFloat, to y1: CGFloat) {
        let bb = path.boundingBoxOfPath
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        ctx.setFillColor(UIColor(white: 0, alpha: 0.5).cgColor)
        var y = y0
        var h: CGFloat = 0.6
        while y < y1 {
            ctx.fill(CGRect(x: bb.minX - 1, y: y, width: bb.width + 2, height: h))
            y += 3
            h = min(1.8, h + 0.25)
        }
        ctx.restoreGState()
    }

    /// Chữ bằng ma trận chấm tròn (LED): chấm nằm trong nét chữ mới sáng.
    private static func drawDots(_ ctx: CGContext, path: CGPath, fs: CGFloat, cols: [UIColor], glow: UIColor?, glowR: CGFloat,
                                 top: CGFloat, bottom: CGFloat) {
        let bb = path.boundingBoxOfPath
        let cell = max(3, fs * 0.16)
        var pts = [CGPoint]()
        var y = bb.minY + cell / 2
        while y < bb.maxY {
            var x = bb.minX + cell / 2
            while x < bb.maxX {
                let p = CGPoint(x: x, y: y)
                if path.contains(p) { pts.append(p) }
                x += cell
            }
            y += cell
        }
        let r = cell * 0.4
        if let g = glow, glowR > 0 {
            ctx.saveGState()
            ctx.setShadow(offset: .zero, blur: glowR * fs, color: g.cgColor)
            ctx.setFillColor(g.cgColor)
            for p in pts { ctx.fillEllipse(in: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)) }
            ctx.restoreGState()
        }
        let first = cols.first ?? .white
        let last = cols.last ?? first
        let span = max(1, bottom - top)
        for p in pts {
            let tt = min(1, max(0, (p.y - top) / span))
            ctx.setFillColor(mix(first, last, tt).cgColor)
            ctx.fillEllipse(in: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2))
        }
    }

    // MARK: Nét trang trí

    private static func star(_ cx: CGFloat, _ cy: CGFloat, _ s: CGFloat) -> CGPath {
        let p = CGMutablePath()
        let k = s * 0.18
        p.move(to: CGPoint(x: cx, y: cy - s))
        p.addLine(to: CGPoint(x: cx + k, y: cy - k))
        p.addLine(to: CGPoint(x: cx + s, y: cy))
        p.addLine(to: CGPoint(x: cx + k, y: cy + k))
        p.addLine(to: CGPoint(x: cx, y: cy + s))
        p.addLine(to: CGPoint(x: cx - k, y: cy + k))
        p.addLine(to: CGPoint(x: cx - s, y: cy))
        p.addLine(to: CGPoint(x: cx - k, y: cy - k))
        p.closeSubpath()
        return p
    }

    private static func heart(_ cx: CGFloat, _ cy: CGFloat, _ s: CGFloat) -> CGPath {
        let p = CGMutablePath()
        let tip = CGPoint(x: cx, y: cy + s * 0.9)
        p.move(to: tip)
        p.addCurve(to: CGPoint(x: cx, y: cy - s * 0.35),
                   control1: CGPoint(x: cx - s * 1.4, y: cy + s * 0.1), control2: CGPoint(x: cx - s * 0.9, y: cy - s))
        p.addCurve(to: tip,
                   control1: CGPoint(x: cx + s * 0.9, y: cy - s), control2: CGPoint(x: cx + s * 1.4, y: cy + s * 0.1))
        p.closeSubpath()
        return p
    }

    private static func drawDecor(_ ctx: CGContext, spec: TextFXSpec, color: UIColor, glow: UIColor?, rect: CGRect,
                                  left: CGFloat, right: CGFloat, top: CGFloat, baseline: CGFloat, fs: CGFloat, cap: CGFloat) {
        let lw = max(1.2, fs * 0.055)
        let cx = (left + right) / 2
        /// Nét có phát sáng nhẹ (nếu kiểu có glow).
        func strokeGlowing(_ p: CGPath, width: CGFloat, col: UIColor) {
            ctx.saveGState()
            if let g = glow { ctx.setShadow(offset: .zero, blur: max(2, fs * 0.15), color: g.cgColor) }
            ctx.setStrokeColor(col.cgColor)
            ctx.setLineWidth(width)
            ctx.setLineCap(.round)
            ctx.setLineJoin(.round)
            ctx.addPath(p)
            ctx.strokePath()
            ctx.restoreGState()
        }
        func fillGlowing(_ p: CGPath, col: UIColor) {
            ctx.saveGState()
            if let g = glow { ctx.setShadow(offset: .zero, blur: max(2, fs * 0.15), color: g.cgColor) }
            ctx.setFillColor(col.cgColor)
            ctx.addPath(p)
            ctx.fillPath()
            ctx.restoreGState()
        }
        switch spec.decor {
        case .none:
            break
        case .crown:
            let w = cap * 1.05, h = fs * 0.5
            let y0 = top - fs * 0.1
            let p = CGMutablePath()
            p.move(to: CGPoint(x: cx - w / 2, y: y0))
            p.addLine(to: CGPoint(x: cx - w / 2, y: y0 - h * 0.55))
            p.addLine(to: CGPoint(x: cx - w / 4, y: y0 - h * 0.3))
            p.addLine(to: CGPoint(x: cx, y: y0 - h))
            p.addLine(to: CGPoint(x: cx + w / 4, y: y0 - h * 0.3))
            p.addLine(to: CGPoint(x: cx + w / 2, y: y0 - h * 0.55))
            p.addLine(to: CGPoint(x: cx + w / 2, y: y0))
            p.closeSubpath()
            fillGlowing(p, col: color)
            strokeGlowing(p, width: max(1, fs * 0.025), col: UIColor(red: 0.42, green: 0.29, blue: 0.07, alpha: 1))
            ctx.setFillColor(UIColor.white.cgColor)
            let dr = max(1.2, fs * 0.04)
            for pt in [CGPoint(x: cx - w / 2, y: y0 - h * 0.55), CGPoint(x: cx, y: y0 - h), CGPoint(x: cx + w / 2, y: y0 - h * 0.55)] {
                ctx.fillEllipse(in: CGRect(x: pt.x - dr, y: pt.y - dr, width: dr * 2, height: dr * 2))
            }
        case .swoosh, .heartSwoosh:
            let p = CGMutablePath()
            p.move(to: CGPoint(x: left, y: baseline + fs * 0.3))
            p.addQuadCurve(to: CGPoint(x: right, y: baseline + fs * 0.08), control: CGPoint(x: cx, y: baseline + fs * 0.66))
            strokeGlowing(p, width: lw, col: color)
            if spec.decor == .heartSwoosh {
                strokeGlowing(heart(right - fs * 0.12, baseline + fs * 0.12, fs * 0.2), width: max(1, lw * 0.7), col: color)
            }
        case .ornament:
            let gap = fs * 0.45
            let yTop = top - fs * 0.3
            let yBot = baseline + fs * 0.32
            for y in [yTop, yBot] {
                let p = CGMutablePath()
                p.move(to: CGPoint(x: left, y: y))
                p.addLine(to: CGPoint(x: cx - gap, y: y))
                p.move(to: CGPoint(x: cx + gap, y: y))
                p.addLine(to: CGPoint(x: right, y: y))
                strokeGlowing(p, width: max(1, fs * 0.025), col: color)
                let d = CGMutablePath()
                let s = fs * 0.1
                d.move(to: CGPoint(x: cx, y: y - s))
                d.addLine(to: CGPoint(x: cx + s, y: y))
                d.addLine(to: CGPoint(x: cx, y: y + s))
                d.addLine(to: CGPoint(x: cx - s, y: y))
                d.closeSubpath()
                fillGlowing(d, col: color)
            }
        case .speed:
            let h = max(1.5, fs * 0.07)
            let lean = fs * 0.12
            let y1 = baseline + fs * 0.14
            let bars: [(CGFloat, CGFloat, CGFloat)] = [(left + (right - left) * 0.05, right, y1),
                                                       (left + (right - left) * 0.5, right - (right - left) * 0.08, y1 + h * 2)]
            for b in bars {
                let p = CGMutablePath()
                p.move(to: CGPoint(x: b.0, y: b.2 + h))
                p.addLine(to: CGPoint(x: b.0 + lean, y: b.2))
                p.addLine(to: CGPoint(x: b.1 + lean, y: b.2))
                p.addLine(to: CGPoint(x: b.1, y: b.2 + h))
                p.closeSubpath()
                fillGlowing(p, col: color)
            }
        case .frame:
            let l = left - fs * 0.3, r = right + fs * 0.3
            let t = top - fs * 0.25, b = baseline + fs * 0.3
            let ch = fs * 0.24
            let p = CGMutablePath()
            p.move(to: CGPoint(x: l + ch, y: t))
            p.addLine(to: CGPoint(x: r, y: t))
            p.addLine(to: CGPoint(x: r, y: b - ch))
            p.addLine(to: CGPoint(x: r - ch, y: b))
            p.addLine(to: CGPoint(x: l, y: b))
            p.addLine(to: CGPoint(x: l, y: t + ch))
            p.closeSubpath()
            strokeGlowing(p, width: max(1.2, fs * 0.05), col: color)
        case .lightning:
            var seed: UInt64 = 20_260_411
            func rnd() -> CGFloat {
                seed = seed &* 6_364_136_223_846_793_005 &+ 1_442_695_040_888_963_407
                return CGFloat((seed >> 33) % 1000) / 1000
            }
            let bolts = CGMutablePath()
            for i in 0..<7 {
                let fromTop = i % 2 == 0
                var x = left + rnd() * (right - left)
                var y = fromTop ? top : baseline
                let dir: CGFloat = fromTop ? -1 : 1
                bolts.move(to: CGPoint(x: x, y: y))
                for _ in 0..<4 {
                    y += dir * fs * 0.13
                    x += (rnd() - 0.5) * fs * 0.32
                    bolts.addLine(to: CGPoint(x: x, y: y))
                }
            }
            strokeGlowing(bolts, width: max(1, fs * 0.035), col: color)
        case .sparkles:
            let spots: [(CGFloat, CGFloat, CGFloat)] = [(0.06, 0.1, 0.22), (0.94, 0.3, 0.16), (0.55, -0.1, 0.12), (0.32, 1.1, 0.14)]
            for s in spots {
                fillGlowing(star(left + s.0 * (right - left), top + s.1 * cap, fs * s.2), col: color)
            }
        case .sparkle:
            fillGlowing(star(right - (right - left) * 0.04, top - fs * 0.05, fs * 0.36), col: color)
            fillGlowing(star(left + (right - left) * 0.12, baseline + fs * 0.12, fs * 0.16), col: color)
        case .line:
            let p = CGMutablePath()
            p.move(to: CGPoint(x: left, y: baseline + fs * 0.28))
            p.addLine(to: CGPoint(x: right, y: baseline + fs * 0.28))
            strokeGlowing(p, width: max(1, fs * 0.03), col: color)
        }
    }

    // MARK: Hình thu nhỏ trong lưới chọn

    private static var thumbCache = [String: UIImage]()
    static let thumbSize = CGSize(width: 240, height: 84)

    /// Hình thu nhỏ của kiểu `index` (0 = chữ thường), chữ mẫu "Quốc Đại".
    static func thumb(_ index: Int) -> UIImage {
        let key = "fx\(index)"
        if let c = thumbCache[key] { return c }
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: thumbSize, format: fmt).image { r in
            UIColor(white: 0.06, alpha: 1).setFill()
            r.fill(CGRect(origin: .zero, size: thumbSize))
            let box = CGRect(origin: .zero, size: thumbSize)
            if let s = spec(index) {
                draw("Quốc Đại", spec: s, font: font(s, size: 34), color: c(0x4FD8FF), in: box)
            } else {
                let f = UIFont.systemFont(ofSize: 34, weight: .bold)
                let attrs: [NSAttributedString.Key: Any] = [.font: f, .foregroundColor: UIColor.white]
                let sz = ("Quốc Đại" as NSString).size(withAttributes: attrs)
                ("Quốc Đại" as NSString).draw(at: CGPoint(x: (box.width - sz.width) / 2, y: (box.height - sz.height) / 2),
                                              withAttributes: attrs)
            }
        }
        thumbCache[key] = img
        return img
    }
}
