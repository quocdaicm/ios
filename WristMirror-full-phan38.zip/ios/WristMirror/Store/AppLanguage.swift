// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI

/// Ngôn ngữ giao diện: tiếng Việt (mặc định) và tiếng Anh. Lưu trong UserDefaults.
enum AppLang: String, CaseIterable, Identifiable {
    case vi, en
    var id: String { rawValue }
    var flag: String { self == .vi ? "🇻🇳" : "🇬🇧" }
    var name: String { self == .vi ? "Tiếng Việt" : "English" }
}

enum Lang {
    static var current: AppLang = {
        let s = UserDefaults.standard.string(forKey: "appLang") ?? ""
        return AppLang(rawValue: s) ?? .vi
    }()
    static let en: [String: String] = LangData.en
    /// Bảng ngược Anh → Việt, để chuỗi cũ đã dịch vẫn đổi về tiếng Việt được.
    static let vi: [String: String] = {
        var d = [String: String]()
        for (k, v) in LangData.en where d[v] == nil { d[v] = k }
        return d
    }()
}

final class LangStore: ObservableObject {
    static let shared = LangStore()
    @Published var lang: AppLang {
        didSet {
            UserDefaults.standard.set(lang.rawValue, forKey: "appLang")
            Lang.current = lang
        }
    }
    private init() { lang = Lang.current }
}

/// Dịch một chuỗi theo ngôn ngữ hiện tại; chuỗi không có trong bảng (tên thiết bị, dữ liệu người dùng…) giữ nguyên.
func tr<S: StringProtocol>(_ s: S) -> String {
    let k = String(s)
    switch Lang.current {
    case .en: return Lang.en[k] ?? k
    case .vi: return Lang.vi[k] ?? k
    }
}

/// Chuỗi có giá trị chèn: khoá dùng "%@", các giá trị được thay lần lượt (và tự dịch nếu là chuỗi có trong bảng).
func trf(_ key: String, _ args: Any...) -> String {
    var out = tr(key)
    for a in args {
        let s = tr(String(describing: a))
        if let r = out.range(of: "%@") { out.replaceSubrange(r, with: s) }
    }
    return out
}
