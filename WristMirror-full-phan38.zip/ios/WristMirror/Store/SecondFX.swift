// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Hiệu ứng chuyển động theo giây: 10 ảnh, mỗi giây đồng hồ hiện một ảnh theo chữ số đơn vị của giây (0...9).
/// Cùng cơ chế "gà mổ thóc mỗi giây" trong file Kozmik Tavuk (dãy ảnh gắn mã số liệu 64).
enum SecondFX: String, CaseIterable, Identifiable {
    case none, dotChase, bloom, arc, pulse
    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "Không"
        case .dotChase: return "Đốm chạy"
        case .bloom: return "Hoa nở"
        case .arc: return "Cung đầy"
        case .pulse: return "Sóng lan"
        }
    }
    static let frameCount = 10
}

extension FaceRenderer {
    /// Vẽ một khung (0...9) của hiệu ứng trong toạ độ mặt đồng hồ 466x466 (gốc trên-trái).
    static func drawSecondFX(_ ctx: CGContext, style: SecondFX, color: UIColor, frame f: Int) {
        let c = center
        let n = SecondFX.frameCount
        let f = max(0, min(n - 1, f))
        ctx.saveGState()
        switch style {
        case .none:
            break
        case .dotChase:
            let r: CGFloat = 206
            for i in 0..<n {
                let a = CGFloat(i) * 2 * CGFloat.pi / CGFloat(n) - CGFloat.pi / 2
                let behind = (f - i + n) % n          // 0 = đốm đang sáng, 1 = vừa qua...
                let alpha: CGFloat = behind == 0 ? 1 : (behind <= 4 ? 0.62 - 0.14 * CGFloat(behind) : 0.12)
                let rad: CGFloat = behind == 0 ? 8 : 5.5
                ctx.setFillColor(color.withAlphaComponent(alpha).cgColor)
                ctx.fillEllipse(in: CGRect(x: c + r * cos(a) - rad, y: c + r * sin(a) - rad, width: rad * 2, height: rad * 2))
            }
        case .bloom:
            let petals = 12
            let len = 28 + CGFloat(f) * 9
            let wid = len * 0.36
            for i in 0..<petals {
                ctx.saveGState()
                ctx.translateBy(x: c, y: c)
                ctx.rotate(by: CGFloat(i) * 2 * CGFloat.pi / CGFloat(petals))
                ctx.setFillColor(color.withAlphaComponent(0.34).cgColor)
                ctx.fillEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                ctx.setStrokeColor(color.withAlphaComponent(0.55).cgColor)
                ctx.setLineWidth(1.2)
                ctx.strokeEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                ctx.restoreGState()
            }
        case .arc:
            let r: CGFloat = 207
            ctx.setLineCap(.round)
            ctx.setLineWidth(5)
            ctx.setStrokeColor(color.withAlphaComponent(0.14).cgColor)
            ctx.strokeEllipse(in: CGRect(x: c - r, y: c - r, width: r * 2, height: r * 2))
            let start = -CGFloat.pi / 2
            let end = start + CGFloat(f + 1) * 2 * CGFloat.pi / CGFloat(n)
            ctx.setStrokeColor(color.withAlphaComponent(0.95).cgColor)
            ctx.addArc(center: CGPoint(x: c, y: c), radius: r, startAngle: start, endAngle: end, clockwise: false)
            ctx.strokePath()
        case .pulse:
            for k in 0..<2 {
                let t = (CGFloat(f) + CGFloat(k) * CGFloat(n) / 2).truncatingRemainder(dividingBy: CGFloat(n)) / CGFloat(n)
                let r = 24 + t * 182
                let alpha = (1 - t) * 0.8
                ctx.setLineWidth(3.5 - 1.5 * t)
                ctx.setStrokeColor(color.withAlphaComponent(alpha).cgColor)
                ctx.strokeEllipse(in: CGRect(x: c - r, y: c - r, width: r * 2, height: r * 2))
            }
        }
        ctx.restoreGState()
    }

    /// 10 ảnh toàn mặt (466x466, nền trong suốt) dùng cho lớp dãy ảnh mã 64.
    static func secondFXFrames(_ d: FaceDesign) -> [HwtRaster] {
        guard d.secondFX != .none else { return [] }
        let side = Int(size)
        let color = UIColor(d.secondFXColor)
        return (0..<SecondFX.frameCount).map { f in
            drawRaster(width: side, height: side) { ctx in
                drawSecondFX(ctx, style: d.secondFX, color: color, frame: f)
            }
        }
    }

    /// Như `secondFXFrames` nhưng cắt về hộp nhỏ nhất chứa mọi điểm không trong suốt của cả 10 khung
    /// (ví dụ "Hoa nở" chỉ cần ~230x230 thay vì 466x466: nhẹ hơn ~4 lần trên đồng hồ).
    static func secondFXCropped(_ d: FaceDesign) -> (x: Int, y: Int, frames: [HwtRaster]) {
        let full = secondFXFrames(d)
        guard let first = full.first else { return (0, 0, []) }
        let w = first.width, h = first.height
        var minX = w, minY = h, maxX = -1, maxY = -1
        for r in full {
            for y in 0..<h {
                let row = y * w
                for x in 0..<w where (r.argb[row + x] >> 24) != 0 {
                    if x < minX { minX = x }
                    if x > maxX { maxX = x }
                    if y < minY { minY = y }
                    if y > maxY { maxY = y }
                }
            }
        }
        guard maxX >= minX, maxY >= minY else { return (0, 0, full) }
        minX = max(0, minX - 2); minY = max(0, minY - 2)
        maxX = min(w - 1, maxX + 2); maxY = min(h - 1, maxY + 2)
        let cw = maxX - minX + 1, ch = maxY - minY + 1
        let frames: [HwtRaster] = full.map { r in
            var out = [UInt32]()
            out.reserveCapacity(cw * ch)
            for y in minY...maxY {
                let base = y * w
                out.append(contentsOf: r.argb[(base + minX)...(base + maxX)])
            }
            return HwtRaster(width: cw, height: ch, argb: out)
        }
        return (minX, minY, frames)
    }

    /// Ảnh thô (MB) của hiệu ứng giây sau khi cắt.
    static func secondFXRawMegabytes(_ d: FaceDesign) -> Double {
        let c = secondFXCropped(d)
        return Double(c.frames.reduce(0) { $0 + $1.width * $1.height * 4 }) / 1_048_576
    }

    /// Ảnh thô (MB) của hoạt ảnh xoay: 24 khung vuông cạnh `decorSide`.
    static func animSpinRawMegabytes(_ d: FaceDesign) -> Double {
        let side = decorSide(animLayer(d))
        return Double(side * side * 4 * AnimFX.frameCount) / 1_048_576
    }
}
