// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation
import UserNotifications

/// Một lịch nhắc: đến giờ, app nhắc bạn đổi sang một mặt đồng hồ trong thư viện.
/// iOS không cho app chạy nền đúng giờ và thao tác thay mặt đồng hồ cần bạn xác nhận,
/// nên đây là LỊCH NHẮC (thông báo cục bộ), không tự thay mặt đồng hồ.
struct ScheduleEntry: Codable, Identifiable, Equatable {
    var id: String = UUID().uuidString.lowercased()
    var itemId: String
    var hour: Int
    var minute: Int
    /// Theo Calendar: 1 = Chủ nhật … 7 = Thứ bảy.
    var weekdays: [Int]
    var enabled: Bool = true

    /// Đưa về dạng hợp lệ: giờ 0–23, phút 0–59, thứ 1–7 không trùng; rỗng = mọi ngày.
    func normalized() -> ScheduleEntry {
        var e = self
        e.hour = min(max(hour, 0), 23)
        e.minute = min(max(minute, 0), 59)
        let days = Set(weekdays.filter { (1...7).contains($0) }).sorted()
        e.weekdays = days.isEmpty ? [1, 2, 3, 4, 5, 6, 7] : days
        return e
    }

    var timeText: String { String(format: "%02d:%02d", hour, minute) }

    var daysText: String {
        let d = Set(weekdays)
        if d.count == 7 { return tr("Mỗi ngày") }
        if d == [2, 3, 4, 5, 6] { return tr("Thứ 2 – Thứ 6") }
        if d == [1, 7] { return tr("Cuối tuần") }
        let names = [1: "CN", 2: "T2", 3: "T3", 4: "T4", 5: "T5", 6: "T6", 7: "T7"]
        return [2, 3, 4, 5, 6, 7, 1].filter { d.contains($0) }.compactMap { names[$0] }.joined(separator: ", ")
    }
}

final class FaceSchedule: ObservableObject {
    static let maxEntries = 8          // 8 × 7 ngày = 56 < giới hạn 64 thông báo đang chờ của iOS
    static let idPrefix = "wm.schedule."
    static let itemKey = "wm.itemId"

    @Published private(set) var entries: [ScheduleEntry] = []
    /// Trả về tên hiển thị của mục thư viện; `nil` nếu mục đã bị xoá (lịch đó không được đặt).
    var nameProvider: (String) -> String? = { _ in nil }

    private let defaults: UserDefaults
    private let key: String
    private let apply: ([UNNotificationRequest]) -> Void

    init(defaults: UserDefaults = .standard, key: String = "wm.face-schedule",
         apply: @escaping ([UNNotificationRequest]) -> Void = FaceSchedule.applyToCenter) {
        self.defaults = defaults
        self.key = key
        self.apply = apply
        if let data = defaults.data(forKey: key), let list = try? JSONDecoder().decode([ScheduleEntry].self, from: data) {
            entries = Array(list.prefix(FaceSchedule.maxEntries)).map { $0.normalized() }
        }
    }

    // MARK: Chỉnh sửa

    /// Thêm hoặc cập nhật. Trả về `false` nếu thêm mới nhưng đã đủ `maxEntries`.
    @discardableResult
    func upsert(_ entry: ScheduleEntry) -> Bool {
        let e = entry.normalized()
        if let i = entries.firstIndex(where: { $0.id == e.id }) {
            entries[i] = e
        } else {
            guard entries.count < FaceSchedule.maxEntries else { return false }
            entries.append(e)
        }
        commit()
        return true
    }

    func delete(id: String) {
        entries.removeAll { $0.id == id }
        commit()
    }

    func setEnabled(id: String, _ on: Bool) {
        guard let i = entries.firstIndex(where: { $0.id == id }), entries[i].enabled != on else { return }
        entries[i].enabled = on
        commit()
    }

    /// Đặt lại thông báo theo trạng thái hiện tại (gọi khi thư viện đổi tên/xoá mục, và khi mở app).
    func resync() { apply(FaceSchedule.requests(for: entries, nameFor: nameProvider)) }

    private func commit() {
        if let data = try? JSONEncoder().encode(entries) { defaults.set(data, forKey: key) }
        resync()
    }

    // MARK: Thông báo

    /// Mỗi lịch × mỗi thứ được chọn = một thông báo lặp hàng tuần. Bỏ qua lịch tắt hoặc mục thư viện không còn.
    static func requests(for entries: [ScheduleEntry], nameFor: (String) -> String?) -> [UNNotificationRequest] {
        var out: [UNNotificationRequest] = []
        for e in entries where e.enabled {
            guard let name = nameFor(e.itemId) else { continue }
            for day in e.weekdays {
                let content = UNMutableNotificationContent()
                content.title = tr("Đến giờ đổi mặt đồng hồ")
                content.body = trf("Chạm để chuẩn bị “%@”, rồi mở thẻ mặt đồng hồ đích và bấm Thay thế.", name)
                content.sound = .default
                content.userInfo = [itemKey: e.itemId]
                var c = DateComponents()
                c.hour = e.hour; c.minute = e.minute; c.weekday = day
                let trigger = UNCalendarNotificationTrigger(dateMatching: c, repeats: true)
                out.append(UNNotificationRequest(identifier: "\(idPrefix)\(e.id).\(day)", content: content, trigger: trigger))
            }
        }
        return out
    }

    static func applyToCenter(_ requests: [UNNotificationRequest]) {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { pending in
            let old = pending.map { $0.identifier }.filter { $0.hasPrefix(idPrefix) }
            center.removePendingNotificationRequests(withIdentifiers: old)
            for r in requests { center.add(r, withCompletionHandler: nil) }
        }
    }

    static func requestAuthorization(_ done: @escaping (Bool) -> Void = { _ in }) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, _ in
            DispatchQueue.main.async { done(granted) }
        }
    }
}

/// Nhận thao tác chạm vào thông báo lịch nhắc (và cho phép hiện thông báo lịch khi app đang mở).
final class ScheduleNotificationRouter: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ScheduleNotificationRouter()
    private var pendingItem: String?
    /// Gán xong sẽ nhận ngay thông báo đã chạm lúc app chưa sẵn sàng (mở nguội).
    var handler: ((String) -> Void)? {
        didSet { flush() }
    }

    private func flush() {
        guard let h = handler, let id = pendingItem else { return }
        pendingItem = nil
        h(id)
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        if let id = info[FaceSchedule.itemKey] as? String {
            DispatchQueue.main.async { [self] in
                pendingItem = id
                flush()
            }
        }
        completionHandler()
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        if notification.request.identifier.hasPrefix(FaceSchedule.idPrefix) {
            completionHandler([.banner, .sound])
        } else {
            completionHandler([])
        }
    }
}
