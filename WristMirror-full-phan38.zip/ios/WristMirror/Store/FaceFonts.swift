// Tính năng mới của bản iOS (không có trong WristMirror gốc).
import SwiftUI
import UIKit

/// Các font có sẵn trong iOS dùng cho chữ và số trên mặt đồng hồ (chữ được vẽ thành ảnh nên không cần cài thêm gì lên đồng hồ).
enum FaceFont: Int, CaseIterable, Identifiable {
    case system, rounded, serif, mono, avenir, avenirCondensed

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .system: return "Hệ thống"
        case .rounded: return "Bo tròn"
        case .serif: return "Có chân"
        case .mono: return "Đơn cách"
        case .avenir: return "Avenir"
        case .avenirCondensed: return "Avenir hẹp"
        }
    }

    static func from(_ index: Int) -> FaceFont { FaceFont(rawValue: index) ?? .system }

    private func design(_ d: UIFontDescriptor.SystemDesign, _ size: CGFloat, _ weight: UIFont.Weight) -> UIFont {
        let base = UIFont.systemFont(ofSize: size, weight: weight)
        if let dsc = base.fontDescriptor.withDesign(d) { return UIFont(descriptor: dsc, size: size) }
        return base
    }

    private func named(_ regular: String, _ bold: String, _ size: CGFloat, _ weight: UIFont.Weight) -> UIFont {
        let n = weight >= .semibold ? bold : regular
        return UIFont(name: n, size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
    }

    /// Font cho chữ (thứ, tên, nhãn, đơn vị, tên thời tiết).
    func text(_ size: CGFloat, _ weight: UIFont.Weight) -> UIFont {
        switch self {
        case .system: return UIFont.systemFont(ofSize: size, weight: weight)
        case .rounded: return design(.rounded, size, weight)
        case .serif: return design(.serif, size, weight)
        case .mono: return design(.monospaced, size, weight)
        case .avenir: return named("AvenirNext-Medium", "AvenirNext-Bold", size, weight)
        case .avenirCondensed: return named("AvenirNextCondensed-Medium", "AvenirNextCondensed-Bold", size, weight)
        }
    }

    /// Font cho chữ số (giữ nguyên số đều nhau với font hệ thống như trước).
    func number(_ size: CGFloat, _ weight: UIFont.Weight) -> UIFont {
        self == .system ? UIFont.monospacedDigitSystemFont(ofSize: size, weight: weight) : text(size, weight)
    }

    /// Bề rộng một ô chữ số: lấy chữ số rộng nhất để không bị cắt khi font không đều số.
    static func digitCell(_ font: UIFont) -> Int {
        let w = (0...9).map { ("\($0)" as NSString).size(withAttributes: [.font: font]).width }.max() ?? 0
        return Int(ceil(w)) + 2
    }
}
