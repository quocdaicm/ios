// Tạm thời: thay cho các phần chưa có trong bản ghép (SeasonArt, SeasonFallView).
// Khi có các file thật (HandShapes.swift, SeasonArt.swift…), XOÁ file này để tránh trùng tên.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Hiệu ứng mùa (hoa, tuyết đứng yên/rơi ở bản xem trước) chưa có: danh sách rỗng.
extension DecorPattern {
    var isSeasonal: Bool { DecorPattern.festive.contains(self) }
    static var geometric: [DecorPattern] { allCases.filter { !festive.contains($0) } }
    static var seasonal: [DecorPattern] { festive }
}

enum SeasonArt {
    static func fallSprites(_ p: DecorPattern) -> [UIImage] { [] }
}

struct SeasonFallView: View {
    let patterns: [DecorPattern]
    var body: some View { Color.clear.allowsHitTesting(false) }
}
