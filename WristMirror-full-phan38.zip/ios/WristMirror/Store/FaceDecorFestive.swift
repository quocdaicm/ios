// Lớp trang trí vector Noel và Tết (xoay theo kim giờ/phút/giây). Bản iOS, không có trong WristMirror gốc.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

extension DecorPattern {
    /// Họa tiết nhiều màu cố định (không dùng bộ chọn màu).
    static let festive: [DecorPattern] = [.noelWreath, .noelStar, .noelSnow, .tetMai, .tetDao, .tetLantern, .tetFirework]
}

extension FaceRenderer {
    /// Gốc (0,0) ở tâm, bán kính R. Mọi họa tiết đối xứng tròn nên quay mượt, không lệch tâm.
    static func drawFestiveDecor(_ ctx: CGContext, pattern: DecorPattern, radius R: CGFloat) {
        let pi = CGFloat.pi
        let lw = max(1.0, R * 0.012)
        ctx.setLineCap(.round)
        ctx.setLineJoin(.round)

        func rgb(_ hex: UInt32, _ a: CGFloat = 1) -> UIColor {
            UIColor(red: CGFloat((hex >> 16) & 255) / 255,
                    green: CGFloat((hex >> 8) & 255) / 255,
                    blue: CGFloat(hex & 255) / 255, alpha: a)
        }
        func fill(_ p: CGPath, _ c: UIColor) {
            ctx.setFillColor(c.cgColor)
            ctx.addPath(p)
            ctx.fillPath()
        }
        func outline(_ p: CGPath, _ c: UIColor, _ w: CGFloat) {
            ctx.setStrokeColor(c.cgColor)
            ctx.setLineWidth(w)
            ctx.addPath(p)
            ctx.strokePath()
        }
        func disc(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ c: UIColor) {
            ctx.setFillColor(c.cgColor)
            ctx.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func circle(_ r: CGFloat, _ c: UIColor, _ w: CGFloat) {
            ctx.setStrokeColor(c.cgColor)
            ctx.setLineWidth(w)
            ctx.strokeEllipse(in: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r))
        }
        func seg(_ x1: CGFloat, _ y1: CGFloat, _ x2: CGFloat, _ y2: CGFloat, _ c: UIColor, _ w: CGFloat) {
            ctx.setStrokeColor(c.cgColor)
            ctx.setLineWidth(w)
            ctx.move(to: CGPoint(x: x1, y: y1))
            ctx.addLine(to: CGPoint(x: x2, y: y2))
            ctx.strokePath()
        }
        func around(_ n: Int, offset: CGFloat = 0, _ body: (Int) -> Void) {
            for i in 0..<n {
                ctx.saveGState()
                ctx.rotate(by: offset + CGFloat(i) * 2 * pi / CGFloat(n))
                body(i)
                ctx.restoreGState()
            }
        }
        /// Lá/cánh nhọn mọc từ gốc lên trên (y âm).
        func leaf(_ len: CGFloat, _ w: CGFloat) -> CGPath {
            let p = CGMutablePath()
            p.move(to: .zero)
            p.addQuadCurve(to: CGPoint(x: 0, y: -len), control: CGPoint(x: w, y: -len * 0.5))
            p.addQuadCurve(to: .zero, control: CGPoint(x: -w, y: -len * 0.5))
            p.closeSubpath()
            return p
        }
        func star(_ n: Int, _ ro: CGFloat, _ ri: CGFloat, _ rot: CGFloat) -> CGPath {
            let p = CGMutablePath()
            for i in 0..<(n * 2) {
                let a = rot + CGFloat(i) * pi / CGFloat(n)
                let r = (i % 2 == 0) ? ro : ri
                let pt = CGPoint(x: sin(a) * r, y: -cos(a) * r)
                if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
            }
            p.closeSubpath()
            return p
        }
        /// Hoa 5 cánh tròn (mai/đào) tại gốc hiện tại.
        func blossom(_ r: CGFloat, petal: UInt32, edge: UInt32, core: UInt32, stamen: UInt32) {
            let pr = r * 0.48
            let cy = -r * 0.56
            for k in 0..<5 {
                ctx.saveGState()
                ctx.rotate(by: CGFloat(k) * 2 * pi / 5)
                let rect = CGRect(x: -pr, y: cy - pr, width: 2 * pr, height: 2 * pr)
                ctx.setFillColor(rgb(petal).cgColor)
                ctx.fillEllipse(in: rect)
                ctx.setStrokeColor(rgb(edge).cgColor)
                ctx.setLineWidth(max(0.8, r * 0.07))
                ctx.strokeEllipse(in: rect)
                ctx.restoreGState()
            }
            disc(0, 0, r * 0.32, rgb(petal))
            disc(0, 0, r * 0.2, rgb(core))
            for k in 0..<5 {
                let a = CGFloat(k) * 2 * pi / 5 + pi / 10
                disc(sin(a) * r * 0.34, -cos(a) * r * 0.34, r * 0.07, rgb(stamen))
            }
        }

        switch pattern {

        case .noelWreath:
            // Vòng thông hai lớp, quả đỏ, nơ đỏ, ngôi sao nhỏ
            circle(R * 0.80, rgb(0x0C3A22), lw * 3)
            around(48) { i in
                ctx.translateBy(x: 0, y: -R * 0.80)
                let dark = rgb(i % 2 == 0 ? 0x146B3A : 0x0F4A2C)
                ctx.saveGState(); ctx.rotate(by: 0.55)
                fill(leaf(R * 0.20, R * 0.045), dark)
                ctx.restoreGState()
                ctx.saveGState(); ctx.rotate(by: -0.55)
                fill(leaf(R * 0.20, R * 0.045), dark)
                ctx.restoreGState()
            }
            around(36, offset: pi / 36) { i in
                ctx.translateBy(x: 0, y: -R * 0.78)
                let light = rgb(i % 2 == 0 ? 0x1F9B52 : 0x3FBF6D)
                ctx.saveGState(); ctx.rotate(by: 0.35)
                fill(leaf(R * 0.17, R * 0.035), light)
                ctx.restoreGState()
                ctx.saveGState(); ctx.rotate(by: -0.35)
                fill(leaf(R * 0.17, R * 0.035), light)
                ctx.restoreGState()
            }
            // Chùm quả đỏ
            around(8, offset: pi / 8) { _ in
                ctx.translateBy(x: 0, y: -R * 0.80)
                disc(-R * 0.03, 0, R * 0.036, rgb(0xB5121B))
                disc(R * 0.03, 0, R * 0.036, rgb(0xB5121B))
                disc(0, -R * 0.045, R * 0.036, rgb(0xB5121B))
                disc(-R * 0.03 - R * 0.01, -R * 0.01, R * 0.012, rgb(0xFF8C8C))
                disc(R * 0.03 - R * 0.01, -R * 0.01, R * 0.012, rgb(0xFF8C8C))
                disc(-R * 0.01, -R * 0.055, R * 0.012, rgb(0xFF8C8C))
            }
            // Nơ đỏ ở đỉnh
            do {
                ctx.saveGState()
                ctx.translateBy(x: 0, y: -R * 0.80)
                let loopL = CGMutablePath()
                loopL.move(to: .zero)
                loopL.addCurve(to: CGPoint(x: -R * 0.20, y: -R * 0.05),
                               control1: CGPoint(x: -R * 0.06, y: -R * 0.20), control2: CGPoint(x: -R * 0.22, y: -R * 0.16))
                loopL.addCurve(to: .zero,
                               control1: CGPoint(x: -R * 0.20, y: R * 0.10), control2: CGPoint(x: -R * 0.06, y: R * 0.08))
                fill(loopL, rgb(0xD81F2A))
                outline(loopL, rgb(0x8E0E16), lw)
                let loopR = CGMutablePath()
                loopR.move(to: .zero)
                loopR.addCurve(to: CGPoint(x: R * 0.20, y: -R * 0.05),
                               control1: CGPoint(x: R * 0.06, y: -R * 0.20), control2: CGPoint(x: R * 0.22, y: -R * 0.16))
                loopR.addCurve(to: .zero,
                               control1: CGPoint(x: R * 0.20, y: R * 0.10), control2: CGPoint(x: R * 0.06, y: R * 0.08))
                fill(loopR, rgb(0xD81F2A))
                outline(loopR, rgb(0x8E0E16), lw)
                disc(0, 0, R * 0.045, rgb(0xB5121B))
                ctx.restoreGState()
            }
            around(12, offset: pi / 12) { i in
                if i % 2 == 0 { return }
                ctx.translateBy(x: 0, y: -R * 0.56)
                fill(star(4, R * 0.045, R * 0.012, 0), rgb(0xFFE9A8))
            }
            circle(R * 0.98, rgb(0xE8B44A), lw)

        case .noelStar:
            // Ngôi sao 8 cánh vàng, tia sáng, vòng quả châu đỏ-xanh, hạt tuyết
            around(16) { i in
                let a = i % 2 == 0 ? R * 0.92 : R * 0.78
                seg(0, -R * 0.62, 0, -a, rgb(0xFFE08A, 0.9), lw * 1.4)
            }
            around(24) { _ in disc(0, -R * 0.97, R * 0.012, rgb(0xFFFFFF, 0.9)) }
            around(12, offset: pi / 12) { i in
                disc(0, -R * 0.70, R * 0.05, rgb(i % 2 == 0 ? 0xD81F2A : 0x1F9B52))
                disc(-R * 0.014, -R * 0.714, R * 0.014, rgb(0xFFFFFF, 0.8))
            }
            circle(R * 0.70, rgb(0xE8B44A, 0.8), lw)
            fill(star(8, R * 0.58, R * 0.22, 0), rgb(0xE8A21A))
            outline(star(8, R * 0.58, R * 0.22, 0), rgb(0x8C4A00), lw)
            fill(star(8, R * 0.44, R * 0.17, pi / 8), rgb(0xFFD866))
            fill(star(8, R * 0.28, R * 0.12, 0), rgb(0xFFF0B0))
            disc(0, 0, R * 0.08, rgb(0xD81F2A))
            disc(-R * 0.02, -R * 0.02, R * 0.025, rgb(0xFFFFFF, 0.8))

        case .noelSnow:
            // Bông tuyết 6 nhánh có cành phụ, viền lục giác và hạt băng
            let ice = rgb(0xE3F4FF)
            let blue = rgb(0x8EC9FF)
            around(6) { _ in
                seg(0, 0, 0, -R * 0.92, ice, lw * 2)
                for (f, l) in [(0.30, 0.20), (0.52, 0.16), (0.72, 0.12)] as [(CGFloat, CGFloat)] {
                    ctx.saveGState()
                    ctx.translateBy(x: 0, y: -R * f)
                    seg(0, 0, -R * l * 0.8, -R * l * 0.8, ice, lw * 1.4)
                    seg(0, 0, R * l * 0.8, -R * l * 0.8, ice, lw * 1.4)
                    disc(-R * l * 0.8, -R * l * 0.8, R * 0.014, blue)
                    disc(R * l * 0.8, -R * l * 0.8, R * 0.014, blue)
                    ctx.restoreGState()
                }
                ctx.saveGState()
                ctx.translateBy(x: 0, y: -R * 0.95)
                let dia = CGMutablePath()
                dia.move(to: CGPoint(x: 0, y: -R * 0.05))
                dia.addLine(to: CGPoint(x: R * 0.03, y: 0))
                dia.addLine(to: CGPoint(x: 0, y: R * 0.04))
                dia.addLine(to: CGPoint(x: -R * 0.03, y: 0))
                dia.closeSubpath()
                fill(dia, rgb(0xFFFFFF))
                ctx.restoreGState()
            }
            around(6, offset: pi / 6) { _ in
                disc(0, -R * 0.60, R * 0.03, blue)
                disc(0, -R * 0.82, R * 0.018, ice)
            }
            let hex = star(6, R * 0.20, R * 0.20, 0)
            fill(hex, rgb(0xBFE3FF))
            outline(hex, rgb(0xFFFFFF), lw)
            disc(0, 0, R * 0.07, rgb(0xFFFFFF))
            circle(R * 0.98, rgb(0x8EC9FF, 0.7), lw)

        case .tetMai:
            let br = rgb(0x7A4426)
            circle(R * 0.80, br, lw * 2.4)
            around(12, offset: pi / 12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.80)
                fill(leaf(R * 0.16, R * 0.05), rgb(0x3F8F3A))
            }
            around(12) { i in
                ctx.translateBy(x: 0, y: -R * 0.80)
                blossom(i % 2 == 0 ? R * 0.15 : R * 0.12, petal: 0xFFD31F, edge: 0xE9A400, core: 0xE58A00, stamen: 0x8C4A00)
            }
            around(12, offset: pi / 12) { _ in disc(0, -R * 0.93, R * 0.028, rgb(0xFFCB12)) }
            circle(R * 0.58, rgb(0xE9A400, 0.7), lw)
            around(6) { _ in
                ctx.translateBy(x: 0, y: -R * 0.44)
                blossom(R * 0.15, petal: 0xFFDB3A, edge: 0xE9A400, core: 0xE58A00, stamen: 0x8C4A00)
            }
            blossom(R * 0.18, petal: 0xFFD31F, edge: 0xE9A400, core: 0xE58A00, stamen: 0x8C4A00)

        case .tetDao:
            let br = rgb(0x6A3A2A)
            circle(R * 0.80, br, lw * 2.4)
            around(12, offset: pi / 12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.80)
                fill(leaf(R * 0.16, R * 0.05), rgb(0x4B9A45))
            }
            around(12) { i in
                ctx.translateBy(x: 0, y: -R * 0.80)
                blossom(i % 2 == 0 ? R * 0.15 : R * 0.12, petal: 0xFFC3D4, edge: 0xE85C86, core: 0xD93A6A, stamen: 0xFFE066)
            }
            around(12, offset: pi / 12) { _ in disc(0, -R * 0.93, R * 0.026, rgb(0xFF9DB8)) }
            circle(R * 0.58, rgb(0xE85C86, 0.65), lw)
            around(6) { _ in
                ctx.translateBy(x: 0, y: -R * 0.44)
                blossom(R * 0.15, petal: 0xFF9DB8, edge: 0xE85C86, core: 0xD93A6A, stamen: 0xFFE066)
            }
            blossom(R * 0.18, petal: 0xFFC3D4, edge: 0xE85C86, core: 0xD93A6A, stamen: 0xFFE066)

        case .tetLantern:
            // 12 đèn lồng đỏ treo hướng vào tâm, vòng vàng và đồng tiền
            circle(R, rgb(0xE8B44A), lw * 1.6)
            circle(R * 0.96, rgb(0xE8B44A, 0.6), lw)
            around(12, offset: pi / 12) { _ in disc(0, -R * 0.98, R * 0.018, rgb(0xFFD866)) }
            around(12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.96)
                // nắp trên
                let capTop = CGRect(x: -R * 0.045, y: 0, width: R * 0.09, height: R * 0.03)
                ctx.setFillColor(rgb(0xE8A21A).cgColor)
                ctx.fill(capTop)
                // thân đèn
                let bodyRect = CGRect(x: -R * 0.075, y: R * 0.03, width: R * 0.15, height: R * 0.19)
                ctx.setFillColor(rgb(0x8E100E).cgColor)
                ctx.fillEllipse(in: bodyRect)
                let inner = bodyRect.insetBy(dx: R * 0.008, dy: R * 0.008)
                ctx.setFillColor(rgb(0xE32B22).cgColor)
                ctx.fillEllipse(in: inner)
                ctx.setFillColor(rgb(0xFF6A4A, 0.55).cgColor)
                ctx.fillEllipse(in: CGRect(x: -R * 0.05, y: R * 0.05, width: R * 0.05, height: R * 0.11))
                ctx.setStrokeColor(rgb(0xFFB52E).cgColor)
                ctx.setLineWidth(max(0.8, lw * 0.8))
                ctx.strokeEllipse(in: CGRect(x: -R * 0.03, y: R * 0.03, width: R * 0.06, height: R * 0.19))
                seg(0, R * 0.03, 0, R * 0.22, rgb(0xFFB52E), max(0.8, lw * 0.8))
                // nắp dưới và tua
                ctx.setFillColor(rgb(0xE8A21A).cgColor)
                ctx.fill(CGRect(x: -R * 0.045, y: R * 0.22, width: R * 0.09, height: R * 0.025))
                seg(-R * 0.015, R * 0.245, -R * 0.02, R * 0.31, rgb(0xFFB52E), lw)
                seg(0, R * 0.245, 0, R * 0.32, rgb(0xFFB52E), lw)
                seg(R * 0.015, R * 0.245, R * 0.02, R * 0.31, rgb(0xFFB52E), lw)
            }
            // đồng tiền vàng
            around(12, offset: pi / 12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.62)
                disc(0, 0, R * 0.05, rgb(0xE8A21A))
                disc(0, 0, R * 0.04, rgb(0xFFD866))
                ctx.setFillColor(rgb(0x8E100E).cgColor)
                ctx.fill(CGRect(x: -R * 0.014, y: -R * 0.014, width: R * 0.028, height: R * 0.028))
            }
            circle(R * 0.46, rgb(0xE8B44A, 0.6), lw)
            around(8) { _ in disc(0, -R * 0.36, R * 0.022, rgb(0xFFD866)) }
            fill(star(12, R * 0.20, R * 0.11, 0), rgb(0xD81F2A))
            disc(0, 0, R * 0.07, rgb(0xFFD866))

        case .tetFirework:
            func burst(_ rays: Int, _ r0: CGFloat, _ r1: CGFloat, _ c1: UInt32, _ c2: UInt32, _ dotR: CGFloat) {
                around(rays) { i in
                    let c = rgb(i % 2 == 0 ? c1 : c2)
                    let len = i % 2 == 0 ? r1 : r1 * 0.78
                    seg(0, -r0, 0, -len, c, lw * 1.3)
                    disc(0, -len - dotR * 1.6, dotR, c)
                }
                disc(0, 0, r0 * 0.7, rgb(0xFFFFFF))
            }
            burst(24, R * 0.10, R * 0.40, 0xFFC83D, 0xFF4A3D, R * 0.014)
            around(8, offset: pi / 8) { i in
                ctx.translateBy(x: 0, y: -R * 0.74)
                let pal: [(UInt32, UInt32)] = [(0xFF7A59, 0xFFD7A0), (0xF8D25A, 0xFFF3C4)]
                let p = pal[i % 2]
                burst(12, R * 0.02, R * 0.15, p.0, p.1, R * 0.010)
            }
            around(16, offset: pi / 16) { i in
                if i % 2 == 0 {
                    ctx.translateBy(x: 0, y: -R * 0.54)
                    fill(star(4, R * 0.04, R * 0.01, 0), rgb(0xFFE9A8))
                }
            }
            circle(R * 0.98, rgb(0xB03A36, 0.8), lw)

        default:
            break
        }
    }
}
