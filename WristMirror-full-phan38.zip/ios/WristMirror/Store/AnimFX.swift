// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Hoạt ảnh xoay liên tục (THỬ NGHIỆM): 24 ảnh của một họa tiết quay trọn một vòng, đồng hồ tự phát lặp lại.
/// Cấu trúc lớp loại 11 đọc từ 3 dervish quay trong file KozmikSemazen (24 ảnh 92x92, chu kỳ 50 ms/khung, 3 bản lệch pha).
/// Ý nghĩa các trường 4/5 và nhóm 4 chưa kiểm chứng, đang chép đúng giá trị của file thật.
enum AnimFX {
    static let frameCount = 24
    static let minInterval = 30
    static let maxInterval = 120
}

extension FaceRenderer {
    /// Lớp trang trí tạm dùng để vẽ họa tiết cho hoạt ảnh (không quay theo kim).
    static func animLayer(_ d: FaceDesign) -> DecorLayer {
        DecorLayer(pattern: d.animPattern, color: d.animColor, opacity: 0.92, scale: min(d.animSize, 0.5), spin: .none)
    }

    /// Cạnh ảnh và vị trí góc trên-trái (toạ độ mặt 466x466, đã kẹp trong mặt).
    static func animPlacement(_ d: FaceDesign) -> (side: Int, x: Int, y: Int) {
        let side = decorSide(animLayer(d))
        let full = Int(size)
        let x = min(max(0, Int((d.animX * Double(full)).rounded()) - side / 2), full - side)
        let y = min(max(0, Int((d.animY * Double(full)).rounded()) - side / 2), full - side)
        return (side, x, y)
    }

    /// Khung `k` (0..<24): họa tiết đã quay k * 360/24 độ (đảo chiều nếu `animReverse`).
    static func animFrame(_ d: FaceDesign, _ k: Int) -> HwtRaster {
        let l = animLayer(d)
        let side = decorSide(l)
        let step = 2 * CGFloat.pi / CGFloat(AnimFX.frameCount)
        let angle = CGFloat(k) * step * (d.animReverse ? -1 : 1)
        return drawRaster(width: side, height: side) { ctx in
            ctx.translateBy(x: CGFloat(side) / 2, y: CGFloat(side) / 2)
            ctx.rotate(by: angle)
            drawDecorLayer(ctx, l)
        }
    }

    static func animFrames(_ d: FaceDesign) -> [HwtRaster] {
        guard d.animOn else { return [] }
        return (0..<AnimFX.frameCount).map { animFrame(d, $0) }
    }
}
