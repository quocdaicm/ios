// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Lưu/đọc `FaceDesign` dưới dạng JSON để mở lại chỉnh sửa mặt đồng hồ đã tạo.
/// - Chỉ ghi các trường có trong bảng `fields`; trường thiếu hoặc sai kiểu khi đọc giữ giá trị mặc định,
///   nên bản app mới thêm trường vẫn mở được thiết kế cũ.
/// - Ảnh nền (`photo`) không nằm trong JSON mà lưu riêng (xem `HwtLibrary.saveDesign`).
/// Khi thêm thuộc tính mới vào `FaceDesign`, thêm một dòng vào `fields` để thuộc tính đó được lưu.
enum FaceDesignCodec {
    static let version = 1

    private struct Field {
        let key: String
        let encode: (FaceDesign) -> Any
        let decode: (inout FaceDesign, Any) -> Void
    }

    // MARK: Màu

    private static func components(_ color: Color) -> [Double] {
        var r: CGFloat = 1, g: CGFloat = 1, b: CGFloat = 1, a: CGFloat = 1
        if UIColor(color).getRed(&r, green: &g, blue: &b, alpha: &a) {
            return [Double(r), Double(g), Double(b), Double(a)]
        }
        return [1, 1, 1, 1]
    }

    private static func color(_ any: Any?) -> Color? {
        guard let arr = any as? [Any], arr.count >= 3 else { return nil }
        let v = arr.compactMap { ($0 as? NSNumber)?.doubleValue }
        guard v.count == arr.count else { return nil }
        let a = v.count > 3 ? v[3] : 1
        return Color(.sRGB, red: v[0], green: v[1], blue: v[2], opacity: a)
    }

    private static func number(_ any: Any?) -> Double? { (any as? NSNumber)?.doubleValue }
    private static func flag(_ any: Any?) -> Bool? { (any as? NSNumber)?.boolValue }

    // MARK: Kiểu phụ

    private static func encodeLayer(_ l: DecorLayer) -> [String: Any] {
        ["id": l.id.uuidString, "pattern": l.pattern.rawValue, "color": components(l.color),
         "opacity": l.opacity, "scale": l.scale, "spin": l.spin.rawValue]
    }

    private static func decodeLayer(_ any: Any) -> DecorLayer? {
        guard let d = any as? [String: Any] else { return nil }
        var l = DecorLayer()
        if let s = d["id"] as? String, let u = UUID(uuidString: s) { l.id = u }
        if let s = d["pattern"] as? String, let p = DecorPattern(rawValue: s) { l.pattern = p }
        if let c = color(d["color"]) { l.color = c }
        if let v = number(d["opacity"]) { l.opacity = v }
        if let v = number(d["scale"]) { l.scale = v }
        if let s = d["spin"] as? String, let p = DecorSpin(rawValue: s) { l.spin = p }
        return l
    }

    private static func encodeWidget(_ w: DataWidget) -> [String: Any] {
        ["show": w.show, "color": components(w.color), "size": w.size, "x": w.x, "y": w.y,
         "unit": w.unit, "icon": w.icon, "iconMono": w.iconMono,
         "customStyle": w.customStyle, "style": w.style.rawValue, "ownColors": w.ownColors]
    }

    private static func decodeWidget(_ any: Any, into base: DataWidget) -> DataWidget {
        guard let d = any as? [String: Any] else { return base }
        var w = base
        if let v = flag(d["show"]) { w.show = v }
        if let c = color(d["color"]) { w.color = c }
        if let v = number(d["size"]) { w.size = v }
        if let v = number(d["x"]) { w.x = v }
        if let v = number(d["y"]) { w.y = v }
        if let v = flag(d["unit"]) { w.unit = v }
        if let v = flag(d["icon"]) { w.icon = v }
        if let v = flag(d["iconMono"]) { w.iconMono = v }
        if let v = flag(d["customStyle"]) { w.customStyle = v }
        if let s = d["style"] as? String, let v = DigitalStyle(rawValue: s) { w.style = v }
        if let v = flag(d["ownColors"]) { w.ownColors = v }
        return w
    }

    private static func encodePlate(_ p: PlateStyle) -> [String: Any] {
        ["shape": p.shape, "fill": components(p.fill), "line": components(p.line),
         "opacity": p.opacity, "outline": p.outline]
    }

    private static func decodePlate(_ any: Any) -> PlateStyle? {
        guard let d = any as? [String: Any] else { return nil }
        var p = PlateStyle()
        if let v = number(d["shape"]) { p.shape = Int(v) }
        if let c = color(d["fill"]) { p.fill = c }
        if let c = color(d["line"]) { p.line = c }
        if let v = number(d["opacity"]) { p.opacity = v }
        if let v = flag(d["outline"]) { p.outline = v }
        return p
    }

    // MARK: Bảng trường

    /// Số / chữ / công tắc.
    private static func f<T>(_ key: String, _ kp: WritableKeyPath<FaceDesign, T>) -> Field {
        Field(key: key, encode: { $0[keyPath: kp] }, decode: { d, any in
            if T.self == Double.self, let v = number(any) { d[keyPath: kp] = v as! T }
            else if T.self == Int.self, let v = number(any) { d[keyPath: kp] = Int(v) as! T }
            else if T.self == Bool.self, let v = flag(any) { d[keyPath: kp] = v as! T }
            else if T.self == String.self, let v = any as? String { d[keyPath: kp] = v as! T }
        })
    }

    private static func c(_ key: String, _ kp: WritableKeyPath<FaceDesign, Color>) -> Field {
        Field(key: key, encode: { components($0[keyPath: kp]) }, decode: { d, any in
            if let v = color(any) { d[keyPath: kp] = v }
        })
    }

    private static func e<T: RawRepresentable>(_ key: String, _ kp: WritableKeyPath<FaceDesign, T>) -> Field where T.RawValue == String {
        Field(key: key, encode: { $0[keyPath: kp].rawValue }, decode: { d, any in
            if let s = any as? String, let v = T(rawValue: s) { d[keyPath: kp] = v }
        })
    }

    private static func d(_ key: String, _ kp: WritableKeyPath<FaceDesign, [DecorLayer]>) -> Field {
        Field(key: key, encode: { $0[keyPath: kp].map(encodeLayer) }, decode: { d, any in
            if let arr = any as? [Any] { d[keyPath: kp] = arr.compactMap(decodeLayer) }
        })
    }

    private static func w(_ key: String, _ kp: WritableKeyPath<FaceDesign, DataWidget>) -> Field {
        Field(key: key, encode: { encodeWidget($0[keyPath: kp]) }, decode: { d, any in
            d[keyPath: kp] = decodeWidget(any, into: d[keyPath: kp])
        })
    }

    private static func p(_ key: String, _ kp: WritableKeyPath<FaceDesign, [String: PlateStyle]>) -> Field {
        Field(key: key, encode: { $0[keyPath: kp].mapValues(encodePlate) }, decode: { d, any in
            guard let dict = any as? [String: Any] else { return }
            var out = [String: PlateStyle]()
            for (k, v) in dict { if let s = decodePlate(v) { out[k] = s } }
            d[keyPath: kp] = out
        })
    }

    private static func m(_ key: String, _ kp: WritableKeyPath<FaceDesign, [String: Int]>) -> Field {
        Field(key: key, encode: { $0[keyPath: kp] }, decode: { d, any in
            guard let dict = any as? [String: Any] else { return }
            var out = [String: Int]()
            for (k, v) in dict { if let n = number(v) { out[k] = Int(n) } }
            d[keyPath: kp] = out
        })
    }

    private static let fields: [Field] = [
            f("name", \.name),
            f("author", \.author),
            c("backgroundColor", \.backgroundColor),
            f("useGradient", \.useGradient),
            c("backgroundColor2", \.backgroundColor2),
            f("photoZoom", \.photoZoom),
            f("photoPanX", \.photoPanX),
            f("photoPanY", \.photoPanY),
            f("photoDim", \.photoDim),
            f("backdrop", \.backdrop),
            f("aodBackdrop", \.aodBackdrop),
            d("decor", \.decor),
            f("showLunar", \.showLunar),
            c("lunarColor", \.lunarColor),
            f("lunarSize", \.lunarSize),
            f("lunarY", \.lunarY),
            f("lunarLabel", \.lunarLabel),
            f("lunarX", \.lunarX),
            e("lunarStyle", \.lunarStyle),
            f("lunarCustom", \.lunarCustom),
            f("lunarOwnColors", \.lunarOwnColors),
            f("lunarSep", \.lunarSep),
            f("lunarLabelLang", \.lunarLabelLang),
            f("lunarLabelFont", \.lunarLabelFont),
            f("showSolar", \.showSolar),
            c("solarColor", \.solarColor),
            f("solarSize", \.solarSize),
            f("solarX", \.solarX),
            f("solarY", \.solarY),
            f("solarLabel", \.solarLabel),
            e("solarStyle", \.solarStyle),
            f("solarCustom", \.solarCustom),
            f("solarOwnColors", \.solarOwnColors),
            f("solarSep", \.solarSep),
            f("solarLabelLang", \.solarLabelLang),
            f("solarLabelFont", \.solarLabelFont),
            f("showWeekday", \.showWeekday),
            c("weekdayColor", \.weekdayColor),
            f("weekdaySize", \.weekdaySize),
            f("weekdayFX", \.weekdayFX),
            f("weekdayX", \.weekdayX),
            f("weekdayY", \.weekdayY),
            f("showDigital", \.showDigital),
            c("digitalColor", \.digitalColor),
            f("digitalSize", \.digitalSize),
            f("digitalX", \.digitalX),
            f("digitalY", \.digitalY),
            e("digitalStyle", \.digitalStyle),
            f("digitalCustom", \.digitalCustom),
            f("digitalOwnColors", \.digitalOwnColors),
            f("showName", \.showName),
            f("nameText", \.nameText),
            c("nameColor", \.nameColor),
            f("nameSize", \.nameSize),
            f("nameX", \.nameX),
            f("nameY", \.nameY),
            f("nameStyle", \.nameStyle),
            f("nameFX", \.nameFX),
            f("textFontIndex", \.textFontIndex),
            f("numberFontIndex", \.numberFontIndex),
            m("elementFonts", \.elementFonts),
            m("taps", \.taps),
            m("edgeTaps", \.edgeTaps),
            f("tapsOn", \.tapsOn),
            e("dataStyle", \.dataStyle),
            f("dataOwnColors", \.dataOwnColors),
            w("battery", \.battery),
            w("steps", \.steps),
            w("heart", \.heart),
            w("calories", \.calories),
            w("weather", \.weather),
            f("weatherText", \.weatherText),
            f("weatherIcon", \.weatherIcon),
            f("weatherIconMono", \.weatherIconMono),
            f("unitSymbol", \.unitSymbol),
            f("batteryIconStyle", \.batteryIconStyle),
            f("thermoStyle", \.thermoStyle),
            f("batteryLevelStyle", \.batteryLevelStyle),
            f("iconSVG", \.iconSVG),
            p("plates", \.plates),
            f("weatherRange", \.weatherRange),
            f("autoLayout", \.autoLayout),
            f("textOutline", \.textOutline),
            e("marks", \.marks),
            c("marksColor", \.marksColor),
            e("numeralStyle", \.numeralStyle),
            f("numeralOwnColors", \.numeralOwnColors),
            e("handStyle", \.handStyle),
            c("hourColor", \.hourColor),
            c("minuteColor", \.minuteColor),
            c("secondColor", \.secondColor),
            c("capColor", \.capColor),
            f("showSecond", \.showSecond),
            f("handWidth", \.handWidth),
            f("handOutline", \.handOutline),
            f("handOwnColors", \.handOwnColors),
            e("secondFX", \.secondFX),
            c("secondFXColor", \.secondFXColor),
            f("animOn", \.animOn),
            e("animPattern", \.animPattern),
            c("animColor", \.animColor),
            f("animSize", \.animSize),
            f("animX", \.animX),
            f("animY", \.animY),
            f("animInterval", \.animInterval),
            f("animReverse", \.animReverse),
            f("animLoopMode", \.animLoopMode),
            e("animKind", \.animKind),
            f("animFallFrames", \.animFallFrames),
            f("animDensity", \.animDensity),
            e("aodBackground", \.aodBackground),
            f("aodBrightness", \.aodBrightness),
            f("aodShowMarks", \.aodShowMarks),
            c("aodHandColor", \.aodHandColor),
            c("aodMarksColor", \.aodMarksColor),
            f("aodPhotoZoom", \.aodPhotoZoom),
            f("aodPhotoPanX", \.aodPhotoPanX),
            f("aodPhotoPanY", \.aodPhotoPanY),
            f("aodPhotoDim", \.aodPhotoDim),
            c("aodColor", \.aodColor),
            c("aodColor2", \.aodColor2),
            f("aodUseGradient", \.aodUseGradient),
            f("aodShowDecor", \.aodShowDecor),
            f("aodShowInfo", \.aodShowInfo),
    ]

    // MARK: API

    /// JSON của thiết kế (không gồm ảnh nền).
    static func encode(_ design: FaceDesign) throws -> Data {
        var dict = [String: Any]()
        for field in fields { dict[field.key] = field.encode(design) }
        let root: [String: Any] = ["version": version, "design": dict]
        return try JSONSerialization.data(withJSONObject: root, options: [.prettyPrinted, .sortedKeys])
    }

    /// Đọc lại thiết kế; `photo` do nơi gọi gán. Trả về nil nếu JSON hỏng.
    static func decode(_ data: Data) -> FaceDesign? {
        guard let root = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let dict = root["design"] as? [String: Any] else { return nil }
        var design = FaceDesign()
        for field in fields {
            if let value = dict[field.key] { field.decode(&design, value) }
        }
        // Thiết kế cũ (trước kiểu số chung) đã chọn kiểu riêng cho giờ số / ngày tháng: giữ nguyên bằng cách bật "kiểu riêng".
        func migrate(_ styleKey: String, _ customKey: String, _ kp: WritableKeyPath<FaceDesign, Bool>) {
            if dict[customKey] == nil, let s = dict[styleKey] as? String, s != DigitalStyle.classic.rawValue {
                design[keyPath: kp] = true
            }
        }
        migrate("digitalStyle", "digitalCustom", \.digitalCustom)
        migrate("solarStyle", "solarCustom", \.solarCustom)
        migrate("lunarStyle", "lunarCustom", \.lunarCustom)
        return design
    }
}
