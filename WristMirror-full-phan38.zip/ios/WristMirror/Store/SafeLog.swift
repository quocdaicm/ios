// Derived from WristMirror (腕镜), Copyright 2026 Escosis, https://github.com/Escosis/WristMirror (Apache-2.0).
// Ported to Swift and modified by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import Foundation

/// Nhật ký chẩn đoán có giới hạn (port từ store/SafeLog.java).
/// Chỉ lưu metadata giao tiếp; che MAC/UUID thiết bị, PIN, khoá, ID Huawei và số dài.
final class SafeLog {
    private static let maxFile = 256 * 1024
    private static let maxRows = 400

    private let lock = NSLock()
    private let fileURL: URL
    private let formatter: DateFormatter
    private var rows: [String] = []
    private var listener: (([String]) -> Void)?

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("diagnostics", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("connection.log")
        formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "MM-dd HH:mm:ss.SSS"
    }

    func setListener(_ cb: (([String]) -> Void)?) {
        lock.lock()
        listener = cb
        let snapshot = rows
        lock.unlock()
        cb?(snapshot)
    }

    private static func sanitize(_ input: String?) -> String {
        guard var s = input else { return "" }
        s = s.replacingOccurrences(of: "\r", with: " ").replacingOccurrences(of: "\n", with: " ")
        s = s.replacingOccurrences(of: "(?i)(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", with: "<device>", options: .regularExpression)
        s = s.replacingOccurrences(
            of: "(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            with: "<device>", options: .regularExpression)
        s = s.replacingOccurrences(
            of: "(?i)(pin|secret|auth[_-]?key|huawei[_-]?id|authToken|encAuthToken)\\s*[:=]\\s*[^ ,;]+",
            with: "$1=<redacted>", options: .regularExpression)
        s = s.replacingOccurrences(
            of: "(?<![0-9a-zA-Z])[0-9]{12,20}(?![0-9a-zA-Z])",
            with: "<long-number>", options: .regularExpression)
        if s.count > 1200 { s = String(s.prefix(1200)) + " [truncated]" }
        return s
    }

    func record(_ event: String, _ metadata: String = "") {
        lock.lock()
        let line = formatter.string(from: Date()) + " " + SafeLog.sanitize(event) + " " + SafeLog.sanitize(metadata)
        rows.append(line)
        if rows.count > SafeLog.maxRows { rows.removeFirst(rows.count - SafeLog.maxRows) }
        persistLocked(line)
        let snapshot = rows
        let cb = listener
        lock.unlock()
        cb?(snapshot)
    }

    private func persistLocked(_ line: String) {
        let bytes = Data((line + "\n").utf8)
        let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        let size = (attrs?[.size] as? NSNumber)?.intValue ?? 0
        if size + bytes.count > SafeLog.maxFile {
            // Ghi lại nửa cuối của các dòng đang giữ (đã gồm dòng mới).
            let kept = Data((rows.joined(separator: "\n") + "\n").utf8)
            try? Data(kept.suffix(SafeLog.maxFile / 2)).write(to: fileURL, options: .atomic)
            return
        }
        if let h = try? FileHandle(forWritingTo: fileURL) {
            defer { try? h.close() }
            _ = try? h.seekToEnd()
            try? h.write(contentsOf: bytes)
        } else {
            try? bytes.write(to: fileURL, options: .atomic)
        }
    }

    private static func hex2(_ v: Int) -> String {
        let s = String(v & 0xff, radix: 16, uppercase: true)
        return s.count < 2 ? "0" + s : s
    }

    func packet(_ incoming: Bool, _ service: Int, _ command: Int, _ bytes: Int,
                _ fields: [TlvView.Part]?, _ encrypted: Bool) {
        let tags = fields.map { TlvView.tags($0) } ?? "raw"
        record(incoming ? "RX" : "TX",
               "service=\(SafeLog.hex2(service)) command=\(SafeLog.hex2(command)) bytes=\(bytes) encrypted=\(encrypted) tags=\(tags)")
    }

    func snapshot() -> String {
        lock.lock(); defer { lock.unlock() }
        var out = tr("Nhật ký chẩn đoán Huawei watch face\n")
        out += tr("Nhật ký chỉ chứa metadata giao tiếp; nội dung xác thực, ID tài khoản, mã ghép nối và khoá phiên đã được loại bỏ.\n\n")
        for r in rows { out += r + "\n" }
        return out
    }

    func clear() {
        lock.lock()
        rows.removeAll()
        try? Data().write(to: fileURL, options: .atomic)
        let cb = listener
        lock.unlock()
        cb?([])
    }
}
