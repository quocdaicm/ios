// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit
import CryptoKit

// MARK: - Đọc protobuf tối giản (chỉ để tìm ranh giới phần tử trong bố cục)

struct HwtProtoField {
    let number: Int
    let wire: Int
    /// Giá trị nếu là varint (wire 0).
    let value: Int
    /// Vị trí byte đầu của thẻ (tag) trong mảng gốc.
    let start: Int
    /// Phạm vi nội dung (wire 2); rỗng với kiểu khác.
    let payload: Range<Int>
    /// Vị trí ngay sau trường.
    let end: Int
}

enum HwtProtoReader {
    private static func varint(_ b: [UInt8], _ i: inout Int, _ limit: Int) throws -> UInt64 {
        var result: UInt64 = 0
        var shift: UInt64 = 0
        while true {
            guard i < limit, shift < 64 else { throw WMFault("LUNAR_LAYOUT_INVALID") }
            let c = b[i]; i += 1
            result |= UInt64(c & 0x7f) << shift
            if c & 0x80 == 0 { return result }
            shift += 7
        }
    }

    /// Liệt kê các trường cấp cao nhất trong `range`.
    static func fields(_ b: [UInt8], in range: Range<Int>) throws -> [HwtProtoField] {
        guard range.lowerBound >= 0, range.upperBound <= b.count else { throw WMFault("LUNAR_LAYOUT_INVALID") }
        var out = [HwtProtoField]()
        var i = range.lowerBound
        let limit = range.upperBound
        while i < limit {
            let start = i
            let tag = try varint(b, &i, limit)
            let number = Int(truncatingIfNeeded: tag >> 3)
            let wire = Int(tag & 7)
            guard number > 0 else { throw WMFault("LUNAR_LAYOUT_INVALID") }
            switch wire {
            case 0:
                let v = try varint(b, &i, limit)
                out.append(HwtProtoField(number: number, wire: 0, value: Int(truncatingIfNeeded: v), start: start, payload: i..<i, end: i))
            case 1:
                guard i + 8 <= limit else { throw WMFault("LUNAR_LAYOUT_INVALID") }
                i += 8
                out.append(HwtProtoField(number: number, wire: 1, value: 0, start: start, payload: i..<i, end: i))
            case 2:
                let n = try varint(b, &i, limit)
                guard n <= UInt64(limit - i) else { throw WMFault("LUNAR_LAYOUT_INVALID") }
                let len = Int(n)
                out.append(HwtProtoField(number: number, wire: 2, value: 0, start: start, payload: i..<(i + len), end: i + len))
                i += len
            case 5:
                guard i + 4 <= limit else { throw WMFault("LUNAR_LAYOUT_INVALID") }
                i += 4
                out.append(HwtProtoField(number: number, wire: 5, value: 0, start: start, payload: i..<i, end: i))
            default:
                throw WMFault("LUNAR_LAYOUT_INVALID")
            }
        }
        return out
    }
}

// MARK: - Chèn âm lịch vào file HWT có sẵn

/// Thêm khối âm lịch (giống Studio) vào một file HWT đã có. Không sửa file gốc; trả về byte của file mới.
/// Cách làm: thêm 1 phần tử bố cục mới (đứng trước phần tử "giờ" để nằm dưới kim), thêm ảnh chữ số vào cuối
/// bảng ảnh của `watchface.bin`, thêm PNG tương ứng vào gói trong, tính lại `hashCode` (giá trị thứ 2).
enum HwtLunarPatch {
    struct Output {
        let hwt: [UInt8]
        /// Ảnh xem trước (đã vẽ âm lịch) để lưu vào thư viện; nil nếu file không có ảnh xem trước.
        let preview: [UInt8]?
    }

    struct PatchedBin {
        let bin: [UInt8]
        let firstNewImage: Int
        let rasters: [HwtRaster]
        let elementID: Int
        /// Số vùng chạm đã thêm vào file (0 nếu file đã có phần tử số 3 hoặc không có mục nào có hành động).
        var tapZones = 0
    }

    static let maxBytes = 64 * 1024 * 1024
    static let lunarValueTypes: Set<Int> = [HwtValueType.lunarMonth, HwtValueType.lunarDayTens, HwtValueType.lunarDayOnes]

    // MARK: Số nguyên little-endian

    private static func u16(_ b: [UInt8], _ o: Int) -> Int { Int(b[o]) | (Int(b[o + 1]) << 8) }
    private static func u32(_ b: [UInt8], _ o: Int) -> Int {
        Int(b[o]) | (Int(b[o + 1]) << 8) | (Int(b[o + 2]) << 16) | (Int(b[o + 3]) << 24)
    }
    private static func le16(_ v: Int) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff)] }
    private static func le32(_ v: Int) -> [UInt8] {
        [UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)]
    }

    // MARK: watchface.bin

    /// Mọi mã dữ liệu (valueType) của các lớp dãy ảnh trong bố cục.
    static func existingValueTypes(layout: [UInt8]) throws -> Set<Int> {
        var found = Set<Int>()
        for el in try HwtProtoReader.fields(layout, in: 0..<layout.count) where el.number == 1 && el.wire == 2 {
            for layer in try HwtProtoReader.fields(layout, in: el.payload) where layer.number == 5 && layer.wire == 2 {
                for body in try HwtProtoReader.fields(layout, in: layer.payload) where body.number == 5 && body.wire == 2 {
                    for f in try HwtProtoReader.fields(layout, in: body.payload) where f.number == 3 && f.wire == 0 {
                        found.insert(f.value)
                    }
                }
            }
            // Định dạng mới (Kozmik Cam/Tavuk...): phần tử có nhiều "kiểu" (trường 7), mỗi kiểu chứa lớp ở trường 2.
            for mode in try HwtProtoReader.fields(layout, in: el.payload) where mode.number == 7 && mode.wire == 2 {
                for layer in try HwtProtoReader.fields(layout, in: mode.payload) where layer.number == 2 && layer.wire == 2 {
                    for body in try HwtProtoReader.fields(layout, in: layer.payload) where body.number == 5 && body.wire == 2 {
                        for f in try HwtProtoReader.fields(layout, in: body.payload) where f.number == 3 && f.wire == 0 {
                            found.insert(f.value)
                        }
                    }
                }
            }
        }
        return found
    }

    /// Kiểm tra bố cục có sẵn âm lịch chưa.
    static func hasLunar(layout: [UInt8]) throws -> Bool {
        !(try existingValueTypes(layout: layout)).isDisjoint(with: lunarValueTypes)
    }

    private static func varintBytes(_ v: Int) -> [UInt8] {
        var out = [UInt8](); var x = UInt64(v)
        while x >= 0x80 { out.append(UInt8(x & 0x7f) | 0x80); x >>= 7 }
        out.append(UInt8(x)); return out
    }

    /// Thêm `layers` vào cuối các lớp (trường 5) của phần tử `element`, đánh chỉ số tiếp theo. Trả về bố cục mới,
    /// hoặc nil nếu phần tử có hoạt ảnh (trường 9) hay không có lớp nào (khi đó dùng phần tử mới).
    static func mergeIntoElement(layout: [UInt8], element el: HwtProtoField, layers: [HwtLayer]) throws -> [UInt8]? {
        let inner = try HwtProtoReader.fields(layout, in: el.payload)
        guard !inner.contains(where: { $0.number == 9 }) else { return nil }
        if inner.contains(where: { $0.number == 7 && $0.wire == 2 }) {
            return try mergeIntoModes(layout: layout, element: el, inner: inner, layers: layers)
        }
        let layerFields = inner.filter { $0.number == 5 && $0.wire == 2 }
        guard let last = layerFields.last else { return nil }
        var maxIndex = -1
        for lf in layerFields {
            if let f = try HwtProtoReader.fields(layout, in: lf.payload).first(where: { $0.number == 1 && $0.wire == 0 }) {
                maxIndex = max(maxIndex, f.value)
            }
        }
        var spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [layers], images: [], elementIDs: [2])
        spec.layerIndexBase = maxIndex + 1
        let built = HwtBuilder.layoutBytes(spec)
        let builtTop = try HwtProtoReader.fields(built, in: 0..<built.count)
        guard let be = builtTop.first(where: { $0.number == 1 && $0.wire == 2 }) else { return nil }
        var newLayers = [UInt8]()
        for f in try HwtProtoReader.fields(built, in: be.payload) where f.number == 5 && f.wire == 2 {
            newLayers += built[f.start..<f.end]
        }
        guard !newLayers.isEmpty else { return nil }
        var payload = Array(layout[el.payload])
        let cut = last.end - el.payload.lowerBound
        payload = Array(payload[0..<cut]) + newLayers + Array(payload[cut...])
        var out = Array(layout[0..<el.start])
        out += [UInt8](layout[el.start..<(el.payload.lowerBound)].prefix(1))   // thẻ trường 1
        out += varintBytes(payload.count)
        out += payload
        out += layout[el.end...]
        return out
    }

    /// Định dạng mới: thêm lớp vào cuối MỖI kiểu (trường 7) của phần tử. Lớp ở đây nằm ở trường 2 của kiểu
    /// (nội dung giống hệt trường 5 của định dạng cũ). Nếu có kiểu nào không có lớp thì trả nil.
    private static func mergeIntoModes(layout: [UInt8], element el: HwtProtoField, inner: [HwtProtoField],
                                       layers: [HwtLayer]) throws -> [UInt8]? {
        var elementPayload = [UInt8]()
        for f in inner {
            guard f.number == 7, f.wire == 2 else {
                elementPayload += layout[f.start..<f.end]
                continue
            }
            let modeFields = try HwtProtoReader.fields(layout, in: f.payload)
            let layerFields = modeFields.filter { $0.number == 2 && $0.wire == 2 }
            guard let last = layerFields.last else { return nil }
            var maxIndex = -1
            for lf in layerFields {
                if let x = try HwtProtoReader.fields(layout, in: lf.payload).first(where: { $0.number == 1 && $0.wire == 0 }) {
                    maxIndex = max(maxIndex, x.value)
                }
            }
            var spec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [layers], images: [], elementIDs: [2])
            spec.layerIndexBase = maxIndex + 1
            let built = HwtBuilder.layoutBytes(spec)
            let builtTop = try HwtProtoReader.fields(built, in: 0..<built.count)
            guard let be = builtTop.first(where: { $0.number == 1 && $0.wire == 2 }) else { return nil }
            var newLayers = [UInt8]()
            for x in try HwtProtoReader.fields(built, in: be.payload) where x.number == 5 && x.wire == 2 {
                newLayers += [UInt8(0x12)] + varintBytes(x.payload.count) + Array(built[x.payload])
            }
            guard !newLayers.isEmpty else { return nil }
            let mp = Array(layout[f.payload])
            let cut = last.end - f.payload.lowerBound
            let newMode = Array(mp[0..<cut]) + newLayers + Array(mp[cut...])
            elementPayload += [UInt8(0x3a)] + varintBytes(newMode.count) + newMode
        }
        var out = Array(layout[0..<el.start])
        out += [UInt8(0x0a)] + varintBytes(elementPayload.count) + elementPayload
        out += layout[el.end...]
        return out
    }

    static func patchBin(_ bin: [UInt8], design: FaceDesign) throws -> PatchedBin {
        // Tiêu đề 16 byte: u16 phiên bản, u16 độ dài bố cục, u32 độ dài bảng ảnh, u32 độ dài phần ảnh, u32 dự phòng.
        guard bin.count >= 16 else { throw WMFault("LUNAR_BIN_FORMAT") }
        let layoutLen = u16(bin, 2), tableLen = u32(bin, 4), postLen = u32(bin, 8)
        guard tableLen >= 0, postLen >= 8, tableLen % 8 == 0, 16 + layoutLen + tableLen + postLen == bin.count else {
            throw WMFault("LUNAR_BIN_FORMAT")
        }
        let layout = Array(bin[16..<(16 + layoutLen)])
        let table = Array(bin[(16 + layoutLen)..<(16 + layoutLen + tableLen)])
        let post = Array(bin[(16 + layoutLen + tableLen)...])
        let imageCount = tableLen / 8

        let top = try HwtProtoReader.fields(layout, in: 0..<layout.count)
        let elements = top.filter { $0.number == 1 && $0.wire == 2 }
        guard !elements.isEmpty else { throw WMFault("LUNAR_LAYOUT_INVALID") }
        guard FaceRenderer.infoActive(design) else { throw WMFault("INFO_NOTHING_SELECTED") }
        // Mục nào file đã có sẵn thì không thêm nữa (sẽ bị hiện chồng lên nhau).
        if !(try existingValueTypes(layout: layout)).isDisjoint(with: FaceRenderer.infoValueTypes(design)) {
            throw WMFault("LUNAR_ALREADY_PRESENT")
        }

        // Số hiệu các phần tử.
        var ids = [Int]()
        for el in elements {
            let first = try HwtProtoReader.fields(layout, in: el.payload).first { $0.number == 1 && $0.wire == 0 }
            ids.append(first?.value ?? -1)
        }

        // Ảnh mới: số thứ tự bắt đầu từ imageCount + 1.
        var rasters = [HwtRaster]()
        let layers = FaceRenderer.infoLayers(design) { r in
            rasters.append(r)
            return imageCount + rasters.count
        }
        guard !rasters.isEmpty, imageCount + rasters.count <= 999 else { throw WMFault("LUNAR_TOO_MANY_IMAGES") }

        // Ưu tiên nhét lớp mới vào phần tử số 2 (ngày) có sẵn của file thật: số hiệu phần tử mới (vd. 4) chưa từng
        // được thử trên đồng hồ, còn 0/1/2/3 là các số hiệu file thật đang dùng.
        if let k = ids.firstIndex(of: 2),
           let merged = try mergeIntoElement(layout: layout, element: elements[k], layers: layers) {
            // Thêm vùng chạm (phần tử số 3) nếu file chưa có phần tử số 3; chèn trước các trường tiêu đề ở cuối bố cục.
            var merged = merged
            var tapCount = 0
            if !ids.contains(HwtFaceSpec.tapElementID) {
                let zones = FaceRenderer.tapZones(design)
                if !zones.isEmpty {
                    var tapSpec = HwtFaceSpec(title: "x", titleCN: "x", author: "x", elements: [], images: [])
                    tapSpec.tapZones = zones
                    let built = HwtBuilder.layoutBytes(tapSpec)
                    let builtTop = try HwtProtoReader.fields(built, in: 0..<built.count)
                    if let be = builtTop.first(where: { $0.number == 1 && $0.wire == 2 }) {
                        let mergedTop = try HwtProtoReader.fields(merged, in: 0..<merged.count)
                        let at = mergedTop.first(where: { $0.number != 1 })?.start ?? merged.count
                        merged = Array(merged[0..<at]) + Array(built[be.start..<be.end]) + Array(merged[at...])
                        tapCount = zones.count
                    }
                }
            }
            guard merged.count <= 0xFFFF else { throw WMFault("LUNAR_LAYOUT_TOO_LARGE") }
            var newTable = table
            var newPost = post
            for r in rasters {
                let rec = HwtRLE.encode(r)
                newTable += le32(newPost.count)
                newTable += le32(rec.count)
                newPost += rec
            }
            var out = [UInt8]()
            out += bin[0..<2]
            out += le16(merged.count)
            out += le32(newTable.count)
            out += le32(newPost.count)
            out += bin[12..<16]
            out += merged
            out += newTable
            out += newPost
            return PatchedBin(bin: out, firstNewImage: imageCount + 1, rasters: rasters, elementID: 2, tapZones: tapCount)
        }

        // Không có phần tử số 2 dùng được: phần tử mới (vd. số 4) đã thử trên máy thật và KHÔNG hiện => từ chối.
        throw WMFault("LUNAR_NO_SLOT")
    }

    // MARK: ZIP

    /// Ghi lại một ZIP: giữ nguyên các mục (theo thứ tự cũ), thay một số mục và thêm mục mới.
    private static func rewrite(_ zip: ZipArchive, replace: [String: [UInt8]], add: [(name: String, data: [UInt8])]) throws -> [UInt8] {
        var writer = HwtZipWriter()
        var total = 0
        let date = Date()
        for e in zip.entries.values.sorted(by: { $0.localOffset < $1.localOffset }) {
            if e.isDirectory { writer.addDirectory(e.name, date: date); continue }
            let data: [UInt8]
            if let r = replace[e.name] {
                data = r
            } else {
                guard e.size <= Int64(maxBytes) else { throw WMFault("LUNAR_FILE_TOO_LARGE") }
                data = try zip.read(e, max: maxBytes)
            }
            total += data.count
            guard total <= maxBytes else { throw WMFault("LUNAR_FILE_TOO_LARGE") }
            writer.add(name: e.name, data: data, date: date)
        }
        for a in add {
            total += a.data.count
            guard total <= maxBytes else { throw WMFault("LUNAR_FILE_TOO_LARGE") }
            writer.add(name: a.name, data: a.data, date: date)
        }
        return writer.finish()
    }

    private static func sha256Upper(_ b: [UInt8]) -> String {
        SHA256.hash(data: Data(b)).map { String(format: "%02X", $0) }.joined()
    }

    private static func isZip(_ b: [UInt8]) -> Bool {
        b.count >= 4 && b[0] == 0x50 && b[1] == 0x4b && b[2] == 0x03 && b[3] == 0x04
    }

    // MARK: Chính

    static func apply(source: URL, design: FaceDesign) throws -> Output {
        let d = design
        let outer = try ZipArchive(url: source)
        let hasRoot = outer.entries["com.huawei.watchface"] != nil
        let hasSnapshot = outer.entries["watchFace/com.huawei.watchface"] != nil
        guard hasRoot != hasSnapshot else { throw WMFault("HWT_RESOURCE_MISSING_OR_AMBIGUOUS") }
        let prefix = hasRoot ? "" : "watchFace/"
        let resName = prefix + "com.huawei.watchface"
        guard let resEntry = outer.entries[resName], !resEntry.isDirectory, resEntry.size > 0,
              resEntry.size <= Int64(maxBytes) else { throw WMFault("LUNAR_FILE_TOO_LARGE") }
        let resBytes = try outer.read(resEntry, max: maxBytes)

        var newResource: [UInt8]
        if isZip(resBytes) {
            let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("wm-lunar-\(UUID().uuidString)")
            defer { try? FileManager.default.removeItem(at: tmp) }
            do { try Data(resBytes).write(to: tmp, options: .atomic) } catch { throw WMFault("FILE_WRITE_FAILED") }
            let inner = try ZipArchive(url: tmp)
            guard let binEntry = inner.entries["watchface.bin"], !binEntry.isDirectory, binEntry.size > 0,
                  binEntry.size <= Int64(maxBytes) else { throw WMFault("LUNAR_NO_BIN") }
            let bin = try inner.read(binEntry, max: maxBytes)
            let patched = try patchBin(bin, design: d)

            var add = [(name: String, data: [UInt8])]()
            for (i, r) in patched.rasters.enumerated() {
                let name = "watchface/res/" + HwtBuilder.resourceName(patched.firstNewImage + i)
                guard inner.entries[name] == nil else { throw WMFault("LUNAR_NAME_CLASH") }
                guard let png = FaceRenderer.pngData(r) else { throw WMFault("BUILD_PNG") }
                add.append((name, png))
            }
            newResource = try rewrite(inner, replace: ["watchface.bin": patched.bin], add: add)
        } else {
            // Tài nguyên là chính watchface.bin (không có ZIP trong).
            newResource = try patchBin(resBytes, design: d).bin
        }

        var replace: [String: [UInt8]] = [resName: newResource]

        // hashCode: "<mô tả>,<gói trong>,<ability>,<hằng>" — chỉ giá trị thứ 2 phụ thuộc gói trong.
        let hashName = prefix + "hashCode"
        if let h = outer.entries[hashName], !h.isDirectory, h.size <= 4096 {
            let text = String(decoding: try outer.read(h, max: 4096), as: UTF8.self)
            var parts = text.split(separator: ",", omittingEmptySubsequences: false).map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
            if parts.count >= 2 {
                parts[1] = sha256Upper(newResource)
                replace[hashName] = Array(parts.joined(separator: ",").utf8)
            }
        }

        // Ảnh xem trước (cover + icon nhỏ): vẽ thêm âm lịch.
        var coverOut: [UInt8]?
        for name in ["preview/cover.jpg", "preview/cover.jpeg", "preview/icon_small.jpg", "preview/icon_small.jpeg"] {
            let full = prefix + name
            guard let e = outer.entries[full], !e.isDirectory, e.size > 0, e.size <= 4 * 1024 * 1024,
                  let bytes = try? outer.read(e, max: 4 * 1024 * 1024),
                  let jpg = overlay(jpeg: bytes, design: d) else { continue }
            replace[full] = jpg
            if coverOut == nil && name.contains("cover") { coverOut = jpg }
            if coverOut == nil && name.contains("icon_small") { coverOut = jpg }
        }

        let result = try rewrite(outer, replace: replace, add: [])
        return Output(hwt: result, preview: coverOut)
    }

    // MARK: Ảnh xem trước

    /// Vẽ âm lịch lên ảnh JPEG xem trước (ảnh vuông ứng với mặt 466×466).
    static func overlay(jpeg: [UInt8], design: FaceDesign) -> [UInt8]? {
        guard let base = UIImage(data: Data(jpeg)), let cg = base.cgImage else { return nil }
        let w = cg.width, h = cg.height
        guard w > 0, h > 0, w == h else { return nil }
        return overlayImage(base: UIImage(cgImage: cg), pixels: w, design: design)?.jpegData(compressionQuality: 0.9).map { [UInt8]($0) }
    }

    /// Ảnh nền + khối âm lịch, cỡ `pixels` × `pixels` điểm ảnh.
    static func overlayImage(base: UIImage, pixels: Int, design: FaceDesign) -> UIImage? {
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let size = CGSize(width: pixels, height: pixels)
        return UIGraphicsImageRenderer(size: size, format: fmt).image { c in
            base.draw(in: CGRect(origin: .zero, size: size))
            let ctx = c.cgContext
            ctx.scaleBy(x: CGFloat(pixels) / FaceRenderer.size, y: CGFloat(pixels) / FaceRenderer.size)
            FaceRenderer.drawInfoPreview(ctx, design: design)
        }
    }
}

// MARK: - Màn hình "Thêm thông tin"

final class LunarPatchModel: ObservableObject {
    @Published var design: FaceDesign = {
        var d = FaceDesign()
        d.showLunar = true
        d.showSolar = true
        d.solarY = 0.50
        d.lunarY = 0.62
        return d
    }() {
        didSet { refresh() }
    }
    @Published private(set) var preview: UIImage?
    @Published var working = false
    @Published var error: String?
    @Published var done = false

    private let base: UIImage
    let hasRealPreview: Bool

    init(previewURL: URL?) {
        if let u = previewURL, let img = Thumbnail.load(url: u, maxPixel: 480) {
            base = img
            hasRealPreview = true
        } else {
            // Không có ảnh xem trước: dùng nền đen có vòng tròn để canh vị trí.
            let fmt = UIGraphicsImageRendererFormat.default()
            fmt.scale = 1
            fmt.opaque = true
            base = UIGraphicsImageRenderer(size: CGSize(width: 480, height: 480), format: fmt).image { c in
                UIColor.black.setFill()
                c.fill(CGRect(x: 0, y: 0, width: 480, height: 480))
                UIColor(white: 0.35, alpha: 1).setStroke()
                let p = UIBezierPath(ovalIn: CGRect(x: 4, y: 4, width: 472, height: 472))
                p.lineWidth = 2
                p.stroke()
            }
            hasRealPreview = false
        }
        refresh()
    }

    private func refresh() {
        preview = HwtLunarPatch.overlayImage(base: base, pixels: 320, design: design)
    }

    static func message(_ code: String) -> String {
        switch code {
        case "LUNAR_ALREADY_PRESENT": return tr("Mặt này đã có sẵn một mục bạn chọn (âm lịch, dương lịch, thứ hoặc giờ số). Hãy tắt mục đó rồi thử lại.")
        case "INFO_NOTHING_SELECTED": return tr("Hãy bật ít nhất một mục.")
        case "LUNAR_BIN_FORMAT", "LUNAR_LAYOUT_INVALID": return tr("Không đọc được cấu trúc watchface.bin của file này.")
        case "LUNAR_NO_BIN": return tr("File không có watchface.bin.")
        case "LUNAR_FILE_TOO_LARGE": return tr("File quá lớn.")
        case "LUNAR_LAYOUT_TOO_LARGE", "LUNAR_TOO_MANY_IMAGES": return tr("Mặt này đã quá đầy, không thêm được.")
        case "LUNAR_NO_SLOT": return tr("Mặt này không có phần tử ngày (số 2) để gộp vào, nên chưa chèn được (chèn phần tử mới thì đồng hồ không hiện).")
        case "LUNAR_NAME_CLASH": return tr("Tên ảnh trong file bị trùng.")
        default: return trf("Thất bại: %@", code)
        }
    }
}

struct LunarPatchView: View {
    @ObservedObject var library: HwtLibrary
    let item: HwtLibraryItem
    @StateObject private var model: LunarPatchModel
    @Environment(\.dismiss) private var dismiss

    init(library: HwtLibrary, item: HwtLibraryItem) {
        self.library = library
        self.item = item
        _model = StateObject(wrappedValue: LunarPatchModel(previewURL: library.previewURL(item)))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
            // Ảnh xem trước cố định phía trên; phần bên dưới cuộn.
            if let img = model.preview {
                Image(uiImage: img).resizable().scaledToFit().frame(maxHeight: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .padding(.horizontal, 16).padding(.vertical, 8)
            }
            ScrollView {
                VStack(spacing: 16) {
                    if !model.hasRealPreview {
                        Text(tr("File không có ảnh xem trước nên xem trước trên nền đen; mặt thật có thể có hình khác phía sau."))
                            .font(.footnote).foregroundStyle(.secondary)
                    }

                    InfoSettingsView(design: $model.design)

                    Text(tr("App tạo thêm một bản mới trong thư viện (file gốc giữ nguyên). Số ngày/giờ do đồng hồ tự cập nhật, không hiện ở AOD. Xem trước dùng ngày giờ hiện tại."))
                        .font(.footnote).foregroundStyle(.secondary)

                    if let e = model.error {
                        Text(tr(e)).foregroundStyle(Color.orange).card()
                    }
                    if model.done {
                        Text(tr("Đã tạo bản mới trong thư viện.")).foregroundStyle(Color.green).card()
                    }

                    Button { start() } label: {
                        if model.working { ProgressView() } else { Label(tr("Tạo bản mới"), systemImage: "calendar.badge.plus") }
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(model.working || model.done || !FaceRenderer.infoActive(model.design))
                }
                .padding(16)
            }
            }
            .background(AppBackground())
            .navigationTitle(tr("Thêm thông tin"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
        }
    }

    private func start() {
        guard let src = library.fileURL(item), !model.working else { return }
        model.working = true
        model.error = nil
        let design = model.design
        let lib = library
        let it = item
        DispatchQueue.global(qos: .userInitiated).async {
            let fm = FileManager.default
            let dir = fm.temporaryDirectory.appendingPathComponent("wm-lunar-out-\(UUID().uuidString)", isDirectory: true)
            defer { try? fm.removeItem(at: dir) }
            var failure: String?
            do {
                let out = try HwtLunarPatch.apply(source: src, design: design)
                try fm.createDirectory(at: dir, withIntermediateDirectories: true)
                let base = (it.fileName as NSString).deletingPathExtension
                let fileName = (base.isEmpty ? "face" : base) + "_thongtin.hwt"
                let file = dir.appendingPathComponent(fileName)
                try Data(out.hwt).write(to: file, options: .atomic)
                var previewURL: URL?
                if let p = out.preview {
                    let u = dir.appendingPathComponent("preview.image")
                    if (try? Data(p).write(to: u)) != nil { previewURL = u }
                }
                let hash = WMCore.hex(try WMCore.digest(file: file))
                if let added = lib.add(original: file, preview: previewURL, sourceHash: hash, title: it.title,
                                       fileName: fileName, xmlVersion: it.xmlVersion) {
                    lib.rename(id: added.id, to: HwtLibrary.cleanName(it.name + tr(" + thông tin")))
                } else {
                    failure = tr("Không lưu được vào thư viện (đầy hoặc lỗi ghi file).")
                }
            } catch {
                failure = LunarPatchModel.message(WMCore.code(error))
            }
            DispatchQueue.main.async {
                model.working = false
                if let f = failure { model.error = f } else { model.done = true }
            }
        }
    }
}
