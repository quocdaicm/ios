// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

// MARK: - Dữ liệu lớp trang trí

/// Họa tiết vector vẽ sẵn (CGPath, không cần file ảnh ngoài).
enum DecorPattern: String, CaseIterable, Identifiable {
    case lotus, mandala, sunburst, gear, star, dotRings, ring, bronzeDrum
    case cherry, waves, hexGrid, compass, snowflake, rosette, chrysanthemum, laurel, flowerOfLife, constellation, scales, moonPhases
    case noelWreath, noelStar, noelSnow, tetMai, tetDao, tetLantern, tetFirework
    var id: String { rawValue }
    var title: String {
        switch self {
        case .lotus: return "Hoa sen"
        case .mandala: return "Mandala"
        case .sunburst: return "Tia sáng"
        case .gear: return "Bánh răng"
        case .star: return "Sao 12 cánh"
        case .dotRings: return "Vòng chấm"
        case .ring: return "Viền hoa"
        case .bronzeDrum: return "Trống đồng"
        case .cherry: return "Hoa đào"
        case .waves: return "Sóng Nhật"
        case .hexGrid: return "Tổ ong"
        case .compass: return "La bàn"
        case .snowflake: return "Bông tuyết"
        case .rosette: return "Hoa văn xoắn"
        case .chrysanthemum: return "Hoa cúc"
        case .laurel: return "Nguyệt quế"
        case .flowerOfLife: return "Hoa sự sống"
        case .constellation: return "Chòm sao"
        case .scales: return "Vảy cá"
        case .moonPhases: return "Tuần trăng"
        case .noelWreath: return "Noel – vòng thông"
        case .noelStar: return "Noel – sao vàng"
        case .noelSnow: return "Noel – bông tuyết"
        case .tetMai: return "Tết – hoa mai"
        case .tetDao: return "Tết – hoa đào"
        case .tetLantern: return "Tết – đèn lồng"
        case .tetFirework: return "Tết – pháo hoa"
        }
    }
}

/// Lớp trang trí quay theo kim nào (hoặc đứng yên).
enum DecorSpin: String, CaseIterable, Identifiable {
    case none, hour, minute, second
    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "Tĩnh"
        case .hour: return "Giờ"
        case .minute: return "Phút"
        case .second: return "Giây"
        }
    }
    /// nil = đứng yên (vẽ thẳng vào nền).
    var valueType: Int? {
        switch self {
        case .none: return nil
        case .hour: return HwtValueType.hour
        case .minute: return HwtValueType.minute
        case .second: return HwtValueType.second
        }
    }
}

struct DecorLayer: Identifiable, Equatable {
    var id = UUID()
    var pattern: DecorPattern = .mandala
    var color = Color.white
    var opacity = 0.4
    /// Đường kính so với mặt đồng hồ (0.2 ... 0.95).
    var scale = 0.8
    var spin: DecorSpin = .minute
}

// MARK: - Vẽ

extension FaceRenderer {
    static let maxDecor = 4

    static func decorRadius(_ l: DecorLayer) -> CGFloat {
        center * CGFloat(min(0.95, max(0.2, l.scale)))
    }

    /// Cạnh (px, số chẵn, ≤ 466) của ảnh vuông chứa lớp quay.
    static func decorSide(_ l: DecorLayer) -> Int {
        var s = Int(ceil(decorRadius(l) * 2)) + 6
        if s % 2 != 0 { s += 1 }
        return min(Int(size), s)
    }

    /// Vẽ lớp tại gốc (0,0) của ctx (người gọi tự dịch/xoay).
    static func drawDecorLayer(_ ctx: CGContext, _ l: DecorLayer) {
        ctx.saveGState()
        ctx.setAlpha(CGFloat(min(1.0, max(0.05, l.opacity))))
        ctx.beginTransparencyLayer(auxiliaryInfo: nil)
        drawDecorPattern(ctx, pattern: l.pattern, radius: decorRadius(l), color: UIColor(l.color))
        ctx.endTransparencyLayer()
        ctx.restoreGState()
    }

    /// Các lớp đứng yên được vẽ thẳng vào nền ban ngày.
    static func drawStaticDecor(_ ctx: CGContext, _ d: FaceDesign) {
        for l in d.decor where l.spin == .none {
            ctx.saveGState()
            ctx.translateBy(x: center, y: center)
            drawDecorLayer(ctx, l)
            ctx.restoreGState()
        }
    }

    static func drawDecorPattern(_ ctx: CGContext, pattern: DecorPattern, radius R: CGFloat, color: UIColor) {
        let pi = CGFloat.pi
        let soft = color.withAlphaComponent(0.35)
        ctx.saveGState()
        ctx.setLineWidth(max(1.2, R * 0.009))
        ctx.setLineJoin(.round)
        ctx.setLineCap(.round)
        ctx.setStrokeColor(color.cgColor)
        ctx.setFillColor(color.cgColor)

        func ring(_ r: CGFloat) {
            ctx.strokeEllipse(in: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r))
        }
        func dot(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            ctx.setFillColor(color.cgColor)
            ctx.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func solid(_ p: CGPath) {
            ctx.setFillColor(color.cgColor)
            ctx.addPath(p)
            ctx.fillPath()
        }
        func paint(_ p: CGPath, fill: UIColor?) {
            if let f = fill {
                ctx.setFillColor(f.cgColor)
                ctx.addPath(p)
                ctx.fillPath()
            }
            ctx.addPath(p)
            ctx.strokePath()
        }
        /// Cánh nhọn mọc từ gốc lên trên (y âm), `w` là độ phình.
        func petal(_ len: CGFloat, _ w: CGFloat) -> CGPath {
            let p = CGMutablePath()
            p.move(to: .zero)
            p.addQuadCurve(to: CGPoint(x: 0, y: -len), control: CGPoint(x: w, y: -len * 0.55))
            p.addQuadCurve(to: .zero, control: CGPoint(x: -w, y: -len * 0.55))
            p.closeSubpath()
            return p
        }
        func starPath(_ n: Int, _ ro: CGFloat, _ ri: CGFloat, _ rot: CGFloat) -> CGPath {
            let p = CGMutablePath()
            for i in 0..<(n * 2) {
                let a = rot + CGFloat(i) * pi / CGFloat(n)
                let r = i % 2 == 0 ? ro : ri
                let pt = CGPoint(x: sin(a) * r, y: -cos(a) * r)
                if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
            }
            p.closeSubpath()
            return p
        }
        func spokes(_ n: Int, offset: CGFloat = 0, _ body: (Int) -> Void) {
            for i in 0..<n {
                ctx.saveGState()
                ctx.rotate(by: offset + CGFloat(i) * 2 * pi / CGFloat(n))
                body(i)
                ctx.restoreGState()
            }
        }

        switch pattern {
        case .lotus:
            spokes(12) { _ in paint(petal(R, R * 0.30), fill: soft) }
            spokes(12, offset: pi / 12) { _ in paint(petal(R * 0.74, R * 0.22), fill: soft) }
            spokes(8) { _ in paint(petal(R * 0.46, R * 0.15), fill: soft) }
            dot(0, 0, R * 0.07)

        case .mandala:
            ring(R)
            ring(R * 0.94)
            spokes(24) { _ in
                ctx.translateBy(x: 0, y: -R * 0.70)
                paint(petal(R * 0.24, R * 0.06), fill: soft)
            }
            ring(R * 0.64)
            spokes(12) { _ in paint(petal(R * 0.60, R * 0.17), fill: nil) }
            spokes(12, offset: pi / 12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.40)
                dot(0, 0, R * 0.025)
            }
            ring(R * 0.14)
            dot(0, 0, R * 0.05)

        case .sunburst:
            spokes(48) { i in
                let len = i % 2 == 0 ? R : R * 0.80
                let w = R * 0.028
                let p = CGMutablePath()
                p.move(to: CGPoint(x: -w, y: -R * 0.34))
                p.addLine(to: CGPoint(x: w, y: -R * 0.34))
                p.addLine(to: CGPoint(x: 0, y: -len))
                p.closeSubpath()
                solid(p)
            }
            ring(R * 0.30)
            ring(R * 0.26)

        case .gear:
            let teeth = 24
            let step = 2 * pi / CGFloat(teeth)
            let profile: [(CGFloat, CGFloat)] = [(0.00, 0.86), (0.15, 0.86), (0.30, 1.0), (0.55, 1.0), (0.70, 0.86)]
            let path = CGMutablePath()
            var first = true
            for t in 0..<teeth {
                for (f, rf) in profile {
                    let a = CGFloat(t) * step + f * step
                    let pt = CGPoint(x: sin(a) * R * rf, y: -cos(a) * R * rf)
                    if first { path.move(to: pt); first = false } else { path.addLine(to: pt) }
                }
            }
            path.closeSubpath()
            paint(path, fill: soft)
            ring(R * 0.70)
            spokes(12) { _ in
                ctx.translateBy(x: 0, y: -R * 0.54)
                dot(0, 0, R * 0.045)
            }
            ring(R * 0.34)
            spokes(6) { _ in
                ctx.move(to: CGPoint(x: 0, y: -R * 0.12))
                ctx.addLine(to: CGPoint(x: 0, y: -R * 0.34))
                ctx.strokePath()
            }
            dot(0, 0, R * 0.08)

        case .star:
            paint(starPath(12, R, R * 0.62, 0), fill: soft)
            paint(starPath(12, R * 0.70, R * 0.44, pi / 12), fill: nil)
            ring(R * 0.30)
            dot(0, 0, R * 0.06)

        case .dotRings:
            let rings: [(CGFloat, Int, CGFloat)] = [(0.97, 72, 0.020), (0.84, 60, 0.017), (0.71, 48, 0.014),
                                                    (0.58, 36, 0.011), (0.45, 24, 0.009), (0.32, 12, 0.007)]
            for (rf, n, dr) in rings {
                spokes(n) { _ in dot(0, -R * rf, R * dr) }
            }
            dot(0, 0, R * 0.04)

        case .ring:
            ring(R)
            ring(R * 0.955)
            spokes(72) { i in dot(0, -R * 0.88, i % 6 == 0 ? R * 0.022 : R * 0.010) }
            spokes(12) { _ in
                let p = CGMutablePath()
                p.move(to: CGPoint(x: 0, y: -R * 0.80))
                p.addLine(to: CGPoint(x: R * 0.03, y: -R * 0.74))
                p.addLine(to: CGPoint(x: 0, y: -R * 0.68))
                p.addLine(to: CGPoint(x: -R * 0.03, y: -R * 0.74))
                p.closeSubpath()
                solid(p)
            }
            ring(R * 0.62)

        case .bronzeDrum:
            // Mặt trống đồng Đông Sơn: sao 14 cánh ở giữa, các vành tròn, vành răng cưa, vành chim lạc.
            paint(starPath(14, R * 0.30, R * 0.14, 0), fill: soft)
            ring(R * 0.34)
            ring(R * 0.40)
            spokes(36) { _ in
                let p = CGMutablePath()
                p.move(to: CGPoint(x: -R * 0.03, y: -R * 0.44))
                p.addLine(to: CGPoint(x: R * 0.03, y: -R * 0.44))
                p.addLine(to: CGPoint(x: 0, y: -R * 0.58))
                p.closeSubpath()
                solid(p)
            }
            ring(R * 0.62)
            ring(R * 0.68)
            spokes(28) { _ in
                ctx.setFillColor(color.cgColor)
                ctx.fillEllipse(in: CGRect(x: -R * 0.022, y: -R * 0.86, width: R * 0.044, height: R * 0.12))
            }
            ring(R * 0.92)
            ring(R)
            spokes(56) { _ in dot(0, -R * 0.96, R * 0.012) }

        default:
            drawExtraDecor(ctx, pattern: pattern, radius: R, color: color)
        }
        ctx.restoreGState()
    }
}

// MARK: - Hình thu nhỏ cho bộ chọn

enum DecorThumbs {
    private static var cache = [DecorPattern: UIImage]()

    static func image(_ p: DecorPattern) -> UIImage {
        if let c = cache[p] { return c }
        let px: CGFloat = 112
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: CGSize(width: px, height: px), format: fmt).image { c in
            UIColor(white: 0.10, alpha: 1).setFill()
            c.fill(CGRect(x: 0, y: 0, width: px, height: px))
            let ctx = c.cgContext
            ctx.translateBy(x: px / 2, y: px / 2)
            FaceRenderer.drawDecorPattern(ctx, pattern: p, radius: px / 2 - 5, color: .white)
        }
        cache[p] = img
        return img
    }
}
