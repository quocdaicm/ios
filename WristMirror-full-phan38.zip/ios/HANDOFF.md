# HANDOFF – WristMirror iOS (đọc file này đầu tiên nếu bạn là AI/lập trình viên làm tiếp)

## 1. Mục tiêu
Viết lại app Android **WristMirror (腕镜)** (Kotlin/Java, repo gốc `WristMirror-main.zip`, giấy phép Apache-2.0)
thành app **iPhone** bằng **Swift + SwiftUI + CoreBluetooth**. App kết nối BLE tới đồng hồ Huawei (GT/FIT…),
xác thực (HiChain ISO / Lite), đọc danh sách mặt đồng hồ, rồi dùng "phương pháp thay thế" để cài
file mặt đồng hồ HWT cục bộ lên một slot mặt đồng hồ thường có sẵn (xem README gốc, mục "替换法的原理").

Người dùng dùng tài khoản Claude miễn phí (sợ hết token) nên công việc được chia thành nhiều phần,
mỗi phần giao ngay bằng một file zip. Người dùng giải nén các zip chồng lên cùng một thư mục.
Build **không cần Mac**: GitHub Actions (`.github/workflows/build.yml`) dùng XcodeGen (`project.yml`)
rồi `xcodebuild` ra IPA chưa ký (người dùng tự ký/cài bằng Sideloadly/AltStore).

## 2. Nguồn Java để port (CẦN file `WristMirror-main.zip` gốc)
Giải nén, nguồn ở: `Escosis-WristMirror-*/app/src/main/java/io/github/escosis/hwtfaceswap/`
Nếu bạn không có zip gốc, hãy yêu cầu người dùng gửi lại. KHÔNG bịa chi tiết giao thức khi chưa đọc Java.

## 3. Trạng thái port (Java → Swift)
Đường dẫn Swift: `WristMirror/…`

| Java | Swift | Trạng thái |
|---|---|---|
| protocol/FrameCodec.java | Protocol/FrameCodec.swift (+ `WMFault`) | ✅ Phần 1 |
| transport/LinkChannel.java, GattChannel.java | Transport/LinkChannel.swift, GattChannel.swift | ✅ Phần 1 (chưa thử trên thiết bị thật) |
| protocol/Core.java | Protocol/Core.swift (`WMCore`) | ✅ Phần 2 |
| protocol/TlvView.java | Protocol/TlvView.swift | ✅ Phần 2 |
| protocol/Wire.java | Protocol/Wire.swift | ✅ Phần 2 |
| protocol/DeviceInfo.java | Protocol/DeviceInfo.swift | ✅ Phần 2 |
| protocol/MiniJson.java | Protocol/MiniJson.swift (`JSONValue`, `JSONObject`) | ✅ Phần 2 |
| protocol/HuaweiCrypto.java | Protocol/HuaweiCrypto.swift + AESPrimitives.swift | ✅ Phần 3 |
| protocol/CryptoSession.java | Protocol/CryptoSession.swift | ✅ Phần 3 |
| protocol/LiteAuth.java | Protocol/LiteAuth.swift | ✅ Phần 3 |
| protocol/LinkCapabilities.java | Protocol/LinkCapabilities.swift (bảng lệnh sinh tự động từ Java) | ✅ Phần 3 |
| protocol/AuthReplyJson.java | Protocol/AuthReplyJson.swift | ✅ Phần 3 |
| protocol/IsoAuth.java, IsoReplyHandler.java | Protocol/IsoAuth.swift, IsoReplyHandler.swift | ✅ Phần 4 |
| transport/WatchConnection.java (39KB) | Transport/WatchConnection.swift (`WatchConnection`, `WatchConnectionListener`) | ✅ Phần 5 (chưa biên dịch/chưa thử máy thật) |
| transport/WatchScanner.java (4.6KB) | Transport/WatchScanner.swift | ✅ Phần 5 (chỉ BLE, khoá = UUID) |
| protocol/WristInitialization.java | Protocol/WristInitialization.swift | ✅ Phần 5 |
| protocol/WireNames.java | Protocol/WireNames.swift (`WireNames.request/parseResponse`) | ✅ Phần 6 (chưa biên dịch) |
| protocol/DeviceTelemetry.java | Protocol/DeviceTelemetry.swift (`DeviceTelemetry`, `.Stats`, `.ProbeOwner`) | ✅ Phần 5 |
| protocol/ActivationState, DeletionState, NameQueryState, ReplacementState .java | Protocol/ActivationState/DeletionState/NameQueryState/ReplacementState.swift (class) | ✅ Phần 6 (chưa biên dịch) |
| store/SecureStore.java | Store/KeychainStore.swift (class `SecureStore`, Keychain) | ✅ Phần 5 |
| store/SafeLog.java | Store/SafeLog.swift | ✅ Phần 5 |
| lifecycle/DeviceRemovalJournal.java | Store/DeviceRemovalGuard.swift | ✅ Phần 5 (rút gọn: chỉ chặn + bộ đếm thế hệ, không có huỷ ghép nối hệ thống) |
| protocol/FileTransfer.java (33KB) | Protocol/FileTransfer.swift | ✅ Phần 6 (chưa biên dịch) |
| protocol/HwtSource.java (12.5KB) | Protocol/HwtSource.swift + Protocol/ZipArchive.swift (bộ đọc ZIP + CRC32 tự viết) | ✅ Phần 6 (chưa biên dịch) |
| protocol/FacePolicy.java, VersionPolicy.java | Protocol/FacePolicy.swift, VersionPolicy.swift | ✅ Phần 6 (chưa biên dịch) |
| transport/WatchfaceManager.java (51KB) | Transport/WatchfaceManager.swift (`WatchfaceManager`, `WatchfaceManagerListener`) | ✅ Phần 7 (chưa biên dịch) |
| AppRuntime.java (29KB) | App/AppRuntime.swift (`AppRuntime.shared`, `Snapshot`, `AppRuntimeObserver`) | ✅ Phần 7 (chưa biên dịch) |
| AppModels.kt | App/Models.swift (`AppUiState`, `FaceItem`, `OperationInfo`, `ReplacementDialogInfo`, protocol `AppActions`…) | ✅ Phần 7 (làm sớm vì AppRuntime cần) |
| store/SavedWatchStore.kt | Store/SavedWatchStore.swift (UserDefaults, khoá = UUID) | ✅ Phần 7 |
| WatchViewModel.kt (85KB) | App/WatchViewModel.swift (ObservableObject, implements `AppActions` + `AppRuntimeObserver`) | ✅ Phần 8 (chưa biên dịch) |
| ui/*.kt (Compose/Miuix) | Views/RootView, DeviceView, FacesView, LogsView, SettingsView (SwiftUI, rút gọn) | ✅ Phần 8 (chưa biên dịch) |
| account/HuaweiId*.kt (WebView đăng nhập Huawei ID) | Views/HuaweiIdWebView.swift (WKWebView nonPersistent + chính sách URL + cookie `uid`) | ✅ Phần 8 (chưa biên dịch) |
| lifecycle/DeviceRemoval*.java, platform/AndroidSystemUnpair.java | — | ❌ Không port nguyên: iOS không cho app huỷ ghép nối hệ thống. Chỉ xoá dữ liệu cục bộ + hướng dẫn người dùng vào Cài đặt > Bluetooth > "Forget This Device". |
| UpdateChecker/UpdateDialog/UpdateReleaseParser/UpdateVersion, ConnectionService.java | — | ❌ Bỏ (tính năng riêng của Android; BLE nền dùng `UIBackgroundModes: bluetooth-central` đã khai báo trong project.yml) |

Thứ tự: Phần 6 ✅ → 7 ✅ → 8 ✅ → **Phần 9 = build GitHub Actions lần đầu, sửa lỗi biên dịch theo log, thử máy thật** ← tiếp theo. Cập nhật bảng này + `README_IOS.md` sau mỗi phần.

## 4. Quy ước code đã dùng (giữ nhất quán)
- Byte luôn là `[UInt8]` (Java `byte[]`, đã xử lý dấu: Java `b & 255` ⇒ `Int(b)`).
- Lỗi giao thức: `throw WMFault("MA_LOI")`; **giữ nguyên chuỗi mã lỗi của Java** (log/UI dựa vào chúng). `WMCore.code(error)` lấy mã.
- Java `long epoch` ⇒ `Int`. Java `Long` có thể null ⇒ `Int64?`.
- JSON: `JSONObject` giữ thứ tự khoá (như LinkedHashMap); chỉ số nguyên, cấm khoá trùng.
- **Cạm bẫy Swift**: `try` không được đứng bên phải toán tử `?:`/`+` không có ngoặc. Dùng `if/else` hoặc đặt một `try` ở đầu biểu thức.
- Giữ nguyên các giới hạn kích thước/ngân sách của bản Java (đây là phần phòng thủ có chủ đích).
- Đa luồng: GattChannel chạy trên `DispatchQueue` tuần tự; callback trả về qua `LinkChannelListener` kèm `epoch` để bỏ qua kết nối cũ.

## 5. Khác biệt iOS cần xử lý (đã biết)
- **Chỉ BLE (GATT)** dùng được: Android có thêm RFCOMM (Bluetooth Classic) – iOS không cho app thường dùng ⇒ bỏ `RfcommChannel`.
- iOS không có địa chỉ MAC; đồng hồ được nhận diện bằng `CBPeripheral.identifier` (UUID). Mọi chỗ Java lưu MAC phải đổi sang UUID (lưu dạng String).
- iOS tự xử lý MTU/CCCD; ghép nối hệ thống xảy ra tự động khi truy cập characteristic mã hoá. Không tự huỷ ghép nối được.
- GATT hằng số: service `FE86`, ghi `FE01`, nhận `FE02` (đã cài trong GattChannel).
- Lưu Secret/khoá vào **Keychain** (không dùng UserDefaults). Ghi `learnedSecret` TRƯỚC khi gửi bước S4 của ISO (xem chú thích đầu IsoAuth.swift).
- Không có `SecureRandom`: dùng `WMRandom.bytes(n)` (SecRandomCopyBytes).
- AES-GCM tự cài (`AESGCMManual`) vì IV 16 byte; thuật toán đã được đối chiếu với thư viện chuẩn bằng mô phỏng Python (khớp).
- Đọc file HWT: HWT là container ZIP chứa `watchface.bin`. Foundation không có API ZIP ⇒ tự viết bộ đọc ZIP tối thiểu (parse central directory; giải nén kiểu deflate bằng `import Compression` với `COMPRESSION_ZLIB`, là raw-deflate). Nhớ giữ giới hạn `WMCore.maxSource/maxMember` và chống ZIP-bomb/path traversal như bản Java.
- Chọn file trong app: `UIDocumentPickerViewController`/`.fileImporter` (cần `startAccessingSecurityScopedResource`).
- Đăng nhập Huawei ID: `WKWebView` (cookie/session quản lý trong `WKWebsiteDataStore`); tham khảo `account/*.kt`.
- Quét thiết bị: bản Java lọc theo cách nào thì đọc `WatchScanner.java`; trên iOS nên thử `scanForPeripherals(withServices: nil)` rồi lọc theo tên/manufacturer data nếu đồng hồ không quảng bá FE86.

## 6. Luồng nghiệp vụ (từ README gốc – xác nhận lại bằng Java khi port)
1. Kết nối BLE → `LinkCapabilities` (link params 01/…, security, services, commands, expand) → xác thực ISO (`IsoAuth`) hoặc Lite (`LiteAuth`) theo `caps.iso()`/`caps.lite()`.
2. Sau khi có khoá phiên: `CryptoSession.seal/open` bọc mọi gói nghiệp vụ (phong bì TLV 7c/7d/7e).
3. Đọc danh sách mặt đồng hồ `0x27/0x02` (`Wire.list`, `Wire.faces`), giữ ID, phiên bản, cờ type thô.
4. Chuẩn bị tải: lấy `watchface.bin` từ HWT, đóng băng + kiểm tra băm.
5. Thay thế: `0x27/0x03` với phiên bản +1 ở trường số cuối (`Wire.operation`); chỉ khi phản hồi thật có `error=0, need=1` mới truyền file; `need=0` thì dừng.
6. Truyền file bằng giao thức `0x28` (FileTransfer): đăng ký file, nhận file ID, thương lượng đơn vị/mã hoá, trả lời digest/chunk/final.
7. Xác minh: kết quả truyền và báo cáo áp dụng được ghi riêng; truy vấn lại danh sách mặt đồng hồ, kiểm tra cùng ID với phiên bản ứng viên. Không coi "100%" là thành công.
- Xoá mặt đồng hồ: `Wire.deletion` (op=2, đúng phiên bản đang cài), xong thì truy vấn lại danh sách.

## 7. Chưa được kiểm chứng (RỦI RO)
- **Chưa có đoạn Swift nào được biên dịch** (môi trường tạo ra không có `swiftc`). Lần build GitHub Actions đầu tiên sẽ lộ lỗi cú pháp/kiểu; sửa theo log.
- GattChannel chưa thử trên đồng hồ thật (đặc biệt: đồng hồ có quảng bá service FE86 không; có cần ghép nối hệ thống trước không).
- Chỉ logic GCM đã được kiểm chứng bằng mô phỏng; các phần mật mã còn lại (HKDF/HMAC/PBKDF2/ISO) port theo Java, chưa có test vector.
- Nên thêm unit test (XCTest) dùng lại các test của Java nếu có (`app/src/test`… trong zip gốc không có thư mục test, chỉ có tác vụ `testDebugUnitTest` trong README).

## 8. Cách làm tiếp
1. Đọc Java của phần kế tiếp (xem bảng mục 3), port từng file, giữ mã lỗi/giới hạn.
2. Đặt file đúng thư mục `WristMirror/<Protocol|Transport|Store|App|Views>/`.
3. Cập nhật bảng trạng thái ở mục 3 và `README_IOS.md`.
4. Đóng zip chỉ chứa file mới/đổi (giải nén chồng lên được), hoặc zip toàn bộ dự án.
5. Giấy phép: giữ Apache-2.0; không chép mã/SDK của Huawei Health (xem `THIRD_PARTY_NOTICES.md` của bản gốc, nên copy sang dự án iOS).

## 9. Ghi chú Phần 5 (dành cho Phần 6/7/8)
- **Khoá thiết bị = UUID của `CBPeripheral`** (chuỗi viết hoa; chuẩn hoá bằng `DeviceRemovalGuard.canonical`). Mọi chỗ Java dùng MAC đều đã đổi.
- `WatchConnection(store:log:deviceModel:)`; truyền `UIDevice.current.model` cho `deviceModel`. Giữ một tham chiếu mạnh tới `WatchConnection` (GattChannel giữ listener yếu). `setListener` giữ yếu.
- Gọi từ UI: `connect(deviceId:account:)`, `submitPin(expectedEpoch:entered:)`, `confirmRebind(expectedEpoch:)`, `respondAgreements(expectedEpoch:accept:)`, `disconnect()`.
- Sau READY: `sendControl(service,command,body)` (gói 0x27, mã hoá) và `sendFile(command,body,encrypt:)` (0x28); gói nghiệp vụ nhận về qua `onPacket` (đã giải mã). `post/execute/delay` chạy trên hàng đợi giao thức; `capabilities` chỉ đọc trên hàng đợi này.
- Giai đoạn `SYSTEM_PAIRING` của bản Java không còn (iOS tự ghép nối khi truy cập characteristic mã hoá).
- `stopForRemoval(id)` (thay `stopForUnpair`) bắt buộc gọi trên hàng đợi giao thức: `connection.post { try? connection.stopForRemoval(id) }`. Quy trình xoá đồng hồ: `removals.beginRemoval` → `stopForRemoval` → `store.clearDevice` → `removals.finishRemoval` (nếu lỗi: `cancelRemoval`).
- Chuỗi mô tả giai đoạn (UI) đã dịch sang tiếng Việt; mã giai đoạn/mã lỗi giữ nguyên tiếng Anh như Java.
- `WatchScanner` lọc theo tên (huawei/honor/watch/华为/荣耀) HOẶC quảng bá service FE86; callback trên main queue.
- Chưa có đoạn Swift nào được biên dịch (xem mục 7). Các điểm dễ lỗi khi build lần đầu: các chuỗi `+` dài của `[UInt8]`, `try` trong biểu thức, `private(set)` trên thuộc tính tính toán ở `WatchConnection`.

## 10. Ghi chú Phần 6 (dành cho Phần 7/8)
- `FacePolicy.isCurrent(face)` (Java `FacePolicy.current`), `eligible`, `canActivate`, `kind` (nhãn tiếng Việt), `defaultSelection`.
- `VersionPolicy.next(id:baseline:listed:)` → phiên bản ứng viên (chỉ +1 trường cuối).
- `WireNames.request(faces:language:)` (rỗng ⇒ bỏ qua gửi), `WireNames.parseResponse(fields)` → `Response{names, orderedNames, ids, malformedNameCount}`.
- Các lớp `*State` là **class** (tham chiếu, đổi được như Java). `Action` là enum `.none/.query/.upload/.activate`. Tham số nhãn: `operation(error:need:echo:)`, `report(type:error:)`, `list(_:generation:ownQuery:serial:)` (Deletion: `querySerial:`), `ReplacementState.list(_:queryGeneration:ownQuery:)`.
- `NameQueryState.next(now:)`/`expire(now:)` dùng mili-giây `Int64`.
- `HwtSource.load(from: URL, privateFiles: URL)`: UI phải gọi `startAccessingSecurityScopedResource()` quanh lời gọi. `privateFiles` nên là Application Support. `freeze(.bin)` → `Snapshot` (chỉ-đọc 0o400); `HwtSource.cleanup(privateFiles:directory:)` xoá thư mục `source-<uuid>`.
- `ZipArchive` chỉ hỗ trợ stored/deflate, không mã hoá, không ZIP64; deflate dùng `Compression` (`COMPRESSION_ZLIB` = raw deflate). Chưa thử trên file HWT thật.
- `FileTransfer(id:installedProtocolVersion:frozen:)`: `metadataBody()` (gửi 0x28/0x02, seal=true) → `onPacket(command:body:transactionsCrypted:)` trả `[Outgoing(command, encrypt, body)]`; bên gọi (WatchfaceManager, Phần 7) gửi qua `WatchConnection.sendFile(command:body:encrypt:)`. Đọc kết quả: `peerResultRaw`, `resultObserved`, `peerComplete`, `completionFailure`. Gọi `close()` khi xong.
- Danh tính file: dùng `systemNumber:systemFileNumber` thay cho `fileKey` của Java; kiểm tra symlink qua `.type == .typeRegular`.
- Rủi ro biên dịch cần soi ở build đầu: `ZipArchive.stream` (con trỏ `compression_stream` trong closure), `HwtSource` (init throwing với nhiều `let`), `FileTransfer.init` (dùng `self` sau khi gán đủ thuộc tính).

## 11. Thêm thông tin vào HWT có sẵn + Studio (mới, CHƯA biên dịch/chưa thử máy thật)
Mã dữ liệu (valueType) đọc từ 2 file HWT thật (Versaled, p0187VietNam), giải mã bằng script Python:
- Dương lịch: tháng 51 (13 mục, mục 0 đệm), chục ngày 70 (4 mục 0..3), đơn vị ngày 71 (10 mục).
- Âm lịch: tháng 92, chục ngày 93 (5 mục), đơn vị ngày 94.
- Thứ: 52, 8 mục (mục 0 đệm lặp "Thứ hai"; 1 = thứ hai ... 7 = chủ nhật).
- Giờ số 24h: chục giờ 59 (3 mục), giờ 60 (10), chục phút 61 (6), phút 62 (10); 63/64 = chục/đơn vị giây (chưa dùng).
- Kim: 150 giờ, 153 phút, 154 giây. Mã 50 (3 mục) có trong Versaled, chưa rõ nghĩa.
- Pin, thời tiết, bước chân, nhịp tim, calo: ĐÃ CÓ mã, đọc từ 3 file Kozmik (Kule, Kristal, Ultimate; ảnh cover đối chiếu từng mục), xem mục 12.
- File HWT thật: `com.huawei.watchface` KHÔNG phải ZIP mà chính là `watchface.bin`; không có hashCode, ability.xml, ảnh xem trước. Thứ tự phần tử: 0 (nền), 3, 2 (ngày), 1 (giờ). Code đã xử lý (nhánh không ZIP).
Code:
- `Store/FaceLunar.swift` (khối ngày/tháng dùng chung âm/dương), `Store/FaceInfo.swift` (thứ, giờ số, tên, gom `infoLayers`/`drawInfoPreview`), `Store/HwtLunarPatch.swift` (chèn vào HWT có sẵn, `HwtLunarPatch.apply`; từ chối nếu file đã có mã trùng), `Views/InfoSettingsView.swift` (UI dùng chung Studio + "Thêm thông tin" trong chi tiết thư viện).
- Phần chèn vào bin đã mô phỏng bằng Python trên 2 file thật (header, bảng ảnh, phần tử mới, ảnh cũ nguyên vẹn). Cả hai file mẫu đã có âm lịch + giờ số nên sẽ bị từ chối nếu bật các mục đó; dùng được "Tên" và "Dương lịch"/"Thứ" khi file chưa có.
- Test: `LunarPatchTests` trong `BuilderTests.swift`. Việc kế tiếp: build GitHub Actions, thử máy thật, thêm pin/thời tiết/bước/nhịp tim khi có file mẫu.

## 12. Số liệu pin / bước chân / nhịp tim / calo / thời tiết (mới, CHƯA biên dịch/chưa thử máy thật)
Nguồn: 3 file `Kozmik*_EN.hwt` (bản mới của HWHD09: có thêm trường 7 = biến thể màu, trường 8 = "widget" trong phần tử 3, nên cấu trúc ngoài khác file cũ).
Lớp (layer) dùng chung một lược đồ ở mọi nơi nên app tái sử dụng trong phần tử "ngày" kiểu cũ (trường 5):
- Lớp loại 3 = SỐ do đồng hồ cập nhật: trường 6 = {1: 10 ảnh chữ số 0..9, 2: ảnh dấu trừ (lặp 2 lần), 3: {x,y}, 4: căn lề (0 trái, 1 giữa, 2 phải), 5: mã loại số liệu, 6: ảnh đơn vị ghép sau số hoặc rỗng, 13: 0}.
  Đã mô phỏng bằng Python: mã hoá lại đúng từng byte cả 25 lớp số trong 3 file (script ở lịch sử phiên làm việc; test `testNumberLayerMatchesRealFile`).
- Mã loại số liệu: 0 bước chân, 1 calo, 2 nhịp tim, 4 nhiệt độ hiện tại, 9 pin %, 18/19 nhịp tim cao/thấp, 20/21 nhiệt độ cao/thấp, 15 giờ đứng, 26 căng thẳng (3 mã cuối chưa dùng).
- Thời tiết: lớp dãy ảnh (loại 2) mã 53, 11 mục: 0 không dữ liệu, 1 nắng, 2 quang, 3 ít mây, 4 nhiều mây, 5 mưa, 6 dông, 7 tuyết, 8 bão cát, 9 mù, 10 sương mù (dùng cho cả biểu tượng và tên tình trạng).
- Chưa dùng: lớp loại 6/7 (thanh/vòng tiến độ), lớp loại 0 (chữ: bình minh/hoàng hôn 121/122, giấc ngủ 142, quãng đường 146), mã tap "code" của widget (trường 8), mã 116 (pha trăng), 117 (mức căng thẳng).
Code: `Store/FaceData.swift` (`DataWidget`, `DataKind`, `WeatherLayout`, `dataLayers`, `drawDataPreview`), `HwtLayer.number` + `HwtDataType` trong `HwtBuilder.swift`, UI trong `InfoSettingsView.swift`.
Rủi ro cần thử máy thật: (1) firmware có chấp nhận lớp số đặt trong phần tử kiểu cũ (trường 5) thay vì widget (trường 8) không; (2) ý nghĩa trường 13 của lớp số (đang để 0 = không AOD); (3) biểu tượng thời tiết dùng SF Symbols nên cần iOS 15+.
Nếu (1) sai: gói các lớp số vào một phần tử số hiệu 3 theo cấu trúc widget như file Kozmik (xem script phân tích trong lịch sử phiên).

## 13. 26 kiểu kim + hiệu ứng mùa (mới, CHƯA biên dịch/chưa thử máy thật)
- Kim: `FaceDesign.HandStyle` nay có 26 case (3 cơ bản + 23 vector). 23 kiểu mới nằm trong `Store/HandShapes.swift` dưới dạng chuỗi lệnh SVG rút gọn (M L Q C Z, O = hình tròn; x theo bề rộng kim, y âm theo tầm kim, y dương theo đuôi), vẽ bằng `HandShapes.draw` (thân tô liền, lỗ khoét bằng blend `.clear` trong transparency layer, mảng tối `shade`, mảng sáng `lume`). Kim giây luôn là thanh mảnh. `handImage` mở rộng ảnh kim gấp ~2.1 lần bề rộng cho kiểu vector. Bản SVG của 23 kiểu: `design/hands_svg/`.
- Hiệu ứng mùa: 7 họa tiết mới trong `DecorPattern` (đào, mai, anh đào, tuyết, lá thu, tia nắng, vòng hoa), vẽ trong `Store/SeasonFX.swift` (`SeasonArt.draw`): chuyển sắc, bóng đổ, gân cánh, nhị hoa. Là lớp quay thật theo kim giờ/phút/giây qua cơ chế `DecorLayer` cũ (xuất thành ảnh PNG trong HWT). Đồng hồ KHÔNG có hạt rơi thật; hạt rơi thật chỉ ở `SeasonFallView` (xem trước trong Studio).
- 6 mẫu mới trong `FacePresets`: peachTet, apricotTet, snowWinter, sunSummer, autumnLeaf, garland.
- Rủi ro: chưa biên dịch; xem trước Studio vẽ lại mỗi lần chỉnh nên hiệu ứng mùa có thể hơi chậm (nếu giật, thu nhỏ `count` trong `SeasonArt.draw` hoặc lưu nhớ tạm ảnh lớp); kích thước PNG lớp mùa lớn hơn họa tiết cũ.

## 14. Phân tích 4 mặt động Kozmik + xem trước động trong Studio (mới, CHƯA biên dịch/chưa thử máy thật)
Phân tích 4 file: KozmikTavuk_EN, KozmikSemazen, Kozmik_Equinox_EN__1_, KozmikCam_EN_v10 (đều HWHD09, `com.huawei.watchface` = bin thô, 4 phần tử 0,3,2,1 như mục 11).
Các kiểu "động" thực sự có trong file:
- **Kim quay theo đồng hồ**: lớp loại 5 (valueType 150 giờ / 153 phút / 154 giây), ảnh kim to bằng cả mặt (466x466) trong Semazen.
- **Dãy ảnh đổi theo số liệu** (lớp loại 2, trường 3 = valueType, KHÔNG phải thời lượng khung hình): ngày 70/71, tháng 51, thứ 52, giờ 59/60, phút 61/62 và **giây 63/64**. Tavuk "gà mổ thóc mỗi giây" = dãy 10 ảnh gắn valueType 64 (chữ số đơn vị giây): mỗi giây đổi một ảnh. Đây là loại chuyển động có thật trên đồng hồ mà `HwtLayer.array` của app đã mã hoá được (chưa dùng mã 63/64).
- **Hoạt ảnh theo thời gian thật**: chỉ thấy ở Semazen trang 0: phần tử trường 9 loại 11, 24 ảnh (223..246), trường 3 = {x,y}, 3 và 4 = 50 và 100 (nghi là chu kỳ ms và tham số lặp), 3 phần tử bắt đầu lệch khung (230, 237). Cam trang 1 có dãy 28 ảnh với số 248 ở trường 3, chưa rõ là valueType hay chu kỳ. CHƯA giải mã chắc chắn, app chưa xuất được loại này.
- Trường 6 của dãy ảnh (0/1) có thể là cờ lặp/AOD, chưa kiểm chứng.
Đã làm (Phần 10): `Views/LivePreview.swift` (`LiveFaceAssets`, `LiveFaceView`, `GlowRing`, `staggerIn`) + sửa `Views/StudioView.swift`: xem trước chạy kim giờ thật (hoặc cố định 10:08:35), kim giây quét mượt, lớp quay chạy thật, vòng sáng, thẻ trượt lên lần lượt, nhấp nhẹ khi áp mẫu. Chỉ là xem trước trong app, không đổi file HWT xuất ra.
Việc kế tiếp: (a) lớp "chuyển động theo giây" xuất ra HWT bằng `.array` valueType 64 (10 ảnh/giây như Tavuk); (b) giải mã phần tử loại 11 của Semazen bằng cách so sánh byte rồi mới thêm vào `HwtLayer`.

## 15. Chuyển động theo giây (Phần 11, mới, CHƯA biên dịch/chưa thử máy thật)
- `Store/SecondFX.swift`: `SecondFX` (none, dotChase, bloom, arc, pulse), `FaceRenderer.drawSecondFX/secondFXFrames` (10 ảnh 466x466 trong suốt).
- `FaceDesign.secondFX`, `secondFXColor`; `FaceBuilder.build` thêm `.array(resources: 10 ảnh, x:0, y:0, valueType: HwtValueType.secondOnes (64), ambient:false)` vào phần tử giờ, dưới kim.
- Xem trước: `LiveFaceAssets.fxFrames` + `LiveFaceView` đổi khung theo chữ số giây. UI: `secondFXCard` trong Studio.
- Rủi ro cần thử máy thật: firmware có nhận dãy ảnh mã 64 đặt trong phần tử giờ không (file Kozmik đặt ở phần tử 1, cùng chỗ nên khả năng cao); ảnh trong suốt toàn mặt tốn bộ nhớ đồng hồ hơn ảnh nhỏ.
- Chưa làm: hoạt ảnh loại 11 của Semazen (Phần 12).

## 16. Hoạt ảnh xoay liên tục, lớp loại 11 (Phần 12, THỬ NGHIỆM, CHƯA biên dịch/chưa thử máy thật)
Giải mã từ KozmikSemazen trang 0 (chỉ file này có): 3 phần tử trường 9 (không phải trường 5), `{1: chỉ số lớp (nối tiếp lớp trường 5), 2: 11, 3: {1: 24 ảnh (lặp), 2: {x,y}, 3: 50, 4: 100, 5: 1, 6..9: 0}, 4: {11: {1:0,2:0}, 12..17: 0}}`. Ảnh 92x92 là dervish quay trọn một vòng trong 24 khung; 3 bản bắt đầu ở khung 0, 7, 14 (lệch pha).
- Trường 3 của nhóm 3 = ms mỗi khung (nghi, khớp 50 ms x 24 = 1,2 s/vòng). Trường 4 = 100 và 5 = 1 chưa rõ nghĩa (nghi 100% độ đục / bật lặp), nhóm 4 toàn 0: app chép đúng giá trị của file thật. Trường 9 của nhóm 3 đang dùng làm cờ AOD (suy từ lớp kim, chưa kiểm chứng).
- Code: `HwtLayer.animation`, nhánh trường 9 trong `HwtBuilder.layoutBytes`, `Store/AnimFX.swift`, `FaceDesign.anim*`, thẻ `animCard` trong Studio, xem trước xoay ở `LiveFaceView`.
- Mặt đồng hồ tự tạo đặt lớp này cuối phần tử nền (vẽ trên nền, dưới kim). Chưa có test; việc cần làm: thêm test so `layoutBytes` với byte thật của Semazen.

## 17. Hoạt ảnh hạt rơi: tuyết / lá / hoa (Phần 13, THỬ NGHIỆM, CHƯA biên dịch/chưa thử máy thật)
- `Store/FallFX.swift` (mới): `AnimKind {spin,snow,leaves,petals}`, `FaceRenderer.fallStrips(design)` → 3 dải cột (cao 466 px, rộng ~185/216/186 px gồm lề 36 px) × 24/32/48 khung ARGB. Mỗi dải là một lớp `.animation` riêng (cùng `intervalMs`, nội dung khác nhau), đặt ở `x = imgX, y = 0`, vẽ trên nền, dưới kim, chỉ ban ngày (không AOD).
- Lặp liền mạch: mọi hạt rơi đúng 466 px mỗi vòng (y = (y0 + 466·t) mod 466), lắc ngang/xoay/lật dùng số chu kỳ NGUYÊN; hạt vẽ hai bản (y và y−466) để qua mép dưới hiện lại ở mép trên. Hạt sinh bằng RNG cố định (SplitMix) nên bản xem trước = bản xuất.
- Hạt tự vẽ (không dùng `SeasonArt`, vì zip này không có file đó): tuyết (chấm mềm / tinh thể 6 nhánh khi bán kính ≥ 4,2 px), lá (5 màu thu, gân + cuống, nửa lá tối), hoa anh đào (4 màu hồng).
- `FaceDesign`: thêm `animKind`, `animFallFrames` (24/32/48), `animDensity`. `buildHwt`: nhánh `animKind.isFall` thêm 3 lớp animation. Xem trước: `LiveFaceAssets.fall` + vẽ trong `LiveFaceView`. UI: thẻ `animCard` có chọn kiểu, mật độ, số khung, chu kỳ.
- Rủi ro: 3 dải × 32 khung ≈ 28 MB ảnh thô trên đồng hồ (hiện cảnh báo trong app); số ảnh = 3 × số khung (tối đa 144, giới hạn 300 của HwtBuilder gồm cả ảnh khác); chưa rõ đồng hồ có chịu được không. Tốc độ rơi cố định = 466 px / (số khung × ms) nên muốn rơi chậm hơn phải tăng số khung hoặc ms (tối đa 120).
- Chưa làm: tái dùng hình lá/tuyết của `SeasonArt` (cần file đó); rơi cho AOD.

## 18. Bản ghép đầy đủ (Phần 13) – LƯU Ý
- Ghép từ WristMirror-iOS-merged (đến mục 12) + phan12-anim + phan13-fall. Các file còn THIẾU trong bản ghép (nằm ở phần giữa, chưa có zip): `HandShapes.swift` (23 kiểu kim vector), `SeasonArt.swift`, `SeasonFallView`, `HandThumbs` và `DecorPattern.isSeasonal/.seasonal/.geometric`.
- `Store/CompatStubs.swift` thay tạm các phần đó để project biên dịch được: kiểu kim ngoài Thanh/Nhọn/Cổ điển vẽ như kim Thanh; hiệu ứng mùa trống. Khi có file thật thì XOÁ `CompatStubs.swift`.
- Chưa biên dịch: nếu build lỗi, gửi log (`out/build.log`) để sửa.

## 19. Sửa lỗi hiệu ứng/hoạt ảnh không chạy liên tục trên đồng hồ (Phần 14, CHƯA biên dịch/chưa thử máy thật)
Nghi nguyên nhân (chưa xác nhận trên máy): (1) ảnh quá nặng: hiệu ứng giây từng là 10 ảnh 466x466 (~8,7 MB), hoạt ảnh xoay cạnh tới 443 px x 24 khung (~18 MB) trong khi file mẫu Semazen chỉ ~0,8 MB; (2) tắt kim giây thì đồng hồ có thể chỉ vẽ lại mỗi phút nên dãy ảnh mã 64 đứng yên.
- `SecondFX.swift`: `secondFXCropped` cắt 10 khung về hộp nhỏ nhất (Hoa nở ~230 px), `secondFXRawMegabytes`, `animSpinRawMegabytes`.
- `FaceDesign.buildHwt`: dãy mã 64 dùng x,y của hộp cắt; nếu `!showSecond` thêm kim giây vô hình 2x2 (valueType giây) để buộc cập nhật mỗi giây.
- `AnimFX.animLayer`: kẹp kích thước ≤ 0,5 mặt; Studio: thanh Kích thước 0,2...0,5 + hiện MB ảnh thô.
- Còn nghi chưa kiểm chứng: trường 4 (=100) và 5 (=1) của lớp loại 11 có thể là số lần lặp/chế độ lặp; nếu vẫn dừng sau một lúc, thử đổi các giá trị này.
- Phần 14b: bản cũ hoạt ảnh mượt nhưng chỉ chạy một lượt rồi nghỉ vài giây ⇒ nghi trường 4/5 của lớp loại 11. Thêm `FaceDesign.animLoopMode` + `HwtFaceSpec.animLoopMode` (A=100/1 chép Semazen, B=100/0, C=0/1, D=0/0) và bộ chọn "Kiểu lặp (thử)" trong thẻ hoạt ảnh; cần thử B/C/D trên đồng hồ và ghi lại kiểu nào lặp liên tục.
- Phần 14c: "Thêm thông tin" làm app báo có âm/dương lịch nhưng đồng hồ không hiện (log: truyền xong, mặt được liệt kê, `visual_application_unverified`). Nghi số hiệu phần tử mới = max+1 (vd. 4) chưa từng thử trên máy. Nay `HwtLunarPatch.mergeIntoElement` nhét lớp mới vào phần tử số 2 có sẵn (chỉ số lớp tiếp theo, `HwtFaceSpec.layerIndexBase`); không được (có hoạt ảnh/không có lớp) thì quay lại thêm phần tử mới. CHƯA biên dịch/thử máy thật. Nghi thêm: ability.xml gốc có thể thiếu bit mã âm lịch — cần file Kozmik_Equinox_EN.hwt gốc để kiểm.
- Phần 14d: ĐÃ XÁC NHẬN trên máy thật: gộp lớp âm/dương lịch vào phần tử số 2 có sẵn thì đồng hồ hiện đúng; phần tử mới số 4 thì không hiện. `mergeIntoElement` là cách mặc định (chưa biên dịch bằng Swift, đã mô phỏng bằng Python trên Kozmik_Equinox_EN). Chỉ số lớp của phần tử file thật bắt đầu từ 1, code lấy max+1 nên khớp.
- Phần 14e: kiểm 4 file mẫu. Equinox/Semazen (lớp ở trường 5, có phần tử số 2) gộp được. Kozmik Cam/Tavuk dùng định dạng bố cục mới (lớp ở trường 7 trong mỗi phần tử, trường 2 của phần tử = 1, có trường 5 cấp cao nhất) => `patchBin` ném `LUNAR_FORMAT_UNSUPPORTED`. Bỏ nhánh thêm phần tử số 4 (đồng hồ không hiện): không gộp được thì ném `LUNAR_NO_SLOT`. Semazen đã có dương lịch (mã 70/71) và thứ, giờ số nên chỉ thêm được âm lịch. CHƯA biên dịch Swift.
- Phần 14f: đã đọc định dạng bố cục MỚI (Kozmik Cam/Tavuk): phần tử có nhiều "kiểu" ở trường 7 (trường 1 = số kiểu, trường 2 = các lớp {1=chỉ số, 2=loại, thân 4/5/6/8 như cũ}, trường 3 = tên ảnh xem trước); Cam có 4 kiểu ở phần tử 0/1/2 và 10 kiểu ở phần tử 3 (ô phụ). Cam/Tavuk đã có dương lịch (51/70/71) + thứ (52) ở phần tử 2 nhưng chưa có âm lịch. `HwtLunarPatch.mergeIntoModes` thêm lớp vào cuối MỖI kiểu của phần tử 2 (tag 0x12), `existingValueTypes` đọc cả trường 7. Mô phỏng bằng Python và tạo 2 file thử (KozmikCam_EN_amlich_test.hwt, KozmikTavuk_EN_amlich_test.hwt, chỉ lớp âm lịch lấy từ ảnh Equinox nên vị trí có thể chồng lên chữ có sẵn). CHƯA thử máy thật, CHƯA biên dịch Swift. Lớp của Cam/Tavuk có cờ AOD=1 ở nhiều lớp ngày: chưa rõ ý nghĩa.

## 16. Biểu tượng SVG riêng, khung nền SVG, font chữ/số, nền AOD gốc (phần 15, CHƯA biên dịch/chưa thử máy thật)
- `Store/FaceSVG.swift`: `MiniSVG` (đọc path M L H V C S Q Z, circle, ellipse, rect; màu theo palette), `PlateStyle` + `FacePlate` (6 khung nền SVG, tạo chuỗi SVG theo kích thước thật), `drawPlatesPreview`/`plateLayers` (khung nền là lớp `.single` đặt TRƯỚC các lớp chữ), `drawWeatherIcon`/`drawDataIcon`.
- `Store/FaceSVGData.swift`: 11 biểu tượng thời tiết + pin, bước chân, tim, calo (viewBox 100x100). `FaceDesign.iconSVG` bật/tắt (tắt = SF Symbols). `FaceDesign.plates[key]` với key: digital, weekday, solar, lunar, weather, battery, steps, heart, calories, name.
- `Store/FaceFonts.swift`: `FaceFont` (6 font), `FaceDesign.textFontIndex`/`numberFontIndex`.
- `FaceDesign.AodBackground.original` = AOD dùng nền ban ngày.
- Pin đổi theo mức: CHƯA làm được; cần mã valueType của dãy ảnh theo mức pin (chưa giải mã, chỉ biết mã số liệu 9 cho lớp số). Cần file HWT thật có biểu tượng pin đổi theo mức để đối chiếu.

## 17. Chỉnh sửa lại mặt đồng hồ đã tạo (Phần 16, CHƯA biên dịch/chưa thử máy thật)
- Mỗi mặt tạo từ Studio nay lưu kèm thiết kế trong thư mục mục thư viện: `design.json` + `photo.jpg` (ảnh nền, nếu có). `Store/FaceDesignCodec.swift` mã hoá/giải mã `FaceDesign` bằng JSON qua bảng `fields` (một dòng mỗi thuộc tính; trường thiếu/sai kiểu giữ mặc định). KHI THÊM THUỘC TÍNH MỚI vào `FaceDesign`, thêm dòng tương ứng vào `fields`, nếu không sẽ không được lưu.
- `HwtLibrary`: `designURL/hasDesign/saveDesign/loadDesign/absorb`. `absorb(newId:into:)` đưa nội dung mục mới vào mục cũ, giữ id cũ (lịch nhắc không hỏng) và ngày thêm.
- `WatchViewModel.importHwt(_:displayName:onLibrary:)`: callback (mục, isNew) sau khi vào thư viện, dùng để gắn thiết kế / ghi đè.
- UI: `LibraryDetailView` có nút "Chỉnh sửa thiết kế" (chỉ khi có `design.json`); ô thư viện có biểu tượng thanh trượt. `StudioView(editing:library:)` mở lại thiết kế; nút "Lưu thay đổi" ghi đè mặt cũ, công tắc "Lưu thành bản mới" tạo mặt riêng. Ảnh xem trước dùng `.id(sourceHash)` để tải lại sau khi sửa.
- Giới hạn: mặt tạo trước bản này, mặt nhập từ file HWT và mặt đã "Thêm âm lịch" không có thiết kế nên không chỉnh được. Sau khi sửa phải gửi lại file lên đồng hồ.
- Test mới: `WristMirrorTests/DesignCodecTests.swift`. Chưa biên dịch Swift.

## 18. Mặt mặc định lấy từ file HWT mẫu của chủ app (Phần 17, CHƯA biên dịch/chưa thử máy thật)
- Nguồn: file `a975934a-face.hwt` (tạo bằng app này). Đọc bố cục nhị phân + ảnh rồi quy ngược toạ độ điểm ảnh về tỉ lệ 0...1 theo đúng công thức của `dateLayout`, `weekdayLayout`, `digitalLayout`, `nameLayout`, `dataNumberLayout`, `WeatherLayout`.
- `Store/FaceDefault.swift`: `FaceDesign.themeDefault` (Studio mở ra với thiết kế này; có thêm mẫu "Mặc định" đầu danh sách `FacePresets.all`). `FaceDesign()` giữ nguyên là thiết kế trống cho các mẫu khác.
- Nội dung: nền chuyển sắc #003649 → #3C061A; hoa sen vàng #F2C879 (độ đậm 0,3, cỡ 0,95) quay theo kim giây; vạch chấm vàng; kim Nhọn (giờ #74A7FF, phút #FF8648, giây #FF4015, núm #A67B01, độ dày 0,9, không viền tối); giờ số trong khung bát giác; thứ trong khung viên thuốc; dương lịch (trắng) + âm lịch (#F6DDA4); pin, nhịp tim, thời tiết (có tên tình trạng); tên "Quốc Đại" (kiểu Mảnh); hiệu ứng giây Hoa nở; lá thu rơi 48 khung, 30 ms, mật độ 1,0, kiểu lặp D; AOD: Nền riêng chuyển sắc #020A13 → #142942, có lớp trang trí tĩnh, kim #C7862E, vạch giờ #856B42, hiện thông tin.
- Giá trị suy ra từ điểm ảnh nên có thể lệch vài px so với số người dùng đã gõ (ví dụ lunarX 0,752, solarY 0,435). `autoLayout` bật; nếu thấy mục bị dời, tắt Tự sắp xếp hoặc chỉnh lại.
- Chưa suy ra được: font (giả định hệ thống), biểu tượng SVG hay SF Symbols (giả định SVG).

## 19. AOD: nền riêng + hiện thông tin (Phần 18, CHƯA biên dịch/chưa thử máy thật)
- `AodBackground.custom` ("Nền riêng"): ảnh riêng (`aodPhoto`, lưu `aodphoto.jpg` trong thư viện) hoặc màu/chuyển sắc riêng (`aodColor/aodColor2`) với 8 nền có sẵn (`FaceDesign.aodPalettes`); tuỳ chọn `aodShowDecor` vẽ lớp trang trí tĩnh lên nền riêng. `FaceRenderer.drawFill` dùng chung cho nền ngày và AOD.
- `aodShowInfo`: thêm bản sao các lớp thông tin (`HwtLayer.ambientCopy`, cùng ảnh, cờ ambient=1) nên không tốn thêm ảnh. Không làm mờ riêng; xem trước AOD vẽ thông tin như ban ngày.
- KHÔNG có ở AOD: lớp quay, hiệu ứng giây, hạt rơi (AOD cập nhật mỗi phút). Rủi ro: chưa rõ firmware có hiện lớp số/mảng ambient=1 trong phần tử thông tin đúng không (file Kozmik có cờ AOD ở lớp ngày nên khả năng cao).

## 20. Ẩn tiêu đề các tab (Phần 19)
- 4 tab gốc (Trang chủ, Thiết bị, Mặt đồng hồ, Cài đặt) ẩn thanh điều hướng bằng `.toolbar(.hidden, for: .navigationBar)` để full màn; màn con (Studio, Lịch nhắc...) vẫn có thanh và nút quay lại. Chưa biên dịch.
- Phần 20: bỏ dòng "Huawei watch face · v… / Làm bởi Quốc Đại" cuối Trang chủ (HomeView). Ghi công vẫn còn ở AboutView/NOTICE.

## 20. Nền SVG mùa, Noel, Tết (CHƯA biên dịch/chưa thử máy thật)
- `Store/FaceBackdropSeasons.swift` (mới): `FaceBackdrops.daySeasonal` (10 nền ban ngày) và `FaceBackdrops.aodSeasonal` (10 nền AOD nét mảnh). `FaceBackdrops.day` / `aod` giờ là `dayBasic + daySeasonal` / `aodBasic + aodSeasonal` (hai mảng cũ đổi tên trong FaceBackdrop.swift), nên bộ chọn và `find` tự có nền mới.
- Ban ngày: tetMai, tetDao, tetBanh, tetPhao, noelWreath, noelNight, seasonSpring, seasonSummer, seasonAutumn, seasonWinter. AOD: aodSpring, aodSummer, aodAutumn, aodWinter, aodNoel, aodNoelTree, aodMai, aodDao, aodBanh, aodPhao.
- SVG được dựng sẵn bằng script ngoài (Python) và viết nguyên văn trong chuỗi `##"..."##`; chỉ dùng path (M L C Q Z), circle, ellipse, rect, fill/stroke dạng #rrggbb hoặc none, opacity, stroke-width (đúng tập con của `MiniSVG`). Đã kiểm tra bằng trình duyệt, chưa chạy trong app.
- Mỗi nền ban ngày 350-810 phần tử, vẽ một lần rồi lưu trong `backdropCache`; không tốn thêm ảnh trong HWT. Vùng giữa mặt được chừa thưa để kim và chữ dễ đọc.

## Phần 24 – Lớp trang trí Noel & Tết (xoay theo kim)
- Thêm 7 họa tiết vector nhiều màu vào `DecorPattern`: noelWreath, noelStar, noelSnow, tetMai, tetDao, tetLantern, tetFirework (Store/FaceDecorFestive.swift).
- `DecorPattern.festive` là danh sách; `CompatStubs.swift` dùng nó cho `isSeasonal`/`geometric`/`seasonal` (hàng "Hiệu ứng mùa (nhiều màu)" trong Studio).
- `FaceBackdrop.drawExtraDecor` nhánh `default` gọi `drawFestiveDecor`. Chưa biên dịch – nếu lỗi, đọc log GitHub Actions.

## Phần 25 – Hiệu ứng rơi Hoa mai / Hoa đào / Pháo hoa
- `AnimKind` thêm `mai`, `dao`, `firework` (Store/FallFX.swift): hoa 5 cánh rơi lắc + lật mặt, tia lửa pháo hoa rơi có đuôi và nhấp nháy. Dùng chung cơ chế dải ảnh/khung của tuyết-lá-hoa nên mật độ, số khung, chu kỳ vẫn chỉnh được.
- Bộ chọn "Kiểu" trong StudioView đổi sang `.menu` vì có 7 lựa chọn.

## Phần 26 – Pháo hoa bắn lên (AnimKind.firework)
- Thay kiểu tia lửa rơi bằng pháo hoa thật: quả bay lên có đuôi, nổ bung (ánh chớp + 48 tia, lực cản + trọng lực), mờ dần và lặp liền mạch. 2–4 quả theo mật độ, lệch pha nhau. Hàm `drawFireworks` vẽ theo toạ độ toàn mặt, mỗi dải ảnh clip đúng cột của mình.

## Phần 27 – Tiếng Anh + nút lá cờ (Việt/Anh)
- Store/AppLanguage.swift: `AppLang` (vi/en, mặc định vi, lưu UserDefaults "appLang"), `LangStore.shared`, hàm `tr()` / `trf("... %@", giá trị…)`. Store/AppLanguageData.swift là bảng dịch Việt→Anh (tạo tự động, ~660 chuỗi); thiếu mục thì giữ nguyên chuỗi gốc. `tr` còn dịch ngược Anh→Việt để chuỗi cũ đổi lại được.
- Mọi chuỗi tiếng Việt trong Views/App/Protocol/Transport/FaceSchedule đã bọc `tr(...)`/`trf(...)`; các `Text(biến)`, `Button(biến)`, `Label(biến, …)`, `.navigationTitle(biến)` … bọc `tr` lúc hiển thị (nên tên nền, mẫu, họa tiết trong Store/ được dịch mà không đụng dữ liệu đã lưu).
- Views/LanguageViews.swift: `LanguageMenuButton` (nút cờ) đặt ở trang giới thiệu đầu tiên (toolbar) và Trang chủ (hàng trên cùng); `LanguagePickerRow` trong Cài đặt. RootView gắn `.id(langStore.lang)` cho từng tab/sheet để vẽ lại khi đổi ngôn ngữ.
- Không dịch: nội dung vẽ lên mặt đồng hồ (thứ, thời tiết, âm lịch trong FaceData/FaceInfo/FaceLunar), chuỗi nhật ký trong SafeLog, quyền trong Info.plist. Thêm chuỗi mới: viết `tr("...")` rồi thêm cặp Việt→Anh vào AppLanguageData.swift.

### Phần 27b – Dịch nốt phần còn lại
- Nội dung vẽ lên mặt đồng hồ cũng theo ngôn ngữ app lúc tạo file: `FaceRenderer.weekdayNames`, `weatherNames` (nay là `static var`), " bước", nhãn "ÂL"/"D. LỊCH" (→ LUN/SOLAR). Đổi ngôn ngữ rồi tạo/ lưu lại mặt đồng hồ thì file HWT mới mang chữ tương ứng; file đã tạo trước đó giữ nguyên.
- HwtLunarPatch.swift (màn "Thêm thông tin") và tiêu đề nhật ký xuất ra (SafeLog) đã bọc `tr`.
- Quyền Bluetooth và tên app: WristMirror/vi.lproj + en.lproj/InfoPlist.strings (theo ngôn ngữ iPhone, không theo nút cờ vì iOS đọc ngôn ngữ hệ thống); project.yml: developmentLanguage vi, CFBundleLocalizations [vi, en].


## Phần 30 – 40 kiểu kim vector theo ảnh thiết kế
- `Store/HandShapes.swift` (MỚI, thay bản tạm trong CompatStubs): 40 kiểu kim (Dauphine x3, Sword x2, Leaf x2, Cathedral, Skeleton, Baton x2, Arrow x2, Feather x2, Trident x2, Diamond x2, Blue Steel, Blue Gold, Rose Gold, Ruby, Sapphire, Luminous x6, Sport, Racing, Royal, Baroque, Luxury, Elegant, Chronograph, Minimalist, Geometric, Future) + `HandThumbs` (hình thu nhỏ cặp kim giờ/phút xếp chữ V).
- Mỗi kim = `Def` (profile (t,w) từ đầu kim → trục → đuôi, bảng màu 5 mức `HP.*`, kiểu tô halves/facets/glow, ô khoét `window`, lõi `coreWin`, chi tiết `extras`). Thêm kiểu mới: thêm dòng `t["tên"] = Def(...)` + `titles` + case trong `FaceDesign.HandStyle`.
- `FaceDesign.handOwnColors` (mặc định bật, lưu trong codec): bật = dùng màu gốc của kiểu kim; tắt = suy ra bảng màu từ màu kim giờ/phút. AOD luôn dùng màu kim AOD.
- Đã xoá các kiểu cũ không có trong ảnh (spear, breguet, lollipop, triangle, syringe, needle, flame, fleur, teardrop, pill, stepped, bamboo, lotusbud); design cũ dùng chúng sẽ rơi về kiểu mặc định khi mở.
- Chưa biên dịch trên máy thật: cần chạy GitHub Actions và xem lại hình kim thật trên iPhone.

## Phần 31 – Kiểu số giờ vector
- `Store/FaceNumerals.swift` (MỚI): `NumeralStyle` (33 case, `.classic` = số thường kiểu cũ) + `NumeralShapes` (bảng `Def`: bộ chữ Ả Rập/La Mã/Hán/Ả Rập cổ/4 số, kiểu tô flat/metal/glow/outline, bố cục thẳng/xoay/huy hiệu tròn/thoi, bảng màu `HP.*` của HandShapes) + `NumeralThumbs`. Chữ → path bằng CoreText rồi tô dải kim loại.
- `FaceDesign.numeralStyle`, `numeralOwnColors` (mặc định bật) lưu trong codec. `FaceRenderer.drawMarks(..., numeral:, own:)`; AOD luôn `own: false` (màu vạch giờ AOD).
- UI: thẻ "Vạch giờ" trong Studio hiện lưới kiểu số khi chọn "Số". Thêm kiểu mới: thêm case + dòng `t["..."] = Def(...)` + `titles`.
- Chưa biên dịch/thử trên máy thật.

## Phần 32 – 17 kiểu số giờ kỹ thuật số vector (mục Giờ số HH:MM)
- `Store/FaceDigitalStyles.swift` (MỚI): `DigitalStyle` (18 case, `.classic` = số thường theo font như cũ) + `DigitalShapes` (bảng `Def`: hình học 7 đoạn hex/bar/cut/viên thuốc/nghiêng, chấm ma trận 5x7 tròn/vuông/thoi, pixel 3x5, nét đơn neon/mảnh/tròn; kiểu tô flat/metal/glow/outline; `ghost` = đoạn tắt mờ; bảng màu `HP.*`) + `DigitalThumbs` (hình "13:00" trong bộ chọn). Hộp số cao 100 đơn vị; path dựng bằng code (nét đơn dùng `MiniSVG.parsePath`, nay là internal).
- `FaceDesign.digitalStyle`, `digitalOwnColors` (mặc định bật) lưu trong codec. `FaceRenderer.digitalLayout` tính ô theo kiểu (lề `pad` để quầng sáng không bị cắt), `drawDigitalPreview`/`digitalLayers` vẽ số vector khi kiểu khác `.classic` (cùng số mục ảnh/valueType như bản font: 3 + 10 + dấu `:` + 6 + 10).
- UI: `InfoSettingsView` – khối "Giờ số (HH:MM)" có lưới chọn kiểu + công tắc "Dùng màu gốc của kiểu số" (tắt thì bảng màu suy ra từ "Màu chữ"). Chuỗi mới đã thêm vào `AppLanguageData.swift`.
- Thêm kiểu mới: thêm case + dòng `t["..."] = Def(...)` + `titles`. Xem trước toàn bộ kiểu: `so-gio-ky-thuat-so-13-00.svg`.
- Test: `WristMirrorTests/DigitalStylesTests.swift`. Chưa biên dịch/thử trên máy thật.


## Phần 33 – Ngày tháng Dương lịch / Âm lịch chọn kiểu số + nhãn chữ vector (Việt/Anh)
- Nhãn đổi tên: Dương lịch = "D lịch" / "Solar", Âm lịch = "Â lịch" / "Lunar" (thay "D. LỊCH"/"ÂL"). Dạng hiển thị chọn được: "D lịch 26/11", "D lịch 26-11", "Â lịch 26/11", "Â lịch 26-11" (`solarSep`/`lunarSep`: 0 = "/", 1 = "-").
- Dùng lại 17 kiểu số của giờ số cho ngày/tháng: `FaceDesign.solarStyle/lunarStyle` (`DigitalStyle`, `.classic` = số thường theo font như cũ), `solarOwnColors/lunarOwnColors`, `solarLabelLang/lunarLabelLang` (0 theo app, 1 Việt, 2 Anh). Lưu trong codec (khoá cùng tên).
- `FaceDigitalStyles.swift`: thêm dấu "/" và "-" cho cả 4 họ hình (7 đoạn, ma trận, pixel, nét đơn): `sepWidth`, `charWidth`, `Cells.sepW`, `cells(..., base:)` (ngày tháng dùng base 26); tách `fillStyled` (dùng chung cho số và nhãn), thêm `drawLabel`.
- `Store/FaceDateStyles.swift` (MỚI): `DateLabelShapes` (chữ → path bằng CoreText, tô cùng kiểu số nên nhãn là hình vector, không cần font; kiểu "Viền rỗng" vẽ nhãn dạng đặc cho dễ đọc) + `DateThumbs` (hình thu nhỏ nhãn + 26/11 trong bộ chọn).
- `FaceLunar.swift`: `dateLayout` nhận `sep/style/own`; `drawDatePreview` và `dateLayers` có nhánh vector. Số mục ảnh/valueType giữ nguyên (chục 4 ảnh + 10 đơn vị + 12 tháng + dấu ngăn + nhãn) nên đồng hồ đọc như cũ. Tháng vẽ 2 chữ số trong 1 ảnh rộng 2 ô.
- UI: `InfoSettingsView.dateContent` – bộ chọn "Dạng hiển thị", lưới kiểu số, công tắc màu gốc, "Hiện nhãn chữ" + chọn ngôn ngữ nhãn. Chuỗi mới đã thêm vào `AppLanguageData.swift`; đã bỏ các khoá "ÂL"/"D. LỊCH".
- Xem trước tất cả kiểu: `design/ngay-thang-kieu-so.svg`. Test: `WristMirrorTests/DateStylesTests.swift`. Chưa biên dịch/thử trên máy thật; file HWT cũ giữ nguyên chữ cũ, cần tạo/lưu lại mặt đồng hồ để có nhãn mới.

### Phần 34 – Thêm nhiều kiểu số và kiểu chữ nhãn
- `DigitalStyle` từ 17 lên 48 kiểu (thêm 31): LED xanh lá/hổ phách/tím nghiêng/băng mảnh, vàng/hồng nghiêng, viên thuốc bạc/vàng/xanh, ruby dày, đoạn mảnh, viền vàng/đỏ/viên thuốc, chấm hồng/thoi xanh/đỏ/vuông bạc, neon xanh lá/cam/đỏ/xanh, tròn bạc/hồng, nét mảnh vàng, nét đậm, pixel xanh lá/vàng/đỏ/băng. Mỗi kiểu là một dòng `t["..."] = Def(...)` + `titles` (dùng chung cho Giờ số và ngày tháng).
- Kiểu chữ nhãn (`solarLabelFont` / `lunarLabelFont`, 0...5: đậm, tròn, có chân, nghiêng, đơn cách, mảnh) qua `DateLabelShapes.font(_:)`; chỉ áp dụng khi chọn kiểu số vector. UI: menu "Kiểu chữ nhãn" trong Dương lịch / Âm lịch.
- `design/ngay-thang-kieu-so.svg` cập nhật đủ 48 kiểu. Chưa biên dịch.

## Phần 35 – Kiểu số vector cho số liệu (pin, bước chân, nhịp tim, calo, thời tiết)
- Dùng lại 48 kiểu số của giờ số / ngày tháng cho các mục số liệu do đồng hồ cập nhật. Có **kiểu chung cho tất cả số liệu** (`FaceDesign.dataStyle`, `dataOwnColors`) và **tuỳ chọn riêng từng mục** (`DataWidget.customStyle` + `style` + `ownColors`; bật "Kiểu số riêng" thì mục đó bỏ qua kiểu chung, kể cả chọn "Số thường"). Mặc định `.classic` nên file/thiết kế cũ không đổi. Lưu trong codec (`dataStyle`, `dataOwnColors`, và trong từng widget `customStyle`/`style`/`ownColors`).
- `Store/FaceDataStyles.swift` (MỚI): `FaceDesign.dataVecStyle(_:)` chọn kiểu thực tế (riêng > chung); `VecSuffix`/`DataVecInfo`; đơn vị (%, bpm, kcal, bước, °) là path chữ CoreText (`DateLabelShapes`) tô cùng kiểu số, "°" căn mép trên, đơn vị khác căn đường cơ sở; mũi tên cao/thấp là path vẽ bằng code (`drawVecArrow`); `DataThumbs` (hình "72 bpm" trong bộ chọn).
- `FaceData.swift`: `DataNumberLayout.vec`, `WeatherLayout.vec/rangeVec` (nhiệt độ hiện tại + "°" cỡ 28, cao/thấp cỡ 18); `dataNumberLayout`, `drawDataPreview`, `drawWeatherPreview`, `dataLayers` có nhánh vector. Ảnh chữ số 0-9 và "-" (nhiệt độ âm) dựng bằng `DigitalShapes.draw`; bộ ảnh dùng chung theo khoá (kiểu + màu gốc + cỡ + màu) để tiết kiệm ảnh trong HWT. Số mục/`dataType` giữ nguyên nên đồng hồ cập nhật như cũ. `FaceLayoutGuard` tự dùng kích thước mới.
- UI (`InfoSettingsView`): thẻ "Kiểu số cho tất cả số liệu" phía trên Pin; mỗi mục (Pin, Bước chân, Nhịp tim, Calo, Thời tiết) có công tắc "Kiểu số riêng cho mục này" + lưới kiểu + "Dùng màu gốc". Ô "Màu chữ" tự ẩn khi kiểu dùng màu gốc. `digitalStyleGrid` nay dùng hàm chung `styleGrid`.
- Chuỗi mới đã thêm vào `AppLanguageData.swift`. Test: `WristMirrorTests/DataStylesTests.swift`. Chưa biên dịch/thử trên máy thật; file HWT cũ giữ nguyên chữ cũ, cần tạo/lưu lại mặt đồng hồ.

### Phần 35b – Kiểu số CHUNG cho mọi thứ có số (đồng bộ giờ số + ngày tháng + số liệu)
- `FaceDesign.dataStyle`/`dataOwnColors` nay là **kiểu số chung** cho giờ số, dương lịch, âm lịch, pin, bước chân, nhịp tim, calo, thời tiết. Từng mục có công tắc "Kiểu số riêng cho mục này": `digitalCustom`, `solarCustom`, `lunarCustom`, `DataWidget.customStyle` (mặc định tắt = theo kiểu chung). `digitalStyle/solarStyle/lunarStyle` (+ `...OwnColors`) chỉ có tác dụng khi công tắc riêng bật.
- Mọi chỗ vẽ/bố cục giờ số và ngày tháng dùng `digitalStyleEff/digitalOwnEff`, `solarStyleEff/solarOwnEff`, `lunarStyleEff/lunarOwnEff` (FaceDataStyles.swift).
- Codec: thêm khoá `digitalCustom/solarCustom/lunarCustom`; thiết kế cũ có `digitalStyle/solarStyle/lunarStyle` khác `classic` mà chưa có khoá custom sẽ tự bật "kiểu riêng" để giữ nguyên hình cũ.
- UI: thẻ "Kiểu số chung cho tất cả" đặt trên cùng (trước Dương lịch); mỗi khối có "Kiểu số riêng cho mục này" (hàm `styleOverride`). Ô "Màu chữ" ẩn khi kiểu hiệu lực dùng màu gốc.
- Test: cập nhật DigitalStylesTests/DateStylesTests (bật custom), thêm `testSharedStyleSyncsTimeAndDates`, `testOldDesignWithOwnTimeStyleStaysCustom`. Chưa biên dịch.

## Phần 36 – Ký hiệu % và ° vector, biểu tượng pin / nhiệt kế vector, 10 khung nền mới (CHƯA biên dịch/chưa thử máy thật)
- `Store/FaceUnitIcons.swift` (MỚI):
  - `UnitSymbols`: 7 kiểu ký hiệu "%" và "°" dựng bằng CGPath (Tròn, Mảnh, Đậm, Vuông, Thoi, Chấm đặc, Đôi); 0 = chữ theo font như cũ. `shape(_:style:)` trả `DateLabelShape` (cùng cấu trúc `DateLabelShapes.Shape`, tâm ở gốc, đơn vị cỡ chữ 100). Chỉ thay "%" và "°"; đơn vị khác (bpm, kcal, bước) giữ nguyên.
  - Chế độ số vector: `FaceRenderer.vecSuffix(..., sym:)` dùng ký hiệu thay path chữ. Chế độ số thường: `drawSuffixText(..., sym:)` gọi `UnitSymbols.drawFlat` (căn "%" trên đường cơ sở, "°" căn mép trên số). Cả hai đọc `FaceDesign.unitSymbol`.
  - `FaceSVGIcons`: 8 biểu tượng pin (`batteryTitles`/`battery`) và 6 nhiệt kế (`thermoTitles`/`thermo`), SVG viewBox 100, chỉ dùng tập con của `MiniSVG`. Màu: pin dùng accent + currentColor; nhiệt kế dùng currentColor (ống), accent (thuỷ ngân nóng), cold (thuỷ ngân lạnh). Một màu (mono) khi bật "Biểu tượng một màu".
  - `UnitIconThumbs`: hình thu nhỏ cho các bộ chọn.
- `FaceDesign`: `unitSymbol` (0...7), `batteryIconStyle` (0 = biểu tượng cũ, 1...8), `thermoStyle` (0 = tắt, 1...6); đã thêm vào `FaceDesignCodec.fields`.
- Pin: `drawDataIcon(..., batteryStyle:)`; kiểu > 0 vẽ SVG mới, bất kể công tắc `iconSVG`. Cần bật "Hiện biểu tượng" của Pin. Biểu tượng là ảnh tĩnh (chưa đổi theo mức pin, xem Phần 16).
- Nhiệt kế: `WeatherLayout.thermoS/thermoW/thermoX/thermoY`; nhiệt kế nằm giữa biểu tượng tình trạng và số nhiệt độ, là lớp `.single` tĩnh (cỡ 34 × `dataScale`); `numX` và `FaceLayoutGuard` đã cộng thêm `thermoW`. Dùng chung công tắc `weatherIconMono`.
- `FacePlate`: thêm 10 khung (7 Vé cắt khuyết, 8 Thẻ mũi tên, 9 Tab vòm, 10 Cắt chéo góc, 11 Ngoặc vuông, 12 Hình bình hành, 13 Nửa viên, 14 Kẻ đôi, 15 Khung pin, 16 Lá bo chéo). Chỉ dùng path M L Q Z và rect. Đã dựng hình bằng Chromium (bản Python của cùng công thức) để kiểm hình dạng ở cỡ 150×44 và 96×40.
- UI (`InfoSettingsView`): thẻ "Kiểu số chung cho tất cả" có lưới "Ký hiệu % và °"; khối Pin có lưới "Kiểu biểu tượng pin" (khi bật biểu tượng); khối Thời tiết có lưới "Nhiệt kế cạnh nhiệt độ"; hàm chung `indexGrid`. Bộ chọn "Khung nền SVG" tự có thêm 10 khung.
- Chuỗi mới đã thêm vào `AppLanguageData.swift` (đã kiểm không trùng khoá; từ điển Swift trùng khoá sẽ chết lúc chạy). Test: `WristMirrorTests/UnitIconsTests.swift`.
- Việc có thể làm tiếp: biểu tượng pin đổi theo mức (cần mã valueType), thêm kiểu nhiệt kế nghiêng/giọt nước, thêm khung nền cho cả mặt đồng hồ.

## Phần 37 – Phân tích 11 file HWT Kozmik/rolex, biểu tượng pin đổi theo mức (CHƯA biên dịch/chưa thử máy thật)
### Cách đọc đã dùng (Python, xem lại nếu cần)
- `com.huawei.watchface` là BIN thô. Phần tử (trường 1 của gốc) có: trường 5 = lớp cũ; trường 7 = biến thể màu `{1: số thứ tự, 2: lớp (lặp), ...}`; trường 8 = widget `{1: số thứ tự, 5: khung chạm, 6: lớp (lặp)}`; trường 9 = lớp hoạt hoạ. Lớp: `{1: idx, 2: loại, trường thân}`; thân: loại 0 chữ = trường 3, 1 ảnh = 4, 2 dãy = 5, 3 số = 6, 5 kim = 8, 6 thanh tiến độ = 9, 7 cung tiến độ = 10.
- Lớp số (loại 3): trường 1 = ảnh chữ số, 2 = ảnh dấu trừ (CHUỖI, không phải vị trí), 3 = vị trí, 4 = căn lề, 5 = dataType, 6 = hậu tố. Dãy (loại 2): 1 = ảnh, 2 = vị trí, 3 = valueType. Ảnh: bảng 8 byte (offset, độ dài) tính từ đầu phần ảnh; ảnh HwtRLE giải mã được (đã xem hình).
- 9/11 file đặt phần lớn lớp trong widget (trường 8) và biến thể (trường 7), chỉ Sporcu và rolex dùng trường 5 nhiều. Mặt các file mẫu rộng 466 (ảnh bìa 960 = tỉ lệ 2,06). Cả 11 file KHÔNG có `ability.xml` nên không cần chỉnh `abilityXML`.
### Kết luận 1: pin có đổi theo mức không
- Biểu tượng pin (hình cục pin) ở cả 11 file luôn là ảnh TĨNH (loại 1). Mức pin được thể hiện bằng 2 cách:
  1. KozmikBeta: dãy ảnh valueType 54, 11 ảnh (0...10), mỗi ảnh là thanh cam dài dần (rộng 104x10), đặt tại (158,396) trong widget 8 của phần tử 3, cùng số pin (dataType 9). Ảnh bìa pin 78% hiện đúng ảnh 8 (rộng 84 px) nên chỉ số = mức/10 (làm tròn hoặc lấy cận trên, chưa phân biệt được).
  2. Các file khác: thanh tiến độ (loại 6) hoặc cung tiến độ (loại 7) mã 163 nằm cùng widget với số pin. Đã ghép mã theo số liệu cùng widget: 163 pin, 161 bước chân, 157 nhịp tim, 158 calo, 159 giờ đứng, 154 giây. Đã thêm `HwtProgressCode` nhưng app CHƯA dựng loại 6/7 (cấu trúc: loại 6 thân `{1 ảnh, 2 khung x/y/w/h, 3 mã}`; loại 7 thân `{1 ảnh, 2 khung, 3 tâm, 4.. góc/bán kính, 8 mã}`, chưa giải hết trường).
### Kết luận 2: thời tiết
- Mã 53 có đủ 11 ảnh (0...10) ở MỌI dãy của cả 10 file có thời tiết (rolex không có). Thường 2 dãy: biểu tượng và tên chữ. Không file nào có mã thời tiết theo giờ hay theo nhiệt độ; nhiệt độ chỉ là số dataType 4 / 20 / 21. Nhãn: 0 Không dữ liệu, 1 Nắng, 2 Quang, 3 Ít mây, 4 Nhiều mây, 5 Mưa, 6 Giông, 7 Tuyết, 8 Bão cát (Beta ghi "mưa tuyết", Sporcu ghi "Rüzgârlı"), 9 Mù/bụi, 10 Sương mù. Sporcu đảo nhãn 3 và 4 (nhiều khả năng lỗi của tác giả). Giữ nguyên bảng hiện có của app.
### Kết luận 3: dataType và valueType mới
- dataType có trong 11 file: 0, 1, 2, 4, 9, 15, 18, 19, 20, 21, 26. Mới so với trước: 15 = giờ đứng, 18 = nhịp tim cao nhất, 19 = nhịp tim thấp nhất (ô "58 - 124": 19 bên trái), 26 = căng thẳng (số). Không có mã nào khác.
- valueType mới: 12 = giờ trong ngày (24 ảnh, nhãn 0...96% và thanh dài dần, ô "DAY 62%" lúc 15 giờ), 54 = mức pin (11 ảnh), 72 = thư chưa đọc (2 ảnh, nghĩa 0/1 suy từ hình), 117 = mức căng thẳng (5 ảnh), 116 = pha trăng (8 ảnh), 65...69 = năm dãy 10 chữ số xếp cong ở mép trái (BetaFinal, chữ cong "STEPS 8432", chưa rõ thứ tự hàng), 175 = 2 ảnh trong rolex (ảnh mặt 466x466 lặp lại, CHƯA rõ nghĩa). Đã thêm hằng vào `HwtValueType` / `HwtDataType`.
### Đã làm trong app
- `FaceDesign.batteryLevelStyle` (0 = tắt, 1...6 = Pin ngang, Pin 4 vạch, Pin dọc, Viên thuốc, Vòng tròn, Viền kép), có dòng trong `FaceDesignCodec.fields`.
- File mới `Store/FaceBatteryLevel.swift`: dựng SVG theo mức (viewBox 100), cung tròn bằng Bézier bậc ba, `index(forPercent:)` làm tròn mức/10, đỏ khi mức ≤ 2 (trừ khi một màu), `FaceRenderer.drawBatteryLevelIcon`.
- `FaceData`: xem trước vẽ ở mức mẫu (86% = ảnh 9); `dataLayers` dựng 11 ảnh và ghi lớp `.array(valueType: 54)` thay cho `.single` khi bật. `FaceInfo.infoValueTypes` thêm mã 54 (để vá file có sẵn không bị trùng mã).
- UI: lưới "Pin đổi theo mức" trong khối Pin; bật thì ẩn lưới "Kiểu biểu tượng pin". Hình nhỏ `UnitIconThumbs.batteryLevel`. Chuỗi mới đã thêm vào `AppLanguageData.swift` (kiểm không trùng khoá). Test: `UnitIconsTests` (mục Phần 37).
### Rủi ro / việc có thể làm tiếp
- (1) Chưa thử máy thật: firmware có nhận dãy mã 54 đặt ở trường 5 của phần tử (không trong widget) hay không. Có tiền lệ: Sporcu đặt dãy mã 53 ở trường 5. Lớp SỐ trong trường 5 vẫn chưa có tiền lệ (cả 11 file đặt số trong widget), rủi ro cũ còn nguyên.
- (2) Chưa biết firmware làm tròn hay lấy cận trên để chọn ảnh.
- (3) Có thể làm tiếp: lớp thanh/cung tiến độ mã 163 (pin) và 161, 157, 158, 159; ô giờ trong ngày (mã 12); mức căng thẳng (117); thư chưa đọc (72).

## Phần 38 – Chữ vector cho "Thứ trong tuần" và "Tên của bạn" (CHƯA biên dịch/chưa thử máy thật)
- Yêu cầu: tạo kiểu chữ như hai bảng logo mẫu (Hoàng Gia 3D, Kim Loại Bạc, Băng Giá, Lửa, Neon, Điện Sét, Thư Pháp, Carbon, HUD, LED, Retro 80s, Vũ Trụ, Kính, Kim Cương...) cho thứ hai…chủ nhật và ô nhập tên.
- `Store/FaceTextFX.swift` (mới): 24 kiểu (`FaceTextFX.specs`, chỉ số kiểu = vị trí + 1, 0 = chữ thường như cũ). Chữ lấy thành đường nét CoreText (CTLine/CTRun, font từng run) rồi tô gradient, viền, phát sáng (setShadow), khối 3D (tô lệch nhiều lớp), chấm LED (path.contains), hoa văn carbon/khe retro, trang trí vẽ code (vương miện, đường uốn, trái tim, khung HUD, tia sét, lấp lánh...). Font dùng tên PostScript có sẵn trên iOS (Baskerville, Georgia, SnellRoundhand, AvenirNext, Didot...), thiếu thì rơi về font hệ thống.
- `FaceDesign.weekdayFX`, `nameFX` (+ dòng trong `FaceDesignCodec.fields`). `FaceInfo`: layout cộng phần đệm (`FaceTextFX.padding`) vào w/h; kiểu `caps` dùng chữ HOA; tên thu nhỏ có tính phần đệm; `drawTextOrFX` dùng cho cả xem trước lẫn ảnh xuất (thứ: 7 ảnh như cũ, tên: 1 ảnh).
- UI: `InfoSettingsView` thêm lưới "Kiểu chữ vector" cho thứ và tên; ô chọn màu chỉ hiện khi kiểu dùng màu người dùng (`tint`); kiểu chữ đậm/mảnh/nghiêng của tên chỉ hiện khi nameFX = 0.
- Dịch: +26 cặp trong `AppLanguageData.swift` (870 khoá, 0 trùng). Test: 4 test mới trong `UnitIconsTests`.
- Rủi ro: ảnh phát sáng/viền dày có thể to hơn ảnh cũ (kích thước file .hwt); giới hạn cao ảnh = 466; chưa biết kết quả thật của font fallback; hiệu ứng nhiều lớp shadow có thể chậm khi xem trước. Có thể làm tiếp: dùng kiểu này cho số liệu khác, thêm kiểu mới.
