// ============================================================================
// Xem HANDOFF.md ở thư mục gốc để biết trạng thái port và các điểm cần soi khi build lần đầu.
// ============================================================================
import SwiftUI

@main
struct WristMirrorApp: App {
    @StateObject private var vm = WatchViewModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(vm)
                .preferredColorScheme(scheme(vm.ui.theme))
        }
    }

    private func scheme(_ m: ThemeMode) -> ColorScheme? {
        switch m {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
