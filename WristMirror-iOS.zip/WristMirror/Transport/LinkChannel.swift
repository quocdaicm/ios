import Foundation

/// Bên nhận sự kiện từ kênh liên kết. `epoch` dùng để bỏ qua callback của kết nối cũ.
protocol LinkChannelListener: AnyObject {
    func linkDidOpen(epoch: Int, name: String)
    func linkDidReceive(epoch: Int, bytes: [UInt8])
    func linkDidFail(epoch: Int, error: String)
}

/// Một kết nối thuộc về app này. Không đụng tới kết nối của app khác.
protocol LinkChannel: AnyObject {
    func connect()
    func send(frames: [[UInt8]], peerMtu: Int, intervalMs: Int) throws
    func close()
}
