import Foundation

// ============================================================================
// Port từ transport/WatchfaceManager.java (Phần 7).
// Thay / xoá / bật mặt đồng hồ trên hàng đợi giao thức tuần tự của WatchConnection.
//
// Khác biệt so với bản Java:
//  - Java so sánh danh sách bằng tham chiếu (`latest==faces`); Swift dùng `listToken` tăng dần.
//  - `summaryOwner`/`previousOwner` là token Int64 (0 = không có) thay vì tham chiếu đối tượng,
//    để chuỗi yêu cầu cũ không bị giữ mãi trong bộ nhớ.
//  - Không có SecurityException (BLUETOOTH_PERMISSION_REQUIRED): iOS không ném lỗi này ở đây.
//  - Hàm `error(...)` của Java đổi tên `reportError` (tránh trùng biến `error` của `catch`).
//  - Listener giữ yếu (weak). Mọi callback listener phát ra từ hàng đợi giao thức.
//  - Thời gian = mili-giây đơn điệu (`wmNowMs()`), thay SystemClock.elapsedRealtime().
// Mọi hàm "actor" (private) CHỈ chạy trên hàng đợi giao thức (connection.post/execute/delay).
// ============================================================================

func wmNowMs() -> Int64 { Int64(DispatchTime.now().uptimeNanoseconds / 1_000_000) }

/// Cờ nguyên tử (thay AtomicBoolean).
final class WMAtomicFlag {
    private let lock = NSLock()
    private var v = false
    func compareAndSet(_ expected: Bool, _ new: Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        if v != expected { return false }
        v = new
        return true
    }
    func set(_ x: Bool) { lock.lock(); v = x; lock.unlock() }
    var value: Bool { lock.lock(); defer { lock.unlock() }; return v }
}

/// Ô giá trị có khoá (thay `volatile`).
final class WMLocked<T> {
    private let lock = NSLock()
    private var v: T
    init(_ initial: T) { v = initial }
    var value: T {
        get { lock.lock(); defer { lock.unlock() }; return v }
        set { lock.lock(); v = newValue; lock.unlock() }
    }
}

protocol WatchfaceManagerListener: AnyObject {
    func onFaces(_ faces: [TlvView.Face], names: [String: String], fresh: Bool, epoch: Int, generation: Int64)
    func onParameters(width: Int?, height: Int?, capability: Int64?)
    func onOperation(kind: String, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool)
    func onPreparedDeletion(face: TlvView.Face, epoch: Int)
    func onError(_ error: String)
    func onRefreshing(_ refreshing: Bool, epoch: Int)
    func onReplacementOperation(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool)
    func onReplacementRequestFinished(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, failed: Bool)
    func onReplacementError(identity: WatchfaceManager.ReplacementIdentity, error: String)
    func onDeletionOperation(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool)
    func onDeletionRequestFinished(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, failed: Bool)
    func onDeletionError(identity: WatchfaceManager.DeletionIdentity, error: String)
    func onActivationOperation(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, active: Bool, failed: Bool)
    func onActivationRequestFinished(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, failed: Bool)
    func onActivationError(identity: WatchfaceManager.ActivationIdentity, error: String)
}

extension WatchfaceManagerListener {
    func onRefreshing(_ refreshing: Bool, epoch: Int) {}
    func onReplacementOperation(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool) {
        onOperation(kind: "replacement", stage: stage, detail: detail, progress: progress, active: active, failed: failed)
    }
    func onReplacementRequestFinished(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, failed: Bool) {}
    func onReplacementError(identity: WatchfaceManager.ReplacementIdentity, error: String) { onError(error) }
    func onDeletionOperation(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool) {
        onOperation(kind: "deletion", stage: stage, detail: detail, progress: progress, active: active, failed: failed)
    }
    func onDeletionRequestFinished(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, failed: Bool) {}
    func onDeletionError(identity: WatchfaceManager.DeletionIdentity, error: String) { onError(error) }
    func onActivationOperation(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, active: Bool, failed: Bool) {
        onOperation(kind: "activation", stage: stage, detail: detail, progress: nil, active: active, failed: failed)
    }
    func onActivationRequestFinished(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, failed: Bool) {}
    func onActivationError(identity: WatchfaceManager.ActivationIdentity, error: String) { onError(error) }
}

/// Gọi lại riêng cho một lần chuẩn bị xoá (Java: DeletionPreparationListener).
struct DeletionPreparationCallback {
    let onPrepared: (TlvView.Face, Int) -> Void
    let onFailure: (String) -> Void
}

final class WatchfaceManager {

    // MARK: Danh tính & yêu cầu

    // Ba loại thao tác dùng chung bộ đếm token; kết quả cũ không thể trùng token của thao tác khác.
    private static let tokenLock = NSLock()
    private static var tokenCounter: Int64 = Int64(DispatchTime.now().uptimeNanoseconds & 0x3fffffffffff)
    fileprivate static func nextToken() -> Int64 {
        tokenLock.lock(); defer { tokenLock.unlock() }
        tokenCounter += 1
        return tokenCounter
    }

    final class ReplacementIdentity {
        let token: Int64, epoch: Int
        let id: String, version: String
        fileprivate init(id: String, version: String, epoch: Int) {
            token = WatchfaceManager.nextToken(); self.id = id; self.version = version; self.epoch = epoch
        }
    }
    final class ReplacementRequest {
        let identity: ReplacementIdentity
        fileprivate let submitted = WMAtomicFlag(), interruptRequested = WMAtomicFlag()
        fileprivate let legacy: Bool
        fileprivate let previousOwner: Int64
        fileprivate init(id: String, version: String, epoch: Int, legacy: Bool, previousOwner: Int64) {
            identity = ReplacementIdentity(id: id, version: version, epoch: epoch)
            self.legacy = legacy; self.previousOwner = previousOwner
        }
    }
    final class DeletionIdentity {
        let token: Int64, epoch: Int
        let id: String, version: String
        fileprivate init(id: String, version: String, epoch: Int) {
            token = WatchfaceManager.nextToken(); self.id = id; self.version = version; self.epoch = epoch
        }
    }
    final class DeletionRequest {
        let identity: DeletionIdentity
        fileprivate let submitted = WMAtomicFlag()
        fileprivate let previousOwner: Int64
        fileprivate init(id: String, version: String, epoch: Int, previousOwner: Int64) {
            identity = DeletionIdentity(id: id, version: version, epoch: epoch); self.previousOwner = previousOwner
        }
    }
    final class ActivationIdentity {
        let token: Int64, epoch: Int
        let id: String, version: String
        fileprivate init(id: String, version: String, epoch: Int) {
            token = WatchfaceManager.nextToken(); self.id = id; self.version = version; self.epoch = epoch
        }
    }
    final class ActivationRequest {
        let identity: ActivationIdentity
        fileprivate let submitted = WMAtomicFlag()
        fileprivate let previousOwner: Int64
        fileprivate init(id: String, version: String, epoch: Int, previousOwner: Int64) {
            identity = ActivationIdentity(id: id, version: version, epoch: epoch); self.previousOwner = previousOwner
        }
    }

    private let summaryOwnerBox = WMLocked<Int64>(0)
    private var summaryOwner: Int64 { get { summaryOwnerBox.value } set { summaryOwnerBox.value = newValue } }
    private let shownReplacementBox = WMLocked<ReplacementRequest?>(nil)
    private let shownDeletionBox = WMLocked<DeletionRequest?>(nil)
    private let shownActivationBox = WMLocked<ActivationRequest?>(nil)
    private var shownReplacementRequest: ReplacementRequest? { get { shownReplacementBox.value } set { shownReplacementBox.value = newValue } }
    private var shownDeletionRequest: DeletionRequest? { get { shownDeletionBox.value } set { shownDeletionBox.value = newValue } }
    private var shownActivationRequest: ActivationRequest? { get { shownActivationBox.value } set { shownActivationBox.value = newValue } }

    func replacementIdentity() -> ReplacementIdentity? { shownReplacementRequest?.identity }
    func currentReplacementRequest() -> ReplacementRequest? { shownReplacementRequest }
    func newReplacementRequest(face: TlvView.Face?, version: String, epoch: Int) -> ReplacementRequest {
        ReplacementRequest(id: face?.id ?? "", version: version, epoch: epoch, legacy: false, previousOwner: summaryOwner)
    }
    func deletionIdentity() -> DeletionIdentity? { shownDeletionRequest?.identity }
    func currentDeletionRequest() -> DeletionRequest? { shownDeletionRequest }
    func newDeletionRequest(face: TlvView.Face?, epoch: Int) -> DeletionRequest {
        DeletionRequest(id: face?.id ?? "", version: face?.version ?? "", epoch: epoch, previousOwner: summaryOwner)
    }
    func activationIdentity() -> ActivationIdentity? { shownActivationRequest?.identity }
    func currentActivationRequest() -> ActivationRequest? { shownActivationRequest }
    func newActivationRequest(face: TlvView.Face?, epoch: Int) -> ActivationRequest {
        ActivationRequest(id: face?.id ?? "", version: face?.version ?? "", epoch: epoch, previousOwner: summaryOwner)
    }

    // MARK: Hằng số

    // Danh sách dùng cho thay thế có hiệu lực 5 phút; xác nhận xoá cuối cùng dùng cửa sổ riêng 30 giây.
    private static let replacementListAge: Int64 = 300_000, deleteListAge: Int64 = 30_000
    private static let postTimeout: Int64 = 90_000, totalTimeout: Int64 = 900_000, deleteOperationTimeout: Int64 = 15_000
    private static let replacementOperationTimeout: Int64 = 30_000
    private static let activationOperationTimeout: Int64 = 30_000, activationListTimeout: Int64 = 30_000
    private static let activationTotalTimeout: Int64 = 60_000
    private static let postQueryBudget = 40

    /// Chỉ giới hạn lần chờ biên nhận chấp nhận ban đầu.
    static func replacementResponseTimedOut(phase: ReplacementState.Phase, elapsed: Int64) -> Bool {
        phase == .waitOperation && elapsed >= replacementOperationTimeout
    }

    // MARK: Trạng thái

    private let connection: WatchConnection
    private let log: SafeLog
    private let listenerLock = NSLock()
    private weak var _listener: WatchfaceManagerListener?
    private var listener: WatchfaceManagerListener? { listenerLock.lock(); defer { listenerLock.unlock() }; return _listener }
    func setListener(_ l: WatchfaceManagerListener?) { listenerLock.lock(); _listener = l; listenerLock.unlock() }

    private let busyBox = WMLocked<Bool>(false)
    private var busyFlag: Bool { get { busyBox.value } set { busyBox.value = newValue } }
    private let latestBox = WMLocked<[TlvView.Face]>([])
    private var latest: [TlvView.Face] { get { latestBox.value } set { latestBox.value = newValue } }
    private var listToken = 0                       // thay so sánh tham chiếu `latest==faces`
    private var names: [String: String] = [:]
    private var listAt: Int64 = 0, listEpoch = 0, serial: Int64 = 0
    private var parametersRequestedEpoch = -1
    private var query: Query?
    private var active: Op?, last: Op?
    private var history: [Op] = []
    private var activationHistory: [Activate] = []
    private var namesRun: NamesRun?
    private var preDelete: PreDelete?
    private var precheckFailure = false
    private let reconnectEpochBox = WMLocked<Int>(-1)
    private var reconnectEpoch: Int { get { reconnectEpochBox.value } set { reconnectEpochBox.value = newValue } }
    func reconnectRequired(_ expectedEpoch: Int) -> Bool { reconnectEpoch == expectedEpoch }

    private struct ListObservation { let at: Int64, epoch: Int, usable: Bool }
    private let observationBox = WMLocked<ListObservation>(ListObservation(at: 0, epoch: 0, usable: false))

    init(connection: WatchConnection, log: SafeLog) {
        self.connection = connection
        self.log = log
    }

    func busy() -> Bool { busyFlag || preDelete != nil }
    func faces() -> [TlvView.Face] { latest }

    /// Giao diện đọc quan sát đã công bố (bất biến), không chạm trạng thái của actor.
    func replacementListFresh(expectedEpoch: Int) -> Bool {
        let o = observationBox.value
        let age = wmNowMs() - o.at
        return o.usable && o.at != 0 && o.epoch == expectedEpoch && connection.epoch == expectedEpoch
            && connection.ready && age >= 0 && age <= WatchfaceManager.replacementListAge
    }
    func deletionListFresh(expectedEpoch: Int) -> Bool {
        let o = observationBox.value
        let age = wmNowMs() - o.at
        return o.usable && o.at != 0 && o.epoch == expectedEpoch && connection.epoch == expectedEpoch
            && connection.ready && age >= 0 && age <= WatchfaceManager.deleteListAge
    }

    // MARK: Kiểu thao tác

    private class Op {
        let id: String, version: String, epoch: Int
        let started = wmNowMs()
        var finished: Int64 = 0
        var listQueries = 0
        init(_ i: String, _ v: String, _ e: Int) { id = i; version = v; epoch = e }
        func matches(_ i: String?, _ v: String?) -> Bool { id == i && version == v }
    }
    private final class Replace: Op {
        let state: ReplacementState, source: HwtSource.Snapshot, request: ReplacementRequest
        var file: FileTransfer?
        var postAt: Int64 = 0
        var fileResultSeen = false
        init(face: TlvView.Face, version: String, source: HwtSource.Snapshot, epoch: Int, request: ReplacementRequest) throws {
            state = try ReplacementState(id: face.id, baseline: face.version, version: version)
            self.source = source; self.request = request
            super.init(face.id, version, epoch)
        }
    }
    private final class Delete: Op {
        let state: DeletionState, otherIds: Set<String>, request: DeletionRequest
        init(face f: TlvView.Face, all: [TlvView.Face], epoch: Int, request: DeletionRequest) throws {
            state = try DeletionState(id: f.id, version: f.version, current: FacePolicy.isCurrent(f))
            self.request = request
            var ids = Set<String>()
            for x in all where f.id != x.id { ids.insert(x.id) }
            otherIds = ids
            super.init(f.id, f.version, epoch)
        }
    }
    private final class Activate: Op {
        let state: ActivationState, request: ActivationRequest
        var acceptedAt: Int64 = -1
        init(face f: TlvView.Face, epoch: Int, request: ActivationRequest) throws {
            state = try ActivationState(id: f.id, version: f.version)
            self.request = request
            super.init(f.id, f.version, epoch)
        }
    }
    private final class NamesRun {
        let epoch: Int, sourceToken: Int, state: NameQueryState, language: Int
        init(epoch: Int, faces: [TlvView.Face], token: Int, known: Set<String>, language: Int) throws {
            self.epoch = epoch; sourceToken = token; state = try NameQueryState(faces: faces, knownKeys: known); self.language = language
        }
    }
    private final class Query {
        let serial: Int64, epoch: Int, op: Op?, generation: Int, preparation: PreDelete?
        init(serial: Int64, epoch: Int, op: Op?, preparation: PreDelete?) {
            self.serial = serial; self.epoch = epoch; self.op = op; self.preparation = preparation
            if let r = op as? Replace { generation = r.state.postGeneration }
            else if let d = op as? Delete { generation = d.state.signalGeneration }
            else if let a = op as? Activate { generation = a.state.signalGeneration }
            else { generation = 0 }
        }
    }
    private final class PreDelete {
        let id: String, version: String, epoch: Int, requested: TlvView.Face?, callback: DeletionPreparationCallback?
        var completed = false
        init(_ i: String, _ v: String, _ e: Int, _ requested: TlvView.Face?, _ callback: DeletionPreparationCallback?) {
            id = i; version = v; epoch = e; self.requested = requested; self.callback = callback
        }
    }

    private func preparationFailed(_ p: PreDelete?, _ code: String, _ publishError: Bool) {
        guard let p = p, !p.completed else { return }
        if preDelete === p { preDelete = nil }
        p.completed = true
        p.callback?.onFailure(code)
        if publishError { reportError(code) }
    }

    private func preparationReady(_ p: PreDelete, _ face: TlvView.Face) {
        if p.completed { return }
        p.completed = true
        if let cb = p.callback { cb.onPrepared(face, p.epoch) }
        else { listener?.onPreparedDeletion(face: face, epoch: p.epoch) }
    }

    // MARK: Vòng đời kết nối

    func authenticated(epoch: Int) {
        connection.execute { [self] in
            if epoch != connection.epoch { return }
            if let a = active {
                if a.epoch == epoch { return }
                retire(a, "CONNECTION_REPLACED")
            }
            preparationFailed(preDelete, "DELETE_CONNECTION_CHANGED", false)
            cancelNames()
            summaryOwner = 0
            shownReplacementRequest = nil; shownDeletionRequest = nil; shownActivationRequest = nil
            reconnectEpoch = -1
            latest = []; listToken += 1
            names.removeAll()
            listAt = 0; listEpoch = epoch
            query = nil; preDelete = nil; busyFlag = false
            refreshActor()
        }
    }

    func closed(closedEpoch: Int, reason: String) {
        connection.execute { [self] in
            if let n = namesRun, n.epoch == closedEpoch { cancelNames() }
            if let q = query, q.epoch == closedEpoch { query = nil }
            if let p = preDelete, p.epoch == closedEpoch { preparationFailed(p, "DELETE_CONNECTION_CHANGED", false) }
            if listEpoch == closedEpoch { listAt = 0 }
            if let a = active, a.epoch == closedEpoch { retire(a, "CONNECTION_CLOSED_" + reason) }
            publishFaces()
        }
    }

    private func retire(_ old: Op, _ reason: String) {
        if let r = old as? Replace {
            r.state.fail(reason, nil)
            r.file?.close()
        } else if let d = old as? Delete { d.state.fail(reason, nil) }
        else if let a = old as? Activate { a.state.fail(reason, nil) }
        old.finished = wmNowMs()
        if active === old { active = nil; busyFlag = false }
        if last === old { show(old) }
        log.record("OLD_OPERATION_RETIRED", "epoch_bound=true reason=\(reason) no_new_connection_failure=true")
    }

    func refresh() {
        connection.post { [self] in
            if busy() { reportError("WATCHFACE_OPERATION_BUSY") }
            else if reconnectRequired(connection.epoch) { reportError("RECONNECT_AFTER_UNCERTAIN_FILE_RESULT") }
            else { refreshActor() }
        }
    }

    private func refreshActor() {
        do {
            if !connection.ready { throw WMFault("CONNECT_AND_AUTHENTICATE_FIRST") }
            if let l = listener {
                l.onError("")
                if precheckFailure {
                    shownReplacementRequest = nil; shownDeletionRequest = nil; shownActivationRequest = nil
                    l.onOperation(kind: "", stage: "", detail: "", progress: nil, active: false, failed: false)
                }
            }
            if query != nil {
                log.record("REFRESH_MERGED", "pending_query=true rows_retained=true")
                return
            }
            // Làm mất hiệu lực tư cách thao tác nhưng giữ danh sách/tên đã hiển thị cho tới khi có danh sách mới đầy đủ.
            precheckFailure = false
            listAt = 0
            // Thông số màn hình/khả năng chỉ đọc một lần mỗi kết nối.
            if parametersRequestedEpoch != connection.epoch {
                parametersRequestedEpoch = connection.epoch
                let body = try Wire.params()
                try connection.sendControl(0x27, 1, body)
            }
            try requestList(nil)
        } catch {
            publishFaces()
            reportError(WMCore.code(error))
        }
    }

    private func publishFaces() {
        let own = connection.epoch
        let age = wmNowMs() - listAt
        let fresh = listAt != 0 && listEpoch == own && age >= 0 && age <= WatchfaceManager.replacementListAge
            && query == nil && connection.ready
        observationBox.value = ListObservation(at: listAt, epoch: listEpoch, usable: fresh)
        if let l = listener {
            l.onRefreshing(query != nil && query?.epoch == own, epoch: own)
            let same = listEpoch == own
            l.onFaces(same ? latest : [], names: same ? names : [:], fresh: fresh, epoch: own, generation: serial)
        }
    }

    private func expireObservation(token: Int, at: Int64, epoch: Int) {
        connection.delay(Int(WatchfaceManager.replacementListAge) + 1) { [self] in
            if listToken == token && listAt == at && listEpoch == epoch && connection.epoch == epoch {
                log.record("LIST_OBSERVATION_EXPIRED", "replacement_limit_ms=\(WatchfaceManager.replacementListAge) rows_retained=true no_operation_sent=true")
                publishFaces()
            }
        }
    }

    private func reportError(_ code: String) {
        log.record("WATCHFACE_ERROR", "code=\(code)")
        listener?.onError(code)
    }

    private func replacementRequestFinished(_ request: ReplacementRequest, _ stage: String, _ code: String) {
        let failed = stage != "CANCELLED"
        log.record(failed ? "REPLACE_PRECHECK_FAILED" : "REPLACE_QUEUED_CANCELLED",
                   "code=\(code) command_sent=false upload_sent=false reconnect_required=false")
        // Kết nối đã đổi, hoặc thao tác khác đang giữ actor ⇒ không ghi đè trạng thái/lỗi của nó.
        let owns = !busy() && request.identity.epoch == connection.epoch && summaryOwner == request.previousOwner
        if owns {
            summaryOwner = request.identity.token
            shownReplacementRequest = request; shownDeletionRequest = nil; shownActivationRequest = nil
            precheckFailure = failed
            listener?.onReplacementOperation(identity: request.identity, stage: stage, detail: code, progress: nil, active: false, failed: failed)
            listener?.onReplacementError(identity: request.identity, error: failed ? code : "")
        } else {
            listener?.onReplacementRequestFinished(identity: request.identity, stage: stage, detail: code, failed: failed)
        }
        if failed && request.legacy && !owns { reportError(code) }
    }

    private func deletionRequestFinished(_ request: DeletionRequest, _ code: String) {
        log.record("DELETE_PRECHECK_FAILED", "code=\(code) command_sent=false upload_sent=false reconnect_required=false")
        let owns = !busy() && request.identity.epoch == connection.epoch && summaryOwner == request.previousOwner
        if owns {
            summaryOwner = request.identity.token
            shownDeletionRequest = request; shownReplacementRequest = nil; shownActivationRequest = nil
            precheckFailure = true
            listener?.onDeletionOperation(identity: request.identity, stage: "PRECHECK_FAILED", detail: code, progress: nil, active: false, failed: true)
            listener?.onDeletionError(identity: request.identity, error: code)
        } else {
            listener?.onDeletionRequestFinished(identity: request.identity, stage: "PRECHECK_FAILED", detail: code, failed: true)
        }
    }

    private func activationRequestFinished(_ request: ActivationRequest, _ code: String) {
        log.record("ACTIVATE_PRECHECK_FAILED", "code=\(code) command_sent=false file_budget=0")
        let owns = !busy() && request.identity.epoch == connection.epoch && summaryOwner == request.previousOwner
        if owns {
            summaryOwner = request.identity.token
            shownActivationRequest = request; shownReplacementRequest = nil; shownDeletionRequest = nil
            precheckFailure = true
            listener?.onActivationOperation(identity: request.identity, stage: "PRECHECK_FAILED", detail: code, active: false, failed: true)
            listener?.onActivationError(identity: request.identity, error: code)
        } else {
            listener?.onActivationRequestFinished(identity: request.identity, stage: "PRECHECK_FAILED", detail: code, failed: true)
        }
    }

    // MARK: Kiểm tra trước khi thao tác

    private func validate(_ face: TlvView.Face, epoch: Int, maxAge: Int64, strictObservation: Bool, activation: Bool = false) throws {
        if !connection.ready || connection.epoch != epoch { throw WMFault("SELECTED_CONNECTION_CHANGED") }
        if reconnectRequired(epoch) { throw WMFault("RECONNECT_AFTER_UNCERTAIN_FILE_RESULT") }
        let allowed = activation ? FacePolicy.canActivate(face) : FacePolicy.eligible(face)
        if !allowed { throw WMFault(activation ? "SELECT_EXISTING_ACTIVATABLE_FACE" : "SELECT_EXISTING_ORDINARY_FACE") }
        let age = wmNowMs() - listAt
        if listAt == 0 || listEpoch != epoch || age < 0 || age > maxAge || query != nil { throw WMFault("FRESH_DEVICE_LIST_REQUIRED") }
        var count = 0
        for x in latest where face.id == x.id {
            count += 1
            // Bit "đang dùng" của mặt thường (4↔5) không đổi danh tính mục tiêu của đường thay thế cũ.
            let xOk = activation ? FacePolicy.canActivate(x) : FacePolicy.eligible(x)
            if face.version != x.version || !xOk
                || (strictObservation && (face.type != x.type || face.expandType != x.expandType)) {
                throw WMFault("SELECTED_FACE_CHANGED")
            }
        }
        if count != 1 { throw WMFault("SELECTED_ID_NOT_UNIQUE") }
    }

    private func fileLength(_ url: URL) -> Int64? {
        guard let a = try? FileManager.default.attributesOfItem(atPath: url.path) else { return nil }
        if (a[.type] as? FileAttributeType) != .typeRegular { return nil }
        return (a[.size] as? NSNumber)?.int64Value
    }

    // MARK: Thay thế

    /// Đường cũ (không có cổng huỷ do giao diện cấp).
    func beginReplacement(face: TlvView.Face?, version: String, source: HwtSource.Snapshot?, epoch: Int) {
        let request = ReplacementRequest(id: face?.id ?? "", version: version, epoch: epoch, legacy: true, previousOwner: summaryOwner)
        beginReplacement(face: face, version: version, source: source, epoch: epoch, request: request)
    }

    func beginReplacement(face: TlvView.Face?, version: String, source: HwtSource.Snapshot?, epoch: Int, request: ReplacementRequest) {
        if !request.submitted.compareAndSet(false, true) { return }
        connection.post { [self] in
            if request.interruptRequested.value { replacementRequestFinished(request, "CANCELLED", "USER_CANCELLED_BEFORE_SEND"); return }
            if busy() { replacementRequestFinished(request, "PRECHECK_FAILED", "WATCHFACE_OPERATION_BUSY"); return }
            if reconnectRequired(connection.epoch) { replacementRequestFinished(request, "PRECHECK_FAILED", "RECONNECT_AFTER_UNCERTAIN_FILE_RESULT"); return }
            log.record("REPLACE_CONFIRM_ACCEPTED",
                       "id=\(face.map { WMCore.clean($0.id) } ?? "absent") baseline=\(face.map { WMCore.clean($0.version) } ?? "absent") version=\(WMCore.clean(version)) list_age_ms=\(wmNowMs() - listAt) replacement_limit_ms=\(WatchfaceManager.replacementListAge)")
            do {
                guard let face = face, request.identity.epoch == epoch, request.identity.id == face.id, request.identity.version == version else {
                    throw WMFault("SELECTED_CONNECTION_CHANGED")
                }
                try validate(face, epoch: epoch, maxAge: WatchfaceManager.replacementListAge, strictObservation: false)
                let expected = try VersionPolicy.next(id: face.id, baseline: face.version, listed: latest)
                if version != expected { throw WMFault("VERSION_CHANGED") }
                // Đã kiểm tra/đóng băng trước khi xác nhận; không tính lại toàn bộ băm trên hàng đợi giao thức.
                guard let source = source, source.mode == .bin, let len = fileLength(source.file), len == Int64(source.size) else {
                    throw WMFault("PAYLOAD_SNAPSHOT_UNAVAILABLE")
                }
                if request.interruptRequested.value { replacementRequestFinished(request, "CANCELLED", "USER_CANCELLED_BEFORE_SEND"); return }
                let r = try Replace(face: face, version: version, source: source, epoch: epoch, request: request)
                start(r)
                log.record("REPLACE_SEND_OPERATION", "id=\(r.id) version=\(r.version) op=1 source_bytes=\(source.size) source_sha256=\(source.hash) pre_operation_budget=1 upload_budget=1")
                let body = try Wire.operation(id: r.id, version: r.version)
                try connection.sendControl(0x27, 3, body)
                show(r); timer(r)
            } catch {
                let code = WMCore.code(error)
                if let r = active as? Replace, r.request === request { failActive(code, nil) }
                else { replacementRequestFinished(request, "PRECHECK_FAILED", code) }
            }
        }
    }

    /// Cờ huỷ đặt ngay; dừng thật chỉ thực hiện trên actor sau khi kiểm lại đối tượng/thế hệ/trạng thái.
    func cancelReplacement(_ request: ReplacementRequest?) {
        guard let request = request else { return }
        request.interruptRequested.set(true)
        connection.post { [self] in
            guard let r = active as? Replace else { return }
            let identity = request.identity
            if r.request !== request || r.request.identity !== identity || r.epoch != identity.epoch
                || connection.epoch != identity.epoch || r.state.terminal { return }
            r.state.cancel()
            finish(r)
        }
    }

    // MARK: Xoá

    func prepareDeletion(id: String, version: String, epoch: Int) {
        prepareDeletion(PreDelete(id, version, epoch, nil, nil))
    }

    func prepareDeletion(face: TlvView.Face?, epoch: Int, callback: DeletionPreparationCallback) {
        prepareDeletion(PreDelete(face?.id ?? "", face?.version ?? "", epoch, face, callback))
    }

    private func prepareDeletion(_ p: PreDelete) {
        connection.post { [self] in
            if busy() || query != nil { preparationFailed(p, "WAIT_FOR_CURRENT_OPERATION_OR_QUERY", p.callback == nil); return }
            do {
                if !connection.ready || connection.epoch != p.epoch { throw WMFault("SELECTED_CONNECTION_CHANGED") }
                if reconnectRequired(p.epoch) { throw WMFault("RECONNECT_AFTER_UNCERTAIN_FILE_RESULT") }
                if p.callback != nil, let req = p.requested {
                    try validate(req, epoch: p.epoch, maxAge: WatchfaceManager.replacementListAge, strictObservation: true)
                }
                preDelete = p
                listAt = 0
                try requestList(nil)
            } catch {
                let code = WMCore.code(error)
                if let fq = query, fq.preparation === p {
                    query = nil; listAt = 0
                    if preDelete === p { preDelete = nil }
                    publishFaces()
                }
                preparationFailed(p, code, p.callback == nil)
            }
        }
    }

    func beginDeletion(face: TlvView.Face?, epoch: Int) {
        beginDeletion(face: face, epoch: epoch, request: newDeletionRequest(face: face, epoch: epoch))
    }

    func beginDeletion(face: TlvView.Face?, epoch: Int, request: DeletionRequest) {
        if !request.submitted.compareAndSet(false, true) { return }
        connection.post { [self] in
            if busy() { deletionRequestFinished(request, "WATCHFACE_OPERATION_BUSY"); return }
            if reconnectRequired(connection.epoch) { deletionRequestFinished(request, "RECONNECT_AFTER_UNCERTAIN_FILE_RESULT"); return }
            do {
                let identity = request.identity
                guard let face = face, identity.epoch == epoch, identity.id == face.id, identity.version == face.version else {
                    throw WMFault("SELECTED_CONNECTION_CHANGED")
                }
                try validate(face, epoch: epoch, maxAge: WatchfaceManager.deleteListAge, strictObservation: true)
                for old in history where old is Delete && old.epoch == epoch && old.matches(face.id, face.version)
                    && old.finished != 0 && wmNowMs() - old.finished <= WatchfaceManager.postTimeout {
                    throw WMFault("RECENT_SAME_DELETE_WAIT_OR_RECONNECT")
                }
                let d = try Delete(face: face, all: latest, epoch: epoch, request: request)
                start(d)
                let body = try Wire.deletion(id: d.id, version: d.version)
                try connection.sendControl(0x27, 3, body)
                show(d); timer(d)
            } catch {
                let code = WMCore.code(error)
                if let d = active as? Delete, d.request === request, d.epoch == request.identity.epoch { failActive(code, nil) }
                else { deletionRequestFinished(request, code) }
            }
        }
    }

    // MARK: Bật

    /// Bật mặt đồng hồ đã có: đúng ID + phiên bản gốc, một lần op1, không gửi file, không có phiên bản ứng viên.
    func beginActivation(face: TlvView.Face?, epoch: Int, request: ActivationRequest) {
        if !request.submitted.compareAndSet(false, true) { return }
        connection.post { [self] in
            if busy() { activationRequestFinished(request, "WATCHFACE_OPERATION_BUSY"); return }
            if reconnectRequired(connection.epoch) { activationRequestFinished(request, "RECONNECT_AFTER_UNCERTAIN_FILE_RESULT"); return }
            do {
                let identity = request.identity
                guard let face = face, identity.epoch == epoch, identity.id == face.id, identity.version == face.version else {
                    throw WMFault("SELECTED_CONNECTION_CHANGED")
                }
                try validate(face, epoch: epoch, maxAge: WatchfaceManager.replacementListAge, strictObservation: true, activation: true)
                let a = try Activate(face: face, epoch: epoch, request: request)
                start(a)
                log.record("ACTIVATE_SEND_OPERATION", "id=\(a.id) version=\(a.version) op=1 original_version=true file_budget=0")
                let body = try Wire.operation(id: a.id, version: a.version)
                try connection.sendControl(0x27, 3, body)
                show(a); timer(a)
            } catch {
                let code = WMCore.code(error)
                if let a = active as? Activate, a.request === request { failActive(code, nil) }
                else { activationRequestFinished(request, code) }
            }
        }
    }

    private func owner(_ op: Op) -> Int64 {
        if let r = op as? Replace { return r.request.identity.token }
        if let d = op as? Delete { return d.request.identity.token }
        if let a = op as? Activate { return a.request.identity.token }
        return 0
    }

    private func start(_ op: Op) {
        precheckFailure = false
        active = op; last = op; busyFlag = true
        summaryOwner = owner(op)
        shownReplacementRequest = (op as? Replace)?.request
        shownDeletionRequest = (op as? Delete)?.request
        shownActivationRequest = (op as? Activate)?.request
        cancelNames()
        if let l = listener {
            if let r = op as? Replace { l.onReplacementError(identity: r.request.identity, error: "") }
            else if let d = op as? Delete { l.onDeletionError(identity: d.request.identity, error: "") }
            else if let a = op as? Activate { l.onActivationError(identity: a.request.identity, error: "") }
        }
        if let a = op as? Activate {
            activationHistory.insert(a, at: 0)
            while activationHistory.count > 4 { activationHistory.removeLast() }
        } else {
            history.insert(op, at: 0)
            while history.count > 4 { history.removeLast() }
        }
        let event = op is Delete ? "DELETE_START" : op is Activate ? "ACTIVATE_START" : "REPLACE_START"
        log.record(event, "id=\(op.id) version=\(op.version) file_budget=\(op is Replace ? 1 : 0) auth08_09_not_fabricated=true")
    }

    // MARK: Truy vấn danh sách

    private func requestList(_ op: Op?) throws {
        if let op = op, op.epoch != connection.epoch { throw WMFault("OPERATION_EPOCH_CHANGED") }
        if let q = query {
            log.record("LIST_QUERY_MERGED", "pending_generation=\(q.generation)")
            return
        }
        if let op = op {
            op.listQueries += 1
            if op.listQueries > WatchfaceManager.postQueryBudget {
                log.record("LIST_QUERY_BUDGET_EXHAUSTED", "id=\(op.id) version=\(op.version) query_budget=\(WatchfaceManager.postQueryBudget) no_more_query=true")
                if op is Delete { throw WMFault("DELETE_LIST_QUERY_BUDGET_EXHAUSTED") }
                if op is Activate { throw WMFault("ACTIVATION_LIST_QUERY_BUDGET_EXHAUSTED") }
                return   // chờ hạn chót hậu kiểm/tổng sẵn có, không tự suy ra kết quả
            }
        }
        serial += 1
        let q = Query(serial: serial, epoch: connection.epoch, op: op, preparation: op == nil ? preDelete : nil)
        query = q
        publishFaces()
        do {
            let body = try Wire.list(serverMode: 2)
            try connection.sendControl(0x27, 2, body)
        } catch {
            if query === q { query = nil }
            listAt = 0
            publishFaces()
            throw error
        }
        log.record("LIST_QUERY", "serial=\(q.serial) generation=\(q.generation) local_not_wire_nonce=true")
        connection.delay(15000) { [self] in
            if query === q && q.epoch == connection.epoch {
                query = nil
                listAt = 0
                if let o = op, active === o { failActive("LIST_QUERY_TIMEOUT", nil) }
                else {
                    preparationFailed(q.preparation, "LIST_QUERY_TIMEOUT_RECONNECT", false)
                    reportError("LIST_QUERY_TIMEOUT_RECONNECT")
                    connection.protocolFailure("LIST_QUERY_TIMEOUT")
                }
                publishFaces()
            }
        }
    }

    // MARK: Nhận gói

    private func opt(_ v: Int64?) -> String { v.map { String($0) } ?? "nil" }

    /// Gọi từ `WatchConnectionListener.onPacket` (đã trên hàng đợi giao thức).
    func packet(epoch: Int, service: Int, command: Int, body: [UInt8], encrypted: Bool) {
        if epoch != connection.epoch || !connection.ready { return }
        let op = active
        if let o = op, o.epoch != epoch { return }
        var owned = false
        var observedFields: [TlvView.Part]? = nil
        var fileStage: String? = nil
        do {
            if service == 0x28 {
                guard let r = op as? Replace, command >= 2, command <= 8, let file = r.file else { return }
                if command == 6 {
                    log.record("RAW_FILE_DATA_OBSERVED", "bytes=\(body.count) no_ack_or_completion_inference=true")
                    return
                }
                owned = true
                let stageLabel = file.stateLabel
                fileStage = stageLabel
                if command == 2 { log.record("FILE_INFO_RESPONSE", "stage=\(stageLabel) bytes=\(body.count) \(file.infoReplyObservation(body))") }
                let outgoing = try file.onPacket(command: command, body: body, transactionsCrypted: true)
                for out in outgoing { try connection.sendFile(out.command, out.body, encrypt: out.encrypt) }
                if command == 3 {
                    let hashFields = try TlvView.decode(body)
                    let mode = try Wire.number(hashFields, 2)
                    log.record("FILE_HASH_REQUEST", "file_id=\(file.fileId) check_mode=\(opt(mode)) missing_not_defaulted_to_three=true")
                }
                if command == 7 && file.resultObserved {
                    r.fileResultSeen = true
                    let raw = file.peerResultRaw
                    let failure = file.completionFailure
                    log.record("FILE_RESULT_OBSERVED", "file_id=\(file.fileId) raw=\(raw.map(String.init) ?? "nil") completion_failure=\(failure ?? "nil") ack_dispatched_first=true transfer_only=true")
                    if let raw = raw, raw == 0 { r.state.nativeResult(0) }
                    else if let f = failure { throw WMFault(f) }
                    else if let raw = raw { r.state.nativeResult(raw) }
                }
                show(r); finish(r)
                return
            }
            if service != 0x27 || !(command == 1 || command == 2 || command == 3 || command == 5 || command == 6) { return }
            if command == 2 { owned = query != nil && query?.epoch == epoch && query?.op === op && op != nil }
            let fields = try TlvView.decode(body)
            observedFields = fields
            if command == 1 {
                let w = try Wire.number(fields, 2), h = try Wire.number(fields, 3), cap = try Wire.number(fields, 0x11)
                listener?.onParameters(width: w.map { Int(truncatingIfNeeded: $0) }, height: h.map { Int(truncatingIfNeeded: $0) }, capability: cap)
                return
            }
            if command == 2 { try handleList(fields, epoch); return }
            if command == 6 {
                let response = try WireNames.parseResponse(fields)
                handleNames(response, epoch, body.count)
                return
            }
            let idOpt = try Wire.text(fields, 1), versionOpt = try Wire.text(fields, 2)
            owned = op != nil && op!.matches(idOpt, versionOpt)
            let err = try Wire.number(fields, 0x7f)
            let value = try Wire.number(fields, command == 3 ? 4 : 3)
            guard owned, let cur = op, let id = idOpt, let version = versionOpt else {
                try late(idOpt, versionOpt, command, err, value, fields, epoch)
                return
            }
            if command == 5, let v = value, v > Int64(Int32.max) { throw WMFault("REPORT_VALUE_OVERFLOW") }
            if command == 5 && (err == nil || err == 100000) {
                let t1 = try WMCore.tlv(1, Array(id.utf8))
                let t2 = try WMCore.tlv(2, Array(version.utf8))
                let t3 = try WMCore.tlv(0x7f, WatchfaceManager.num(100000, 4))
                try connection.sendControl(0x27, 5, t1 + t2 + t3)
            }
            if let r = cur as? Replace {
                // Luồng thay thế không coi trường 03 của 27/03 là bắt buộc phải được lặp lại.
                let action: ReplacementState.Action
                if command == 3 { action = r.state.operation(error: err, need: value) }
                else { action = r.state.report(type: value.map { Int($0) }, error: err) }
                log.record(command == 3 ? "OPERATION_RESPONSE" : "WATCH_REPORT",
                           "id=\(id) version=\(version) error=\(opt(err)) value=\(opt(value)) \(r.state.summary())")
                try actReplace(r, action)
                show(r); finish(r)
            } else if let d = cur as? Delete {
                let action: DeletionState.Action
                if command == 3 {
                    let echo = try Wire.number(fields, 3)
                    if let e = echo, e != 2 { return }
                    action = d.state.operation(error: err, need: value, echo: echo)
                } else {
                    action = d.state.report(type: value.map { Int($0) }, error: err)
                }
                if action == .query { try requestList(d) }
                show(d); finish(d)
            } else if let a = cur as? Activate {
                let action: ActivationState.Action
                if command == 3 {
                    let echo = try Wire.number(fields, 3)
                    action = a.state.operation(error: err, need: value, echo: echo)
                } else {
                    action = a.state.report(type: value.map { Int($0) }, error: err)
                }
                log.record(command == 3 ? "ACTIVATE_RESPONSE" : "ACTIVATE_REPORT",
                           "id=\(id) version=\(version) error=\(opt(err)) value=\(opt(value)) \(a.state.summary())")
                if action == .query {
                    if a.acceptedAt < 0 { a.acceptedAt = wmNowMs() }
                    try requestList(a)
                }
                show(a); finish(a)
            }
        } catch {
            let code = WMCore.code(error)
            if service == 0x28 {
                log.record("FILE_TRANSFER_ERROR", "command=\(command) stage=\(fileStage ?? "nil") code=\(code) bytes=\(body.count) owned=\(owned) no_retry=true")
            }
            if service == 0x27 && command == 6 {
                // Tên chỉ để hiển thị: lỗi định dạng/thiết bị không xoá danh sách, không kết thúc thao tác, không giả làm lỗi thay thế.
                log.record("NAMES_UNAVAILABLE", "code=\(code) bytes=\(body.count) tags=\(observedFields.map { TlvView.tags($0) } ?? "unparsed")")
                if let run = namesRun, run.epoch == epoch, run.sourceToken == listToken {
                    run.state.failCurrent()
                    advanceNames(run)
                }
                return
            }
            if owned, let o = op, active === o { failActive(code, nil) }
            else {
                reportError(code)
                if service == 0x27 && command == 2, let q = query, q.epoch == epoch {
                    query = nil
                    preparationFailed(q.preparation, code, false)
                    listAt = 0
                    publishFaces()
                }
            }
        }
    }

    private func handleList(_ fields: [TlvView.Part], _ epoch: Int) throws {
        guard let q = query, q.epoch == epoch else { return }
        let faces = try Wire.faces(fields)
        let err = try Wire.number(fields, 0x7f)
        if let e = err, e != 0, e != 100000 { throw WMFault("DEVICE_LIST_ERROR") }
        cancelNames()
        query = nil
        latest = faces; listToken += 1
        listAt = wmNowMs(); listEpoch = epoch
        var listedKeys = Set<String>()
        for f in faces { listedKeys.insert(f.id + "_" + f.version) }
        names = names.filter { listedKeys.contains($0.key) }
        publishFaces()
        expireObservation(token: listToken, at: listAt, epoch: epoch)
        log.record("RESOURCE_LIST", "entries=\(faces.count) serial=\(q.serial) generation=\(q.generation)")
        for f in faces {
            log.record("LIST_ENTRY", "id=\(f.id) version=\(f.version) type=\(opt(f.type)) expand=\(opt(f.expandType))")
        }
        if let p = q.preparation, preDelete === p {
            preDelete = nil
            do {
                if p.epoch != epoch { throw WMFault("DELETE_CONNECTION_CHANGED") }
                var requested: TlvView.Face? = nil
                var count = 0
                for f in faces where p.id == f.id { requested = f; count += 1 }
                guard count == 1, let req = requested, p.version == req.version, FacePolicy.eligible(req) else {
                    throw WMFault("DELETE_PREPARATION_CHANGED")
                }
                if let pr = p.requested, pr.type != req.type || pr.expandType != req.expandType {
                    throw WMFault("DELETE_PREPARATION_CHANGED")
                }
                preparationReady(p, req)
            } catch {
                preparationFailed(p, WMCore.code(error), false)
                throw error
            }
        }
        if let op = q.op, op === active {
            if let r = op as? Replace {
                r.state.list(faces, queryGeneration: q.generation, ownQuery: true)
                show(r); finish(r)
                if active === r && r.state.postObserved {
                    connection.delay(q.generation < r.state.postGeneration ? 1 : 1500) { [self] in
                        if active === r {
                            do { try requestList(r) } catch { failActive(WMCore.code(error), nil) }
                        }
                    }
                }
            } else if let d = op as? Delete {
                var ids = Set<String>()
                for f in faces { ids.insert(f.id) }
                if d.otherIds.isSubset(of: ids) {
                    d.state.list(faces, generation: q.generation, ownQuery: true, querySerial: q.serial)
                } else {
                    d.state.markNonTargetListIncomplete()
                }
                show(d); finish(d)
                if active === d {
                    let wait = q.generation < d.state.signalGeneration ? 1 : (d.state.consecutiveAbsences == 1 ? 500 : 1500)
                    connection.delay(wait) { [self] in
                        if active === d {
                            do { try requestList(d) } catch { failActive(WMCore.code(error), nil) }
                        }
                    }
                }
            } else if let a = op as? Activate {
                a.state.list(faces, generation: q.generation, ownQuery: true, serial: q.serial)
                show(a); finish(a)
                if active === a {
                    connection.delay(1500) { [self] in
                        if active === a {
                            do { try requestList(a) } catch { failActive(WMCore.code(error), nil) }
                        }
                    }
                }
            }
        }
        if active == nil { requestNames() }
    }

    // MARK: Tên mặt đồng hồ (27/06)

    private func cancelNames() {
        let run = namesRun
        namesRun = nil
        run?.state.cancel()
    }

    private func requestNames() {
        do {
            if latest.isEmpty || !connection.ready || !connection.capabilities.hasCommand(0x27, 6) { return }
            if namesRun == nil || namesRun!.epoch != connection.epoch || namesRun!.sourceToken != listToken {
                cancelNames()
                let zh = Locale.preferredLanguages.first?.hasPrefix("zh") == true
                namesRun = try NamesRun(epoch: connection.epoch, faces: latest, token: listToken,
                                        known: Set(names.keys), language: zh ? 2 : 1)
            }
            advanceNames(namesRun)
        } catch {
            log.record("NAMES_UNAVAILABLE", "code=\(WMCore.code(error))")
        }
    }

    private func advanceNames(_ run: NamesRun?) {
        guard let run = run, namesRun === run, run.epoch == connection.epoch, run.sourceToken == listToken,
              connection.ready, !busy(), query == nil else { return }
        guard let batch = run.state.next(now: wmNowMs()) else { return }
        do {
            let body = try WireNames.request(faces: batch.faces, language: run.language)
            try connection.sendControl(0x27, 6, body)
            log.record("NAMES_BATCH_QUERY", "serial=\(batch.serial) ids=\(batch.ids.count) list_entries=\(latest.count) local_not_wire_nonce=true")
            connection.delay(Int(NameQueryState.replyTimeoutMs)) { [self] in
                if namesRun === run && run.epoch == connection.epoch && run.sourceToken == listToken
                    && run.state.current?.serial == batch.serial && run.state.expire(now: wmNowMs()) {
                    log.record("NAMES_BATCH_TIMEOUT", "serial=\(batch.serial) ids=\(batch.ids.count) names_retained=true")
                    advanceNames(run)
                }
            }
        } catch {
            log.record("NAMES_UNAVAILABLE", "code=\(WMCore.code(error)) serial=\(batch.serial)")
            run.state.failCurrent()
            advanceNames(run)
        }
    }

    private func handleNames(_ response: WireNames.Response, _ epoch: Int, _ bytes: Int) {
        guard let run = namesRun, run.epoch == epoch, run.sourceToken == listToken else {
            log.record("NAMES_REPLY_IGNORED", "bytes=\(bytes) current_owner=false")
            return
        }
        let found = run.state.accept(response)
        var added = 0
        for face in latest {
            if let name = found[face.id] {
                let key = face.id + "_" + face.version
                if names[key] == nil { names[key] = WMCore.clean(name); added += 1 }
            }
        }
        log.record("NAMES_BATCH_RESPONSE", "received_ids=\(response.ids.count) matched_names=\(added) malformed_names_skipped=\(response.malformedNameCount) bytes=\(bytes) names_only=true")
        publishFaces()
        advanceNames(run)
    }

    // MARK: Điều phối thay thế / hẹn giờ / kết thúc

    private func actReplace(_ r: Replace, _ action: ReplacementState.Action) throws {
        if active !== r || r.epoch != connection.epoch { return }
        switch action {
        case .upload:
            if r.file != nil { throw WMFault("UPLOAD_BUDGET_EXHAUSTED") }
            r.file = try FileTransfer(id: r.id, installedProtocolVersion: r.version, frozen: r.source)
            log.record("UPLOAD_START", "id=\(r.id) version=\(r.version) bytes=\(r.source.size) sha256=\(r.source.hash) file_type=1 upload_budget=1")
            if let f = r.file {
                let meta = try f.metadataBody()
                try connection.sendFile(2, meta, encrypt: true)
            }
        case .activate:
            r.postAt = wmNowMs()
            log.record("POST_UPLOAD_ACTIVATION", "id=\(r.id) version=\(r.version) report_two_drives_post=true file_result_is_separate=true post_timeout_ms=\(WatchfaceManager.postTimeout)")
            let body = try Wire.operation(id: r.id, version: r.version)
            try connection.sendControl(0x27, 3, body)
        case .query:
            try requestList(r)
        case .none:
            break
        }
    }

    private func kind(_ op: Op) -> String { op is Replace ? "replacement" : op is Delete ? "deletion" : "activation" }

    private func phaseName(_ op: Op) -> String {
        if let r = op as? Replace { return r.state.phase.rawValue }
        if let d = op as? Delete { return d.state.phase.rawValue }
        if let a = op as? Activate { return a.state.phase.rawValue }
        return ""
    }

    private func isTerminal(_ op: Op) -> Bool {
        if let r = op as? Replace { return r.state.terminal }
        if let d = op as? Delete { return d.state.terminal }
        if let a = op as? Activate { return a.state.terminal }
        return true
    }

    private func timer(_ op: Op) {
        connection.delay(1000) { [self] in
            if active !== op || op.epoch != connection.epoch { return }
            let now = wmNowMs(), age = now - op.started
            var initialExpired = false
            if let r = op as? Replace { initialExpired = WatchfaceManager.replacementResponseTimedOut(phase: r.state.phase, elapsed: age) }
            var activationExpired = false
            if let a = op as? Activate {
                activationExpired = age >= WatchfaceManager.activationTotalTimeout
                    || (a.state.phase == .waitOperation && age >= WatchfaceManager.activationOperationTimeout)
                    || (a.acceptedAt >= 0 && now - a.acceptedAt >= WatchfaceManager.activationListTimeout)
            }
            var timed = initialExpired || activationExpired
            if !(op is Activate) && age > (op is Delete ? WatchfaceManager.postTimeout : WatchfaceManager.totalTimeout) { timed = true }
            if let r = op as? Replace, r.postAt != 0, now - r.postAt > WatchfaceManager.postTimeout { timed = true }
            if let d = op as? Delete, d.state.phase == .waitDevice, age > WatchfaceManager.deleteOperationTimeout { timed = true }
            if timed {
                log.record("WATCHFACE_TIMEOUT", "kind=\(kind(op)) phase=\(phaseName(op)) age_ms=\(age) initial_acceptance_timeout=\(initialExpired) initial_limit_ms=\(WatchfaceManager.replacementOperationTimeout)")
                if let d = op as? Delete { d.state.timeout() }
                else if let r = op as? Replace { r.state.timeout() }
                else if let a = op as? Activate { a.state.timeout() }
                finish(op)
                return
            }
            timer(op)
        }
    }

    private func failActive(_ reason: String, _ err: Int64?) {
        guard let op = active else { return }
        if let r = op as? Replace { r.state.fail(reason, err) }
        else if let d = op as? Delete { d.state.fail(reason, err) }
        else if let a = op as? Activate { a.state.fail(reason, err) }
        finish(op)
    }

    private func finish(_ op: Op) {
        if active !== op || !isTerminal(op) { return }
        let resultSettled = (op as? Replace)?.fileResultSeen ?? false
        show(op)
        op.finished = wmNowMs()
        active = nil; busyFlag = false; query = nil
        (op as? Replace)?.file?.close()
        var ok = false
        if let r = op as? Replace { ok = r.state.phase == .listed || r.state.phase == .noTransfer }
        else if let d = op as? Delete { ok = d.state.phase == .deleted }
        else if let a = op as? Activate { ok = a.state.phase == .activated }
        let event = op is Replace ? "REPLACE_SUMMARY" : op is Delete ? "DELETE_SUMMARY" : "ACTIVATE_SUMMARY"
        let extra = (op as? Replace).map { " " + $0.state.summary() } ?? ""
        log.record(event, "id=\(op.id) version=\(op.version) reliable_protocol_end=\(ok) visual_application_unverified=true\(extra)")
        if !ok && op.epoch == connection.epoch {
            listAt = 0
            reconnectEpoch = op.epoch
            if !resultSettled { connection.protocolFailure("WATCHFACE_OPERATION_UNCERTAIN_RECONNECT") }
            else { log.record("FILE_RESULT_RECONNECT_REQUIRED", "ack_queue_preserved=true no_more_operation_until_new_authenticated_epoch=true") }
        }
        publishFaces()
        if ok { requestNames() }
    }

    private func show(_ op: Op) {
        guard let l = listener, summaryOwner == owner(op) else { return }
        if let r = op as? Replace {
            shownReplacementRequest = r.request; shownDeletionRequest = nil; shownActivationRequest = nil
            var progress: Int? = nil
            if let f = r.file, f.totalSize > 0 {
                progress = Int(min(Int64(100), f.bytesSentOrPrepared * 100 / Int64(f.totalSize)))
            }
            let p = r.state.phase
            l.onReplacementOperation(identity: r.request.identity, stage: p.rawValue, detail: r.state.summary(), progress: progress,
                                     active: !r.state.terminal, failed: p == .failed || p == .timedOut || p == .cancelled)
        } else if let d = op as? Delete {
            shownReplacementRequest = nil; shownActivationRequest = nil; shownDeletionRequest = d.request
            let p = d.state.phase
            l.onDeletionOperation(identity: d.request.identity, stage: p.rawValue, detail: d.state.summary(), progress: nil,
                                  active: !d.state.terminal, failed: p == .failed || p == .timedOut)
        } else if let a = op as? Activate {
            shownReplacementRequest = nil; shownDeletionRequest = nil; shownActivationRequest = a.request
            let p = a.state.phase
            l.onActivationOperation(identity: a.request.identity, stage: p.rawValue, detail: a.state.summary(),
                                    active: !a.state.terminal, failed: p == .failed || p == .timedOut)
        }
    }

    /// Lỗi muộn của thao tác vừa kết thúc: chỉ đánh dấu thất bại, không thử lại, không ACK, không dừng.
    private func late(_ id: String?, _ version: String?, _ command: Int, _ err: Int64?, _ value: Int64?,
                      _ fields: [TlvView.Part], _ epoch: Int) throws {
        let badError = err != nil && err != 0 && (command != 5 || err != 100000)
        let reportThree = command == 5 && value == 3
        let invalidActivationReceipt = command == 3 && (err == nil || value == nil || value != 0)
        if !badError && !reportThree && !invalidActivationReceipt { return }
        var recent: [Op] = history
        recent.append(contentsOf: activationHistory as [Op])
        let lastOp = last
        recent.sort { a, b in
            if a === b { return false }
            if a === lastOp { return true }
            if b === lastOp { return false }
            return a.finished > b.finished
        }
        for old in recent where old !== active && old.epoch == epoch && old.matches(id, version)
            && old.finished != 0 && wmNowMs() - old.finished < WatchfaceManager.postTimeout {
            if let d = old as? Delete {
                if !badError { continue }
                if command == 5 && !reportThree { return }
                if command == 3 {
                    let echo = try Wire.number(fields, 3)
                    if let e = echo, e != 2 { continue }
                }
                d.state.fail("LATE_DEVICE_ERROR", err)
            } else if let r = old as? Replace {
                if !badError && !reportThree { continue }
                r.state.fail(reportThree ? "LATE_WATCH_REPORT_FAILURE" : "LATE_DEVICE_ERROR", err)
            } else if let a = old as? Activate {
                if command == 3 {
                    let echo = try Wire.number(fields, 3)
                    if let e = echo, e != 1 { continue }
                    _ = a.state.operation(error: err, need: value, echo: echo)
                } else {
                    _ = a.state.report(type: value.map { Int($0) }, error: err)
                }
            }
            log.record("LATE_ERROR", "id=\(id ?? "nil") version=\(version ?? "nil") report_three=\(reportThree) no_retry_no_ack_no_stop=true")
            if active == nil && last === old && summaryOwner == owner(old) {
                show(old)
                if !(old is Replace) { connection.protocolFailure("LATE_OPERATION_ERROR_RECONNECT") }
            }
            return
        }
    }

    private static func num(_ n: Int64, _ len: Int) -> [UInt8] {
        var v = UInt64(bitPattern: n)
        var b = [UInt8](repeating: 0, count: len)
        var i = len - 1
        while i >= 0 { b[i] = UInt8(truncatingIfNeeded: v); v >>= 8; i -= 1 }
        return b
    }
}
