import Foundation
import CoreBluetooth

/// Kênh BLE của Huawei (service FE86, ghi FE01, nhận FE02) bằng CoreBluetooth.
/// Mọi thao tác chạy trên một hàng đợi tuần tự; hàng đợi ghi có giới hạn.
final class GattChannel: NSObject, LinkChannel {
    private static let serviceUUID = CBUUID(string: "FE86")
    private static let writeUUID = CBUUID(string: "FE01")
    private static let notifyUUID = CBUUID(string: "FE02")

    private let identifier: UUID
    private let epoch: Int
    private weak var listener: LinkChannelListener?
    private let work = DispatchQueue(label: "wristmirror.gatt")

    private let lock = NSLock()
    private var _closed = false
    private var closed: Bool { lock.lock(); defer { lock.unlock() }; return _closed }

    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var writeChar: CBCharacteristic?
    private var scanning = false
    private var ready = false
    private var busy = false
    private var noResponse = false
    private var payload = 20
    private var delayMs = 5
    private var queuedBytes = 0
    private var writeSerial = 0
    private var queue: [[UInt8]] = []
    private var head = 0

    init(identifier: UUID, epoch: Int, listener: LinkChannelListener) {
        self.identifier = identifier
        self.epoch = epoch
        self.listener = listener
        super.init()
    }

    // MARK: LinkChannel

    func connect() {
        work.async { [self] in
            if closed { return }
            central = CBCentralManager(delegate: self, queue: work)
            work.asyncAfter(deadline: .now() + 20) { [self] in
                if !ready && !closed { fail("GATT_SETUP_TIMEOUT") }
            }
        }
    }

    func send(frames: [[UInt8]], peerMtu: Int, intervalMs: Int) throws {
        if closed { throw WMFault("TRANSPORT_CLOSED") }
        if frames.count > 256 { throw WMFault("FRAME_QUEUE_LIMIT") }
        var total = 0
        for f in frames {
            total += f.count
            if total > 2 * 1024 * 1024 { throw WMFault("FRAME_QUEUE_LIMIT") }
        }
        let owned = frames
        let sum = total
        work.async { [self] in
            if closed { return }
            if queuedBytes + sum > 4 * 1024 * 1024 { fail("GATT_QUEUE_LIMIT"); return }
            let mtu = min(payload, peerMtu >= 16 ? peerMtu : payload)
            delayMs = max(5, min(intervalMs, 1000))
            for b in owned {
                var p = 0
                while p < b.count {
                    queue.append(Array(b[p..<min(b.count, p + mtu)]))
                    p += mtu
                }
            }
            queuedBytes += sum
            pump()
        }
    }

    func close() {
        lock.lock()
        if _closed { lock.unlock(); return }
        _closed = true
        lock.unlock()
        work.async { [self] in
            queue.removeAll(); head = 0; queuedBytes = 0
            ready = false; busy = false
            if scanning { central?.stopScan(); scanning = false }
            if let p = peripheral { central?.cancelPeripheralConnection(p) }
            peripheral = nil; writeChar = nil
        }
    }

    // MARK: Nội bộ

    private func fail(_ code: String) {
        if closed { return }
        listener?.linkDidFail(epoch: epoch, error: code)
        close()
    }

    private func attach(_ p: CBPeripheral) {
        peripheral = p
        p.delegate = self
        central?.connect(p, options: nil)
    }

    private func pump() {
        guard !closed, ready, !busy, head < queue.count,
              let p = peripheral, let w = writeChar else { return }
        if noResponse && !p.canSendWriteWithoutResponse { return } // đợi peripheralIsReady
        let chunk = queue[head]
        busy = true
        writeSerial += 1
        let token = writeSerial
        p.writeValue(Data(chunk), for: w, type: noResponse ? .withoutResponse : .withResponse)
        if noResponse {
            work.asyncAfter(deadline: .now() + .milliseconds(delayMs)) { [self] in
                if !closed && busy && writeSerial == token { completeWrite() }
            }
        } else {
            work.asyncAfter(deadline: .now() + 5) { [self] in
                if !closed && busy && writeSerial == token { fail("GATT_WRITE_TIMEOUT") }
            }
        }
    }

    private func completeWrite() {
        if head < queue.count {
            queuedBytes -= queue[head].count
            head += 1
            if head > 1024 { queue.removeFirst(head); head = 0 }
        }
        busy = false
        work.asyncAfter(deadline: .now() + .milliseconds(delayMs)) { [self] in pump() }
    }
}

// MARK: - CBCentralManagerDelegate

extension GattChannel: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ c: CBCentralManager) {
        if closed { return }
        switch c.state {
        case .poweredOn:
            if peripheral != nil || scanning { return }
            if let p = c.retrievePeripherals(withIdentifiers: [identifier]).first {
                attach(p)
            } else {
                scanning = true
                c.scanForPeripherals(withServices: nil, options: nil)
            }
        case .unauthorized: fail("BLUETOOTH_UNAUTHORIZED")
        case .poweredOff: fail("BLUETOOTH_OFF")
        case .unsupported: fail("BLUETOOTH_UNSUPPORTED")
        default: break
        }
    }

    func centralManager(_ c: CBCentralManager, didDiscover p: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        if closed || p.identifier != identifier { return }
        c.stopScan(); scanning = false
        attach(p)
    }

    func centralManager(_ c: CBCentralManager, didConnect p: CBPeripheral) {
        if closed || p !== peripheral { return }
        p.discoverServices([GattChannel.serviceUUID])
    }

    func centralManager(_ c: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) {
        if p === peripheral { fail("GATT_CONNECT_FAILED") }
    }

    func centralManager(_ c: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) {
        if p === peripheral { fail("GATT_CONNECTION_CLOSED") }
    }
}

// MARK: - CBPeripheralDelegate

extension GattChannel: CBPeripheralDelegate {
    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        if closed || p !== peripheral { return }
        if error != nil { fail("GATT_SERVICE_ERROR"); return }
        guard let s = p.services?.first(where: { $0.uuid == GattChannel.serviceUUID }) else {
            fail("HUAWEI_BLE_SERVICE_MISSING"); return
        }
        p.discoverCharacteristics([GattChannel.writeUUID, GattChannel.notifyUUID], for: s)
    }

    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor s: CBService, error: Error?) {
        if closed || p !== peripheral { return }
        if error != nil { fail("GATT_SERVICE_ERROR"); return }
        let chars = s.characteristics ?? []
        guard let w = chars.first(where: { $0.uuid == GattChannel.writeUUID }),
              let n = chars.first(where: { $0.uuid == GattChannel.notifyUUID }) else {
            fail("HUAWEI_BLE_CHARACTERISTIC_MISSING"); return
        }
        noResponse = !w.properties.contains(.write)
        if noResponse && !w.properties.contains(.writeWithoutResponse) {
            fail("GATT_WRITE_PROPERTY_MISSING"); return
        }
        if !n.properties.contains(.notify) && !n.properties.contains(.indicate) {
            fail("GATT_CCCD_MISSING"); return
        }
        writeChar = w
        p.setNotifyValue(true, for: n)
    }

    func peripheral(_ p: CBPeripheral, didUpdateNotificationStateFor c: CBCharacteristic, error: Error?) {
        if closed || p !== peripheral || c.uuid != GattChannel.notifyUUID { return }
        if error != nil { fail("GATT_CCCD_REJECTED"); return }
        if c.isNotifying && !ready {
            ready = true
            let m = p.maximumWriteValueLength(for: noResponse ? .withoutResponse : .withResponse)
            payload = max(20, min(244, m))
            listener?.linkDidOpen(epoch: epoch, name: p.name ?? "Huawei")
            pump()
        }
    }

    func peripheral(_ p: CBPeripheral, didUpdateValueFor c: CBCharacteristic, error: Error?) {
        if closed || p !== peripheral || c.uuid != GattChannel.notifyUUID { return }
        if let v = c.value { listener?.linkDidReceive(epoch: epoch, bytes: [UInt8](v)) }
    }

    func peripheral(_ p: CBPeripheral, didWriteValueFor c: CBCharacteristic, error: Error?) {
        if closed || p !== peripheral || c.uuid != GattChannel.writeUUID { return }
        if error != nil { fail("GATT_WRITE_REJECTED"); return }
        if noResponse || !busy { return }
        completeWrite()
    }

    func peripheralIsReady(toSendWriteWithoutResponse p: CBPeripheral) {
        pump()
    }
}
