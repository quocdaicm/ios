import SwiftUI
import UniformTypeIdentifiers

struct FacesView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var importing = false

    private static let hwtType = UTType(filenameExtension: "hwt") ?? .data

    var body: some View {
        NavigationStack {
            List {
                sourceSection
                Section("Mặt đồng hồ trên đồng hồ") {
                    if !vm.ui.connected {
                        Text("Hãy kết nối đồng hồ ở tab Thiết bị.").foregroundStyle(.secondary)
                    } else if !vm.ui.listReady {
                        HStack { ProgressView(); Text("Đang đọc danh sách…") }
                    }
                    if vm.ui.quarantine {
                        Text("Cần kết nối lại trước khi thao tác tiếp.").foregroundStyle(.orange)
                    }
                    ForEach(vm.ui.faces) { face in
                        FaceRow(face: face, importing: $importing)
                    }
                }
            }
            .navigationTitle("Mặt đồng hồ")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { vm.refreshFaces() } label: { Image(systemName: "arrow.clockwise") }
                        .disabled(!vm.ui.connected || vm.ui.listRefreshing || vm.ui.operation.active)
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [FacesView.hwtType, .data], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let u = urls.first { vm.importHwt(u) } else { vm.cancelHwtPick() }
                case .failure:
                    vm.cancelHwtPick()
                }
            }
            .onChange(of: importing) { now in
                // Đóng bộ chọn mà không chọn gì => thu hồi token chọn file.
                if !now && vm.ui.pickingHwt { DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { if vm.ui.pickingHwt { vm.cancelHwtPick() } } }
            }
        }
    }

    private var sourceSection: some View {
        Section("File HWT") {
            if let s = vm.ui.source {
                if let p = s.previewPath, let img = UIImage(contentsOfFile: p) {
                    Image(uiImage: img).resizable().scaledToFit().frame(maxHeight: 160).frame(maxWidth: .infinity)
                }
                Text(s.title).font(.headline)
                Text(s.fileName).font(.footnote).foregroundStyle(.secondary)
                Text("Nội dung truyền: \(s.payloadBytes) B · XML \(s.xmlVersion)").font(.footnote)
                Text("SHA-256 \(String(s.sha256.prefix(16)))…").font(.caption2).foregroundStyle(.secondary)
            } else {
                Text("Chưa chọn file").foregroundStyle(.secondary)
            }
            if vm.ui.operation.kind == "source" && vm.ui.operation.active {
                HStack { ProgressView(); Text(vm.ui.operation.detail) }
            }
            Button("Chọn file .hwt…") {
                if vm.prepareHwtPick() { importing = true }
            }
            .disabled(vm.ui.operation.active || vm.ui.connecting)
        }
    }
}

struct FaceRow: View {
    @EnvironmentObject var vm: WatchViewModel
    let face: FaceItem
    @Binding var importing: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(face.title).font(.headline)
                if face.current { Text("Đang dùng").font(.caption2).padding(4).background(Color.green.opacity(0.2)).clipShape(Capsule()) }
            }
            Text("\(face.kind) · ID \(face.id) · v\(face.version)").font(.footnote).foregroundStyle(.secondary)
            HStack {
                Button("Thay thế") { vm.requestReplacement(face: face, epoch: vm.ui.connectionEpoch) }
                    .disabled(!face.selectable || vm.ui.source == nil)
                Button("Bật") { vm.requestActivation(face: face, epoch: vm.ui.connectionEpoch) }
                    .disabled(!face.activatable || face.current)
                Button("Xoá", role: .destructive) { vm.requestDeletion(face: face, epoch: vm.ui.connectionEpoch) }
                    .disabled(!face.selectable)
            }
            .buttonStyle(.bordered)
            .font(.footnote)
            .disabled(!vm.ui.connected || !vm.ui.listReady || vm.ui.listRefreshing || vm.ui.quarantine || vm.ui.operation.active)
        }
        .padding(.vertical, 4)
    }
}
