import SwiftUI
import WebKit

/// Port từ account/HuaweiIdWebPolicy.kt: chỉ đọc đúng cookie `uid` từ vmall.com; không đọc DOM.
enum HuaweiIdWebPolicy {
    static let startURL = URL(string: "https://www.vmall.com/")!

    static func validId(_ v: String?) -> Bool {
        guard let v = v, (1...19).contains(v.count), v.allSatisfy({ $0.isASCII && $0.isNumber }) else { return false }
        return v.contains { $0 != "0" }
    }

    private static func host(_ url: URL?) -> String? {
        guard let url = url, url.absoluteString.count <= 8192, url.scheme?.lowercased() == "https",
              url.user == nil, url.password == nil, url.port == nil || url.port == 443 else { return nil }
        return url.host?.lowercased()
    }
    private static func within(_ h: String, _ d: String) -> Bool { h == d || h.hasSuffix("." + d) }
    static func allowsNavigation(_ url: URL?) -> Bool {
        guard let h = host(url) else { return false }
        return within(h, "vmall.com") || within(h, "huawei.com")
    }
    static func allowsEmbedded(_ url: URL?) -> Bool { host(url) != nil }
    static func displayHost(_ url: URL?) -> String {
        if let h = host(url), allowsNavigation(url) { return h }
        return "Huawei Mall"
    }

    /// Chỉ nhận khi mọi cookie `uid` của vmall.com đều hợp lệ và trùng nhau; mơ hồ/xung đột => nil.
    static func id(from cookies: [HTTPCookie]) -> String? {
        var found: String?
        for c in cookies where c.name == "uid" {
            let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
            guard within(d.lowercased(), "vmall.com") else { continue }
            guard c.value.count <= 64, validId(c.value) else { return nil }
            if let f = found, f != c.value { return nil }
            found = c.value
        }
        return found
    }
}

struct HuaweiIdWebSheet: View {
    let onAcquired: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var host = "Huawei Mall"

    var body: some View {
        NavigationStack {
            HuaweiIdWebView(onAcquired: onAcquired, onHost: { host = $0 })
                .navigationTitle(host)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } } }
        }
    }
}

/// Phiên duyệt web không lưu (nonPersistent): đóng sheet là xoá sạch cookie/session.
struct HuaweiIdWebView: UIViewRepresentable {
    let onAcquired: (String) -> Void
    let onHost: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .nonPersistent()
        cfg.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = context.coordinator
        context.coordinator.web = web
        web.load(URLRequest(url: HuaweiIdWebPolicy.startURL))
        context.coordinator.startPolling()
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        coordinator.stop()
        uiView.stopLoading()
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let parent: HuaweiIdWebView
        weak var web: WKWebView?
        private var timer: Timer?
        private var done = false
        init(_ p: HuaweiIdWebView) { parent = p }

        func startPolling() {
            timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in self?.check() }
        }
        func stop() { timer?.invalidate(); timer = nil }

        private func check() {
            guard !done, let store = web?.configuration.websiteDataStore.httpCookieStore else { return }
            store.getAllCookies { [weak self] cookies in
                guard let self = self, !self.done, let id = HuaweiIdWebPolicy.id(from: cookies) else { return }
                self.done = true
                self.stop()
                DispatchQueue.main.async { self.parent.onAcquired(id) }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            let main = action.targetFrame?.isMainFrame ?? true
            let ok = main ? HuaweiIdWebPolicy.allowsNavigation(action.request.url) : HuaweiIdWebPolicy.allowsEmbedded(action.request.url)
            decisionHandler(ok ? .allow : .cancel)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.onHost(HuaweiIdWebPolicy.displayHost(webView.url))
            check()
        }
    }
}
