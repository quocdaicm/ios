import SwiftUI

struct DeviceView: View {
    @EnvironmentObject var vm: WatchViewModel
    @State private var showWeb = false

    private var selected: NearbyWatch? {
        guard let a = vm.ui.selectedDeviceAddress else { return nil }
        return vm.ui.devices.first { $0.address == a }
            ?? vm.ui.savedDevices.first { $0.address == a }?.nearby()
    }

    var body: some View {
        NavigationStack {
            List {
                statusSection
                accountSection
                scanSection
                savedSection
            }
            .navigationTitle("WristMirror")
            .sheet(isPresented: $showWeb) {
                HuaweiIdWebSheet { id in
                    vm.setHuaweiId(id)
                    showWeb = false
                }
            }
        }
    }

    private var statusSection: some View {
        Section("Kết nối") {
            VStack(alignment: .leading, spacing: 6) {
                Text(vm.ui.phase).font(.headline)
                Text(vm.ui.detail).font(.footnote).foregroundStyle(.secondary)
                if vm.ui.connecting { ProgressView() }
            }
            if vm.ui.connected {
                row("Đồng hồ", vm.ui.watchName)
                if let m = vm.ui.deviceModel { row("Model", m) }
                row("Firmware", vm.ui.firmware)
                row("Serial", vm.ui.serialNumber)
                if let b = vm.ui.batteryPercent { row("Pin", "\(b)%") }
                if let f = vm.ui.freeMemoryBytes { row("Bộ nhớ trống", ByteCountFormatter.string(fromByteCount: f, countStyle: .file)) }
                if let w = vm.ui.width, let h = vm.ui.height { row("Màn hình", "\(w)×\(h)") }
            }
            if vm.ui.connected || vm.ui.connecting {
                Button("Ngắt kết nối", role: .destructive) { vm.disconnect() }
            } else if let d = selected {
                Button("Kết nối \(d.name)") { vm.connect(d, huaweiId: vm.ui.huaweiIdInput) }
                    .disabled(vm.ui.removing || (!vm.ui.accountConfigured && vm.ui.huaweiIdInput.trimmingCharacters(in: .whitespaces).isEmpty))
            } else {
                Text("Hãy quét và chọn một đồng hồ.").foregroundStyle(.secondary)
            }
        }
    }

    private var accountSection: some View {
        Section {
            TextField("Huawei ID (số)", text: Binding(get: { vm.ui.huaweiIdInput }, set: { vm.setHuaweiId($0) }))
                .keyboardType(.numberPad)
                .disabled(vm.ui.selectedDeviceAddress == nil || vm.ui.connecting || vm.ui.operation.active)
            HStack {
                Button("Lưu") { vm.saveHuaweiId() }
                    .disabled(!vm.ui.huaweiIdDirty)
                Spacer()
                Button("Lấy từ tài khoản…") { showWeb = true }
                    .disabled(vm.ui.selectedDeviceAddress == nil || vm.ui.connecting || vm.ui.operation.active)
            }
        } header: {
            Text("Huawei ID")
        } footer: {
            Text("ID này phải trùng với ID đã dùng để ghép đồng hồ trong Huawei Health. Chỉ lưu trong Keychain trên máy này.")
        }
    }

    private var scanSection: some View {
        Section("Đồng hồ ở gần") {
            Button(vm.ui.scanning ? "Dừng quét" : "Quét đồng hồ") {
                if vm.ui.scanning { vm.stopScan() } else { vm.scan() }
            }
            ForEach(vm.ui.devices) { d in
                Button { vm.selectDevice(d) } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(d.name)
                            Text(d.address).font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        if let r = d.rssi { Text("\(r) dBm").font(.caption).foregroundStyle(.secondary) }
                        if vm.ui.selectedDeviceAddress == d.address { Image(systemName: "checkmark") }
                    }
                }
                .foregroundStyle(.primary)
            }
        }
    }

    private var savedSection: some View {
        Section("Đồng hồ đã dùng") {
            if vm.ui.savedDevices.isEmpty { Text("Chưa có").foregroundStyle(.secondary) }
            ForEach(vm.ui.savedDevices) { d in
                Button { vm.selectDevice(d.nearby()) } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(d.name)
                            if let m = d.model { Text(m).font(.caption).foregroundStyle(.secondary) }
                        }
                        Spacer()
                        if vm.ui.selectedDeviceAddress == d.address { Image(systemName: "checkmark") }
                    }
                }
                .foregroundStyle(.primary)
                .swipeActions {
                    Button("Xoá", role: .destructive) { vm.requestRemoval(d.nearby()) }
                }
            }
        }
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack { Text(k); Spacer(); Text(v).foregroundStyle(.secondary) }
    }
}
