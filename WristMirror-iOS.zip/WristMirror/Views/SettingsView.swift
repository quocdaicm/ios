import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var vm: WatchViewModel

    var body: some View {
        NavigationStack {
            Form {
                Section("Giao diện") {
                    Picker("Chủ đề", selection: Binding(get: { vm.ui.theme }, set: { vm.setTheme($0) })) {
                        Text("Theo hệ thống").tag(ThemeMode.system)
                        Text("Sáng").tag(ThemeMode.light)
                        Text("Tối").tag(ThemeMode.dark)
                    }
                }
                Section {
                    Toggle("Tự kết nối khi mở app", isOn: Binding(get: { vm.ui.autoConnect }, set: { vm.setAutoConnect($0) }))
                } footer: {
                    Text("Tính năng này chỉ lưu tuỳ chọn; tự kết nối khi mở app sẽ được nối ở bản sau.")
                }
                Section("Dữ liệu") {
                    Button("Xoá bộ nhớ đệm HWT đã nhập") { vm.clearCache() }
                }
                Section("Giới thiệu") {
                    Text("WristMirror iOS — bản viết lại bằng Swift/SwiftUI của WristMirror (腕镜) cho Android, giấy phép Apache-2.0.")
                    Text("Dùng phương pháp thay thế: ghi file HWT cục bộ lên một slot mặt đồng hồ thường có sẵn. Hãy tự chịu rủi ro; app không chép mã hay SDK của Huawei Health.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("Huỷ ghép nối: Cài đặt iOS > Bluetooth > (i) > Forget This Device.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Cài đặt")
        }
    }
}
