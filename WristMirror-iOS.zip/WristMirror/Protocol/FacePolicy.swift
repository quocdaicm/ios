import Foundation

/// Chính sách chọn/hiển thị dựa trên trường 27/02 đã quan sát (port từ FacePolicy.java).
/// Trường 05 là tập bit; trường 07 là enum 0..5. Không suy ra kết quả cài đặt hay giấy phép.
enum FacePolicy {
    static let current: Int64 = 0x01, preset: Int64 = 0x02, supportDelete: Int64 = 0x04, editable: Int64 = 0x08
    static let video: Int64 = 0x10, photo: Int64 = 0x20, trial: Int64 = 0x40, kaleidoscope: Int64 = 0x80
    static let expandVideo: Int64 = 1, expandPhoto: Int64 = 2, expandKaleidoscope: Int64 = 3
    static let expandWear: Int64 = 4, expandSticker: Int64 = 5
    private static let knownRawBits: Int64 = 0xff
    private static let ineligibleBits: Int64 = preset | video | photo | trial | kaleidoscope

    private static func typeObserved(_ face: TlvView.Face?) -> Bool {
        guard let t = face?.type else { return false }
        return t >= 0 && t <= 0xffffffff
    }
    private static func has(_ face: TlvView.Face?, _ bit: Int64) -> Bool {
        guard typeObserved(face), let t = face?.type else { return false }
        return (t & bit) != 0
    }
    private static func expand(_ face: TlvView.Face?, _ value: Int64) -> Bool {
        guard let e = face?.expandType else { return false }
        return e == value
    }
    /// Thiếu trường 07 ⇒ mặc định nghiệp vụ 0 (giá trị thô vẫn là nil).
    private static func effectiveExpandType(_ face: TlvView.Face) -> Int64 { face.expandType ?? 0 }

    /// Bit "hiện tại", kể cả mục được bảo vệ/đặc biệt.
    static func isCurrent(_ face: TlvView.Face?) -> Bool { has(face, current) }

    /// Chỉ chọn mặt đồng hồ thường đã có, không preset, xoá được.
    static func eligible(_ face: TlvView.Face?) -> Bool {
        guard let face = face, typeObserved(face), face.validResource, let type = face.type else { return false }
        if (type & ~knownRawBits) != 0 || (type & supportDelete) == 0 || (type & ineligibleBits) != 0 { return false }
        return effectiveExpandType(face) == 0
    }

    /// Bật mặt đồng hồ đã cài (cùng ID/phiên bản, op1): tách khỏi quyền ghi đè/xoá.
    static func canActivate(_ face: TlvView.Face?) -> Bool {
        guard let face = face, typeObserved(face), face.validResource, let type = face.type else { return false }
        if (type & ~knownRawBits) != 0 { return false }
        let e = effectiveExpandType(face)
        return e >= 0 && e <= expandSticker
    }

    /// Nhãn loại (tiếng Việt). Thứ tự ưu tiên theo bản gốc: video, ảnh, kính vạn hoa, đeo, rồi sticker.
    static func kind(_ face: TlvView.Face?) -> String {
        guard let face = face else { return "Chưa xác định loại" }
        var special: String? = nil
        if has(face, video) || expand(face, expandVideo) { special = "Mặt đồng hồ video" }
        if has(face, photo) || expand(face, expandPhoto) { special = "Mặt đồng hồ ảnh" }
        if has(face, kaleidoscope) || expand(face, expandKaleidoscope) { special = "Mặt đồng hồ kính vạn hoa" }
        if expand(face, expandWear) { special = "Mặt đồng hồ kiểu đeo" }
        if expand(face, expandSticker) { special = "Sticker vui" }
        if let s = special { return s }
        if !typeObserved(face) { return "Chưa xác định loại" }
        if let t = face.type, (t & ~knownRawBits) != 0 { return "Chưa xác định loại" }
        if effectiveExpandType(face) != 0 { return "Loại mở rộng chưa xác định" }
        if has(face, trial) { return "Mặt đồng hồ dùng thử" }
        if has(face, preset) { return "Mặt đồng hồ có sẵn" }
        if !has(face, supportDelete) { return "Mặt đồng hồ thường, không xoá được" }
        return "Mặt đồng hồ thường"
    }

    /// Chỉ khi có đúng MỘT mục "hiện tại" và mục đó chọn được thì mới là mặc định.
    static func defaultSelection(_ faces: [TlvView.Face]?) -> TlvView.Face? {
        guard let faces = faces, faces.count <= TlvView.maxFields else { return nil }
        var selected: TlvView.Face? = nil
        for face in faces where isCurrent(face) {
            if selected != nil { return nil }
            selected = face
        }
        if let s = selected, eligible(s) { return s }
        return nil
    }
}
