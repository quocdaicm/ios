import Foundation
import CryptoKit

/// Các primitive mật mã cho giao thức Huawei Health / HiChain ISO (port từ HuaweiCrypto.java).
enum HuaweiCrypto {
    static let maxCryptoBytes = WMCore.maxChunk
    static let maxPinBytes = 1024
    static let gcmTagBytes = 16
    private static let maxGcmIvBytes = 64

    // Hằng số giao thức công khai, cố định (không phải PIN hay khoá cá nhân).
    private static let pinVersion14 = try! WMCore.unhex("70FB6C24035FDB552F38898AEEDE3F69")
    private static let pinVersion2 = try! WMCore.unhex("93ACDEF76ACB09857DBFE5261AABCD78")
    private static let pinVersionOther = try! WMCore.unhex("9C2763A9CCE134766DE3FF6118200553")

    private static func require(_ v: [UInt8]?, _ min: Int, _ max: Int, _ code: String) throws -> [UInt8] {
        guard let v = v, v.count >= min, v.count <= max else { throw WMFault(code) }
        return v
    }

    static func sha256(_ data: [UInt8]) throws -> [UInt8] {
        WMCore.digest(try require(data, 0, maxCryptoBytes, "CRYPTO_DATA_LENGTH"))
    }

    /// HMAC-SHA256; khoá rỗng được thay bằng 1 byte 0 (tương đương theo chuẩn).
    static func hmac(_ key: [UInt8], _ data: [UInt8]) throws -> [UInt8] {
        var k = try require(key, 0, maxCryptoBytes, "HMAC_KEY_LENGTH")
        let input = try require(data, 0, maxCryptoBytes, "CRYPTO_DATA_LENGTH")
        if k.isEmpty { k = [0] }
        let mac = HMAC<SHA256>.authenticationCode(for: Data(input), using: SymmetricKey(data: Data(k)))
        return [UInt8](mac)
    }

    /// HKDF-SHA256 (RFC 5869), đúng 32 byte: extract rồi expand một khối. Thứ tự: IKM, salt, info.
    static func hkdf32(_ ikm: [UInt8], _ salt: [UInt8]?, _ info: [UInt8]?) throws -> [UInt8] {
        let input = try require(ikm, 0, maxCryptoBytes, "HKDF_IKM_LENGTH")
        let s: [UInt8]
        if let sv = salt, !sv.isEmpty {
            s = try require(sv, 0, maxCryptoBytes, "HKDF_SALT_LENGTH")
        } else {
            s = [UInt8](repeating: 0, count: 32)
        }
        let context = try require(info ?? [], 0, maxCryptoBytes - 1, "HKDF_INFO_LENGTH")
        let prk = try hmac(s, input)
        return try hmac(prk, context + [1])
    }

    static func constantTimeEquals(_ a: [UInt8]?, _ b: [UInt8]?) -> Bool {
        guard let a = a, let b = b else { return false }
        var diff = a.count ^ b.count
        let n = max(a.count, b.count)
        for i in 0..<n {
            let x = i < a.count ? Int(a[i]) : 0
            let y = i < b.count ? Int(b[i]) : 0
            diff |= x ^ y
        }
        return diff == 0
    }

    /// SHA256(UTF8(HEX_IN_HOA(PIN thô))).
    static func pinBase(_ pinRaw: [UInt8]) throws -> [UInt8] {
        let pin = try require(pinRaw, 1, maxPinBytes, "PIN_LENGTH_INVALID")
        let alphabet = Array("0123456789ABCDEF".utf8)
        var up = [UInt8]()
        up.reserveCapacity(pin.count * 2)
        for v in pin { up.append(alphabet[Int(v >> 4)]); up.append(alphabet[Int(v & 15)]) }
        return try sha256(up)
    }

    static func pinMagic(_ authVersion: Int) -> [UInt8] {
        if authVersion == 1 || authVersion == 4 { return pinVersion14 }
        if authVersion == 2 { return pinVersion2 }
        return pinVersionOther
    }

    static func isAesKeyLength(_ n: Int) -> Bool { n == 16 || n == 24 || n == 32 }
    static func validateKeyLength(_ n: Int) throws {
        if !isAesKeyLength(n) { throw WMFault("AES_KEY_LENGTH_INVALID") }
    }
    static func validateKeyLength(_ key: [UInt8]?) throws {
        guard let key = key else { throw WMFault("AES_KEY_REQUIRED") }
        try validateKeyLength(key.count)
    }

    // MARK: GCM (tag 128 bit nối cuối, không gắn IV vào đầu)
    static func aesGcmEncrypt(_ key: [UInt8], _ iv: [UInt8], _ data: [UInt8], _ aad: [UInt8]?) throws -> [UInt8] {
        try validateKeyLength(key)
        let nonce = try require(iv, 1, maxGcmIvBytes, "GCM_IV_LENGTH_INVALID")
        let input = try require(data, 0, maxCryptoBytes, "GCM_DATA_LENGTH_INVALID")
        let a = try require(aad ?? [], 0, maxCryptoBytes, "GCM_AAD_LENGTH_INVALID")
        return try AESGCMManual.seal(key: key, iv: nonce, plain: input, aad: a)
    }

    static func aesGcmDecrypt(_ key: [UInt8], _ iv: [UInt8], _ data: [UInt8], _ aad: [UInt8]?) throws -> [UInt8] {
        try validateKeyLength(key)
        let nonce = try require(iv, 1, maxGcmIvBytes, "GCM_IV_LENGTH_INVALID")
        let input = try require(data, gcmTagBytes, maxCryptoBytes + gcmTagBytes, "GCM_DATA_LENGTH_INVALID")
        let a = try require(aad ?? [], 0, maxCryptoBytes, "GCM_AAD_LENGTH_INVALID")
        return try AESGCMManual.open(key: key, iv: nonce, sealed: input, aad: a)
    }

    // MARK: CBC (PKCS7; KHÔNG phải xác thực)
    static func aesCbcEncrypt(_ key: [UInt8], _ iv: [UInt8], _ data: [UInt8]) throws -> [UInt8] {
        try validateKeyLength(key)
        let v = try require(iv, 16, 16, "CBC_IV_LENGTH_INVALID")
        let input = try require(data, 0, maxCryptoBytes, "CBC_DATA_LENGTH_INVALID")
        return try AESPrimitives.cbc(encrypt: true, key: key, iv: v, data: input)
    }

    static func aesCbcDecrypt(_ key: [UInt8], _ iv: [UInt8], _ data: [UInt8]) throws -> [UInt8] {
        try validateKeyLength(key)
        let v = try require(iv, 16, 16, "CBC_IV_LENGTH_INVALID")
        let input = try require(data, 16, maxCryptoBytes + 16, "CBC_DATA_LENGTH_INVALID")
        if input.count & 15 != 0 { throw WMFault("CBC_CIPHERTEXT_ALIGNMENT_INVALID") }
        return try AESPrimitives.cbc(encrypt: false, key: key, iv: v, data: input)
    }

    // MARK: Mã hoá nghiệp vụ
    static func businessUsesGcm(encryptMethod: Int, supportType: Int) -> Bool {
        encryptMethod == 1 || supportType == 4
    }

    static func businessEncrypt(key: [UInt8], iv: [UInt8], data: [UInt8], encryptMethod: Int, supportType: Int) throws -> [UInt8] {
        _ = try require(iv, 16, 16, "BUSINESS_IV_LENGTH_INVALID")
        if businessUsesGcm(encryptMethod: encryptMethod, supportType: supportType) {
            return try aesGcmEncrypt(key, iv, data, nil)
        }
        return try aesCbcEncrypt(key, iv, data)
    }

    static func businessDecrypt(key: [UInt8], iv: [UInt8], data: [UInt8], encryptMethod: Int, supportType: Int) throws -> [UInt8] {
        _ = try require(iv, 16, 16, "BUSINESS_IV_LENGTH_INVALID")
        if businessUsesGcm(encryptMethod: encryptMethod, supportType: supportType) {
            return try aesGcmDecrypt(key, iv, data, nil)
        }
        return try aesCbcDecrypt(key, iv, data)
    }

    /// Giải mã PIN 01/2C (IV GCM 1..64 byte, CBC phải 16 byte).
    static func decryptPin(authVersion: Int, encryptMethod: Int, iv: [UInt8], encrypted: [UInt8]) throws -> [UInt8] {
        let magic = pinMagic(authVersion)
        _ = try require(encrypted, 1, maxPinBytes + 16, "PIN_CIPHERTEXT_LENGTH_INVALID")
        let result: [UInt8]
        if encryptMethod == 1 {
            result = try aesGcmDecrypt(magic, iv, encrypted, nil)
        } else {
            result = try aesCbcDecrypt(magic, iv, encrypted)
        }
        return try require(result, 1, maxPinBytes, "PIN_LENGTH_INVALID")
    }
}
