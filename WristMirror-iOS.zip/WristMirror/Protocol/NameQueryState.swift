import Foundation

/// Tuần tự hoá có giới hạn các truy vấn tên 27/06 cho một danh sách đã quan sát (port từ NameQueryState.java).
/// Không gửi lệnh, không đặt hẹn giờ; thời gian do chủ sở hữu truyền vào (đơn vị ms).
final class NameQueryState {
    static let maxBatchSize = 64
    static let replyTimeoutMs: Int64 = 8000

    /// Ảnh chụp bất biến của một yêu cầu; `ids` là cả lô, không phải phần còn lại.
    struct Batch {
        let serial: Int64
        let startedAt: Int64
        let faces: [TlvView.Face]
        let ids: [String]
    }

    private var pending: [TlvView.Face] = []
    private var pendingHead = 0
    private var sentIds = Set<String>()
    private var remainingIds = Set<String>()
    private var serial: Int64 = 0
    private(set) var current: Batch?
    private var cancelled = false

    /// `knownKeys` chứa tên đã cache dạng "ID_version". Chỉ bỏ qua ID khi MỌI phiên bản hợp lệ đã biết.
    init(faces: [TlvView.Face]?, knownKeys: Set<String>?) throws {
        guard let faces = faces else { throw WMFault("NAMES_QUERY_FACES_REQUIRED") }
        if faces.count > TlvView.maxFields { throw WMFault("NAMES_QUERY_FIELDS_LIMIT") }
        var order: [String] = []
        var representatives: [String: TlvView.Face] = [:]
        var unknownIds = Set<String>()
        for face in faces where face.validResource {
            if representatives[face.id] == nil {
                representatives[face.id] = face
                order.append(face.id)
            }
            if knownKeys == nil || !knownKeys!.contains(face.id + "_" + face.version) {
                unknownIds.insert(face.id)
            }
        }
        for id in order where unknownIds.contains(id) {
            if let f = representatives[id] { pending.append(f) }
        }
    }

    private var pendingCount: Int { pending.count - pendingHead }

    /// Trả lô mới chỉ khi đang rảnh. Chủ sở hữu phải gửi thật hoặc gọi `failCurrent()`.
    func next(now: Int64) -> Batch? {
        if cancelled || current != nil || pendingCount == 0 { return nil }
        var faces: [TlvView.Face] = []
        var ids: [String] = []
        var idSet = Set<String>()
        while faces.count < NameQueryState.maxBatchSize && pendingCount > 0 {
            let face = pending[pendingHead]
            pendingHead += 1
            faces.append(face)
            if idSet.insert(face.id).inserted { ids.append(face.id) }
        }
        serial += 1
        let batch = Batch(serial: serial, startedAt: now, faces: faces, ids: ids)
        current = batch
        sentIds.formUnion(idSet)
        remainingIds.formUnion(idSet)
        return batch
    }

    /// Chỉ ghép tên cho ID đã gửi. Phản hồi null/sau huỷ ⇒ rỗng.
    func accept(_ response: WireNames.Response?) -> [String: String] {
        guard !cancelled, let response = response else { return [:] }
        var matched: [String: String] = [:]
        for (id, name) in response.names where sentIds.contains(id) { matched[id] = name }
        if current != nil {
            remainingIds.subtract(response.ids)
            if remainingIds.isEmpty { current = nil }
        }
        return matched
    }

    /// Bỏ lô hiện tại (không thử lại).
    func failCurrent() {
        current = nil
        remainingIds.removeAll()
    }

    /// Hết hạn lô hiện tại nếu đã ≥ 8 giây; mốc thời gian lùi không làm hết hạn.
    func expire(now: Int64) -> Bool {
        guard let c = current, now >= c.startedAt else { return false }
        let (elapsed, overflow) = now.subtractingReportingOverflow(c.startedAt)
        if !overflow && elapsed < NameQueryState.replyTimeoutMs { return false }
        failCurrent()
        return true
    }

    var done: Bool { pendingCount == 0 && current == nil }

    /// Kết thúc: giải phóng mọi việc còn lại và từ chối tên/lô mới.
    func cancel() {
        cancelled = true
        pending.removeAll()
        pendingHead = 0
        sentIds.removeAll()
        failCurrent()
    }
}
