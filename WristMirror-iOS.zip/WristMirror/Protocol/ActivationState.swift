import Foundation

/// Quan sát thuần cho việc bật một mặt đồng hồ đã cài (cùng ID, cùng phiên bản, op1) – port từ ActivationState.java.
/// Không chọn tài nguyên khác, không gửi lệnh, không truyền file, không tự thử lại.
final class ActivationState {
    enum Phase: String { case waitOperation = "WAIT_OPERATION", waitList = "WAIT_LIST", activated = "ACTIVATED", failed = "FAILED", timedOut = "TIMED_OUT" }
    enum Action { case none, query }

    let id: String
    let version: String
    private(set) var phase: Phase = .waitOperation
    private(set) var reason = "WAITING_EXPLICIT_ACTIVATION_27_03"
    private(set) var operationError: Int64?, need: Int64?, operationEcho: Int64?, reportError: Int64?, firstError: Int64?
    private(set) var reportType: Int?
    private(set) var operationObserved = false, reportOneObserved = false, listed = false, current = false
    private(set) var signalGeneration = 0, listObservations = 0, targetCount = 0, currentCount = 0
    private var lastObservedQuery: Int64 = 0

    init(id: String, version: String) throws {
        try WMCore.resource(id, version)
        self.id = id
        self.version = version
    }

    func matches(_ id: String, _ version: String) -> Bool { self.id == id && self.version == version }

    var terminal: Bool { phase == .activated || phase == .failed || phase == .timedOut }

    /// Thiếu echo của op là tương thích; echo của op khác ⇒ không liên quan.
    func operation(error: Int64?, need transferNeed: Int64?, echo: Int64?) -> Action {
        if let e = echo, e != 1 { return .none }
        operationError = error
        need = transferNeed
        operationEcho = echo
        if let e = error, e != 0 { fail("ACTIVATION_OPERATION_ERROR", e); return .none }
        guard error != nil, let n = transferNeed else { fail("ACTIVATION_OPERATION_FIELDS_MISSING", nil); return .none }
        if n != 0 {
            fail(n == 1 ? "ACTIVATION_UNEXPECTED_FILE_REQUEST_NO_TRANSFER" : "ACTIVATION_OPERATION_NEED_INVALID", nil)
            return .none
        }
        if terminal || operationObserved { return .none }
        operationObserved = true
        signalGeneration += 1
        phase = .waitList
        reason = "ACTIVATION_OPERATION_CONFIRMED_WAIT_NEW_CURRENT_LIST"
        return .query
    }

    /// Report 1 chỉ để quan sát; report 2 không bao giờ là quyền bật/tải file.
    func report(type: Int?, error: Int64?) -> Action {
        reportType = type
        reportError = error
        if let e = error, e != 0, e != 100000 { fail("ACTIVATION_REPORT_ERROR", e); return .none }
        if type == 3 { fail("ACTIVATION_REPORT_THREE_FAILURE", nil); return .none }
        if type == 1 {
            reportOneObserved = true
            if !terminal && !operationObserved { reason = "ACTIVATION_REPORT_ONE_WAIT_EXPLICIT_OPERATION" }
        }
        return .none
    }

    private static func observedText(_ text: String) -> Bool {
        if text.isEmpty || text.count > 32 { return false }
        let bytes = Array(text.utf8)
        guard bytes.count <= 32, let back = try? WMCore.utf8(bytes) else { return false }
        return back == text
    }

    private static func observedNumber(_ v: Int64?) -> Bool {
        guard let v = v else { return false }
        return v >= 0 && v <= 0xffffffff
    }

    private static func observedFace(_ face: TlvView.Face) -> Bool {
        observedText(face.id) && observedText(face.version) && observedNumber(face.type)
            && (face.expandType == nil || observedNumber(face.expandType))
    }

    /// Chỉ truy vấn do chính chủ sở hữu tạo SAU thao tác thành công mới được xác nhận.
    func list(_ faces: [TlvView.Face]?, generation: Int, ownQuery: Bool, serial: Int64) {
        if terminal || phase != .waitList || !operationObserved || signalGeneration <= 0 || !ownQuery
            || generation != signalGeneration || serial <= 0 || serial <= lastObservedQuery { return }
        lastObservedQuery = serial
        listObservations += 1
        listed = false
        current = false
        targetCount = 0
        currentCount = 0
        guard let faces = faces else { fail("ACTIVATION_LIST_MISSING", nil); return }
        if faces.count > TlvView.maxFields { fail("ACTIVATION_LIST_LIMIT", nil); return }
        var target: TlvView.Face? = nil
        for face in faces {
            if !ActivationState.observedFace(face) { fail("ACTIVATION_LIST_INVALID", nil); return }
            if id == face.id { targetCount += 1; target = face }
            if FacePolicy.isCurrent(face) { currentCount += 1 }
        }
        if targetCount == 0 { fail("ACTIVATION_TARGET_ID_ABSENT", nil); return }
        if targetCount != 1 { fail("ACTIVATION_TARGET_ID_DUPLICATE", nil); return }
        guard let t = target else { return }
        listed = (version == t.version)
        current = FacePolicy.isCurrent(t)
        if !listed { fail("ACTIVATION_TARGET_INSTALLED_VERSION_CHANGED", nil); return }
        if !FacePolicy.canActivate(t) { fail("ACTIVATION_TARGET_NO_LONGER_ACTIVATABLE", nil); return }
        if current && currentCount == 1 {
            phase = .activated
            reason = "ACTIVATION_FRESH_LIST_TARGET_CURRENT_VISUAL_CHECK_REQUIRED"
        } else {
            reason = currentCount > 1 ? "ACTIVATION_WAIT_UNIQUE_CURRENT_MARKER" : "ACTIVATION_TARGET_NOT_CURRENT_WAIT_NEW_LIST"
        }
    }

    func fail(_ why: String, _ error: Int64?) {
        if firstError == nil, let e = error, e != 0 { firstError = e }
        if !terminal || phase == .activated {
            phase = .failed
            reason = WMCore.clean(why)
        }
    }

    func timeout() {
        if !terminal {
            phase = .timedOut
            reason = "ACTIVATION_TIMEOUT_NOT_A_VISUAL_VERDICT"
        }
    }

    func summary() -> String {
        func s(_ v: Int64?) -> String { v.map(String.init) ?? "nil" }
        return "phase=\(phase.rawValue) reason=\(WMCore.clean(reason)) id=\(id) version=\(version)"
            + " operation_error=\(s(operationError)) need=\(s(need)) operation_echo=\(s(operationEcho))"
            + " report_type=\(reportType.map(String.init) ?? "nil") report_error=\(s(reportError))"
            + " operation_observed=\(operationObserved) report_one_observed=\(reportOneObserved)"
            + " signal_generation=\(signalGeneration) list_observations=\(listObservations)"
            + " last_query_serial=\(lastObservedQuery) target_count=\(targetCount)"
            + " listed=\(listed) current=\(current) current_count=\(currentCount) first_error=\(s(firstError))"
    }
}
