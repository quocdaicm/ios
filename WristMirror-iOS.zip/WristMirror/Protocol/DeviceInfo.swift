import Foundation

/// Đọc thông tin sản phẩm (service 0x01 / command 0x07): model và firmware.
enum DeviceInfo {
    static let service = 0x01
    static let productCommand = 0x07
    static let firmwareTag = 0x07
    static let modelTag = 0x0a
    static let maxFirmwareBytes = 80
    static let maxModelBytes = 128

    private static let versionRegex = try! NSRegularExpression(
        pattern: "^[vV]?[0-9]+(?:\\.[0-9]+)+(?:[A-Za-z][A-Za-z0-9._-]*|[ _-][A-Za-z0-9._-]+| ?\\([A-Za-z0-9._ -]+\\))*$")

    static func model(service s: Int, command: Int, plain: [UInt8]) throws -> String? {
        if s != service || command != productCommand { throw WMFault("DEVICE_INFO_HEADER_MISMATCH") }
        return try model(TlvView.decode(plain))
    }

    static func model(_ fields: [TlvView.Part]) throws -> String? {
        let error = try Wire.number(fields, 0x7f)
        if let e = error, e != 0, e != 100000 { throw WMFault("PRODUCT_INFO_REJECTED") }
        guard let f = try Wire.unique(fields, modelTag), !f.value.isEmpty else { return nil }
        if f.value.count > maxModelBytes + 1 { throw WMFault("PRODUCT_MODEL_SIZE") }
        var end = f.value.count
        if f.value[end - 1] == 0 { end -= 1 }
        if end > maxModelBytes { throw WMFault("PRODUCT_MODEL_SIZE") }
        return try modelText(WMCore.utf8(Array(f.value[0..<end])))
    }

    private static func isControl(_ s: Unicode.Scalar) -> Bool {
        s.value < 32 || (s.value >= 127 && s.value <= 159)
    }

    /// Dùng chung cho model đọc từ đồng hồ và model cache cục bộ.
    static func modelText(_ text: String?) throws -> String? {
        guard let text = text else { return nil }
        if text.utf16.count > maxModelBytes { throw WMFault("PRODUCT_MODEL_SIZE") }
        for s in text.unicodeScalars {
            if isControl(s) || s.properties.generalCategory == .format || s.value == 0xfffd {
                throw WMFault("PRODUCT_MODEL_CONTROL")
            }
        }
        if text.utf8.count > maxModelBytes { throw WMFault("PRODUCT_MODEL_SIZE") }
        let m = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = m.lowercased()
        if m.isEmpty || lower == "unknown" || m == "未知" || m == "未知型号" || lower == "null" || lower == "n/a" {
            return nil
        }
        return m
    }

    static func firmware(service s: Int, command: Int, plain: [UInt8]) throws -> String? {
        if s != service || command != productCommand { throw WMFault("DEVICE_INFO_HEADER_MISMATCH") }
        return try firmware(TlvView.decode(plain))
    }

    /// Tag 07 gốc = softwareVersion. Thiếu/rỗng/không giống phiên bản → nil.
    static func firmware(_ fields: [TlvView.Part]) throws -> String? {
        let error = try Wire.number(fields, 0x7f)
        if let e = error, e != 0, e != 100000 { throw WMFault("PRODUCT_INFO_REJECTED") }
        guard let f = try Wire.unique(fields, firmwareTag), !f.value.isEmpty else { return nil }
        if f.value.count > maxFirmwareBytes + 1 { throw WMFault("PRODUCT_FIRMWARE_SIZE") }
        var end = f.value.count
        if f.value[end - 1] == 0 { end -= 1 }
        if end > maxFirmwareBytes { throw WMFault("PRODUCT_FIRMWARE_SIZE") }
        if end == 0 { return nil }
        let text = try WMCore.utf8(Array(f.value[0..<end]))
        for s in text.unicodeScalars where isControl(s) { throw WMFault("PRODUCT_FIRMWARE_CONTROL") }
        let v = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let range = NSRange(v.startIndex..., in: v)
        return versionRegex.firstMatch(in: v, options: [], range: range) != nil ? v : nil
    }
}
