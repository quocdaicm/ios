import Foundation

/// Khoá nghiệp vụ + bộ đếm IV cho MỘT kết nối; không bao giờ ghi ra bộ nhớ lâu dài.
final class CryptoSession {
    typealias RandomSource = (Int) -> [UInt8]

    private let lock = NSLock()
    private let random: RandomSource
    private let method: Int
    private let supportType: Int
    private var key: [UInt8]?
    private var counter: UInt64

    init(sessionKey: [UInt8], method: Int, supportType: Int, counter: Int64,
         random: @escaping RandomSource = { WMRandom.bytes($0) }) throws {
        if sessionKey.count != 16 && sessionKey.count != 24 && sessionKey.count != 32 {
            throw WMFault("SESSION_KEY_LENGTH")
        }
        self.key = sessionKey
        self.method = method
        self.supportType = supportType
        self.counter = UInt64(truncatingIfNeeded: counter) & 0xffffffff
        self.random = random
    }

    private func nextIvLocked() throws -> [UInt8] {
        if key == nil { throw WMFault("SESSION_CLOSED") }
        var iv = random(16)
        if supportType != 4 {
            counter = (counter + 1) & 0xffffffff
            if counter == 0 { counter = 1 }
            for i in 0..<4 { iv[12 + i] = UInt8((counter >> UInt64(24 - 8 * i)) & 0xff) }
        }
        return iv
    }

    func nextIv() throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        return try nextIvLocked()
    }

    private var usesGcm: Bool { method == 1 || supportType == 4 }

    func seal(_ plain: [UInt8]) throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        guard let k = key else { throw WMFault("SESSION_CLOSED") }
        let iv = try nextIvLocked()
        let cipher: [UInt8]
        if usesGcm {
            cipher = try HuaweiCrypto.aesGcmEncrypt(k, iv, plain, nil)
        } else {
            cipher = try HuaweiCrypto.aesCbcEncrypt(k, iv, plain)
        }
        return try WMCore.tlv(0x7c, [1]) + WMCore.tlv(0x7d, iv) + WMCore.tlv(0x7e, cipher)
    }

    /// true nếu thân gói là phong bì mã hoá hợp lệ; false nếu không có trường 7c/7d/7e nào.
    static func wrapped(_ body: [UInt8]) throws -> Bool {
        let p = try TlvView.decode(body)
        let flag = try Wire.unique(p, 0x7c), iv = try Wire.unique(p, 0x7d), ct = try Wire.unique(p, 0x7e)
        if flag == nil && iv == nil && ct == nil { return false }
        guard p.count == 3, let f = flag, f.value.count == 1, f.value[0] == 1,
              let i = iv, i.value.count == 16, let c = ct, c.value.count >= 16 else {
            throw WMFault("ENCRYPTED_ENVELOPE_INVALID")
        }
        return true
    }

    func open(_ body: [UInt8]) throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        guard let k = key else { throw WMFault("SESSION_CLOSED") }
        let p = try TlvView.decode(body)
        let flag = try Wire.unique(p, 0x7c), iv = try Wire.unique(p, 0x7d), cipher = try Wire.unique(p, 0x7e)
        guard p.count == 3, let f = flag, f.value.count == 1, f.value[0] == 1,
              let i = iv, i.value.count == 16, let c = cipher, c.value.count >= 16 else {
            throw WMFault("ENCRYPTED_ENVELOPE_INVALID")
        }
        if usesGcm { return try HuaweiCrypto.aesGcmDecrypt(k, i.value, c.value, nil) }
        return try HuaweiCrypto.aesCbcDecrypt(k, i.value, c.value)
    }

    func close() {
        lock.lock(); defer { lock.unlock() }
        key = nil
    }
}
