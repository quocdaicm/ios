import Foundation

/// Mỗi lần thay mặt đồng hồ chỉ cho phép một thao tác tiền đề và một lần tải (port từ ReplacementState.java).
final class ReplacementState {
    enum Phase: String {
        case waitOperation = "WAIT_OPERATION", transferring = "TRANSFERRING", waitReport = "WAIT_REPORT"
        case waitPost = "WAIT_POST", waitList = "WAIT_LIST", listed = "LISTED", noTransfer = "NO_TRANSFER"
        case failed = "FAILED", cancelled = "CANCELLED", timedOut = "TIMED_OUT"
    }
    enum Action { case none, upload, activate, query }

    let id: String, baseline: String, version: String
    private(set) var phase: Phase = .waitOperation
    private(set) var reason = "WAITING_EXPLICIT_27_03"
    private(set) var uploadIssued = false, reportReceived = false, postIssued = false, postObserved = false
    private(set) var listed = false, current = false
    private(set) var nativeRespondObserved = false
    private var freshList = false
    private(set) var nativeRespond: Int?, progress: Int?, report: Int?
    private(set) var firstError: Int64?, initialError: Int64?, initialNeed: Int64?, postError: Int64?, postNeed: Int64?
    private(set) var postGeneration = 0, listObservations = 0

    init(id: String, baseline: String, version: String) throws {
        try WMCore.resource(id, baseline)
        try WMCore.resource(id, version)
        self.id = id
        self.baseline = baseline
        self.version = version
    }

    func matches(_ id: String, _ version: String) -> Bool { self.id == id && self.version == version }

    var terminal: Bool {
        phase == .listed || phase == .noTransfer || phase == .failed || phase == .cancelled || phase == .timedOut
    }

    func operation(error: Int64?, need: Int64?) -> Action {
        if phase == .waitOperation { initialError = error; initialNeed = need }
        else if postIssued { postError = error; postNeed = need }
        if let e = error, e != 0 { fail("DEVICE_OPERATION_ERROR", e); return .none }
        if terminal { return .none }
        if phase == .waitOperation {
            initialError = error
            initialNeed = need
            guard error != nil, let n = need else { fail("OPERATION_FIELDS_MISSING", nil); return .none }
            if n == 0 {
                phase = .noTransfer
                reason = "INCREMENTED_VERSION_NEED_ZERO_NO_MORE_RETRY"
                return .none
            }
            if n != 1 { fail("OPERATION_NEED_INVALID", nil); return .none }
            uploadIssued = true
            phase = .transferring
            reason = "DEVICE_REQUESTED_FILE"
            return .upload
        }
        if postIssued {
            postError = error
            postNeed = need
            guard error != nil, let n = need else { fail("POST_OPERATION_FIELDS_MISSING", nil); return .none }
            if n != 0 { fail("POST_OPERATION_REQUESTED_MORE_FILE_NO_RETRY", nil); return .none }
            if !postObserved { postObserved = true; postGeneration += 1 }
            phase = .waitList
            reason = "POST_OPERATION_CONFIRMED_WAIT_FRESH_LIST"
            return .query
        }
        return .none
    }

    func report(type: Int?, error: Int64?) -> Action {
        if let e = error, e != 100000, e != 0 { fail("WATCH_REPORT_ERROR", e); return .none }
        report = type
        if type == 3 { fail("WATCH_REPORT_FAILURE", nil); return .none }
        if terminal { return .none }
        if type == 2 && uploadIssued {
            reportReceived = true
            if !postIssued {
                postIssued = true
                phase = .waitPost
                reason = "REPORT_TWO_SEND_ONE_POST_ACTIVATION"
                return .activate
            }
        }
        return .none
    }

    func nativeResult(_ raw: Int) {
        nativeRespondObserved = true
        nativeRespond = raw
        if raw == 0 { fail("NATIVE_FILE_RESPOND_ZERO", nil); return }
        if terminal { return }
        if raw == 1 && phase == .transferring {
            phase = .waitReport
            reason = "NATIVE_TRANSFER_CALLBACK_WAIT_REPORT_TWO"
        }
        maybeListed()
    }

    func nativeProgress(_ raw: Int) {
        if raw >= 0 && raw <= 100 { progress = raw }
    }

    func fail(_ why: String, _ error: Int64?) {
        if firstError == nil, let e = error { firstError = e }
        reason = why
        phase = .failed
    }

    func cancel() { if !terminal { phase = .cancelled; reason = "USER_CANCELLED" } }
    func timeout() { if !terminal { phase = .timedOut; reason = "TIMEOUT_NOT_INSTALL_VERDICT" } }

    func list(_ faces: [TlvView.Face], queryGeneration: Int, ownQuery: Bool) {
        listObservations += 1
        listed = false
        current = false
        for face in faces where matches(face.id, face.version) {
            listed = true
            if let t = face.type { current = (t & 1) != 0 }
        }
        if terminal { return }
        freshList = ownQuery && postObserved && postGeneration > 0 && queryGeneration == postGeneration
        maybeListed()
    }

    private func maybeListed() {
        if terminal { return }
        if uploadIssued && reportReceived && postIssued && postObserved && listed && freshList
            && nativeRespondObserved && nativeRespond == 1 {
            phase = .listed
            reason = "REPLACEMENT_LISTED_APPLICATION_VISUAL_CHECK_REQUIRED"
        }
    }

    func summary() -> String {
        func s(_ v: Int64?) -> String { v.map(String.init) ?? "nil" }
        func i(_ v: Int?) -> String { v.map(String.init) ?? "nil" }
        return "phase=\(phase.rawValue) reason=\(reason) initial_error=\(s(initialError)) initial_need=\(s(initialNeed))"
            + " upload_issued=\(uploadIssued) native_result=\(i(nativeRespond)) native_percent=\(i(progress)) report=\(i(report))"
            + " report_two=\(reportReceived) post_issued=\(postIssued) post_error=\(s(postError)) post_need=\(s(postNeed))"
            + " listed=\(listed) current=\(current) generation=\(postGeneration) list_observations=\(listObservations)"
            + " first_error=\(s(firstError))"
    }
}
