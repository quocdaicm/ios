import Foundation

private func hexIds(_ hex: String) -> [UInt8] {
    let u = Array(hex.utf8)
    var out = [UInt8]()
    var i = 0
    func v(_ c: UInt8) -> UInt8 { c <= 57 ? c - 48 : (c >= 97 ? c - 87 : c - 55) }
    while i + 1 < u.count { out.append(v(u[i]) << 4 | v(u[i + 1])); i += 2 }
    return out
}

/// Ghi lại các quan sát giao thức; không đoán năng lực theo tên model, không suy ra quyền tài khoản.
final class LinkCapabilities {
    var protocolVersion = 0, sliceSize = 1024, mtu = 1024, intervalMs = 0
    var authVersion = 0, deviceSupportType = 0, authAlgorithm = 0, bondState = 0
    var encryptMethod = 0, authMode = 0, authType = 0
    var serverNonce: [UInt8]?

    // Thứ tự yêu cầu quyết định thứ tự các cờ boolean trong phản hồi.
    private static let services: [UInt8] = hexIds("02030405060708090A0B0C0D0E0F101112131415161718191A1B1D202223242526272A2B2D2E3032333435")
    private static let commandRows: [(Int, [UInt8])] = [
        (0x01, hexIds("040708090A0D0E10111213141B1A1D21222324292A2B322E31303536372F")),
        (0x02, hexIds("010405060708")),
        (0x03, hexIds("010304")),
        (0x04, hexIds("01")),
        (0x05, hexIds("01")),
        (0x06, hexIds("01")),
        (0x07, hexIds("0103050708090A0E1013161517181B1C1D1E21222324252829061F")),
        (0x08, hexIds("010203")),
        (0x09, hexIds("010B0C0D0E0F")),
        (0x0a, hexIds("01090A")),
        (0x0b, hexIds("0103")),
        (0x0c, hexIds("01")),
        (0x0d, hexIds("01")),
        (0x0f, hexIds("0103050607080A0B0C")),
        (0x10, hexIds("01")),
        (0x11, hexIds("01")),
        (0x12, hexIds("01")),
        (0x13, hexIds("01")),
        (0x14, hexIds("01")),
        (0x15, hexIds("01")),
        (0x16, hexIds("010307")),
        (0x17, hexIds("010406070B0C10121517")),
        (0x18, hexIds("010204050609")),
        (0x19, hexIds("0104")),
        (0x1a, hexIds("0103070506")),
        (0x1b, hexIds("010F191A")),
        (0x1d, hexIds("0102030405060708090A")),
        (0x20, hexIds("01020304090A")),
        (0x22, hexIds("01")),
        (0x23, hexIds("020B")),
        (0x24, hexIds("0102030405060708090A0B0C")),
        (0x25, hexIds("02040E")),
        (0x26, hexIds("0203")),
        (0x27, hexIds("010E02030506")),
        (0x2a, hexIds("0106")),
        (0x2b, hexIds("12")),
        (0x2d, hexIds("01")),
        (0x2e, hexIds("010203")),
        (0x30, hexIds("01")),
        (0x32, hexIds("01")),
        (0x33, hexIds("0102")),
        (0x34, hexIds("01")),
        (0x35, hexIds("0304"))
    ]
    private static let commandMap: [Int: [UInt8]] = Dictionary(uniqueKeysWithValues: commandRows)

    private var serviceFlags: [Int: Bool] = [:]
    private var commandFlags: [String: Bool] = [:]
    private var requestedCommandServices = Set<Int>()
    private var expand: [UInt8]?

    private static func byteValue(_ p: [TlvView.Part], _ tag: Int, _ fallback: Int) throws -> Int {
        guard let f = try Wire.unique(p, tag), !f.value.isEmpty else { return fallback }
        return Int(f.value[0])
    }

    private static func shortValue(_ p: [TlvView.Part], _ tag: Int) throws -> Int {
        guard let f = try Wire.unique(p, tag), f.value.count == 2 else { throw WMFault("LINK_PARAM_MISSING_OR_LENGTH") }
        return Int(try WMCore.number(f.value))
    }

    static func linkRequest() throws -> [UInt8] {
        var b = [UInt8]()
        for t in [1, 2, 3, 4] { b += try WMCore.tlv(t, []) }
        return b
    }

    func parseLink(_ body: [UInt8]) throws {
        let p = try TlvView.decode(body)
        protocolVersion = try LinkCapabilities.byteValue(p, 1, -1)
        sliceSize = try LinkCapabilities.shortValue(p, 2)
        mtu = try LinkCapabilities.shortValue(p, 3)
        intervalMs = try LinkCapabilities.shortValue(p, 4)
        if protocolVersion < 0 || sliceSize < 16 || sliceSize > 32767 || mtu < 16 || mtu > 32767 || intervalMs > 1000 {
            throw WMFault("LINK_PARAM_RANGE_UNSUPPORTED")
        }
        let v = try Wire.unique(p, 5)
        authVersion = (v != nil && v!.value.count >= 2) ? Int(v!.value[1]) : 0
        serverNonce = (v != nil && v!.value.count >= 18) ? Array(v!.value[2..<18]) : nil
        deviceSupportType = try LinkCapabilities.byteValue(p, 7, 0)
        authAlgorithm = try LinkCapabilities.byteValue(p, 8, 0)
        bondState = try LinkCapabilities.byteValue(p, 9, 0)
        encryptMethod = try LinkCapabilities.byteValue(p, 0x0c, 0)
        authMode = deviceSupportType == 4 ? 4 : ([1, 2, 3, 8].contains(deviceSupportType) ? 2 : 0)
    }

    func securityRequest(selfId: [UInt8]?, model: String?) throws -> [UInt8] {
        guard let selfId = selfId, selfId.count == 32 else { throw WMFault("CLIENT_IDENTITY_REQUIRED") }
        var b = [UInt8]()
        b += try WMCore.tlv(1, [UInt8(authMode)])
        b += try WMCore.tlv(5, selfId)
        b += try WMCore.tlv(3, [1])
        b += try WMCore.tlv(4, [0])
        if authMode == 2 || authMode == 4 { b += try WMCore.tlv(2, [1]) }
        if authMode == 4 {
            b += try WMCore.tlv(6, [])
            var m = model ?? "iPhone"
            if m.count > 80 { m = String(m.prefix(80)) }
            b += try WMCore.tlv(7, Array(m.utf8))
        }
        if encryptMethod == 1 { b += try WMCore.tlv(0x0d, [1]) }
        return b
    }

    /// 01/33 dùng giá trị chọn ở byte đầu, không diễn giải như mã thành công uint32 chung.
    func parseSecurity(_ body: [UInt8]) throws {
        let p = try TlvView.decode(body)
        let first = try LinkCapabilities.byteValue(p, 1, 0)
        var type = first == 1 ? 100000 : 0
        if let t = try Wire.unique(p, 2), !t.value.isEmpty {
            type = Int(t.value[0])
            if first == 4 { type ^= 4 }
        }
        type = try LinkCapabilities.byteValue(p, 0x7f, type)
        authType = type
    }

    func iso() -> Bool { authType == 100000 || authType == 5 || authType == 6 }
    func lite() -> Bool { authType == 1 || authType == 2 }

    static func servicesRequest() throws -> [UInt8] { try WMCore.tlv(1, services) }

    func parseServices(_ body: [UInt8]) throws {
        guard let f = try Wire.unique(TlvView.decode(body), 2) else { throw WMFault("SERVICE_CAPABILITIES_MISSING") }
        serviceFlags.removeAll(); commandFlags.removeAll(); requestedCommandServices.removeAll()
        serviceFlags[1] = true
        // Phần đuôi bị thiếu giữ ở trạng thái chưa biết, không bịa thành true.
        for i in 0..<min(LinkCapabilities.services.count, f.value.count) {
            serviceFlags[Int(LinkCapabilities.services[i])] = f.value[i] != 0
        }
    }

    private static func row(_ out: inout [UInt8], _ e: (Int, [UInt8])) throws {
        out += try WMCore.tlv(2, [UInt8(e.0)])
        out += try WMCore.tlv(3, e.1)
    }

    static func commandsRequest() throws -> [UInt8] {
        var b = [UInt8]()
        for e in commandRows { try row(&b, e) }
        return try WMCore.tlv(0x81, b)
    }

    func commandsForSupportedServices() throws -> [UInt8] {
        var b = [UInt8]()
        requestedCommandServices.removeAll()
        for e in LinkCapabilities.commandRows {
            if e.0 != 1 && !hasService(e.0) { continue }
            requestedCommandServices.insert(e.0)
            try LinkCapabilities.row(&b, e)
        }
        return try WMCore.tlv(0x81, b)
    }

    func parseCommands(_ body: [UInt8]) throws {
        guard let root = try Wire.unique(TlvView.decode(body), 0x81) else {
            throw WMFault("COMMAND_CAPABILITIES_ROOT_MISSING")
        }
        var observed: [String: Bool] = [:]
        var seen = Set<Int>()
        var rowServices = [Int]()
        var rowFlags = [[UInt8]]()
        // Tag 02 thứ i ghép với tag 04 thứ i (không phải theo trường liền kề).
        for f in try TlvView.decode(root.value) {
            if f.tag == 2 {
                if f.value.count != 1 { throw WMFault("COMMAND_CAPABILITY_SERVICE_LENGTH") }
                let s = Int(f.value[0])
                if !seen.insert(s).inserted { throw WMFault("COMMAND_CAPABILITY_DUPLICATE_SERVICE") }
                rowServices.append(s)
            } else if f.tag == 4 {
                rowFlags.append(f.value)
            }
        }
        if rowServices.count != rowFlags.count { throw WMFault("COMMAND_CAPABILITY_ROW_INCOMPLETE") }
        for r in 0..<rowServices.count {
            let s = rowServices[r]
            let flags = rowFlags[r]
            if let requested = LinkCapabilities.commandMap[s],
               requestedCommandServices.isEmpty || requestedCommandServices.contains(s) {
                for i in 0..<min(requested.count, flags.count) {
                    observed["\(s):\(requested[i])"] = flags[i] != 0
                }
            }
        }
        commandFlags = observed
    }

    func parseExpand(_ body: [UInt8]) throws {
        guard let p = try Wire.unique(TlvView.decode(body), 1), p.value.count <= 512 else {
            throw WMFault("EXPAND_CAPABILITY_INVALID")
        }
        expand = p.value
    }

    func hasService(_ id: Int) -> Bool { serviceFlags[id] == true }
    func hasCommand(_ service: Int, _ command: Int) -> Bool { commandFlags["\(service):\(command)"] == true }
    func bit(_ index: Int) -> Bool {
        guard let e = expand, index >= 0, index / 8 < e.count else { return false }
        return (e[index / 8] & UInt8(1 << (index % 8))) != 0
    }

    func accountSupported() -> Bool { hasCommand(0x1a, 5) && hasCommand(0x1a, 6) }

    func accountRequest(_ id: String?) throws -> [UInt8] {
        let s = (id ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if s.utf8.count > 128 { throw WMFault("ACCOUNT_IDENTIFIER_TOO_LONG") }
        var b = try WMCore.tlv(1, s.isEmpty ? [0] : Array(s.utf8))
        if bit(172) { b += try WMCore.tlv(3, [1]) }
        return b
    }
}
