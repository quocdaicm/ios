import Foundation
import CryptoKit

/// Truyền MỘT payload BIN đã đóng băng bằng thân dịch vụ 0x28 (port từ FileTransfer.java).
///
/// Bên gọi chịu trách nhiệm: quyền (27/03), kết nối, giải mã gói, `CryptoSession.seal`, đóng khung,
/// MTU ghi socket, đối chiếu ghi↔ACK và hạn chót. Chuẩn bị byte ở đây KHÔNG đồng nghĩa với đã ghi socket,
/// cũng không chứng minh cài đặt thành công. `peerComplete` chỉ có nghĩa: 28/07 có kết quả 1 được đối chiếu rõ
/// ràng và payload cục bộ còn nguyên vẹn.
final class FileTransfer {
    static let service = 0x28
    private static let success: Int64 = 100000
    // Ngân sách xử lý cục bộ có giới hạn; cố ý không diễn giải như trường của đối phương.
    static let windowRequestBudget = 65536
    static let packetRequestBudget = 65536
    private static let integrityBlockBytes = 65536
    private static let preparedByteMultiplier: Int64 = 4
    private static let failureCodeLimit = 96

    /// Lệnh 06 có thân là byte dữ liệu thô; các lệnh điều khiển có thân TLV.
    struct Outgoing {
        let command: Int
        let encrypt: Bool
        let body: [UInt8]
    }

    private enum Stage: String {
        case new = "NEW", waitInfo = "WAIT_INFO", waitConsult = "WAIT_CONSULT", waitWindow = "WAIT_WINDOW"
        case transferring = "TRANSFERRING", waitPeerResult = "WAIT_PEER_RESULT", resultObserved = "RESULT_OBSERVED"
        case peerComplete = "PEER_COMPLETE", failed = "FAILED", closed = "CLOSED"
    }

    private struct FileIdentity {
        let key: String?
        let created: Date?
        func sameAs(_ other: FileIdentity) -> Bool {
            if key != nil || other.key != nil { return key != nil && key == other.key }
            return created == other.created
        }
    }

    private let lock = NSLock()
    private let frozen: HwtSource.Snapshot
    private let frozenFile: URL
    private var frozenIdentity: FileIdentity
    private let size: Int
    private let sha256: [UInt8]
    private let filename: [UInt8]
    private var metadata: [UInt8] = []
    private var blockHashes: [[UInt8]] = []
    private let preparedByteBudget: Int64
    private var input: FileHandle?
    private var stage: Stage = .new
    private var currentFileId = -1
    private var negotiatedUnit = 0
    private var noEncrypt = -1
    private var packetRequests = 0
    private var windowRequests = 0
    private var preparedBytes: Int64 = 0
    private var fullSnapshotChecks: Int64 = 0
    private var fullHandleChecks: Int64 = 0
    private var handleBytesRead: Int64 = 0
    private var windowHandleBytesRead: Int64 = 0
    private var complete = false
    // Chỉ giữ giá trị vô hướng; không bao giờ giữ thân gói của đối phương hay thông điệp lỗi không giới hạn.
    private var peerResultRawValue: Int?
    private var resultObservedFlag = false
    private var completionFailureCode: String?
    private var resultAckAfterFailure = false

    init(id: String, installedProtocolVersion: String, frozen: HwtSource.Snapshot) throws {
        try WMCore.resource(id, installedProtocolVersion)
        if frozen.mode != .bin { throw WMFault("FILE_TRANSFER_FROZEN_BIN_REQUIRED") }
        if frozen.size <= 0 || Int64(frozen.size) > WMCore.maxMember { throw WMFault("FILE_TRANSFER_SOURCE_SIZE_LIMIT") }
        if frozen.hash.count != 64 { throw WMFault("FILE_TRANSFER_SNAPSHOT_HASH_INVALID") }
        let hashBytes = try WMCore.unhex(frozen.hash)
        let file = frozen.file.resolvingSymlinksInPath().standardizedFileURL
        let dir = frozen.source.directory.resolvingSymlinksInPath().standardizedFileURL
        var isDirectory: ObjCBool = false
        if dir.path != file.deletingLastPathComponent().path
            || !FileManager.default.fileExists(atPath: file.path, isDirectory: &isDirectory) || isDirectory.boolValue {
            throw WMFault("FILE_TRANSFER_PRIVATE_SNAPSHOT_REQUIRED")
        }
        self.frozen = frozen
        self.size = frozen.size
        self.sha256 = hashBytes
        self.frozenFile = file
        self.frozenIdentity = try FileTransfer.readIdentity(file, expectedSize: frozen.size)
        self.filename = Array((id + "_" + installedProtocolVersion).utf8)
        self.preparedByteBudget = FileTransfer.preparedByteMultiplier * Int64(frozen.size) + Int64(WMCore.maxChunk)
        self.metadata = try FileTransfer.makeMetadata(filename: filename, size: frozen.size, id: id, version: installedProtocolVersion)
        let blocks = (frozen.size + FileTransfer.integrityBlockBytes - 1) / FileTransfer.integrityBlockBytes
        self.blockHashes = [[UInt8]](repeating: [], count: blocks)
        // HwtSource.freeze tạo bản chụp riêng, chỉ đọc; ở đây không bao giờ mở nguồn/BIN để ghi.
        do {
            guard let h = try? FileHandle(forReadingFrom: file) else { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
            input = h
            try checkSize()
            var whole = SHA256()
            fullHandleChecks += 1
            for block in 0..<blocks {
                let data = try readBlock(block)
                blockHashes[block] = WMCore.digest(data)
                whole.update(data: Data(data))
            }
            if [UInt8](whole.finalize()) != sha256 { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
            try verifyWholeSnapshot()
        } catch {
            closeInput()
            throw error
        }
    }

    // MARK: - API

    /// Siêu dữ liệu chuẩn bị đúng một lần; bên gọi gửi như 28/02 với mã hoá điều khiển thường (seal=true).
    func metadataBody() throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        try requireOpen()
        do {
            if stage != .new { throw WMFault("FILE_TRANSFER_METADATA_ALREADY_PREPARED") }
            try verifyFrozen()
            stage = .waitInfo
            return metadata
        } catch {
            fail(error)
            throw error
        }
    }

    /// Nhận thân dịch vụ 0x28 đã giải khung/giải mã. 07 được đối chiếu hợp lệ luôn nhận ACK trước,
    /// kể cả khi kết quả = 0 hoặc kiểm tra toàn vẹn cuối thất bại.
    func onPacket(command: Int, body: [UInt8]?, transactionsCrypted: Bool) throws -> [Outgoing] {
        lock.lock(); defer { lock.unlock() }
        resultObservedFlag = false
        if !(command == 0x07 && stage == .failed && resultAckAfterFailure) { try requireOpen() }
        do {
            if command < 0 || command > 255 { throw WMFault("FILE_TRANSFER_COMMAND_INVALID") }
            if packetRequests >= FileTransfer.packetRequestBudget { throw WMFault("FILE_TRANSFER_PACKET_REQUEST_BUDGET") }
            packetRequests += 1
            if command == 0x08 { return try deviceError(body) }
            try FileTransfer.checkBody(body)
            switch command {
            case 0x02: return try infoReply(try FileTransfer.fields(body))
            case 0x03: return try hashRequest(try FileTransfer.fields(body))
            case 0x04: return try consult(try FileTransfer.fields(body))
            case 0x05: return try window(try FileTransfer.fields(body), transactionsCrypted: transactionsCrypted)
            case 0x06: return []   // 06 không phải điều kiện ACK
            case 0x07: return try result(try FileTransfer.fields(body))
            default: return []     // lệnh lạ không bao giờ là ACK/hoàn tất
            }
        } catch {
            fail(error)
            throw error
        }
    }

    // MARK: - Xử lý từng lệnh

    private func infoReply(_ fields: [TlvView.Part]) throws -> [Outgoing] {
        let name = try FileTransfer.required(fields, 0x01)
        let type = try FileTransfer.metadataByteNumber(try FileTransfer.required(fields, 0x03))
        // Định danh tác vụ gốc = tên file + loại file; gói của tác vụ khác không được ảnh hưởng tác vụ này.
        if name.value != filename || type != 1 { return [] }
        try requireStage(.waitInfo)
        let assignedId = try FileTransfer.metadataByteNumber(try FileTransfer.required(fields, 0x04))
        let code = try FileTransfer.fixedNumber(try FileTransfer.required(fields, 0x7f), 4)
        if code != FileTransfer.success && code != 0 { throw WMFault("FILE_TRANSFER_INFO_ERROR_\(code)") }
        currentFileId = assignedId
        stage = .waitConsult
        return []
    }

    private func hashRequest(_ fields: [TlvView.Part]) throws -> [Outgoing] {
        try requireRegistered()
        if !(try associatedId(fields)) { return [] }
        if peerResultRawValue != nil || stage == .peerComplete || stage == .resultObserved { return [] }
        let mode = try Wire.unique(fields, 0x02)
        var checkMode = 0
        if let m = mode { checkMode = try FileTransfer.byteNumber(m) }
        if checkMode != 3 { return [] }
        let position = try hashPosition(try Wire.unique(fields, 0x04))
        try verifyFrozen()
        var hash = sha256
        if position != 0 { hash = try suffixHash(position) }
        var out = try WMCore.tlv(0x01, [UInt8(currentFileId)])
        out += try WMCore.tlv(0x03, hash)
        if position != 0 { out += try WMCore.tlv(0x04, FileTransfer.number32(Int64(position))) }
        return [Outgoing(command: 0x03, encrypt: true, body: out)]
    }

    private func consult(_ fields: [TlvView.Part]) throws -> [Outgoing] {
        try requireRegistered()
        if !(try associatedId(fields)) { return [] }
        _ = try Wire.unique(fields, 0x02)   // protocolVersion: chỉ từ chối trùng, không diễn giải
        let unit = try WMCore.number(try FileTransfer.required(fields, 0x05).value)
        if unit <= 0 || unit > Int64(WMCore.maxChunk) { throw WMFault("FILE_TRANSFER_UNIT_SIZE_INVALID") }
        let rawNoEncrypt = try Wire.unique(fields, 0x09)
        var value = 0
        if let r = rawNoEncrypt { value = try FileTransfer.byteNumber(r) }
        for tag in [0x03, 0x04, 0x06, 0x07] {
            if let observed = try Wire.unique(fields, tag) { _ = try WMCore.number(observed.value) }
        }
        if let observed08 = try Wire.unique(fields, 0x08) { _ = try FileTransfer.fixedNumber(observed08, 4) }
        let reply = Outgoing(command: 0x04, encrypt: true, body: try ackBody(acknowledgeNoEncrypt: value == 1))
        negotiatedUnit = Int(unit)
        noEncrypt = value
        if stage == .waitConsult { stage = .waitWindow }
        return [reply]
    }

    private func window(_ fields: [TlvView.Part], transactionsCrypted: Bool) throws -> [Outgoing] {
        try requireRegistered()
        if !(try optionalAssociatedId(fields)) { return [] }
        try requireDataStage()
        let offset64 = try FileTransfer.fixedNumber(try FileTransfer.required(fields, 0x02), 4)
        let count64 = try FileTransfer.fixedNumber(try FileTransfer.required(fields, 0x03), 4)
        let total = Int64(size)
        let unit64 = Int64(negotiatedUnit)
        if offset64 > total || count64 <= 0 || count64 > Int64(WMCore.maxChunk) || count64 > total - offset64
            || negotiatedUnit <= 0 || negotiatedUnit > WMCore.maxChunk
            || (count64 + unit64 - 1) / unit64 > 256 {
            throw WMFault("FILE_TRANSFER_WINDOW_INVALID")
        }
        if windowRequests >= FileTransfer.windowRequestBudget { throw WMFault("FILE_TRANSFER_WINDOW_REQUEST_BUDGET") }
        if count64 > preparedByteBudget - preparedBytes { throw WMFault("FILE_TRANSFER_PREPARED_BYTE_BUDGET") }
        windowRequests += 1
        let offset = Int(offset64), count = Int(count64)
        try checkSize()
        let beforeRead = handleBytesRead
        var data: [UInt8] = []
        do {
            data = try readWindow(offset: offset, count: count)
            windowHandleBytesRead += handleBytesRead - beforeRead
        } catch {
            windowHandleBytesRead += handleBytesRead - beforeRead
            throw error
        }
        let units = (count + negotiatedUnit - 1) / negotiatedUnit
        var outgoing: [Outgoing] = []
        outgoing.reserveCapacity(units)
        let encryptUnits = noEncrypt != 1 && transactionsCrypted
        var used = 0
        for sequence in 0..<units {
            let actual = min(negotiatedUnit, data.count - used)
            var raw = [UInt8](repeating: 0, count: actual + 6)
            raw[0] = UInt8(currentFileId & 0xff)
            raw[1] = UInt8(sequence & 0xff)   // 00..FF, đếm lại ở mỗi cửa sổ
            FileTransfer.put32(&raw, 2, Int64(offset + used))
            for i in 0..<actual { raw[6 + i] = data[used + i] }
            outgoing.append(Outgoing(command: 0x06, encrypt: encryptUnits, body: raw))
            used += actual   // khối cuối có thể ngắn hơn negotiatedUnit
        }
        try checkSize()
        preparedBytes += Int64(used)
        if offset + used == size || stage == .waitPeerResult {
            stage = .waitPeerResult
        } else {
            stage = .transferring
        }
        return outgoing
    }

    private func result(_ fields: [TlvView.Part]) throws -> [Outgoing] {
        try requireRegistered()
        if !(try associatedId(fields)) { return [] }
        let raw = try Wire.unique(fields, 0x02)
        var value: Int? = nil
        if let r = raw { value = try FileTransfer.byteNumber(r) }
        let reply = Outgoing(command: 0x07, encrypt: true, body: try ackBody(acknowledgeNoEncrypt: false))
        resultObservedFlag = true
        peerResultRawValue = value
        if completionFailureCode == nil { complete = false; stage = .resultObserved }
        if value == nil {
            resultFailure(WMFault("FILE_TRANSFER_REQUIRED_TAG_2"))
        } else if value == 0 {
            // ACK trước, giữ giá trị 0 thật cho `State.nativeResult(0)`; lỗi không bị ghi đè bởi kết quả 1 về sau.
            resultFailure(WMFault("FILE_TRANSFER_PEER_RESULT_0"))
        } else if value == 1 && completionFailureCode == nil {
            do {
                try verifyFrozen()
                complete = true
                stage = .peerComplete
            } catch {
                // Vẫn ACK; báo lỗi toàn vẹn cục bộ riêng thay vì ném trước khi gửi ACK.
                resultFailure(error)
            }
        }
        // Giá trị u8 khác chỉ là quan sát thô, không tạo trạng thái thành công.
        return [reply]
    }

    private func deviceError(_ body: [UInt8]?) throws -> [Outgoing] {
        if currentFileId < 0 { return [] }
        var decoded: [TlvView.Part] = []
        do {
            decoded = try FileTransfer.fields(body)
            guard let id = try Wire.unique(decoded, 0x01) else { return [] }
            if try FileTransfer.byteNumber(id) != currentFileId { return [] }
        } catch {
            return []   // không chứng minh được thông báo thuộc file nào
        }
        guard let rawCode = try Wire.unique(decoded, 0x7f) else { throw WMFault("FILE_TRANSFER_DEVICE_ERROR_MISSING") }
        let code = try WMCore.number(rawCode.value)
        throw WMFault("FILE_TRANSFER_DEVICE_ERROR_\(code)")
    }

    // MARK: - Dựng thân

    private static func makeMetadata(filename: [UInt8], size: Int, id: String, version: String) throws -> [UInt8] {
        var out = try WMCore.tlv(0x01, filename)
        out += try WMCore.tlv(0x02, number32(Int64(size)))
        out += try WMCore.tlv(0x03, [1])
        out += try WMCore.tlv(0x05, Array(id.utf8))
        out += try WMCore.tlv(0x06, Array(version.utf8))
        return out
    }

    private func ackBody(acknowledgeNoEncrypt: Bool) throws -> [UInt8] {
        var out = try WMCore.tlv(0x7f, FileTransfer.number32(FileTransfer.success))
        out += try WMCore.tlv(0x01, [UInt8(currentFileId & 0xff)])
        if acknowledgeNoEncrypt { out += try WMCore.tlv(0x09, [1]) }
        return out
    }

    /// Kiểm tra phạm vi cục bộ chặt hơn bản gốc (long có dấu không kiểm tra).
    private func hashPosition(_ field: TlvView.Part?) throws -> Int {
        guard let field = field else { return 0 }
        if field.value.isEmpty || field.value.count > 8 { throw WMFault("FILE_TRANSFER_HASH_POSITION_INVALID") }
        var value: UInt64 = 0
        for b in field.value { value = (value << 8) | UInt64(b) }
        if value > UInt64(size) { throw WMFault("FILE_TRANSFER_HASH_POSITION_INVALID") }
        return Int(value)
    }

    private func suffixHash(_ position: Int) throws -> [UInt8] {
        var digest = SHA256()
        var block = position / FileTransfer.integrityBlockBytes
        while block < blockHashes.count {
            let data = try verifiedBlock(block)
            let start = max(0, position - block * FileTransfer.integrityBlockBytes)
            digest.update(data: Data(data[start...]))
            block += 1
        }
        try checkSize()
        return [UInt8](digest.finalize())
    }

    // MARK: - Toàn vẹn / đọc khối

    private func verifyFrozen() throws {
        try verifyWholeSnapshot()
        fullHandleChecks += 1
        for block in 0..<blockHashes.count { _ = try verifiedBlock(block) }
        try checkSize()
    }

    private func verifyWholeSnapshot() throws {
        try checkSize()
        fullSnapshotChecks += 1
        try frozen.verify()
        try checkSize()
    }

    private func readWindow(offset: Int, count: Int) throws -> [UInt8] {
        var result = [UInt8](repeating: 0, count: count)
        let end = offset + count
        var written = 0
        var block = offset / FileTransfer.integrityBlockBytes
        let last = (end - 1) / FileTransfer.integrityBlockBytes
        while block <= last {
            let data = try verifiedBlock(block)
            let blockStart = block * FileTransfer.integrityBlockBytes
            let start = max(offset, blockStart)
            let until = min(end, blockStart + data.count)
            let length = until - start
            for i in 0..<length { result[written + i] = data[start - blockStart + i] }
            written += length
            block += 1
        }
        return result
    }

    private func verifiedBlock(_ block: Int) throws -> [UInt8] {
        let data = try readBlock(block)
        if WMCore.digest(data) != blockHashes[block] { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
        return data
    }

    private func readBlock(_ block: Int) throws -> [UInt8] {
        try checkSize()
        let offset = block * FileTransfer.integrityBlockBytes
        let want = min(FileTransfer.integrityBlockBytes, size - offset)
        guard let h = input else { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
        var data: [UInt8] = []
        data.reserveCapacity(want)
        do {
            try h.seek(toOffset: UInt64(offset))
            while data.count < want {
                guard let part = try h.read(upToCount: want - data.count), !part.isEmpty else {
                    throw WMFault("PAYLOAD_SNAPSHOT_CHANGED")
                }
                data += [UInt8](part)
                handleBytesRead += Int64(part.count)
            }
        } catch let f as WMFault { throw f } catch { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
        try checkSize()
        return data
    }

    private static func readIdentity(_ url: URL, expectedSize: Int) throws -> FileIdentity {
        // attributesOfItem dùng lstat: symlink hiện là .typeSymbolicLink ⇒ bị từ chối (tương đương NOFOLLOW_LINKS).
        guard let a = try? FileManager.default.attributesOfItem(atPath: url.path),
              (a[.type] as? FileAttributeType) == .typeRegular,
              let s = (a[.size] as? NSNumber)?.int64Value, s == Int64(expectedSize) else {
            throw WMFault("PAYLOAD_SNAPSHOT_CHANGED")
        }
        var key: String? = nil
        if let dev = a[.systemNumber] as? NSNumber, let ino = a[.systemFileNumber] as? NSNumber {
            key = "\(dev.int64Value):\(ino.uint64Value)"
        }
        return FileIdentity(key: key, created: a[.creationDate] as? Date)
    }

    private func checkSize() throws {
        let current = frozen.file.resolvingSymlinksInPath().standardizedFileURL
        if current.path != frozenFile.path { throw WMFault("PAYLOAD_SNAPSHOT_IDENTITY_CHANGED") }
        let now = try FileTransfer.readIdentity(frozenFile, expectedSize: size)
        if !frozenIdentity.sameAs(now) { throw WMFault("PAYLOAD_SNAPSHOT_IDENTITY_CHANGED") }
        guard let h = input, let end = try? h.seekToEnd(), end == UInt64(size) else { throw WMFault("PAYLOAD_SNAPSHOT_CHANGED") }
    }

    // MARK: - Phân tích TLV

    private static func checkBody(_ body: [UInt8]?) throws {
        guard let body = body, body.count <= TlvView.maxBytes else { throw WMFault("FILE_TRANSFER_BODY_INVALID") }
    }

    private static func fields(_ body: [UInt8]?) throws -> [TlvView.Part] {
        try checkBody(body)
        return try TlvView.decode(body)
    }

    private static func required(_ fields: [TlvView.Part], _ tag: Int) throws -> TlvView.Part {
        guard let v = try Wire.unique(fields, tag) else { throw WMFault("FILE_TRANSFER_REQUIRED_TAG_" + String(tag, radix: 16)) }
        return v
    }

    private static func fixedNumber(_ part: TlvView.Part, _ bytes: Int) throws -> Int64 {
        if part.value.count != bytes { throw WMFault("FILE_TRANSFER_FIELD_WIDTH_" + String(part.tag, radix: 16)) }
        return try WMCore.number(part.value)
    }

    private static func byteNumber(_ part: TlvView.Part) throws -> Int { Int(try fixedNumber(part, 1)) }

    /// metadata 03/04 đọc BE 1..4 byte không rỗng; ID file vẫn phải là u8 hợp lệ.
    private static func metadataByteNumber(_ part: TlvView.Part) throws -> Int {
        let n = try WMCore.number(part.value)
        if n > 255 { throw WMFault("FILE_TRANSFER_METADATA_U8_RANGE_" + String(part.tag, radix: 16)) }
        return Int(n)
    }

    private static func number32(_ value: Int64) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: 4)
        put32(&out, 0, value)
        return out
    }

    private static func put32(_ out: inout [UInt8], _ offset: Int, _ value: Int64) {
        out[offset] = UInt8((value >> 24) & 0xff)
        out[offset + 1] = UInt8((value >> 16) & 0xff)
        out[offset + 2] = UInt8((value >> 8) & 0xff)
        out[offset + 3] = UInt8(value & 0xff)
    }

    // MARK: - Quan sát chẩn đoán

    /// Chỉ in tag/độ dài/giá trị số/cờ khớp; không ghi tên file hay nội dung của đối phương.
    func infoReplyObservation(_ body: [UInt8]?) -> String {
        lock.lock(); defer { lock.unlock() }
        do {
            let values = try FileTransfer.fields(body)
            let name = try Wire.unique(values, 0x01)
            let match = name == nil ? "missing" : String(name!.value == filename)
            return "tags=\(TlvView.tags(values)) filename_match=\(match) type=\(scalar(values, 0x03))"
                + " assigned_file_id=\(scalar(values, 0x04)) result=\(scalar(values, 0x7f))"
        } catch {
            return "tags=unparsed diagnostic_code=\(WMCore.code(error))"
        }
    }

    private func scalar(_ values: [TlvView.Part], _ tag: Int) -> String {
        do {
            guard let v = try Wire.unique(values, tag) else { return "missing" }
            return String(try WMCore.number(v.value))
        } catch { return "invalid" }
    }

    // MARK: - Kiểm tra trạng thái

    private func requireRegistered() throws {
        if currentFileId < 0 { throw WMFault("FILE_TRANSFER_STAGE_" + stage.rawValue) }
    }

    /// Tra ID gốc: ID hợp lệ khác ⇒ không thuộc tác vụ này; thiếu/nhập nhằng ⇒ lỗi.
    private func associatedId(_ fields: [TlvView.Part]) throws -> Bool {
        try FileTransfer.byteNumber(try FileTransfer.required(fields, 0x01)) == currentFileId
    }

    private func optionalAssociatedId(_ fields: [TlvView.Part]) throws -> Bool {
        guard let id = try Wire.unique(fields, 0x01) else { return true }
        return try FileTransfer.byteNumber(id) == currentFileId
    }

    private func requireStage(_ expected: Stage) throws {
        if stage != expected { throw WMFault("FILE_TRANSFER_STAGE_" + stage.rawValue) }
    }

    private func requireDataStage() throws {
        let allowed = stage == .transferring || stage == .waitPeerResult || stage == .waitWindow
        if !allowed || currentFileId < 0 || negotiatedUnit <= 0 || noEncrypt < 0 {
            throw WMFault("FILE_TRANSFER_STAGE_" + stage.rawValue)
        }
    }

    private func requireOpen() throws {
        if stage == .closed { throw WMFault("FILE_TRANSFER_CLOSED") }
        if stage == .failed { throw WMFault("FILE_TRANSFER_FAILED") }
    }

    private func fail(_ error: Error) { terminalFailure(error, mayAcknowledgeRepeatedResults: false) }
    private func resultFailure(_ error: Error) { terminalFailure(error, mayAcknowledgeRepeatedResults: true) }

    private func terminalFailure(_ error: Error, mayAcknowledgeRepeatedResults: Bool) {
        if completionFailureCode == nil { completionFailureCode = FileTransfer.boundedFailureCode(error) }
        complete = false
        stage = .failed
        resultAckAfterFailure = mayAcknowledgeRepeatedResults
        closeInput()
    }

    private static func boundedFailureCode(_ error: Error) -> String {
        let code = WMCore.code(error)
        if code.isEmpty { return "FILE_TRANSFER_LOCAL_FAILURE" }
        var out = ""
        for u in code.unicodeScalars.prefix(failureCodeLimit) {
            let ok = (u.value >= 65 && u.value <= 90) || (u.value >= 97 && u.value <= 122) || (u.value >= 48 && u.value <= 57) || u == "_"
            out.unicodeScalars.append(ok ? u : "_")
        }
        return out
    }

    private func closeInput() {
        if let h = input { try? h.close() }
        input = nil
    }

    // MARK: - Thuộc tính công khai (chỉ đọc)

    var stateLabel: String { lock.lock(); defer { lock.unlock() }; return stage.rawValue }
    var fileId: Int { lock.lock(); defer { lock.unlock() }; return currentFileId }
    /// Tổng byte file đã chuẩn bị, gồm cả gửi lại theo yêu cầu; không phải số ACK socket.
    var bytesSentOrPrepared: Int64 { lock.lock(); defer { lock.unlock() }; return preparedBytes }
    var totalSize: Int { size }
    var peerComplete: Bool { lock.lock(); defer { lock.unlock() }; return complete }
    /// u8 thô của 07 được đối chiếu gần nhất; nil nếu chưa có hoặc 07 đó thiếu kết quả.
    var peerResultRaw: Int? { lock.lock(); defer { lock.unlock() }; return peerResultRawValue }
    /// true chỉ khi lần `onPacket` gần nhất quan sát được 07 hợp lệ thuộc file này.
    var resultObserved: Bool { lock.lock(); defer { lock.unlock() }; return resultObservedFlag }
    /// Mã lỗi kết thúc đầu tiên (≤96 ký tự an toàn).
    var completionFailure: String? { lock.lock(); defer { lock.unlock() }; return completionFailureCode }
    /// -1 trước khi thương lượng; sau đó là u8 thô (thiếu 09 ⇒ 0). Chỉ đúng bằng 1 mới tắt mã hoá.
    var lastNoEncrypt: Int { lock.lock(); defer { lock.unlock() }; return noEncrypt }
    var unitSize: Int { lock.lock(); defer { lock.unlock() }; return negotiatedUnit }
    var statsFullSnapshotChecks: Int64 { lock.lock(); defer { lock.unlock() }; return fullSnapshotChecks }
    var statsFullHandleChecks: Int64 { lock.lock(); defer { lock.unlock() }; return fullHandleChecks }
    var statsBytesReadFromFrozenHandle: Int64 { lock.lock(); defer { lock.unlock() }; return handleBytesRead }
    var statsWindowBytesReadFromFrozenHandle: Int64 { lock.lock(); defer { lock.unlock() }; return windowHandleBytesRead }
    var fileIdentityMode: String { frozenIdentity.key == nil ? "creationTimeFallback" : "fileKey" }

    /// Idempotent; chỉ đóng handle chỉ-đọc của lớp này, không xoá hay sửa payload.
    func close() {
        lock.lock(); defer { lock.unlock() }
        if stage == .closed { return }
        stage = .closed
        closeInput()
    }

    deinit { closeInput() }
}
