import Foundation

/// Lỗi giao thức (tương đương Core.Fault bên Android).
struct WMFault: Error, CustomStringConvertible {
    let code: String
    init(_ code: String) { self.code = code }
    var description: String { code }
}

/// Mã hoá/giải mã khung 0x5A của Huawei, có CRC16-XMODEM.
enum FrameCodec {
    static let maxFrame = 65540
    static let maxBody = 65536

    static func crc16(_ d: [UInt8], _ offset: Int, _ length: Int) -> Int {
        var crc = 0
        for i in offset..<(offset + length) {
            crc ^= Int(d[i]) << 8
            for _ in 0..<8 {
                crc = (crc & 0x8000) != 0 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
            }
        }
        return crc
    }

    struct Packet {
        let service: Int
        let command: Int
        let body: [UInt8]
    }

    private static func framed(control: Int, sequence: Int, data: [UInt8]) throws -> [UInt8] {
        let overhead = control == 0 ? 1 : 2
        let len = data.count + overhead
        if len > 65535 { throw WMFault("FRAME_LENGTH_LIMIT") }
        var out = [UInt8](repeating: 0, count: len + 5)
        out[0] = 0x5a
        out[1] = UInt8((len >> 8) & 0xff)
        out[2] = UInt8(len & 0xff)
        out[3] = UInt8(control & 0xff)
        var at = 4
        if control != 0 { out[at] = UInt8(sequence & 0xff); at += 1 }
        for (i, b) in data.enumerated() { out[at + i] = b }
        let crc = crc16(out, 0, out.count - 2)
        out[out.count - 2] = UInt8((crc >> 8) & 0xff)
        out[out.count - 1] = UInt8(crc & 0xff)
        return out
    }

    /// maxFrameBytes gồm cả header và CRC.
    static func encode(service: Int, command: Int, body: [UInt8], maxFrameBytes: Int) throws -> [[UInt8]] {
        if service < 0 || service > 255 || command < 0 || command > 255
            || body.count > maxBody || maxFrameBytes < 16 || maxFrameBytes > maxFrame {
            throw WMFault("FRAME_ARGUMENTS")
        }
        let logical = [UInt8(service), UInt8(command)] + body
        if body.count + 8 <= maxFrameBytes && body.count + 3 <= 65535 {
            return [try framed(control: 0, sequence: 0, data: logical)]
        }
        let unit = min(maxFrameBytes - 7, 65533)
        let count = (logical.count + unit - 1) / unit
        if count < 2 || count > 256 { throw WMFault("FRAME_SLICE_BUDGET") }
        var result: [[UInt8]] = []
        var pos = 0
        for seq in 0..<count {
            let n = min(unit, logical.count - pos)
            let control = seq == 0 ? 1 : (seq == count - 1 ? 3 : 2)
            result.append(try framed(control: control, sequence: seq, data: Array(logical[pos..<(pos + n)])))
            pos += n
        }
        return result
    }

    final class Decoder {
        private var pending: [UInt8] = []
        private var assembly: [UInt8]? = nil
        private var nextSeq = 0
        private var started: Int64 = 0
        private(set) var errors = 0
        private(set) var lastError = ""

        func clear() {
            pending = []; assembly = nil; nextSeq = 0; started = 0; errors = 0; lastError = ""
        }

        private func bad(_ why: String) {
            errors += 1; lastError = why; assembly = nil; nextSeq = 0; started = 0
        }

        /// `now` tính bằng mili giây.
        func receive(_ input: [UInt8], now: Int64) throws -> [Packet] {
            if input.count > FrameCodec.maxFrame * 2 { throw WMFault("FRAME_RX_LIMIT") }
            if assembly != nil && now - started > 15000 { bad("FRAME_ASSEMBLY_TIMEOUT") }
            if pending.count + input.count > FrameCodec.maxFrame * 3 {
                bad("FRAME_BUFFER_LIMIT"); pending = []
                throw WMFault("FRAME_BUFFER_LIMIT")
            }
            let joined = pending + input
            var cursor = 0
            var out: [Packet] = []
            while cursor < joined.count {
                if joined[cursor] != 0x5a { cursor += 1; bad("FRAME_MAGIC_RESYNC"); continue }
                if joined.count - cursor < 3 { break }
                let n = (Int(joined[cursor + 1]) << 8) | Int(joined[cursor + 2])
                let total = n + 5
                if n < 2 || total > FrameCodec.maxFrame { cursor += 1; bad("FRAME_INVALID_SIZE"); continue }
                if joined.count - cursor < total { break }
                let expected = (Int(joined[cursor + total - 2]) << 8) | Int(joined[cursor + total - 1])
                if FrameCodec.crc16(joined, cursor, total - 2) != expected {
                    cursor += 1; bad("FRAME_CRC"); continue
                }
                let frame = Array(joined[cursor..<(cursor + total)])
                cursor += total
                let control = Int(frame[3])
                if control == 0 {
                    if total < 8 { bad("FRAME_UNSLICED_SHORT"); continue }
                    if assembly != nil { bad("FRAME_UNSLICED_INTERRUPTED_SLICES") }
                    out.append(Packet(service: Int(frame[4]), command: Int(frame[5]),
                                      body: Array(frame[6..<(total - 2)])))
                    continue
                }
                if control < 1 || control > 3 || total < 7 { bad("FRAME_CONTROL"); continue }
                let seq = Int(frame[4])
                let data = Array(frame[5..<(total - 2)])
                if control == 1 {
                    if seq != 0 || data.count < 2 { bad("FRAME_FIRST_SLICE"); continue }
                    if assembly != nil { bad("FRAME_OVERLAPPING_SLICES") }
                    assembly = []; started = now; nextSeq = 0
                }
                if assembly == nil || seq != nextSeq { bad("FRAME_SLICE_SEQUENCE"); continue }
                if assembly!.count + data.count > FrameCodec.maxBody + 2 { bad("FRAME_BODY_LIMIT"); continue }
                assembly!.append(contentsOf: data)
                nextSeq += 1
                if control == 3 {
                    let logical = assembly!
                    assembly = nil; nextSeq = 0; started = 0
                    if logical.count < 2 { bad("FRAME_SLICED_SHORT"); continue }
                    out.append(Packet(service: Int(logical[0]), command: Int(logical[1]),
                                      body: Array(logical[2...])))
                }
            }
            pending = Array(joined[cursor...])
            return out
        }
    }
}
