import Foundation
import CommonCrypto
import Security

enum WMRandom {
    static func bytes(_ n: Int) -> [UInt8] {
        var b = [UInt8](repeating: 0, count: n)
        if n > 0 { _ = SecRandomCopyBytes(kSecRandomDefault, n, &b) }
        return b
    }
}

/// AES thô qua CommonCrypto (ECB không đệm, CBC + PKCS7) và PBKDF2-HMAC-SHA256.
enum AESPrimitives {
    static func ecbEncrypt(key: [UInt8], data: [UInt8]) throws -> [UInt8] {
        if data.isEmpty { return [] }
        if data.count % 16 != 0 { throw WMFault("AES_ECB_ALIGNMENT") }
        var out = [UInt8](repeating: 0, count: data.count + kCCBlockSizeAES128)
        var moved = 0
        let st = CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionECBMode),
                         key, key.count, nil, data, data.count, &out, out.count, &moved)
        if st != kCCSuccess || moved != data.count { throw WMFault("AES_ECB_FAILED") }
        return Array(out[0..<moved])
    }

    static func cbc(encrypt: Bool, key: [UInt8], iv: [UInt8], data: [UInt8]) throws -> [UInt8] {
        var out = [UInt8](repeating: 0, count: data.count + kCCBlockSizeAES128)
        var moved = 0
        let st = CCCrypt(CCOperation(encrypt ? kCCEncrypt : kCCDecrypt), CCAlgorithm(kCCAlgorithmAES),
                         CCOptions(kCCOptionPKCS7Padding), key, key.count, iv, data, data.count,
                         &out, out.count, &moved)
        if st == CCCryptorStatus(kCCDecodeError) { throw WMFault("CBC_PADDING_INVALID") }
        if st != kCCSuccess { throw WMFault("AES_CBC_FAILED") }
        return Array(out[0..<moved])
    }

    /// PBKDF2-HMAC-SHA256; mật khẩu và salt là chuỗi ASCII (hex in hoa).
    static func pbkdf2(password: String, salt: [UInt8], iterations: Int, outLength: Int) throws -> [UInt8] {
        var out = [UInt8](repeating: 0, count: outLength)
        let st = CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), password, password.utf8.count,
                                      salt, salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256),
                                      UInt32(iterations), &out, outLength)
        if st != kCCSuccess { throw WMFault("PBKDF2_UNAVAILABLE") }
        return out
    }
}

/// AES-GCM tự cài (IV độ dài bất kỳ 1..64 byte — CryptoKit chỉ hỗ trợ tốt nonce 12 byte).
/// Thuật toán đã được đối chiếu với thư viện chuẩn bằng bản mô phỏng Python.
enum AESGCMManual {
    private struct U128 { var hi: UInt64; var lo: UInt64 }

    private static func load(_ b: [UInt8]) -> U128 {
        var hi: UInt64 = 0, lo: UInt64 = 0
        for i in 0..<8 { hi = (hi << 8) | UInt64(b[i]); lo = (lo << 8) | UInt64(b[8 + i]) }
        return U128(hi: hi, lo: lo)
    }

    private static func bytes(_ v: U128) -> [UInt8] {
        var o = [UInt8](repeating: 0, count: 16)
        for i in 0..<8 {
            o[i] = UInt8((v.hi >> UInt64(56 - 8 * i)) & 0xff)
            o[8 + i] = UInt8((v.lo >> UInt64(56 - 8 * i)) & 0xff)
        }
        return o
    }

    private static func gmul(_ x: U128, _ h: U128) -> U128 {
        var zh: UInt64 = 0, zl: UInt64 = 0
        var vh = h.hi, vl = h.lo
        for i in 0..<128 {
            let bit: UInt64 = i < 64 ? (x.hi >> UInt64(63 - i)) & 1 : (x.lo >> UInt64(127 - i)) & 1
            if bit == 1 { zh ^= vh; zl ^= vl }
            let lsb = vl & 1
            vl = (vl >> 1) | ((vh & 1) << 63)
            vh >>= 1
            if lsb == 1 { vh ^= 0xE100000000000000 }
        }
        return U128(hi: zh, lo: zl)
    }

    private static func ghash(_ h: U128, _ y: inout U128, _ data: [UInt8]) {
        var i = 0
        var blk = [UInt8](repeating: 0, count: 16)
        while i < data.count {
            for j in 0..<16 { blk[j] = i + j < data.count ? data[i + j] : 0 }
            let b = load(blk)
            y = gmul(U128(hi: y.hi ^ b.hi, lo: y.lo ^ b.lo), h)
            i += 16
        }
    }

    private static func be64(_ v: UInt64) -> [UInt8] {
        (0..<8).map { UInt8((v >> UInt64(56 - 8 * $0)) & 0xff) }
    }

    private static func gctr(key: [UInt8], icb: [UInt8], data: [UInt8]) throws -> [UInt8] {
        if data.isEmpty { return [] }
        let n = (data.count + 15) / 16
        var ctr = (UInt32(icb[12]) << 24) | (UInt32(icb[13]) << 16) | (UInt32(icb[14]) << 8) | UInt32(icb[15])
        var input = [UInt8]()
        input.reserveCapacity(n * 16)
        for _ in 0..<n {
            input.append(contentsOf: icb[0..<12])
            input.append(UInt8((ctr >> 24) & 0xff)); input.append(UInt8((ctr >> 16) & 0xff))
            input.append(UInt8((ctr >> 8) & 0xff)); input.append(UInt8(ctr & 0xff))
            ctr = ctr &+ 1
        }
        let ks = try AESPrimitives.ecbEncrypt(key: key, data: input)
        var out = data
        for i in 0..<data.count { out[i] ^= ks[i] }
        return out
    }

    private static func inc32(_ b: [UInt8]) -> [UInt8] {
        var o = b
        var c = (UInt32(b[12]) << 24) | (UInt32(b[13]) << 16) | (UInt32(b[14]) << 8) | UInt32(b[15])
        c = c &+ 1
        o[12] = UInt8((c >> 24) & 0xff); o[13] = UInt8((c >> 16) & 0xff)
        o[14] = UInt8((c >> 8) & 0xff); o[15] = UInt8(c & 0xff)
        return o
    }

    private static func tag(key: [UInt8], h: U128, j0: [UInt8], aad: [UInt8], ct: [UInt8]) throws -> [UInt8] {
        var y = U128(hi: 0, lo: 0)
        ghash(h, &y, aad)
        ghash(h, &y, ct)
        ghash(h, &y, be64(UInt64(aad.count) * 8) + be64(UInt64(ct.count) * 8))
        let s = bytes(y)
        let e = try AESPrimitives.ecbEncrypt(key: key, data: j0)
        return (0..<16).map { e[$0] ^ s[$0] }
    }

    private static func setup(key: [UInt8], iv: [UInt8]) throws -> (h: U128, j0: [UInt8]) {
        let h = load(try AESPrimitives.ecbEncrypt(key: key, data: [UInt8](repeating: 0, count: 16)))
        if iv.count == 12 { return (h, iv + [0, 0, 0, 1]) }
        var y = U128(hi: 0, lo: 0)
        ghash(h, &y, iv)
        ghash(h, &y, [UInt8](repeating: 0, count: 8) + be64(UInt64(iv.count) * 8))
        return (h, bytes(y))
    }

    /// Trả về ciphertext || tag(16).
    static func seal(key: [UInt8], iv: [UInt8], plain: [UInt8], aad: [UInt8]) throws -> [UInt8] {
        let (h, j0) = try setup(key: key, iv: iv)
        let ct = try gctr(key: key, icb: inc32(j0), data: plain)
        return ct + (try tag(key: key, h: h, j0: j0, aad: aad, ct: ct))
    }

    /// Chỉ trả plaintext khi tag 128 bit khớp.
    static func open(key: [UInt8], iv: [UInt8], sealed: [UInt8], aad: [UInt8]) throws -> [UInt8] {
        if sealed.count < 16 { throw WMFault("GCM_DATA_LENGTH_INVALID") }
        let ct = Array(sealed[0..<(sealed.count - 16)])
        let got = Array(sealed[(sealed.count - 16)...])
        let (h, j0) = try setup(key: key, iv: iv)
        let want = try tag(key: key, h: h, j0: j0, aad: aad, ct: ct)
        if !HuaweiCrypto.constantTimeEquals(want, got) { throw WMFault("GCM_AUTHENTICATION_FAILED") }
        return try gctr(key: key, icb: inc32(j0), data: ct)
    }
}
