import Foundation

/// Nguồn HWT cục bộ (port từ HwtSource.java). Chỉ nhận file qua bộ chọn file của hệ thống;
/// sao chép/trích NGUYÊN byte, không sửa XML, header BIN hay mục ZIP.
final class HwtSource {
    enum Mode { case bin }
    static let maxPreviewBytes = 2 * 1024 * 1024

    let directory: URL, original: URL, resource: URL
    let bin: URL?, preview: URL?
    let sourceHash: String, resourceHash: String
    let binHash: String?, previewHash: String?
    let xmlVersion: String, screen: String, title: String
    let resourceIsZip: Bool

    private init(dir: URL, outer: URL, resource: URL, bin: URL?, zip: Bool, xml: (String, String, String), preview: URL?) throws {
        directory = dir
        original = outer
        self.resource = resource
        self.bin = bin
        resourceIsZip = zip
        sourceHash = WMCore.hex(try WMCore.digest(file: outer))
        resourceHash = WMCore.hex(try WMCore.digest(file: resource))
        if let b = bin { binHash = WMCore.hex(try WMCore.digest(file: b)) } else { binHash = nil }
        xmlVersion = xml.0
        screen = xml.1
        title = xml.2
        if let p = preview, let h = try? WMCore.digest(file: p) {
            self.preview = p
            previewHash = WMCore.hex(h)
        } else {
            self.preview = nil
            previewHash = nil
        }
    }

    // MARK: - Nạp

    /// Sao chép file người dùng chọn vào thư mục riêng của app rồi kiểm tra.
    /// `privateFiles`: thư mục riêng (ví dụ Application Support). Nếu `url` là security-scoped, gọi
    /// `startAccessingSecurityScopedResource()` trước khi gọi hàm này.
    static func load(from url: URL, privateFiles: URL) throws -> HwtSource {
        let fm = FileManager.default
        let parent = privateFiles.appendingPathComponent("local-hwt", isDirectory: true)
        do { try fm.createDirectory(at: parent, withIntermediateDirectories: true) }
        catch { throw WMFault("PRIVATE_DIRECTORY_UNAVAILABLE") }
        let dir = parent.appendingPathComponent("source-" + UUID().uuidString.lowercased(), isDirectory: true)
        do { try fm.createDirectory(at: dir, withIntermediateDirectories: false) }
        catch { throw WMFault("PRIVATE_DIRECTORY_UNAVAILABLE") }
        let outer = dir.appendingPathComponent("source.hwt")
        do {
            try copy(from: url, to: outer, max: WMCore.maxSource)
            return try inspect(outer: outer, dir: dir)
        } catch {
            try? cleanup(privateFiles: privateFiles, directory: dir)
            throw error
        }
    }

    private static func copy(from src: URL, to dst: URL, max: Int64) throws {
        guard let input = try? FileHandle(forReadingFrom: src) else { throw WMFault("FILE_OPEN_FAILED") }
        defer { try? input.close() }
        FileManager.default.createFile(atPath: dst.path, contents: nil)
        guard let output = try? FileHandle(forWritingTo: dst) else { throw WMFault("FILE_OPEN_FAILED") }
        defer { try? output.close() }
        var total: Int64 = 0
        while true {
            guard let d = try? input.read(upToCount: 65536), !d.isEmpty else { break }
            total += Int64(d.count)
            if total > max { throw WMFault("FILE_LIMIT") }
            do { try output.write(contentsOf: d) } catch { throw WMFault("FILE_WRITE_FAILED") }
        }
    }

    private static func fileSize(_ url: URL) -> Int64 {
        ((try? FileManager.default.attributesOfItem(atPath: url.path))?[.size] as? NSNumber)?.int64Value ?? -1
    }

    static func inspect(outer: URL, dir: URL) throws -> HwtSource {
        let length = fileSize(outer)
        if length <= 0 || length > WMCore.maxSource { throw WMFault("SOURCE_SIZE_LIMIT") }
        let resource = dir.appendingPathComponent("resource.data")
        var bin: URL? = nil
        var preview: URL? = nil
        var xml: (String, String, String) = ("unknown", "unknown", "HWT cục bộ")
        do {
            let zip = try ZipArchive(url: outer)
            let root = zip.entries["com.huawei.watchface"] != nil
            let snapshot = zip.entries["watchFace/com.huawei.watchface"] != nil
            if root == snapshot { throw WMFault("HWT_RESOURCE_MISSING_OR_AMBIGUOUS") }
            let prefix = root ? "" : "watchFace/"
            if let description = zip.entries[prefix + "description.xml"] {
                xml = try parseDescription(try readMember(zip, description, max: 65536))
            }
            try extract(zip, zip.entries[prefix + "com.huawei.watchface"], to: resource)
            preview = extractPreview(zip, prefix: prefix, dir: dir)
        } catch let f as WMFault {
            let zipCodes: Set<String> = ["ZIP_INVALID", "ZIP_TRUNCATED", "ZIP64_UNSUPPORTED", "ZIP_ENCRYPTED", "ZIP_METHOD_UNSUPPORTED",
                                         "ZIP_INFLATE_INIT_FAILED", "ZIP_INFLATE_FAILED", "ZIP_INFLATE_TRUNCATED"]
            throw zipCodes.contains(f.code) ? WMFault("SOURCE_NOT_READABLE_HWT") : f
        }
        let isZip = zipMagic(resource)
        if isZip {
            do {
                let inner = try ZipArchive(url: resource)
                if let e = inner.entries["watchface.bin"] {
                    let target = dir.appendingPathComponent("watchface.bin")
                    try extract(inner, e, to: target)
                    bin = target
                }
            } catch let f as WMFault {
                if f.code.hasPrefix("ZIP") { throw WMFault("INNER_RESOURCE_ZIP_INVALID") }
                throw f
            }
        } else {
            bin = resource
        }
        return try HwtSource(dir: dir, outer: outer, resource: resource, bin: bin, zip: isZip, xml: xml, preview: preview)
    }

    // MARK: - Xem trước (tuỳ chọn)

    /// Xem trước là đường phụ: lỗi không ảnh hưởng việc trích tài nguyên hay payload gốc.
    private static func extractPreview(_ zip: ZipArchive, prefix: String, dir: URL) -> URL? {
        let candidates = ["preview/cover.jpg", "preview/cover.jpeg", "preview/cover.png", "preview/cover.webp", "preview/cover.gif",
                          "preview/preview.png", "preview/preview.jpg", "preview/preview.jpeg", "preview/preview.webp", "preview/preview.gif",
                          "preview.png", "preview.jpg", "preview.jpeg", "preview.webp", "preview.gif",
                          "cover.png", "cover.jpg", "cover.jpeg", "cover.webp",
                          "preview/icon_small.png", "preview/icon_small.jpg", "preview/icon_small.jpeg", "preview/icon_small.webp"]
        for candidate in candidates {
            let wanted = (prefix + candidate).lowercased()
            var found: ZipArchive.Entry? = nil
            var ambiguous = false
            for (name, entry) in zip.entries where name.lowercased() == wanted {
                if found != nil { ambiguous = true; break }
                found = entry
            }
            guard let e = found, !ambiguous, !e.isDirectory, e.size > 0, e.size <= Int64(maxPreviewBytes) else { continue }
            if e.compressedSize > 0 && e.size > e.compressedSize * 500 { continue }
            guard let bytes = try? zip.read(e, max: maxPreviewBytes), Int64(bytes.count) == e.size, previewMagic(bytes) else { continue }
            let out = dir.appendingPathComponent("preview.image")
            if (try? Data(bytes).write(to: out)) != nil { return out }
        }
        return nil
    }

    private static func previewMagic(_ b: [UInt8]) -> Bool {
        if b.count >= 8 && b[0] == 137 && b[1] == 80 && b[2] == 78 && b[3] == 71 && b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10 { return true }
        if b.count >= 3 && b[0] == 255 && b[1] == 216 && b[2] == 255 { return true }
        if b.count >= 12 && b[0] == 82 && b[1] == 73 && b[2] == 70 && b[3] == 70 && b[8] == 87 && b[9] == 69 && b[10] == 66 && b[11] == 80 { return true }
        return b.count >= 6 && b[0] == 71 && b[1] == 73 && b[2] == 70 && b[3] == 56 && (b[4] == 55 || b[4] == 57) && b[5] == 97
    }

    // MARK: - ZIP phụ trợ

    private static func readMember(_ zip: ZipArchive, _ e: ZipArchive.Entry, max: Int) throws -> [UInt8] {
        if e.isDirectory || e.size <= 0 || e.size > Int64(max) { throw WMFault("DESCRIPTION_SIZE_LIMIT") }
        do { return try zip.read(e, max: max) }
        catch let f as WMFault { throw f.code == "ZIP_CRC" ? WMFault("DESCRIPTION_CRC") : f }
    }

    private static func extract(_ zip: ZipArchive, _ e: ZipArchive.Entry?, to url: URL) throws {
        guard let e = e, !e.isDirectory, e.size > 0, e.size <= WMCore.maxMember else { throw WMFault("RESOURCE_SIZE_LIMIT") }
        if e.compressedSize > 0 && e.size > e.compressedSize * 500 { throw WMFault("ZIP_EXPANSION_LIMIT") }
        try zip.extract(e, to: url, maxBytes: WMCore.maxMember)
    }

    private static func zipMagic(_ url: URL) -> Bool {
        guard let h = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? h.close() }
        guard let d = try? h.read(upToCount: 4), d.count == 4 else { return false }
        let b = [UInt8](d)
        if b[0] != 80 || b[1] != 75 { return false }
        return (b[2] == 3 && b[3] == 4) || (b[2] == 5 && b[3] == 6) || (b[2] == 7 && b[3] == 8)
    }

    // MARK: - description.xml

    private final class DescriptionParser: NSObject, XMLParserDelegate {
        var depth = 0
        var rootName: String?
        var fields: [String: String] = [:]
        var current: String?
        var text = ""
        var fault: WMFault?

        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String] = [:]) {
            depth += 1
            if depth == 1 { rootName = name; return }
            if depth == 2 {
                guard ["version", "screen", "title"].contains(name) else { return }
                if fields[name] != nil { fault = WMFault("DESCRIPTION_DUPLICATE_FIELD"); parser.abortParsing(); return }
                current = name
                text = ""
                fields[name] = ""
                return
            }
            // Phần tử con bên trong trường: chỉ cấm với tên ta cần.
            if let c = current, ["version", "screen", "title"].contains(c) {
                fault = WMFault("DESCRIPTION_NESTED_FIELD"); parser.abortParsing()
            }
        }
        func parser(_ parser: XMLParser, foundCharacters string: String) { if depth == 2 { text += string } }
        func parser(_ parser: XMLParser, foundCDATA CDATABlock: Data) {
            if depth == 2, let s = String(data: CDATABlock, encoding: .utf8) { text += s }
        }
        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
            if depth == 2, current == name { fields[name] = text; current = nil }
            depth -= 1
        }
    }

    private static func parseDescription(_ bytes: [UInt8]) throws -> (String, String, String) {
        let text = try WMCore.utf8(bytes)
        let upper = text.uppercased()
        if upper.contains("<!DOCTYPE") || upper.contains("<!ENTITY") { throw WMFault("XML_DTD_FORBIDDEN") }
        let parser = XMLParser(data: Data(bytes))
        parser.shouldResolveExternalEntities = false
        parser.shouldProcessNamespaces = false
        let delegate = DescriptionParser()
        parser.delegate = delegate
        let ok = parser.parse()
        if let f = delegate.fault { throw f }
        if !ok { throw WMFault("DESCRIPTION_XML_INVALID") }
        if delegate.rootName != "HwTheme" { throw WMFault("DESCRIPTION_ROOT_UNSUPPORTED") }
        func field(_ name: String, _ fallback: String) -> String {
            guard var v = delegate.fields[name] else { return fallback }
            v = v.trimmingCharacters(in: .whitespacesAndNewlines)
            if v.count > 160 { v = String(v.prefix(160)) }
            return v.isEmpty ? fallback : WMCore.clean(v)
        }
        return (field("version", "unknown"), field("screen", "unknown"), field("title", "HWT cục bộ"))
    }

    // MARK: - Đóng băng payload

    final class Snapshot {
        let source: HwtSource
        let file: URL
        let size: Int
        let hash: String
        let mode: Mode
        init(source: HwtSource, file: URL, size: Int, hash: String, mode: Mode) {
            self.source = source; self.file = file; self.size = size; self.hash = hash; self.mode = mode
        }
        func verify() throws {
            if HwtSource.fileSize(file) != Int64(size) || WMCore.hex(try WMCore.digest(file: file)) != hash {
                throw WMFault("PAYLOAD_SNAPSHOT_CHANGED")
            }
        }
    }

    /// Sao chép `watchface.bin` thành bản đóng băng chỉ-đọc, kiểm tra băm trùng với lúc nạp.
    func freeze(_ mode: Mode) throws -> Snapshot {
        guard let input = bin else { throw WMFault("ROOT_WATCHFACE_BIN_MISSING") }
        let file = directory.appendingPathComponent("payload-" + UUID().uuidString.lowercased() + ".bin")
        try HwtSource.copy(from: input, to: file, max: WMCore.maxMember)
        let count = HwtSource.fileSize(file)
        let hash = WMCore.hex(try WMCore.digest(file: file))
        if count <= 0 || count != HwtSource.fileSize(input) || hash != binHash { throw WMFault("SOURCE_CHANGED_DURING_FREEZE") }
        do { try FileManager.default.setAttributes([.posixPermissions: 0o400], ofItemAtPath: file.path) }
        catch { throw WMFault("PRIVATE_PAYLOAD_READONLY_FAILED") }
        return Snapshot(source: self, file: file, size: Int(count), hash: hash, mode: mode)
    }

    // MARK: - Dọn dẹp

    /// Chỉ xoá thư mục con trực tiếp do app tạo (`source-<uuid>`); không bao giờ dùng đường dẫn bên ngoài.
    static func cleanup(privateFiles: URL, directory: URL) throws {
        let fm = FileManager.default
        let parent = privateFiles.appendingPathComponent("local-hwt", isDirectory: true).resolvingSymlinksInPath()
        let target = directory.resolvingSymlinksInPath()
        let name = target.lastPathComponent
        if target.deletingLastPathComponent().path != parent.path
            || name.range(of: "^source-[0-9a-f-]{36}$", options: .regularExpression) == nil {
            throw WMFault("CLEANUP_PATH_REJECTED")
        }
        guard fm.fileExists(atPath: target.path) else { return }
        guard let children = try? fm.contentsOfDirectory(at: target, includingPropertiesForKeys: [.isDirectoryKey]) else {
            throw WMFault("CLEANUP_FAILED")
        }
        for child in children {
            let resolved = child.resolvingSymlinksInPath()
            let isDir = (try? child.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if resolved.deletingLastPathComponent().path != target.path || isDir { throw WMFault("CLEANUP_PATH_REJECTED") }
            // Payload đóng băng là chỉ-đọc: cho phép ghi lại trước khi xoá.
            try? fm.setAttributes([.posixPermissions: 0o600], ofItemAtPath: child.path)
            do { try fm.removeItem(at: child) } catch { throw WMFault("CLEANUP_FAILED") }
        }
        do { try fm.removeItem(at: target) } catch { throw WMFault("CLEANUP_FAILED") }
    }
}
