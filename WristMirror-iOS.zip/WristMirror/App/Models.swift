import Foundation

// ============================================================================
// Port từ AppModels.kt (Phần 7). Đã bỏ: Uri (Android), UpdateInfo/cập nhật app, huỷ ghép nối hệ thống.
// Khoá thiết bị = UUID của CBPeripheral (chuỗi viết hoa) — Java gọi là "address"/MAC.
// ============================================================================

enum ThemeMode: String { case system, light, dark }

struct NearbyWatch: Equatable, Identifiable {
    /// UUID CBPeripheral viết hoa.
    let address: String
    let name: String
    let bonded: Bool
    var rssi: Int? = nil
    var transport: String = "BLE"
    var likelyHuawei: Bool = true
    var id: String { address }
    var addressLabel: String { address.trimmingCharacters(in: .whitespaces).isEmpty ? "Chưa có mã thiết bị" : address }
}

/// Đồng hồ đã từng READY; không phản ánh trạng thái ghép nối hệ thống hiện tại.
struct SavedWatch: Equatable, Identifiable {
    let address: String
    let name: String
    var transport: String = "BLE"
    var lastConnectedAt: Int64 = 0
    /// Model đọc tin cậy đầu tiên (không bao giờ bị ghi đè).
    var model: String? = nil
    /// Số serial đọc tin cậy đầu tiên.
    var serialNumber: String? = nil
    var id: String { address }
    func nearby() -> NearbyWatch { NearbyWatch(address: address, name: name, bonded: false, transport: transport) }
}

struct FaceItem: Equatable, Identifiable {
    let id: String
    let version: String
    let rawType: Int64
    let expandType: Int64?
    var name: String? = nil
    var current = false
    var selectable = false
    var kind = "Chưa xác định loại"
    var activatable = false

    var title: String {
        switch kind {
        case "Sticker vui", "Mặt đồng hồ ảnh", "Mặt đồng hồ video": return kind
        default:
            if let n = name, !n.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return n }
            return "Mặt đồng hồ \(id)"
        }
    }
}

struct SourceInfo: Equatable {
    let title: String
    let fileName: String
    let sourceBytes: Int64
    let payloadBytes: Int
    let xmlVersion: String
    let sha256: String
    var previewPath: String? = nil
    var previewSha256: String? = nil
}

struct OperationInfo: Equatable {
    var kind = ""
    var stage = ""
    var detail = ""
    var progress: Int? = nil
    var active = false
    var failed = false
}

/// Ảnh chụp hiển thị của phiên thay/xoá/bật; `token` là danh tính cục bộ không đổi theo tiến độ.
struct ReplacementDialogInfo: Equatable {
    let token: Int64
    let connectionEpoch: Int
    let targetId: String
    let targetVersion: String
    let title: String
    let fileName: String
    let operation: OperationInfo
    var interruptRequested = false
}

/// Chỉ bảo vệ token giao diện và quyền đóng; không thay thế kiểm tra danh tính/thế hệ/giao thức của runtime.
enum ReplacementDialogPolicy {
    static func canInterrupt(_ dialog: ReplacementDialogInfo?, token: Int64) -> Bool {
        guard let d = dialog else { return false }
        return d.operation.kind == "replacement" && d.token == token && d.operation.active && !d.interruptRequested
    }
    static func canDismiss(_ dialog: ReplacementDialogInfo?, token: Int64) -> Bool {
        guard let d = dialog else { return false }
        return d.token == token && !d.operation.active
    }
}

struct ActionPrompt: Equatable {
    let token: Int64
    let kind: String
    let title: String
    let message: String
    let destructive: Bool
    let positiveLabel: String
    var negativeLabel = "Huỷ"
}

struct AppUiState {
    var theme: ThemeMode = .system
    var scanning = false
    var devices: [NearbyWatch] = []
    var savedDevices: [SavedWatch] = []
    var autoConnect = false
    var introductionPending = false
    var appVersion = "1.0.1"
    var selectedDeviceAddress: String? = nil
    var connectionFormRevision: Int64 = 0
    // Giá trị đang soạn chỉ nằm trong bộ nhớ tiến trình, không vào preferences hay nhật ký.
    var huaweiIdInput = ""
    var phaseCode = "IDLE"
    var connectionEpoch = 0
    var phase = "Chưa kết nối"
    var detail = "Quét thiết bị, nhập Huawei ID rồi kết nối"
    var connected = false
    var connecting = false
    var watchName = ""
    var deviceAddress = ""
    var serialNumber = "Không rõ"
    var firmware = "Không rõ"
    var deviceModel: String? = nil
    var batteryPercent: Int? = nil
    var freeMemoryBytes: Int64? = nil
    var width: Int? = nil
    var height: Int? = nil
    var capability: Int64? = nil
    var faces: [FaceItem] = []
    var listReady = false
    var listRefreshing = false
    var selectedId: String? = nil
    var source: SourceInfo? = nil
    var pickingHwt = false
    var operation = OperationInfo()
    var replacementDialog: ReplacementDialogInfo? = nil
    var deletionDialog: ReplacementDialogInfo? = nil
    var activationDialog: ReplacementDialogInfo? = nil
    var prompt: ActionPrompt? = nil
    var needsPin = false
    var pinMessage = "Hãy xác nhận ghép nối trên đồng hồ rồi nhập mã hiển thị"
    var accountConfigured = false
    var huaweiIdDirty = false
    /// iOS không huỷ ghép nối hệ thống được; chỉ cờ "đang xoá dữ liệu cục bộ".
    var removing = false
    var rebindCount = 0
    var quarantine = false
    var logs: [String] = []
    var statusMessage = ""
    var noticeSerial: Int64 = 0
    var noticeMessage = ""

    /// Runtime chỉ giữ một phiên thao tác hiển thị; giao diện dùng chung một cổng modal.
    var operationDialog: ReplacementDialogInfo? { replacementDialog ?? deletionDialog ?? activationDialog }
}

/// Ranh giới thao tác của giao diện (Java: interface AppActions). Các hàm có mặc định = no-op như bản Kotlin.
protocol AppActions: AnyObject {
    func setTheme(_ mode: ThemeMode)
    func scan()
    func stopScan()
    func selectDevice(_ device: NearbyWatch)
    func setHuaweiId(_ value: String)
    func saveHuaweiId()
    /// Chuỗi rỗng = chưa cấu hình; nil = không đọc được / không thao tác được.
    func readHuaweiIdForDevice(_ device: NearbyWatch) -> String?
    func saveHuaweiIdForDevice(_ device: NearbyWatch, value: String) -> Bool
    func setAutoConnect(_ enabled: Bool)
    func introductionInteractionIsCurrent() -> Bool
    func acknowledgeIntroduction() -> Bool
    func connect(_ device: NearbyWatch, huaweiId: String)
    func disconnect()
    /// Xoá dữ liệu cục bộ của đồng hồ (iOS: người dùng tự "Forget This Device" trong Cài đặt > Bluetooth).
    func requestRemoval(_ device: NearbyWatch)
    func submitPin(expectedEpoch: Int, pin: String)
    func cancelPin(expectedEpoch: Int)
    func refreshFaces()
    func selectFace(_ id: String)
    func prepareHwtPick() -> Bool
    func cancelHwtPick()
    func importHwt(_ url: URL)
    func requestReplacement()
    func requestReplacement(face: FaceItem, epoch: Int)
    func requestActivation(face: FaceItem, epoch: Int)
    func requestDeletion(face: FaceItem, epoch: Int)
    func interruptReplacement(token: Int64)
    func dismissReplacementResult(token: Int64)
    func requestActivation()
    func dismissActivationResult(token: Int64)
    func requestDeletion()
    func dismissDeletionResult(token: Int64)
    func confirmAction(token: Int64)
    func dismissAction(token: Int64)
    func exportLogs(to url: URL)
    func clearLogs()
    func clearCache()
}

extension AppActions {
    func introductionInteractionIsCurrent() -> Bool { false }
    func acknowledgeIntroduction() -> Bool { false }
    func requestReplacement(face: FaceItem, epoch: Int) {}
    func requestActivation(face: FaceItem, epoch: Int) {}
    func requestDeletion(face: FaceItem, epoch: Int) {}
    func interruptReplacement(token: Int64) {}
    func dismissReplacementResult(token: Int64) {}
    func requestActivation() {}
    func dismissActivationResult(token: Int64) {}
    func dismissDeletionResult(token: Int64) {}
}
