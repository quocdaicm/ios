import Foundation
import UIKit

// ============================================================================
// Port từ AppRuntime.java (Phần 7).
// Trạng thái chạy trong tiến trình, dùng chung giữa giao diện và kết nối. Là listener của cả
// WatchConnection lẫn WatchfaceManager, gom lại thành `Snapshot` bất biến phát cho các Observer.
//
// Khác biệt so với bản Java:
//  - `synchronized` → NSRecursiveLock (`sync { }`). Observer được gọi trên luồng bất kỳ: giao diện
//    (Phần 8) PHẢI chuyển về main (`DispatchQueue.main.async`) trước khi đụng @Published.
//  - Bỏ DeviceRemovalController/AndroidSystemUnpair/ConnectionService. Thay bằng `removeDevice(_:)`
//    (chặn → dừng kết nối → xoá Keychain → xoá lịch sử → thả chặn). iOS không huỷ ghép nối hệ thống được.
//  - `names`, `visible` giữ nguyên ngữ nghĩa; Snapshot là struct (giá trị).
//  - Chuỗi hiển thị dịch sang tiếng Việt.
// ============================================================================

protocol AppRuntimeObserver: AnyObject {
    func changed(_ state: AppRuntime.Snapshot)
    func rebindRequested(_ message: String)
    func deletionPrepared(_ face: TlvView.Face, epoch: Int)
}

final class AppRuntime: WatchConnectionListener, WatchfaceManagerListener {
    static let shared = AppRuntime()

    struct Snapshot {
        let code: String, detail: String, deviceAddress: String, serialNumber: String, firmware: String
        let deviceModel: String?
        let kind: String, stage: String, operationDetail: String, message: String, pinMessage: String
        let ready: Bool, connecting: Bool, needsPin: Bool, listReady: Bool, listRefreshing: Bool, active: Bool, failed: Bool
        let rebind: Int
        let epoch: Int, generation: Int64
        let operationRevision: Int64, replacementDialogRevision: Int64, deletionDialogRevision: Int64, activationDialogRevision: Int64
        let replacementIdentity: WatchfaceManager.ReplacementIdentity?, replacementDialogIdentity: WatchfaceManager.ReplacementIdentity?
        let deletionIdentity: WatchfaceManager.DeletionIdentity?, deletionDialogIdentity: WatchfaceManager.DeletionIdentity?
        let activationIdentity: WatchfaceManager.ActivationIdentity?, activationDialogIdentity: WatchfaceManager.ActivationIdentity?
        let replacementDialog: ReplacementDialogInfo?, deletionDialog: ReplacementDialogInfo?, activationDialog: ReplacementDialogInfo?
        let width: Int?, height: Int?, progress: Int?, batteryPercent: Int?
        let capability: Int64?, freeMemoryBytes: Int64?
        let faces: [TlvView.Face]
        let names: [String: String]
    }

    let secure: SecureStore
    let logs: SafeLog
    let connection: WatchConnection
    let watchfaces: WatchfaceManager
    let history: SavedWatchStore

    /// Móc thay ConnectionService.runtimeState(kết nối/đang thao tác, đang thao tác, mã).
    var onRuntimeState: ((_ linked: Bool, _ operating: Bool, _ code: String) -> Void)?

    private let lock = NSRecursiveLock()
    private struct WeakObserver { weak var ref: AppRuntimeObserver? }
    private var observers: [WeakObserver] = []

    private var code = "IDLE", detail = "Chưa kết nối", deviceAddress = "", serialNumber = "Không rõ", firmware = "Không rõ"
    private var kind = "", stage = "", operationDetail = "", message = "", pinMessage = ""
    private var deviceModel: String?
    private var ready = false, connecting = false, needsPin = false, listReady = false, listRefreshing = false, active = false, failed = false
    private var rebind = 0
    private var epoch = 0
    private var generation: Int64 = 0
    private var operationRevision: Int64 = 0, replacementDialogRevision: Int64 = 0, deletionDialogRevision: Int64 = 0, activationDialogRevision: Int64 = 0
    private var width: Int?, height: Int?, progress: Int?, batteryPercent: Int?
    private var capability: Int64?, freeMemoryBytes: Int64?
    private var replacementIdentity: WatchfaceManager.ReplacementIdentity?
    private var deletionIdentity: WatchfaceManager.DeletionIdentity?
    private var activationIdentity: WatchfaceManager.ActivationIdentity?
    // Phiên trong tiến trình chỉ giữ tiêu đề/tên file và danh tính cục bộ bất biến; không giữ URL, tài khoản, khoá.
    private var replacementRequest: WatchfaceManager.ReplacementRequest?
    private var deletionRequest: WatchfaceManager.DeletionRequest?
    private var activationRequest: WatchfaceManager.ActivationRequest?
    private var replacementDialog: ReplacementDialogInfo?, deletionDialog: ReplacementDialogInfo?, activationDialog: ReplacementDialogInfo?
    // Đóng giao diện không xoá lịch sử gốc; tóm tắt cũ đến muộn không được mở lại phiên đã đóng/nhường chỗ.
    private var retiredDialogTokens = Set<Int64>()
    private var visible: [TlvView.Face] = []
    private var names: [String: String] = [:]

    private init() {
        let secure = SecureStore()
        let logs = SafeLog()
        let connection = WatchConnection(store: secure, log: logs, deviceModel: UIDevice.current.model)
        self.secure = secure
        self.logs = logs
        self.connection = connection
        self.watchfaces = WatchfaceManager(connection: connection, log: logs)
        self.history = SavedWatchStore(removals: secure.removals)
        connection.setListener(self)
        watchfaces.setListener(self)
        let history = self.history
        connection.setKnownDeviceModelGuard { address in
            history.devices().contains { $0.address.caseInsensitiveCompare(address) == .orderedSame && $0.model != nil }
        }
        let removals = secure.removals
        connection.setPendingRemovalGuard { address in removals.blocked(address) }
    }

    private func sync<T>(_ body: () -> T) -> T {
        lock.lock(); defer { lock.unlock() }
        return body()
    }

    private func removalBlocksCurrent() -> Bool { secure.removals.blocked(connection.address) }

    func snapshot() -> Snapshot { sync { makeSnapshot() } }

    private func makeSnapshot() -> Snapshot {
        Snapshot(code: code, detail: detail, deviceAddress: deviceAddress, serialNumber: serialNumber, firmware: firmware,
                 deviceModel: deviceModel, kind: kind, stage: stage, operationDetail: operationDetail, message: message, pinMessage: pinMessage,
                 ready: ready, connecting: connecting, needsPin: needsPin, listReady: listReady, listRefreshing: listRefreshing,
                 active: active, failed: failed, rebind: rebind, epoch: epoch, generation: generation,
                 operationRevision: operationRevision, replacementDialogRevision: replacementDialogRevision,
                 deletionDialogRevision: deletionDialogRevision, activationDialogRevision: activationDialogRevision,
                 replacementIdentity: replacementIdentity, replacementDialogIdentity: replacementRequest?.identity,
                 deletionIdentity: deletionIdentity, deletionDialogIdentity: deletionRequest?.identity,
                 activationIdentity: activationIdentity, activationDialogIdentity: activationRequest?.identity,
                 replacementDialog: replacementDialog, deletionDialog: deletionDialog, activationDialog: activationDialog,
                 width: width, height: height, progress: progress, batteryPercent: batteryPercent,
                 capability: capability, freeMemoryBytes: freeMemoryBytes, faces: visible, names: names)
    }

    // MARK: Observer

    func addObserver(_ o: AppRuntimeObserver) {
        let snap: Snapshot = sync {
            observers.removeAll { $0.ref == nil }
            if !observers.contains(where: { $0.ref === o }) { observers.append(WeakObserver(ref: o)) }
            return makeSnapshot()
        }
        o.changed(snap)
    }

    func removeObserver(_ o: AppRuntimeObserver) {
        sync { observers.removeAll { $0.ref == nil || $0.ref === o } }
    }

    private func currentObservers() -> [AppRuntimeObserver] { observers.compactMap { $0.ref } }

    private static func activeDialog(_ d: ReplacementDialogInfo?) -> Bool { d?.operation.active ?? false }
    private func activeOperationDialog() -> Bool {
        AppRuntime.activeDialog(replacementDialog) || AppRuntime.activeDialog(deletionDialog) || AppRuntime.activeDialog(activationDialog)
    }

    /// Gọi khi đã giữ khoá.
    private func publish() {
        let s = makeSnapshot()
        for o in currentObservers() { o.changed(s) }
        onRuntimeState?(s.connecting || s.ready,
                        s.active || AppRuntime.activeDialog(s.replacementDialog) || AppRuntime.activeDialog(s.deletionDialog) || AppRuntime.activeDialog(s.activationDialog),
                        s.code)
    }

    // MARK: Phiên thao tác (dialog)

    /// Retire các phiên cũ trong cùng một lần phát để getter dùng chung không để kết quả thay cũ che xoá mới.
    private func retireDialogSessions() {
        if let d = replacementDialog { retiredDialogTokens.insert(d.token); replacementDialog = nil; replacementRequest = nil; replacementDialogRevision += 1 }
        if let d = deletionDialog { retiredDialogTokens.insert(d.token); deletionDialog = nil; deletionRequest = nil; deletionDialogRevision += 1 }
        if let d = activationDialog { retiredDialogTokens.insert(d.token); activationDialog = nil; activationRequest = nil; activationDialogRevision += 1 }
    }

    private func installReplacementDialog(_ request: WatchfaceManager.ReplacementRequest, _ title: String, _ fileName: String) {
        retireDialogSessions()
        replacementRequest = request
        let id = request.identity
        replacementDialog = ReplacementDialogInfo(token: id.token, connectionEpoch: id.epoch, targetId: id.id, targetVersion: id.version,
                                                  title: title, fileName: fileName,
                                                  operation: OperationInfo(kind: "replacement", stage: "WAIT_OPERATION", detail: "Đang bắt đầu thay thế", progress: nil, active: true, failed: false),
                                                  interruptRequested: false)
        replacementDialogRevision += 1
    }

    private func installDeletionDialog(_ request: WatchfaceManager.DeletionRequest, _ title: String) {
        retireDialogSessions()
        deletionRequest = request
        let id = request.identity
        deletionDialog = ReplacementDialogInfo(token: id.token, connectionEpoch: id.epoch, targetId: id.id, targetVersion: id.version,
                                               title: title, fileName: "",
                                               operation: OperationInfo(kind: "deletion", stage: "WAIT_OPERATION", detail: "Đang bắt đầu xoá", progress: nil, active: true, failed: false),
                                               interruptRequested: false)
        deletionDialogRevision += 1
    }

    private func installActivationDialog(_ request: WatchfaceManager.ActivationRequest, _ title: String) {
        retireDialogSessions()
        activationRequest = request
        let id = request.identity
        activationDialog = ReplacementDialogInfo(token: id.token, connectionEpoch: id.epoch, targetId: id.id, targetVersion: id.version,
                                                 title: title, fileName: "",
                                                 operation: OperationInfo(kind: "activation", stage: "WAIT_OPERATION", detail: "Đang bật mặt đồng hồ", progress: nil, active: true, failed: false),
                                                 interruptRequested: false)
        activationDialogRevision += 1
    }

    func openActivationDialog(_ request: WatchfaceManager.ActivationRequest?, title: String) -> Bool {
        sync {
            guard let request = request, request !== activationRequest, !retiredDialogTokens.contains(request.identity.token),
                  !activeOperationDialog() else { return false }
            installActivationDialog(request, title)
            publish()
            return true
        }
    }

    /// Xác nhận tạo ngay WAIT_OPERATION; tóm tắt LISTED cũ không được "cho mượn" cho yêu cầu mới chưa vào actor.
    func openReplacementDialog(_ request: WatchfaceManager.ReplacementRequest?, title: String, fileName: String) -> Bool {
        sync {
            guard let request = request, request !== replacementRequest, !retiredDialogTokens.contains(request.identity.token),
                  !activeOperationDialog() else { return false }
            installReplacementDialog(request, title, fileName)
            publish()
            return true
        }
    }

    func openDeletionDialog(_ request: WatchfaceManager.DeletionRequest?, title: String) -> Bool {
        sync {
            guard let request = request, request !== deletionRequest, !retiredDialogTokens.contains(request.identity.token),
                  !activeOperationDialog() else { return false }
            installDeletionDialog(request, title)
            publish()
            return true
        }
    }

    private func ownsReplacementDialog(_ identity: WatchfaceManager.ReplacementIdentity?) -> Bool {
        guard let identity = identity, let req = replacementRequest, req.identity === identity, let d = replacementDialog else { return false }
        return d.operation.kind == "replacement" && d.token == identity.token && d.connectionEpoch == identity.epoch
            && d.targetId == identity.id && d.targetVersion == identity.version
    }

    private func updateReplacementDialog(_ identity: WatchfaceManager.ReplacementIdentity, _ stage: String, _ detail: String, _ progress: Int?, _ active: Bool, _ failed: Bool) {
        guard ownsReplacementDialog(identity), let old = replacementDialog else { return }
        replacementDialog = ReplacementDialogInfo(token: old.token, connectionEpoch: old.connectionEpoch, targetId: old.targetId, targetVersion: old.targetVersion,
                                                  title: old.title, fileName: old.fileName,
                                                  operation: OperationInfo(kind: "replacement", stage: stage, detail: detail, progress: progress, active: active, failed: failed),
                                                  interruptRequested: old.interruptRequested)
        replacementDialogRevision += 1
    }

    private func ownsDeletionDialog(_ identity: WatchfaceManager.DeletionIdentity?) -> Bool {
        guard let identity = identity, let req = deletionRequest, req.identity === identity, let d = deletionDialog else { return false }
        return d.operation.kind == "deletion" && d.token == identity.token && d.connectionEpoch == identity.epoch
            && d.targetId == identity.id && d.targetVersion == identity.version
    }

    private func updateDeletionDialog(_ identity: WatchfaceManager.DeletionIdentity, _ stage: String, _ detail: String, _ progress: Int?, _ active: Bool, _ failed: Bool) {
        guard ownsDeletionDialog(identity), let old = deletionDialog else { return }
        deletionDialog = ReplacementDialogInfo(token: old.token, connectionEpoch: old.connectionEpoch, targetId: old.targetId, targetVersion: old.targetVersion,
                                               title: old.title, fileName: "",
                                               operation: OperationInfo(kind: "deletion", stage: stage, detail: detail, progress: progress, active: active, failed: failed),
                                               interruptRequested: false)
        deletionDialogRevision += 1
    }

    private func ownsActivationDialog(_ identity: WatchfaceManager.ActivationIdentity?) -> Bool {
        guard let identity = identity, let req = activationRequest, req.identity === identity, let d = activationDialog else { return false }
        return d.operation.kind == "activation" && d.token == identity.token && d.connectionEpoch == identity.epoch
            && d.targetId == identity.id && d.targetVersion == identity.version
    }

    private func updateActivationDialog(_ identity: WatchfaceManager.ActivationIdentity, _ stage: String, _ detail: String, _ active: Bool, _ failed: Bool) {
        guard ownsActivationDialog(identity), let old = activationDialog else { return }
        activationDialog = ReplacementDialogInfo(token: old.token, connectionEpoch: old.connectionEpoch, targetId: old.targetId, targetVersion: old.targetVersion,
                                                 title: old.title, fileName: "",
                                                 operation: OperationInfo(kind: "activation", stage: stage, detail: detail, progress: nil, active: active, failed: failed),
                                                 interruptRequested: false)
        activationDialogRevision += 1
    }

    func rejectActivationDialog(_ identity: WatchfaceManager.ActivationIdentity?, code: String) {
        sync {
            guard let identity = identity, ownsActivationDialog(identity), activationDialog?.operation.active == true,
                  watchfaces.activationIdentity() !== identity else { return }
            updateActivationDialog(identity, "PRECHECK_FAILED", code, false, true)
            publish()
        }
    }

    /// Chỉ giao diện từ chối tiền kiểm rẻ; không đổi thao tác gốc, lỗi hay cách ly.
    func rejectReplacementDialog(_ identity: WatchfaceManager.ReplacementIdentity?, code: String) {
        sync {
            guard let identity = identity, ownsReplacementDialog(identity), replacementDialog?.operation.active == true,
                  watchfaces.replacementIdentity() !== identity else { return }
            updateReplacementDialog(identity, "PRECHECK_FAILED", code, nil, false, true)
            publish()
        }
    }

    func rejectDeletionDialog(_ identity: WatchfaceManager.DeletionIdentity?, code: String) {
        sync {
            guard let identity = identity, ownsDeletionDialog(identity), deletionDialog?.operation.active == true,
                  watchfaces.deletionIdentity() !== identity else { return }
            updateDeletionDialog(identity, "PRECHECK_FAILED", code, nil, false, true)
            publish()
        }
    }

    /// UI đã đối chiếu token; ở đây đối chiếu lại cùng đối tượng yêu cầu + thế hệ kết nối, actor đối chiếu Replace thật.
    func interruptReplacement(_ identity: WatchfaceManager.ReplacementIdentity?) -> Bool {
        sync {
            guard let identity = identity, ownsReplacementDialog(identity), identity.epoch == connection.epoch, epoch == identity.epoch,
                  let d = replacementDialog, d.operation.active, !d.interruptRequested else { return false }
            // Cổng tức thời đặt trước: begin còn xếp hàng thì không gửi gì (zero TX); trạng thái cuối chỉ do actor dừng thật mới phát.
            let own = replacementRequest
            watchfaces.cancelReplacement(own)
            // Nếu biên đồng bộ tái nhập đã phát việc khác thì không đánh dấu huỷ cho chủ sở hữu mới.
            guard ownsReplacementDialog(identity), let old = replacementDialog else { return true }
            replacementDialog = ReplacementDialogInfo(token: old.token, connectionEpoch: old.connectionEpoch, targetId: old.targetId, targetVersion: old.targetVersion,
                                                      title: old.title, fileName: old.fileName, operation: old.operation, interruptRequested: true)
            replacementDialogRevision += 1
            publish()
            return true
        }
    }

    /// Đóng chỉ là rút phiên UI; lỗi muộn của trạng thái cuối vẫn xử lý theo giao thức gốc.
    func dismissReplacementResult(_ identity: WatchfaceManager.ReplacementIdentity?) -> Bool {
        sync {
            guard let identity = identity, ownsReplacementDialog(identity), replacementDialog?.operation.active == false else { return false }
            retiredDialogTokens.insert(identity.token)
            replacementDialog = nil; replacementRequest = nil; replacementDialogRevision += 1
            publish()
            return true
        }
    }

    func dismissDeletionResult(_ identity: WatchfaceManager.DeletionIdentity?) -> Bool {
        sync {
            guard let identity = identity, ownsDeletionDialog(identity), deletionDialog?.operation.active == false else { return false }
            retiredDialogTokens.insert(identity.token)
            deletionDialog = nil; deletionRequest = nil; deletionDialogRevision += 1
            publish()
            return true
        }
    }

    func dismissActivationResult(_ identity: WatchfaceManager.ActivationIdentity?) -> Bool {
        sync {
            guard let identity = identity, ownsActivationDialog(identity), activationDialog?.operation.active == false else { return false }
            retiredDialogTokens.insert(identity.token)
            activationDialog = nil; activationRequest = nil; activationDialogRevision += 1
            publish()
            return true
        }
    }

    // MARK: Xoá đồng hồ khỏi app (thay DeviceRemovalController)

    /// Quy trình: chặn → dừng kênh/phiên (trên hàng đợi giao thức) → xoá Keychain → xoá lịch sử → thả chặn (tăng thế hệ).
    /// Lỗi ⇒ `cancelRemoval` (giữ dữ liệu). iOS không huỷ ghép nối hệ thống: người dùng vào Cài đặt > Bluetooth > "Forget This Device".
    /// `completion` chạy trên hàng đợi giao thức: nil = thành công, ngược lại là mã lỗi.
    func removeDevice(_ address: String, completion: ((String?) -> Void)? = nil) {
        guard let id = DeviceRemovalGuard.canonical(address) else { completion?("DEVICE_ADDRESS_INVALID"); return }
        let busyNow: Bool = sync {
            let s = makeSnapshot()
            return watchfaces.busy() || s.active || AppRuntime.activeDialog(s.replacementDialog)
                || AppRuntime.activeDialog(s.deletionDialog) || AppRuntime.activeDialog(s.activationDialog)
        }
        if busyNow { completion?("WATCHFACE_OPERATION_BUSY"); return }
        secure.removals.beginRemoval(id)
        connection.post { [self] in
            do {
                try connection.stopForRemoval(id)
                try secure.clearDevice(id)
                try history.removeDevice(id)
                secure.removals.finishRemoval(id)
                logs.record("DEVICE_REMOVED_LOCAL", "local_data_cleared=true system_pairing_untouched=true")
                completion?(nil)
            } catch {
                secure.removals.cancelRemoval(id)
                let c = WMCore.code(error)
                logs.record("DEVICE_REMOVAL_FAILED", "code=\(c)")
                completion?(c)
            }
        }
    }

    // MARK: WatchConnectionListener

    func onConnection(code: String, detail: String, ready: Bool, connecting: Bool, rebindCount: Int, epoch: Int) {
        sync {
            if epoch != connection.epoch || ((ready || connecting) && removalBlocksCurrent()) { return }
            if self.epoch != epoch {
                // Kết nối thiết bị đã đổi: thông số và mặt đồng hồ của phiên trước không dùng cho thiết bị mới.
                deviceAddress = ""; serialNumber = "Không rõ"; firmware = "Không rõ"; deviceModel = nil
                batteryPercent = nil; freeMemoryBytes = nil
                width = nil; height = nil; capability = nil
                visible = []; names = [:]; listReady = false; listRefreshing = false; message = ""
            }
            self.code = code; self.detail = detail; self.ready = ready; self.connecting = !ready && connecting
            deviceAddress = ready ? connection.address : ""
            rebind = rebindCount; self.epoch = epoch
            if ready { message = "" }
            publish()
        }
        // Bỏ qua điều khoản giao thức: runtime tự hoàn tất cùng nhánh dù giao diện đã đóng.
        if code == "AGREEMENT_CONFIRM" { connection.respondAgreements(expectedEpoch: epoch, accept: false) }
    }

    func onPin(needed: Bool, message msg: String) {
        sync {
            if needed && removalBlocksCurrent() { return }
            needsPin = needed; pinMessage = msg
            publish()
        }
    }

    func onRebind(message: String) {
        if removalBlocksCurrent() { return }
        for o in sync({ currentObservers() }) { o.rebindRequested(message) }
    }

    func onDeviceInfo(epoch: Int, firmware version: String) {
        sync {
            if self.epoch != epoch || epoch != connection.epoch || removalBlocksCurrent() || !ready || !connection.ready || version.isEmpty { return }
            firmware = version
            publish()
        }
    }

    func onDeviceModel(epoch: Int, model: String) {
        sync {
            if self.epoch != epoch || epoch != connection.epoch || removalBlocksCurrent() || !ready || !connection.ready
                || deviceAddress.caseInsensitiveCompare(connection.address) != .orderedSame || deviceModel != nil { return }
            guard let known = (try? DeviceInfo.modelText(model)) ?? nil else { return }
            deviceModel = known
            publish()
        }
    }

    func onDeviceStats(epoch: Int, serialNumber serial: String?, batteryPercent battery: Int?, freeMemoryBytes freeBytes: Int64?) {
        sync {
            if self.epoch != epoch || epoch != connection.epoch || removalBlocksCurrent() || !ready || !connection.ready { return }
            if let s = serial, !s.isEmpty { serialNumber = s }
            if let b = battery, b >= 0, b <= 100 { batteryPercent = b }
            if let f = freeBytes, f > 0 { freeMemoryBytes = f }
            publish()
        }
    }

    func onReady(epoch: Int, caps: LinkCapabilities) {
        sync {
            if epoch != connection.epoch || self.epoch != epoch || removalBlocksCurrent() { return }
            kind = ""; stage = ""; operationDetail = ""; message = ""; active = false; failed = false; progress = nil
            replacementIdentity = nil; deletionIdentity = nil; activationIdentity = nil
            operationRevision += 1
            publish()
            watchfaces.authenticated(epoch: epoch)
        }
    }

    func onPacket(epoch: Int, service: Int, command: Int, plain: [UInt8], encrypted: Bool) {
        if removalBlocksCurrent() { return }
        watchfaces.packet(epoch: epoch, service: service, command: command, body: plain, encrypted: encrypted)
    }

    func onClosed(closedEpoch: Int, reason: String) {
        watchfaces.closed(closedEpoch: closedEpoch, reason: reason)
    }

    // MARK: WatchfaceManagerListener

    func onFaces(_ faces: [TlvView.Face], names newNames: [String: String], fresh: Bool, epoch: Int, generation gen: Int64) {
        sync {
            if epoch != connection.epoch { return }
            visible = faces; names = newNames; listReady = fresh; generation = gen
            publish()
        }
    }

    func onRefreshing(_ refreshing: Bool, epoch: Int) {
        sync {
            if epoch != connection.epoch { return }
            listRefreshing = refreshing
            if !refreshing && listReady { message = "" }
            publish()
        }
    }

    func onParameters(width: Int?, height: Int?, capability: Int64?) {
        sync {
            self.width = width; self.height = height; self.capability = capability
            publish()
        }
    }

    func onOperation(kind: String, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool) {
        sync {
            operationRevision += 1
            replacementIdentity = nil; deletionIdentity = nil; activationIdentity = nil
            self.kind = kind; self.stage = stage; operationDetail = detail
            self.progress = progress; self.active = active; self.failed = failed
            publish()
        }
    }

    func onReplacementOperation(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool) {
        sync {
            guard let current = watchfaces.currentReplacementRequest(), current.identity === identity,
                  watchfaces.replacementIdentity() === identity, !(active && identity.epoch != connection.epoch) else { return }
            // Callback cũ chỉ cập nhật đúng tóm tắt manager còn đang công bố; tiêu đề/tên file không dựng lại từ lựa chọn hiện tại.
            if !ownsReplacementDialog(identity) && active && !activeOperationDialog() && !retiredDialogTokens.contains(identity.token) {
                installReplacementDialog(current, identity.id, "HWT cục bộ")
            }
            if replacementIdentity !== identity { message = "" }
            operationRevision += 1
            replacementIdentity = identity; deletionIdentity = nil; activationIdentity = nil
            kind = "replacement"; self.stage = stage; operationDetail = detail
            self.progress = progress; self.active = active; self.failed = failed
            updateReplacementDialog(identity, stage, detail, progress, active, failed)
            publish()
        }
    }

    func onReplacementRequestFinished(identity: WatchfaceManager.ReplacementIdentity, stage: String, detail: String, failed: Bool) {
        sync {
            guard ownsReplacementDialog(identity), replacementDialog?.operation.active == true,
                  watchfaces.replacementIdentity() !== identity else { return }
            updateReplacementDialog(identity, stage, detail, nil, false, failed)
            publish()
        }
    }

    func onReplacementError(identity: WatchfaceManager.ReplacementIdentity, error: String) {
        sync {
            guard let current = watchfaces.currentReplacementRequest(), current.identity === identity,
                  replacementIdentity === identity, watchfaces.replacementIdentity() === identity else { return }
            message = error
            publish()
        }
    }

    func onDeletionOperation(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, progress: Int?, active: Bool, failed: Bool) {
        sync {
            guard let current = watchfaces.currentDeletionRequest(), current.identity === identity,
                  watchfaces.deletionIdentity() === identity, !(active && identity.epoch != connection.epoch) else { return }
            if !ownsDeletionDialog(identity) && active && !activeOperationDialog() && !retiredDialogTokens.contains(identity.token) {
                installDeletionDialog(current, identity.id)
            }
            if deletionIdentity !== identity { message = "" }
            operationRevision += 1
            deletionIdentity = identity; replacementIdentity = nil; activationIdentity = nil
            kind = "deletion"; self.stage = stage; operationDetail = detail
            self.progress = progress; self.active = active; self.failed = failed
            updateDeletionDialog(identity, stage, detail, progress, active, failed)
            publish()
        }
    }

    func onDeletionRequestFinished(identity: WatchfaceManager.DeletionIdentity, stage: String, detail: String, failed: Bool) {
        sync {
            guard ownsDeletionDialog(identity), deletionDialog?.operation.active == true,
                  watchfaces.deletionIdentity() !== identity else { return }
            updateDeletionDialog(identity, stage, detail, nil, false, failed)
            publish()
        }
    }

    func onDeletionError(identity: WatchfaceManager.DeletionIdentity, error: String) {
        sync {
            guard let current = watchfaces.currentDeletionRequest(), current.identity === identity,
                  deletionIdentity === identity, watchfaces.deletionIdentity() === identity else { return }
            message = error
            publish()
        }
    }

    func onActivationOperation(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, active: Bool, failed: Bool) {
        sync {
            guard let current = watchfaces.currentActivationRequest(), current.identity === identity,
                  watchfaces.activationIdentity() === identity, !(active && identity.epoch != connection.epoch) else { return }
            if !ownsActivationDialog(identity) && active && !activeOperationDialog() && !retiredDialogTokens.contains(identity.token) {
                installActivationDialog(current, identity.id)
            }
            if activationIdentity !== identity { message = "" }
            operationRevision += 1
            activationIdentity = identity; replacementIdentity = nil; deletionIdentity = nil
            kind = "activation"; self.stage = stage; operationDetail = detail
            progress = nil; self.active = active; self.failed = failed
            updateActivationDialog(identity, stage, detail, active, failed)
            publish()
        }
    }

    func onActivationRequestFinished(identity: WatchfaceManager.ActivationIdentity, stage: String, detail: String, failed: Bool) {
        sync {
            guard ownsActivationDialog(identity), activationDialog?.operation.active == true,
                  watchfaces.activationIdentity() !== identity else { return }
            updateActivationDialog(identity, stage, detail, false, failed)
            publish()
        }
    }

    func onActivationError(identity: WatchfaceManager.ActivationIdentity, error: String) {
        sync {
            guard let current = watchfaces.currentActivationRequest(), current.identity === identity,
                  activationIdentity === identity, watchfaces.activationIdentity() === identity else { return }
            message = error
            publish()
        }
    }

    func onPreparedDeletion(face: TlvView.Face, epoch: Int) {
        if epoch != connection.epoch || !connection.ready { return }
        for o in sync({ currentObservers() }) { o.deletionPrepared(face, epoch: epoch) }
    }

    func onError(_ msg: String) {
        sync {
            message = msg
            publish()
        }
    }
}
