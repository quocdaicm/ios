import Foundation
import Security

/// Lưu danh tính, khoá xác thực, ID Huawei theo từng đồng hồ trong Keychain
/// (thay SecureStore.java dùng Android Keystore). Khoá thiết bị = UUID CBPeripheral.
/// Mục Keychain: AfterFirstUnlockThisDeviceOnly, không đồng bộ iCloud.
/// Lưu ý iOS: mục Keychain có thể còn sau khi xoá app; dùng clearDevice khi người dùng xoá đồng hồ.
final class SecureStore {
    private static let service = "io.github.escosis.wristmirror.secure"
    private let lock = NSRecursiveLock()
    private let random: (Int) -> [UInt8]
    let removals: DeviceRemovalGuard

    init(removals: DeviceRemovalGuard = DeviceRemovalGuard(),
         random: @escaping (Int) -> [UInt8] = { WMRandom.bytes($0) }) {
        self.removals = removals
        self.random = random
    }

    // MARK: Keychain thô

    private func baseQuery(_ name: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: SecureStore.service,
         kSecAttrAccount as String: name]
    }

    private func get(_ name: String) throws -> [UInt8]? {
        var q = baseQuery(name)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        let st = SecItemCopyMatching(q as CFDictionary, &out)
        if st == errSecItemNotFound { return nil }
        guard st == errSecSuccess, let d = out as? Data else { throw WMFault("LOCAL_SECURE_STORAGE_UNAVAILABLE") }
        return [UInt8](d)
    }

    private func put(_ name: String, _ value: [UInt8]) throws {
        let attrs: [String: Any] = [
            kSecValueData as String: Data(value),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        ]
        var st = SecItemUpdate(baseQuery(name) as CFDictionary, attrs as CFDictionary)
        if st == errSecItemNotFound {
            var add = baseQuery(name)
            for (k, v) in attrs { add[k] = v }
            st = SecItemAdd(add as CFDictionary, nil)
        }
        guard st == errSecSuccess else { throw WMFault("LOCAL_SECURE_STORAGE_WRITE_FAILED") }
    }

    private func remove(_ name: String) throws {
        let st = SecItemDelete(baseQuery(name) as CFDictionary)
        guard st == errSecSuccess || st == errSecItemNotFound else { throw WMFault("LOCAL_DEVICE_CLEAR_FAILED") }
    }

    private func suffix(_ id: String) throws -> String {
        guard let c = DeviceRemovalGuard.canonical(id) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        return WMCore.hex(WMCore.digest(Array(c.utf8)))
    }

    private func key(_ prefix: String, _ id: String) throws -> String {
        let s = try suffix(id)
        return prefix + s
    }

    // MARK: API theo thiết bị (cùng tên với bản Java)

    /// 32 byte ASCII = hex thường của 16 byte ngẫu nhiên, ổn định theo từng đồng hồ.
    func identity(_ id: String) throws -> [UInt8] {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        let name = try key("identity_", id)
        var value = try get(name)
        if value == nil {
            let created = Array(WMCore.hex(random(16)).utf8)
            try put(name, created)
            value = created
        }
        guard let v = value, v.count == 32,
              v.allSatisfy({ ($0 >= 48 && $0 <= 57) || ($0 >= 97 && $0 <= 102) }) else {
            throw WMFault("LOCAL_IDENTITY_INVALID")
        }
        return v
    }

    /// "FF:FF:FF:XX:XX:XX" ngẫu nhiên, cố định theo từng đồng hồ (dùng cho bước Lite BOND).
    func virtualMac(_ id: String) throws -> String {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        let name = try key("virtual_mac_", id)
        if let s = try get(name) { return String(decoding: s, as: UTF8.self) }
        let b = random(3)
        func h(_ x: UInt8) -> String { let s = String(x, radix: 16, uppercase: true); return s.count < 2 ? "0" + s : s }
        let v = "FF:FF:FF:\(h(b[0])):\(h(b[1])):\(h(b[2]))"
        try put(name, Array(v.utf8))
        return v
    }

    func huaweiId(_ id: String) throws -> String {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        guard let b = try get(key("huawei_id_", id)) else { return "" }
        return try WMCore.utf8(b)
    }

    func saveHuaweiId(_ id: String, _ value: String?) throws {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        let s = (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if s.utf8.count > 128 { throw WMFault("HUAWEI_ID_TOO_LONG") }
        try put(key("huawei_id_", id), Array(s.utf8))
    }

    func authKey(_ id: String) throws -> [UInt8]? {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        return try get(key("auth_", id))
    }

    func saveAuthKey(_ id: String, _ bytes: [UInt8]?) throws {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        guard let b = bytes, b.count == 16 || b.count == 24 || b.count == 32 else {
            throw WMFault("AUTH_KEY_LENGTH_UNSUPPORTED")
        }
        try put(key("auth_", id), b)
    }

    func clearAuthKey(_ id: String) throws {
        lock.lock(); defer { lock.unlock() }
        try removals.requireUsable(id)
        do { try remove(key("auth_", id)) } catch { throw WMFault("LOCAL_AUTH_CLEAR_FAILED") }
    }

    /// Xoá bốn mục của một đồng hồ. Idempotent; thất bại thì ném LOCAL_DEVICE_CLEAR_FAILED.
    func clearDevice(_ id: String) throws {
        lock.lock(); defer { lock.unlock() }
        let s = try suffix(id)
        for prefix in ["huawei_id_", "auth_", "identity_", "virtual_mac_"] { try remove(prefix + s) }
    }
}
