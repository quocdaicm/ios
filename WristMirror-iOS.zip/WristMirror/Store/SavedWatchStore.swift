import Foundation

/// Port từ store/SavedWatchStore.kt (Phần 7).
/// Siêu dữ liệu các đồng hồ đã từng READY + tuỳ chọn tự kết nối khi mở app. Không lưu Huawei ID, PIN, khoá.
/// Dùng UserDefaults (không chứa bí mật). Danh sách theo thứ tự READY, mới nhất đứng đầu.
/// Khoá thiết bị = UUID CBPeripheral viết hoa. Định dạng dòng: "UUID\tBLE\tthời_điểm\tbase64(tên)".
/// So với Java: UserDefaults không có commit() thất bại, nên bỏ cơ chế "pending write" của SharedPreferences.
final class SavedWatchStore {
    private static let lock = NSRecursiveLock()   // thay DeviceRemovalJournal.LOCK
    private static let devicesKey = "wm.ready-devices-v1"
    private static let autoConnectKey = "wm.auto-connect"
    private static let format = "1"
    private static let modelPrefix = "wm.first-model-v1_"
    private static let serialPrefix = "wm.first-serial-v1_"
    private static let maxNameChars = 256
    private static let maxStorageChars = 256 * 1024

    private let defaults: UserDefaults
    private let removals: DeviceRemovalGuard

    init(removals: DeviceRemovalGuard, defaults: UserDefaults = .standard) {
        self.removals = removals
        self.defaults = defaults
    }

    static func canonicalAddress(_ address: String) -> String? { DeviceRemovalGuard.canonical(address) }

    func devices() -> [SavedWatch] {
        SavedWatchStore.lock.lock(); defer { SavedWatchStore.lock.unlock() }
        let encoded = defaults.string(forKey: SavedWatchStore.devicesKey) ?? ""
        if encoded.count > SavedWatchStore.maxStorageChars { return [] }
        var lines = encoded.split(separator: "\n", omittingEmptySubsequences: false).makeIterator()
        guard let head = lines.next(), head == SavedWatchStore.format else { return [] }
        var seen = Set<String>()
        var out: [SavedWatch] = []
        while let line = lines.next() {
            let parts = line.split(separator: "\t", omittingEmptySubsequences: false).map(String.init)
            if parts.count != 4 { continue }
            guard let address = SavedWatchStore.canonicalAddress(parts[0]), parts[1] == "BLE",
                  let at = Int64(parts[2]), at > 0,
                  let data = Data(base64Encoded: parts[3]), let name = String(data: data, encoding: .utf8),
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, name.count <= SavedWatchStore.maxNameChars
            else { continue }
            if seen.insert(address).inserted {
                out.append(SavedWatch(address: address, name: name, transport: "BLE", lastConnectedAt: at,
                                      model: cachedModel(address), serialNumber: cachedSerial(address)))
            }
        }
        return out
    }

    func autoConnect() -> Bool { defaults.string(forKey: SavedWatchStore.autoConnectKey) == "true" }

    func setAutoConnect(_ enabled: Bool) {
        defaults.set(enabled ? "true" : "false", forKey: SavedWatchStore.autoConnectKey)
    }

    /// Chỉ gọi sau khi đã kiểm độc lập rằng kết nối hiện tại READY đúng lô.
    @discardableResult
    func remember(_ device: NearbyWatch, connectedAt: Int64 = Int64(Date().timeIntervalSince1970 * 1000)) throws -> [SavedWatch] {
        SavedWatchStore.lock.lock(); defer { SavedWatchStore.lock.unlock() }
        guard let address = SavedWatchStore.canonicalAddress(device.address) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        // Callback READY cũ không được ghi lại lịch sử khi đang có dấu xoá chờ xử lý.
        try removals.requireUsable(address)
        if device.transport != "BLE" { throw WMFault("DEVICE_TRANSPORT_INVALID") }
        var name = String(device.name.prefix(SavedWatchStore.maxNameChars))
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { name = "Đồng hồ Huawei" }
        let previous = devices()
        let old = previous.first { $0.address == address }
        let saved = SavedWatch(address: address, name: name, transport: "BLE", lastConnectedAt: max(connectedAt, 1),
                               model: old?.model, serialNumber: old?.serialNumber)
        let next = [saved] + previous.filter { $0.address != address }
        try persist(next, failure: "LOCAL_DEVICE_HISTORY_WRITE_FAILED")
        return next
    }

    /// Chỉ model thật của cùng READY đã xác minh; giá trị hợp lệ đầu tiên không bao giờ bị ghi đè; không xếp lại lịch sử.
    @discardableResult
    func rememberModel(_ address: String, model: String?, expectedGeneration: Int) throws -> [SavedWatch] {
        SavedWatchStore.lock.lock(); defer { SavedWatchStore.lock.unlock() }
        guard let mac = SavedWatchStore.canonicalAddress(address) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        if !removals.usable(mac, generation: expectedGeneration) { throw WMFault("DEVICE_HISTORY_CHANGED") }
        let history = devices()
        guard let saved = history.first(where: { $0.address == mac }) else { return history }
        if saved.model != nil { return history }
        guard let first = (try? DeviceInfo.modelText(model)) ?? nil else { return history }
        defaults.set(first, forKey: SavedWatchStore.modelPrefix + mac)
        return history.map { $0.address == mac ? SavedWatch(address: $0.address, name: $0.name, transport: $0.transport, lastConnectedAt: $0.lastConnectedAt, model: first, serialNumber: $0.serialNumber) : $0 }
    }

    @discardableResult
    func rememberSerial(_ address: String, serialNumber: String?, expectedGeneration: Int) throws -> [SavedWatch] {
        SavedWatchStore.lock.lock(); defer { SavedWatchStore.lock.unlock() }
        guard let mac = SavedWatchStore.canonicalAddress(address) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        if !removals.usable(mac, generation: expectedGeneration) { throw WMFault("DEVICE_HISTORY_CHANGED") }
        let history = devices()
        guard let saved = history.first(where: { $0.address == mac }) else { return history }
        if saved.serialNumber != nil { return history }
        guard let first = (try? DeviceTelemetry.serialText(serialNumber)) ?? nil else { return history }
        defaults.set(first, forKey: SavedWatchStore.serialPrefix + mac)
        return history.map { $0.address == mac ? SavedWatch(address: $0.address, name: $0.name, transport: $0.transport, lastConnectedAt: $0.lastConnectedAt, model: $0.model, serialNumber: first) : $0 }
    }

    private func cachedModel(_ address: String) -> String? {
        (try? DeviceInfo.modelText(defaults.string(forKey: SavedWatchStore.modelPrefix + address))) ?? nil
    }

    private func cachedSerial(_ address: String) -> String? {
        (try? DeviceTelemetry.serialText(defaults.string(forKey: SavedWatchStore.serialPrefix + address))) ?? nil
    }

    /// Chỉ xoá lịch sử + cache model/serial của đúng thiết bị; giữ thứ tự, thiết bị khác và tuỳ chọn tự kết nối.
    @discardableResult
    func removeDevice(_ address: String) throws -> [SavedWatch] {
        SavedWatchStore.lock.lock(); defer { SavedWatchStore.lock.unlock() }
        guard let mac = SavedWatchStore.canonicalAddress(address) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        let next = devices().filter { $0.address != mac }
        try persist(next, failure: "LOCAL_DEVICE_HISTORY_CLEAR_FAILED")
        defaults.removeObject(forKey: SavedWatchStore.modelPrefix + mac)
        defaults.removeObject(forKey: SavedWatchStore.serialPrefix + mac)
        return next
    }

    private func persist(_ devices: [SavedWatch], failure: String) throws {
        var encoded = SavedWatchStore.format
        for w in devices {
            encoded += "\n" + w.address + "\tBLE\t" + String(w.lastConnectedAt) + "\t" + Data(w.name.utf8).base64EncodedString()
        }
        if encoded.count > SavedWatchStore.maxStorageChars { throw WMFault(failure) }
        defaults.set(encoded, forKey: SavedWatchStore.devicesKey)
    }
}
