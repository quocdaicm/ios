import Foundation

/// Phiên bản rút gọn của DeviceRemovalJournal.java cho iOS.
/// iOS không cho app huỷ ghép nối hệ thống, nên chỉ còn: đánh dấu "đang xoá dữ liệu cục bộ",
/// và bộ đếm thế hệ để bỏ qua callback đến muộn sau khi dữ liệu của thiết bị đã bị xoá.
/// Khoá thiết bị = UUID của CBPeripheral, viết hoa (không có MAC trên iOS).
final class DeviceRemovalGuard {
    private let lock = NSLock()
    private var pending = Set<String>()
    private var generations: [String: Int] = [:]

    static func canonical(_ id: String?) -> String? {
        guard let id = id, let u = UUID(uuidString: id) else { return nil }
        return u.uuidString
    }

    func blocked(_ id: String) -> Bool {
        guard let c = DeviceRemovalGuard.canonical(id) else { return false }
        lock.lock(); defer { lock.unlock() }
        return pending.contains(c)
    }

    func generation(_ id: String) -> Int {
        guard let c = DeviceRemovalGuard.canonical(id) else { return 0 }
        lock.lock(); defer { lock.unlock() }
        return generations[c] ?? 0
    }

    func usable(_ id: String, generation g: Int) -> Bool {
        guard let c = DeviceRemovalGuard.canonical(id) else { return false }
        lock.lock(); defer { lock.unlock() }
        return !pending.contains(c) && (generations[c] ?? 0) == g
    }

    func requireUsable(_ id: String) throws {
        guard let c = DeviceRemovalGuard.canonical(id) else { throw WMFault("DEVICE_ADDRESS_INVALID") }
        lock.lock(); defer { lock.unlock() }
        if pending.contains(c) { throw WMFault("DEVICE_REMOVAL_PENDING") }
    }

    /// Gọi trước khi xoá dữ liệu cục bộ của thiết bị.
    func beginRemoval(_ id: String) {
        guard let c = DeviceRemovalGuard.canonical(id) else { return }
        lock.lock(); pending.insert(c); lock.unlock()
    }

    /// Gọi sau khi xoá xong: tăng thế hệ để mọi callback cũ bị vô hiệu.
    func finishRemoval(_ id: String) {
        guard let c = DeviceRemovalGuard.canonical(id) else { return }
        lock.lock()
        pending.remove(c)
        generations[c, default: 0] += 1
        lock.unlock()
    }

    /// Xoá thất bại: giữ nguyên dữ liệu, bỏ chặn.
    func cancelRemoval(_ id: String) {
        guard let c = DeviceRemovalGuard.canonical(id) else { return }
        lock.lock(); pending.remove(c); lock.unlock()
    }
}
