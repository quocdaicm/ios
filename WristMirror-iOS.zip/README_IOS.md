# WristMirror iOS (bản viết lại bằng Swift/SwiftUI)

Build không cần Mac: đẩy thư mục này lên GitHub → tab Actions → "Build IPA" → tải artifact `WristMirror-ipa` (IPA chưa ký, cần tự ký/cài bằng Sideloadly, AltStore...).

> Người/AI làm tiếp: đọc **HANDOFF.md** trước.

## Các phần
1. Khung dự án, FrameCodec, GattChannel (CoreBluetooth)  ✅
2. Core, TlvView, Wire, DeviceInfo, MiniJson  ✅
3. Mật mã (AES-GCM/CBC, HMAC, HKDF), CryptoSession, LiteAuth, LinkCapabilities, AuthReplyJson  ✅
4. IsoAuth + IsoReplyHandler (xác thực HiChain ISO)  ✅
5. WatchConnection + WatchScanner + WristInitialization + DeviceTelemetry + SafeLog + Keychain store  ✅
6. FacePolicy/VersionPolicy + WireNames + các lớp *State + HwtSource (+ZipArchive) + FileTransfer (giao thức 0x28)  ✅ (chưa biên dịch)
7. WatchfaceManager (thay/xoá/bật mặt đồng hồ) + AppRuntime + Models + SavedWatchStore  ✅ (chưa biên dịch)
8. WatchViewModel + giao diện SwiftUI + đăng nhập Huawei ID (WKWebView)  ✅ (chưa biên dịch)
9. Build GitHub Actions lần đầu, sửa lỗi biên dịch, thử trên đồng hồ thật  ← tiếp theo
