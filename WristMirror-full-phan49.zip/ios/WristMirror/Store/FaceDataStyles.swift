// Tính năng mới của bản iOS (không có trong WristMirror gốc).
// Kiểu số vector cho các mục số liệu do đồng hồ cập nhật: pin, bước chân, nhịp tim, calo, thời tiết (nhiệt độ, cao/thấp).
// Dùng lại bộ kiểu số của giờ số / ngày tháng (FaceDigitalStyles.swift). Có kiểu chung cho tất cả số liệu
// (`FaceDesign.dataStyle`) và tuỳ chọn riêng từng mục (`DataWidget.customStyle` + `style`). Đơn vị (%, bpm, kcal, bước, °)
// là path chữ (CoreText) tô cùng kiểu; mũi tên cao/thấp là path vẽ bằng code nên toàn bộ là hình vector, không cần font.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// Đơn vị dạng path chữ (đặt cạnh số vector).
struct VecSuffix {
    let path: CGPath
    /// Tỉ lệ từ đơn vị path (cỡ chữ 100) sang điểm ảnh.
    let scale: CGFloat
    /// Bề rộng cả ô đơn vị (gồm khoảng cách trái và lề).
    let w: Int
    let labelW: Int
    let labelH: Int
    let gap: Int
    let lpad: Int
    /// Dấu "°" căn mép trên của số; các đơn vị khác căn đường cơ sở.
    let alignTop: Bool
}

/// Thông tin kiểu số vector của một mục.
struct DataVecInfo {
    let def: DigitalShapes.Def
    let own: Bool
    let pad: Int
    let glyphH: Int
    /// Khoá bộ ảnh chữ số dùng chung (kiểu + màu gốc).
    let key: String
    var suffix: VecSuffix?
}

extension FaceDesign {
    /// Kiểu số và màu gốc thực tế của giờ số / dương lịch / âm lịch: kiểu riêng nếu bật, không thì kiểu số chung (`dataStyle`).
    var digitalStyleEff: DigitalStyle { digitalCustom ? digitalStyle : dataStyle }
    var digitalOwnEff: Bool { digitalCustom ? digitalOwnColors : dataOwnColors }
    var solarStyleEff: DigitalStyle { solarCustom ? solarStyle : dataStyle }
    var solarOwnEff: Bool { solarCustom ? solarOwnColors : dataOwnColors }
    var lunarStyleEff: DigitalStyle { lunarCustom ? lunarStyle : dataStyle }
    var lunarOwnEff: Bool { lunarCustom ? lunarOwnColors : dataOwnColors }

    /// Kiểu số thực tế của một mục: kiểu riêng nếu bật "Kiểu riêng", không thì kiểu chung. nil = số thường (font).
    func dataVecStyle(_ w: DataWidget) -> (def: DigitalShapes.Def, own: Bool, key: String)? {
        let st = w.customStyle ? w.style : dataStyle
        let own = w.customStyle ? w.ownColors : dataOwnColors
        guard st != .classic, let def = st.def else { return nil }
        return (def, own, "\(st.rawValue)|\(own)")
    }
}

extension FaceRenderer {
    /// Đường cơ sở số vector: lề `pad` + chiều cao số `glyphH`.
    static func vecSuffix(_ text: String, fontScale: CGFloat, glyphH: Int, pad: Int, def: DigitalShapes.Def,
                          gap: Int, alignTop: Bool = false, sym: Int = 0) -> VecSuffix? {
        let t = text.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return nil }
        // "%" và "°" có thể dùng ký hiệu vector riêng (sym > 0); các đơn vị khác vẫn là path chữ.
        let shape = UnitSymbols.shape(t, style: sym) ?? DateLabelShapes.shape(t, font: 0)
        let lpad = def.paint == .glow ? 6 : 3
        let labelW = Int(ceil(shape.w * fontScale)) + 2 * lpad
        let labelH = Int(ceil(shape.h * fontScale)) + 2 * lpad
        return VecSuffix(path: shape.path, scale: fontScale, w: gap + labelW, labelW: labelW, labelH: labelH,
                         gap: gap, lpad: lpad, alignTop: alignTop)
    }

    /// Vẽ đơn vị vector. (ox, oy) = góc trên-trái ô đơn vị (cao bằng ô số), ctx gốc trên-trái.
    static func drawVecSuffix(_ ctx: CGContext, _ v: DataVecInfo, color: UIColor, x ox: CGFloat, y oy: CGFloat) {
        guard let s = v.suffix else { return }
        let top = oy + CGFloat(v.pad)
        let baseline = top + CGFloat(v.glyphH)
        let y = s.alignTop ? top - CGFloat(s.lpad) : baseline - CGFloat(s.labelH) + CGFloat(s.lpad)
        DigitalShapes.drawLabel(ctx, def: v.def, shape: s.path, scale: s.scale,
                                in: CGRect(x: ox + CGFloat(s.gap), y: y, width: CGFloat(s.labelW), height: CGFloat(s.labelH)),
                                color: color, own: v.own)
    }

    /// Vẽ chuỗi số vector căn trái, mỗi chữ số một ô `digitW`. Trả về toạ độ x ngay sau chữ số cuối.
    @discardableResult
    static func drawVecNumber(_ ctx: CGContext, _ text: String, _ v: DataVecInfo, digitW: Int, lineH: Int,
                              x: Int, y: Int, color: UIColor) -> Int {
        var cx = x
        for ch in text {
            DigitalShapes.draw(ctx, def: v.def, char: ch, in: CGRect(x: cx, y: y, width: digitW, height: lineH),
                               pad: CGFloat(v.pad), color: color, own: v.own)
            cx += digitW
        }
        return cx
    }

    /// Mũi tên cao/thấp (path vẽ bằng code) trong ô `rect`.
    static func drawVecArrow(_ ctx: CGContext, up: Bool, in rect: CGRect, color: UIColor) {
        let w = rect.width, h = rect.height
        let cx = rect.midX
        let stem = max(1.6, w * 0.16)
        let headH = h * 0.46
        let p = CGMutablePath()
        if up {
            p.move(to: CGPoint(x: cx, y: rect.minY))
            p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + headH))
            p.addLine(to: CGPoint(x: cx + stem / 2, y: rect.minY + headH))
            p.addLine(to: CGPoint(x: cx + stem / 2, y: rect.maxY))
            p.addLine(to: CGPoint(x: cx - stem / 2, y: rect.maxY))
            p.addLine(to: CGPoint(x: cx - stem / 2, y: rect.minY + headH))
            p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + headH))
        } else {
            p.move(to: CGPoint(x: cx, y: rect.maxY))
            p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - headH))
            p.addLine(to: CGPoint(x: cx + stem / 2, y: rect.maxY - headH))
            p.addLine(to: CGPoint(x: cx + stem / 2, y: rect.minY))
            p.addLine(to: CGPoint(x: cx - stem / 2, y: rect.minY))
            p.addLine(to: CGPoint(x: cx - stem / 2, y: rect.maxY - headH))
            p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - headH))
        }
        p.closeSubpath()
        ctx.addPath(p)
        ctx.setFillColor(color.cgColor)
        ctx.fillPath()
    }

    /// Bố cục vector cho một mục số liệu đơn giản (pin, bước chân, nhịp tim, calo).
    static func dataVecLayout(_ kind: DataKind, _ w: DataWidget, _ d: FaceDesign, k: CGFloat)
        -> (v: DataVecInfo, digitW: Int, lineH: Int, suffixW: Int)? {
        guard let m = d.dataVecStyle(w) else { return nil }
        let c = DigitalShapes.cells(m.def, scale: k, base: 28)
        let glyphH = c.lineH - 2 * c.pad
        let text = w.unit ? kind.suffix : ""
        let gap = Int((4 * k).rounded())
        let suf = vecSuffix(text, fontScale: 22 * k / 100, glyphH: glyphH, pad: c.pad, def: m.def, gap: gap, sym: d.unitSymbol)
        let v = DataVecInfo(def: m.def, own: m.own, pad: c.pad, glyphH: glyphH, key: m.key, suffix: suf)
        return (v, c.digitW, c.lineH, suf?.w ?? 0)
    }

    /// Ảnh một chữ số / dấu "-" vector (ô `digitW` × `lineH`).
    static func vecGlyphRaster(_ ch: Character, _ v: DataVecInfo, w: Int, h: Int, color: UIColor) -> HwtRaster {
        drawRaster(width: w, height: h) { ctx in
            DigitalShapes.draw(ctx, def: v.def, char: ch, in: CGRect(x: 0, y: 0, width: w, height: h),
                               pad: CGFloat(v.pad), color: color, own: v.own)
        }
    }

    /// Ảnh đơn vị vector (rộng `w`, cao `h` = ô số).
    static func vecSuffixRaster(_ v: DataVecInfo, w: Int, h: Int, color: UIColor) -> HwtRaster {
        drawRaster(width: w, height: h) { ctx in
            drawVecSuffix(ctx, v, color: color, x: 0, y: 0)
        }
    }
}

// MARK: - Hình thu nhỏ trong bộ chọn kiểu số liệu ("72 bpm")

enum DataThumbs {
    static let size = CGSize(width: 240, height: 84)
    private static var cache = [DigitalStyle: UIImage]()

    static func image(_ st: DigitalStyle) -> UIImage {
        if let c = cache[st] { return c }
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { c in
            UIColor(white: 0.06, alpha: 1).setFill()
            c.fill(CGRect(origin: .zero, size: size))
            let ctx = c.cgContext
            if let def = st.def {
                let cl = DigitalShapes.cells(def, scale: 1.1, base: 30)
                let glyphH = cl.lineH - 2 * cl.pad
                let suf = FaceRenderer.vecSuffix(" bpm", fontScale: 0.2, glyphH: glyphH, pad: cl.pad, def: def, gap: 4)
                let v = DataVecInfo(def: def, own: true, pad: cl.pad, glyphH: glyphH, key: st.rawValue, suffix: suf)
                let total = CGFloat(cl.digitW * 2 + (suf?.w ?? 0))
                let x0 = (size.width - total) / 2
                let y = (size.height - CGFloat(cl.lineH)) / 2
                let end = FaceRenderer.drawVecNumber(ctx, "72", v, digitW: cl.digitW, lineH: cl.lineH,
                                                     x: Int(x0), y: Int(y), color: .white)
                FaceRenderer.drawVecSuffix(ctx, v, color: .white, x: CGFloat(end), y: y)
            } else {
                let font = UIFont.monospacedDigitSystemFont(ofSize: 40, weight: .bold)
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white]
                let text = "72 bpm"
                let sz = (text as NSString).size(withAttributes: attrs)
                (text as NSString).draw(at: CGPoint(x: (size.width - sz.width) / 2, y: (size.height - sz.height) / 2), withAttributes: attrs)
            }
        }
        cache[st] = img
        return img
    }
}
