// Tạm thời: thay cho các phần chưa có trong bản ghép (HandShapes, SeasonArt, SeasonFallView, HandThumbs).
// Khi có các file thật (HandShapes.swift, SeasonArt.swift…), XOÁ file này để tránh trùng tên.
// Written by Quốc Đại (quocdaicm, https://quocdai.site) (2026). Licensed under the Apache License, Version 2.0 – see LICENSE and NOTICE.
import SwiftUI
import UIKit

/// 23 kiểu kim vector chưa có: mọi kiểu ngoài Thanh/Nhọn/Cổ điển tạm vẽ như kim Thanh.
enum HandShapes {
    struct Def {}
    static let table: [String: Def] = [:]
    static func title(_ raw: String) -> String {
        raw.prefix(1).uppercased() + raw.dropFirst()
    }
    static func draw(_ ctx: CGContext, def: Def, geo: FaceRenderer.HandGeometry, color: UIColor, outline: Bool) {}
}

/// Hình thu nhỏ trong bộ chọn kiểu kim: vẽ thẳng bằng `FaceRenderer.drawHand`.
enum HandThumbs {
    private static var cache = [FaceDesign.HandStyle: UIImage]()

    static func image(_ st: FaceDesign.HandStyle) -> UIImage {
        if let c = cache[st] { return c }
        let px: CGFloat = 112
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: CGSize(width: px, height: px), format: fmt).image { c in
            UIColor(white: 0.10, alpha: 1).setFill()
            c.fill(CGRect(x: 0, y: 0, width: px, height: px))
            let ctx = c.cgContext
            ctx.translateBy(x: px / 2, y: px * 0.78)
            let geo = FaceRenderer.HandGeometry(reach: 80, tail: 14, width: 12)
            FaceRenderer.drawHand(ctx, kind: .minute, geo: geo, style: st, color: .white, outline: false)
        }
        cache[st] = img
        return img
    }
}

/// Hiệu ứng mùa (hoa, tuyết đứng yên/rơi ở bản xem trước) chưa có: danh sách rỗng.
extension DecorPattern {
    var isSeasonal: Bool { DecorPattern.festive.contains(self) }
    static var geometric: [DecorPattern] { allCases.filter { !festive.contains($0) } }
    static var seasonal: [DecorPattern] { festive }
}

enum SeasonArt {
    static func fallSprites(_ p: DecorPattern) -> [UIImage] { [] }
}

struct SeasonFallView: View {
    let patterns: [DecorPattern]
    var body: some View { Color.clear.allowsHitTesting(false) }
}
