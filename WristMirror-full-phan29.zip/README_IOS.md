
## Vùng chạm và font riêng từng mục (phần 28)

- `Store/FaceTap.swift`: hành động chạm (`TapAction`), font riêng (`FaceDesign.textFace/numberFace`), tính vùng chạm (`FaceRenderer.tapZones`).
- `HwtBuilder.layoutBytes` ghi thêm phần tử số 3 chứa các vùng chạm `{1: số thứ tự, 2: 0, 5: {x, y, rộng, cao}, 8: mã hành động}` (cấu trúc đọc từ Kozmik Sporcu / BetaFinal).
- Mã hành động đối chiếu với ảnh xem trước: 10 bước chân, 11 nhịp tim, 12 calo, 17 pin, 21 thời tiết, 24 quãng đường, 25 giấc ngủ, 16 căng thẳng; 9 (mặt trời mọc/lặn) chưa kiểm chứng.
- `Views/ElementStyleView.swift`: chọn font, cỡ chữ (pt) và hành động chạm cho từng mục, nằm trong `InfoSettingsView`.
- Chưa biên dịch/thử trên thiết bị khi viết: cần chạy `TapZoneTests` và thử cài một mặt có vùng chạm lên đồng hồ thật.

### Phần 29

- Vùng chạm ở mép mặt đồng hồ (`TapEdge`: trên, trái, dưới, phải) chọn trong `ElementStyleView`, lưu ở `FaceDesign.edgeTaps`.
- "Thêm thông tin vào HWT" (`HwtLunarPatch.patchBin`) ghi vùng chạm vào file có sẵn nếu file chưa có phần tử số 3 (chèn trước các trường tiêu đề); file đã có phần tử số 3 thì giữ nguyên, không thêm.
